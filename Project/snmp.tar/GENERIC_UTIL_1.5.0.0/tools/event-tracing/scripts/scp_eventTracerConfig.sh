#!/usr/bin/bash

# The list of Application Log Directories
APPLICATION_LOG_FILE_PATHS=("/opt/product/rgopal/work/PLATFORM_1.0.0.0/scripts/")

APPLICATION_OUTPUT_FILE_NAME_PREFIXES=("ORCABLU1")




# The below should be changed only if required

# The time (in minutes) to be searched backward for a log file
BACKWARD_SEARCH_FILE_TIME=300
export BACKWARD_SEARCH_FILE_TIME

# The maximum time of a session (in minutes)
SESSION_MAXIMUM_TIME=30
export SESSION_MAXIMUM_TIME

# The Search Descriptions to be printed
SEARCH_DESCRIPTIONS="|Calling Party|Called Party|Location|Call Type|"
export SEARCH_DESCRIPTIONS

# The Search Keys which are present in the EVENT_TRACER: START log print of the application
SEARCH_KEYS="|CLGPARTY|CLDPARTY|LOCATION|CALLTYPE|"
export SEARCH_KEYS

