#include <time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

int tokenize(char *p_input, char *p_str, int p_size)
{
   char *l_ptr1, *l_ptr2;
   l_ptr1=l_ptr2=p_input;
   l_ptr2++;
   int l_i=1;
   while(*l_ptr2 != '\0')
   {
      if('|' == *l_ptr2)
      {
         if(l_ptr2-l_ptr1 == 1)
         {
            strncpy(p_str+(l_i*p_size),"0",1);
         }
         else
         {
            strncpy(p_str+(l_i*p_size),l_ptr1+1,l_ptr2-l_ptr1-1);
         }
         l_ptr1=l_ptr2;
         l_i++;
      }
      l_ptr2++;
   }
   return l_i-1;
}

void catch_sig_int(int p_sig_num)
{
   (void)signal(SIGINT,     catch_sig_int);
   printf("\n");
   return;
}

bool prepareData(char *p_output, char *p_fileName, char *p_key)
{ 
   p_output[0]='|';
   FILE *f1=NULL; 
   f1=fopen(p_fileName,"r"); 
   if(f1 != NULL)
   {
      char l_temp[100];
      memset(l_temp, '\0', sizeof(l_temp));
      char l_temp_char[5000];
      memset(l_temp_char, '\0', sizeof(l_temp_char));
      while(1)
      {
         if(fgets(l_temp_char,5000,f1) != NULL)
         {
            //printf("\nfgets output [%s]\n", l_temp_char);
            strcat(p_output, l_temp_char);
         }
         else
         {
            //printf("\nfgets some error\n");
            break;
         }
      }



      //if(fgets(p_output+1,250000,f1) != NULL)
      {  
        // printf("\nfgets success\n");
         char l_sessionIds[10000][30];
         int l_count=tokenize(p_output, (char*)l_sessionIds, 30);
         sprintf(p_output, "|");
         for(int i=1; i<=l_count; i++)
         {

           // printf("\nfor each session id: [%s]\n", l_sessionIds[i]);
            sprintf(l_temp, "%s:%s|", p_key, l_sessionIds[i]);
            strcat(p_output, l_temp);
         }
         return true;
      }
      /*
         else
         {
         printf("\nfgets failed");
         return false;
         }
         */
   }
   else
   {
      printf("\nError in opening the file");
      return false;
   }
}

int main(int argc, char *argv[])
{
   (void)signal(SIGINT,     catch_sig_int);


   char l_parameters_value[20][100];
   memset(l_parameters_value, '\0', sizeof(l_parameters_value));

   char l_parameters_descriptions[20][100];
   int  l_parameters_desc_count=0;
   memset(l_parameters_descriptions, '\0', sizeof(l_parameters_descriptions));
   char *l_temp=NULL;
   l_temp = getenv("SEARCH_DESCRIPTIONS");
   if(NULL == l_temp)
   {
      printf("\nSEARCH_DESCRIPTIONS not found\n");
      exit(1);
   }
   else
   {
      //printf("\nSEARCH_DESCRIPTIONS : [%s]", l_temp);

      l_parameters_desc_count=tokenize(l_temp, (char*)l_parameters_descriptions, 100);
   }

   char l_parameters_search[20][100];
   int  l_parameters_search_count=0;
   memset(l_parameters_search, '\0', sizeof(l_parameters_search));
   l_temp=NULL;
   l_temp = getenv("SEARCH_KEYS");
   if(NULL == l_temp)
   {
      printf("\nSEARCH_KEYS not found\n");
      exit(1);
   }
   else
   {
      //printf("\nSEARCH_KEYS : [%s]", l_temp);
      l_parameters_search_count=tokenize(l_temp, (char*)l_parameters_search, 100);
   }

   //printf("\n %d %d", l_parameters_desc_count, l_parameters_search_count);
   if(l_parameters_desc_count != l_parameters_search_count)
   {
      printf("\nError in counts %d %d\n", l_parameters_desc_count, l_parameters_search_count);
      exit(1);
   }

   if(l_parameters_desc_count < 1)
   {
      printf("\nNo parameters to search\n");
      exit(1);
   }


   char l_search_string[250000+1000];
   memset(l_search_string, '\0', sizeof(l_search_string));

   printf("\n\nSearch Inputs :\n");

   for(int l_i=1; l_i<=l_parameters_desc_count; l_i++)
   {
      printf("\n  Enter the %-30s    : ", l_parameters_descriptions[l_i]);
      scanf("%s", l_parameters_value[l_i]);

      if(strlen(l_parameters_value[l_i]) > 0)
      {
         char l_temp_file[100];
         memset(l_temp_file, '\0', sizeof(l_temp_file));
         strcpy(l_temp_file, l_parameters_value[l_i]);
         if(0 == strncmp(l_parameters_value[l_i], "file:", 5))
         {
            char c[500000]; 
            memset(c, '\0', sizeof(c));
            bool l_result = prepareData(c, &l_temp_file[5], l_parameters_search[l_i]);
            if(false == l_result)
            {
               printf("\nProblem in reading the file : [%s]", l_parameters_value[l_i]);
               return 1;
            }
            else
            {
            char t[500000];
            memset(t, '\0', sizeof(t));
            int j=0;
            for(int i=0; i<strlen(c); i++)
            {
               if('\n' != c[i])
               {
                  t[j] = c[i];
                  j++;
               }

            }
               printf("\nPrepared Data:  [%s]", t);
               strcat(l_search_string, t);
               strcat(l_search_string, " ");
            }
         }
         else
         {
            char l_temp[100];
            memset(l_temp, '\0', sizeof(l_temp));

            sprintf(l_temp, "%s:%s ", l_parameters_search[l_i], l_parameters_value[l_i]);
            strcat(l_search_string, l_temp);
         }
      }
   }

   printf("\nEnd of search inputs.\n\n");

   if(strlen(l_search_string) > 0)
   {
      //printf("\nlength of string [%d]", strlen(l_search_string));
      //printf("\n string [%s]", l_search_string);
      fwrite(l_search_string, strlen(l_search_string), 1, stderr);
      return 0;
   }
   else
   {
      return 1;
   }


}

