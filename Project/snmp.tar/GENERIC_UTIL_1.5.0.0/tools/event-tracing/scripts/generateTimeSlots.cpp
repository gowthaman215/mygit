#include <time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
   char l_ftime[30];
   char l_ttime[30];
   time_t from_t,to_t,diff_t;
   struct tm from_tm,to_tm;
   memset(l_ftime,'\0',sizeof(l_ftime));
   memset(l_ttime,'\0',sizeof(l_ttime));

   char l_timezone[10];
   memset(l_timezone, '\0', sizeof(l_timezone));
   time_t l_temp= time(NULL);
   struct tm * l_timezoneTm=NULL;
   l_timezoneTm=localtime(&l_temp);
   strftime (l_timezone,sizeof(l_timezone)-1,"%Z",l_timezoneTm);


   if (3 != argc)
   {
      printf("\nUsage: ./genTimeSlots <from-date(YYYY_MM_DD_HH_MM)> <to-date(YYYY_MM_DD_HH_MM)> \n\n");
      exit(1);
   }

   sprintf(l_ftime,"%s_%s", argv[1], l_timezone);
   sprintf(l_ttime,"%s_%s", argv[2], l_timezone);

   if(strptime(l_ftime,"%Y_%m_%d_%H_%M_%Z",&from_tm) == NULL)
   {
      printf("Error in From Date format. Should be yyyy_[01-12]_mm[00-11]_dd[01-31]_hh[00-23]_MM[00-59] \n");
      exit(2);
   }

   if(strptime(l_ttime,"%Y_%m_%d_%H_%M_%Z",&to_tm) == NULL)
   {
      printf("Error in To Date format. Should be yyyy_[01-12]_mm[00-11]_dd[01-31]_hh[00-23]_MM[00-59] \n");
      exit(3);
   }

   from_t=mktime(&from_tm);
   to_t=mktime(&to_tm);

   if(from_t > to_t)
   {
      printf("\nFrom Date is greater thatn To Date\n\n");
      exit(4);
   }

   for(diff_t=from_t;diff_t<=to_t;)
   {
      char l_time[30];
      struct tm * timeinfo=NULL;
      memset(l_time,'\0',sizeof(l_time));
      timeinfo=localtime(&diff_t);
      strftime (l_time,sizeof(l_time),"%Y_%m_%d_%H_%M",timeinfo);

      printf("%s\n",l_time);
      timeinfo=NULL;
      diff_t=diff_t+60;
   }
   return 0;
}

