#include <time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
   char l_ftime[30];
   time_t from_t,diff_t;
   struct tm from_tm;
   memset(l_ftime,'\0',sizeof(l_ftime));

   if (3 != argc)
   {
      printf("\nUsage: ./genTimeSlots <from-date(YYYY_MM_DD_HH_MM)> <minutes>\n\n");
      exit(1);
   }

   int l_minutes = atoi(argv[2]);
   if(l_minutes < -2000 || l_minutes > 2000)
   {
      printf("\nError in the minutes parameter [%d]\n", l_minutes);
      exit(2);
   }

   char l_timezone[10];
   memset(l_timezone, '\0', sizeof(l_timezone));
   time_t l_temp= time(NULL);
   struct tm * l_timezoneTm=NULL;
   l_timezoneTm=localtime(&l_temp);
   strftime (l_timezone,sizeof(l_timezone)-1,"%Z",l_timezoneTm);


   sprintf(l_ftime,"%s_%s", argv[1], l_timezone);

   if(strptime(l_ftime,"%Y_%m_%d_%H_%M_%Z",&from_tm) == NULL)
   {
      printf("\nError in From Date format. Should be yyyy_mm[01-12]_dd[01-31]_hh[00-23]_mi[00-59] \n");
      exit(2);
   }

   int l_multiplier=l_minutes/abs(l_minutes);

   from_t=mktime(&from_tm);
   if(-1 == l_multiplier)
   {
      diff_t=from_t;
   }
   else
   {
      diff_t=from_t+60;
   }
   for(int i=0; i<abs(l_minutes); i++)
   {
      char l_time[20];
      struct tm * timeinfo;
      memset(l_time,'\0',sizeof(l_time));
      timeinfo=localtime(&diff_t);
      strftime (l_time,sizeof(l_time),"%Y_%m_%d_%H_%M",timeinfo);
      printf("%s\n",l_time);
      timeinfo=NULL;
      diff_t=diff_t+ (60*l_multiplier);
   }
   return 0;
}

