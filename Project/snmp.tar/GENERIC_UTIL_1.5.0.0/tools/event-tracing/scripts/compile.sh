g++ generateTimeSlots.cpp -o genTimeSlots
g++ getNextMinuteSlots.cpp -o getNextMinSlots
g++ collectInputs.cpp -o getInputs
