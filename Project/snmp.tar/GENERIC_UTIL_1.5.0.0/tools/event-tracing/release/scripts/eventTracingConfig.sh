##########  This is the configuration file for the HLR TDR Processor Script  

SCRIPT_PATH=/export/home/sachi/CodeBase/GENERIC_UTIL_1.1.0.0/event-tracing/scripts/

# The path of the log file (Make sure this directory exists)
SCRIPT_LOG_FILE_PATH=/export/home/sachi/CodeBase/GENERIC_UTIL_1.1.0.0/event-tracing/scripts/log/

# The maximum size of the log file, which this script writes
SCRIPT_LOG_FILE_SIZE=100000                   

# The file prefix of the log file
SCRIPT_LOG_FILE_PREFIX=EVENT_PROCESSOR_LOG_

##########  End of Configurations


