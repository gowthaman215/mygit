#!/usr/bin/bash

##########  Description

#       The script takes the 

##########  End of Description


########## Script Functions begin

#######
###  This function log is used to log data into the log file
#######
log()
{
   g_logFileCheckCounter=`expr $g_logFileCheckCounter + 1`
   if [ $g_logFileCheckCounter -eq 10000 ]; then
      g_logFileCheckCounter=0
      fileSize=`ls -l $g_currentLogFileName | awk '{print $5}'`
      if [ $fileSize -gt $SCRIPT_LOG_FILE_SIZE ]; then
         g_currentLogFileName=$SCRIPT_LOGGING_PATH/$SCRIPT_LOG_FILE_PREFIX`echo $$_``date '+%Y_%m_%d_%H_%M_%S'`.log
      fi
   fi
   echo `date` $1 >> $g_currentLogFileName
}


trace()
{
   echo $1 >> $g_tracefile

}



########## Script Begins

SCRIPT_VERSION="1.1.0.0"
source eventTracingConfig.sh
SCRIPT_LOGGING_PATH=$SCRIPT_LOG_FILE_PATH/
#echo "path of logging is $SCRIPT_LOGGING_PATH"
#echo "prefix of logging is $SCRIPT_LOG_FILE_PREFIX"
g_currentLogFileName=$SCRIPT_LOGGING_PATH/$SCRIPT_LOG_FILE_PREFIX`echo $$_``date '+%Y_%m_%d_%H_%M_%S'`.log
g_logFileCheckCounter=0
l_date=`date '+%Y%d%m%H%M%S'`
l_trace_file=`echo "trace.out"`
g_tracefile=`echo "$SCRIPT_PATH/outputs/$l_date/$l_trace_file"`

log "`echo Initializing the Event Tracing Script v$SCRIPT_VERSION ...`"
if [ $# -eq 3 ]
then
  log "Called getInputs"
  source $1
  if [ $? -ne 0 ]
  then
     echo "Not a valid sourcing file: $1"
     exit 1
  fi
  mkdir $SCRIPT_PATH/outputs/$l_date
  touch $g_tracefile
  echo "Product file used for search   :   $1" >> $g_tracefile
  $SCRIPT_PATH/getInputs  2>$SCRIPT_PATH/outputs/$l_date/trace_search.out
  if [ $? -ne 0 ]
  then
     echo "Nothing to be captured"
     exit 1
  fi

  l_capture_data=`cat $SCRIPT_PATH/outputs/$l_date/trace_search.out`
  log "Capture data is $l_capture_data"
  l_even_tracer_string=`echo EVENT_TRACER: START $l_capture_data`

  l_from_date=$2
  echo "From Date                      :   $l_from_date" >> $g_tracefile
  l_to_date=$3
  echo "To Date                        :   $l_to_date" >> $g_tracefile
  l_app_log_path=${APPLICATION_LOG_FILE_PATHS[0]}
  echo "Application Log Path           :   $l_app_log_path" >> $g_tracefile
  cd $l_app_log_path

  echo 
  echo "Searching for files older than the ones which start with $l_from_date..."
  echo 
  echo 

  ## addding for getting old file
  l_old_hours=`$SCRIPT_PATH/getNextMinSlots $l_from_date -$BACKWARD_SEARCH_FILE_TIME`
  #log "Old Hours are  $l_old_hours"
  l_preferred_from_date=$l_from_date
  for l_current_old_hour in $l_old_hours
  do
     log "Searching old hour with $l_current_old_hour"
     for file in `ls  *_$l_current_old_hour*.log *_$l_current_old_hour*.log.gz 2>/dev/null`
     do
        log "Found an old hour file $file"
        l_preferred_from_date=$l_current_old_hour
        break 2
     done
  done

  log "Preferred From Date is $l_preferred_from_date . To Date is $l_to_date"
  ## end of addition

  l_search_hours=`$SCRIPT_PATH/genTimeSlots $l_preferred_from_date $l_to_date`
  if [ $? -ne 0 ]
  then
     log "Error in Date Formats"
     echo $l_search_hours
     exit 1
  fi
  log "Time slots are $l_search_hours"
  echo "Trace file                                    : outputs/$l_date/$l_trace_file"
  echo "Sessions file                                 : outputs/$l_date/trace_sessions.out"
  l_no_of_slots=`echo $l_search_hours | wc -w |  sed 's/^ *\(.*\) *$/\1/'`
  echo "Number of search minute slots                 : $l_no_of_slots"

  log "Getting Session Ids"
  touch $SCRIPT_PATH/outputs/$l_date/trace_sessions.out

  count=1
  l_pattern_1=" "
  l_pattern_2=" "
  l_pattern_3=" "
  l_pattern_4=" "
  l_pattern_5=" "
  for pattern in $l_capture_data
  do
     if [ $count -eq 1 ]; then
        l_pattern_1=$pattern
     elif [ $count -eq 2 ]; then
        l_pattern_2=$pattern
     elif [ $count -eq 3 ]; then
        l_pattern_3=$pattern
     elif [ $count -eq 4 ]; then
        l_pattern_4=$pattern
     elif [ $count -eq 5 ]; then
        l_pattern_5=$pattern
     fi
     ((count=count+1))
  done

  #echo "Pattern1 |$l_pattern_1|"
  #echo "Pattern2 |$l_pattern_2|"
  #echo "Pattern3 |$l_pattern_3|"
  #echo "Pattern4 |$l_pattern_4|"
  #echo "Pattern5 |$l_pattern_5|"

  log "Pattern1 is $l_pattern_1"
  log "Pattern2 is $l_pattern_2"


  echo "Pass 1 "
  for current_hour in $l_search_hours
  do
     echo -n "."
     for file in `ls  *_$current_hour*.log *_$current_hour*.log.gz 2>/dev/null`
     do
        l_file_name_length=${#file}
        ((l_file_name_length=l_file_name_length-4))
        log "File found is $file  ${file:$l_file_name_length:4}"

        l_file_name_ext=${file:$l_file_name_length:4}
        if [ $l_file_name_ext == ".log" ]
        then
           log "Searching a .log file"
           l_search_id=`grep "EVENT_TRACER: START" $file | egrep "$l_pattern_1" | grep "$l_pattern_2" | grep "$l_pattern_3" | grep "$l_pattern_4" | awk -F"|" '{printf("%s|",$3);}'`
        fi

        ((l_file_name_length=l_file_name_length-7))
        l_file_name_ext=${file:$l_file_name_length:7}
        if [ $l_file_name_ext == ".log.gz" ]
        then
           l_search_id=`gzgrep "EVENT_TRACER: START" $file | egrep "$l_pattern_1" | grep "$l_pattern_2" | grep "$l_pattern_3" | grep "$l_pattern_4" | awk -F"|" '{printf("%s|",$3);}'`
        fi

        echo $l_search_id >> $SCRIPT_PATH/outputs/$l_date/trace_sessions.out
        log "all session ids $l_search_id"
     done
  done
  log "Pass 1 is done"

  echo

  g_session_ids=`tr '\n' ' ' < $SCRIPT_PATH/outputs/$l_date/trace_sessions.out`
  log "Preparing for Pass 2.... Step 1"
  g_session_ids=`echo $g_session_ids | sed s/' '//g`
  log "all session ids are $g_session_ids"
  log "Preparing for Pass 2.... Step 2"

  l_temp=`echo $g_session_ids | sed s/'|'/' '/g`
  log "Preparing for Pass 2.... Step 3"
  l_no_of_sessions=`echo $l_temp | wc -w |  sed 's/^ *\(.*\) *$/\1/'`
  log "Preparing for Pass 2.... Step 4"

  if [ $l_no_of_sessions -lt 1 ]
  then
     echo "No Sessions Found."
     echo "No Sessions Found." > $g_tracefile
     echo "Exiting."
     exit 1
  fi
  echo "Number of sessions found                      : $l_no_of_sessions"

  echo "Number of sessions found       :   $l_no_of_sessions" >> $g_tracefile
  echo >> $g_tracefile
  log "Preparing for Pass 2.... Step 5"

  l_extended_search=`$SCRIPT_PATH/getNextMinSlots $l_to_date $SESSION_MAXIMUM_TIME`
  log "Preparing for Pass 2.... Step 6"

  l_pass2_search=`echo $l_search_hours $l_extended_search`
  log "Preparing for Pass 2.... Step 7"
  l_pass2_slots=`echo $l_pass2_search | wc -w |  sed 's/^ *\(.*\) *$/\1/'`
  echo "Number of search minute slots                 : $l_pass2_slots"


  echo "Pass 2 "
  for current_hour in $l_pass2_search
  do
    echo -n "."
    for file in `ls  *_$current_hour*.log *_$current_hour*.log.gz  2>/dev/null`
    do 
       log "Pass2 File found is $file"
       l_file_name_length=${#file}
        ((l_file_name_length=l_file_name_length-4))
       l_file_name_ext=${file:$l_file_name_length:4}
       if [ $l_file_name_ext == ".log" ]
       then
          egrep "$g_session_ids" $file >> $SCRIPT_PATH/outputs/$l_date/trace_temp.out
       fi
       ((l_file_name_length=l_file_name_length-7))
       l_file_name_ext=${file:$l_file_name_length:7}
       if [ $l_file_name_ext == ".log.gz" ]
       then
          gzegrep "$g_session_ids" $file >> $SCRIPT_PATH/outputs/$l_date/trace_temp.out
       fi
    done
  done
  echo

  sed '/^\s*$/d' $SCRIPT_PATH/outputs/$l_date/trace_sessions.out > test.tmp
  cat test.tmp > $SCRIPT_PATH/outputs/$l_date/trace_sessions.out
  rm test.tmp


  l_curr_sess_count=0
  echo "Pass 3 "
  for current_session in $l_temp
  do
     ((l_curr_sess_count=l_curr_sess_count+1))
     echo -n "."
     echo >> $g_tracefile
     echo >> $g_tracefile
     echo "Session: ($l_curr_sess_count).. $current_session" >> $g_tracefile
     echo "====================================" >> $g_tracefile
     grep $current_session $SCRIPT_PATH/outputs/$l_date/trace_temp.out >> $g_tracefile
  done

  echo
  echo "End"

else
  log "wrong usage"
  echo "Only $# arguments seen"
  echo
  echo "Usage: ./eventTracer.sh <respective product env file> <from-date(YYYY_MM_DD_HH_MM)> <to-date(YYYY_MM_DD_HH_MM)>"
  echo
  exit 1
fi


########## Script Ends



