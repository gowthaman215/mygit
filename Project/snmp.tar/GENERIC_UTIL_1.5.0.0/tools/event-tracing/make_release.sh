cp -p ./scripts/eventTracer.sh                ./release/scripts/
cp -p ./scripts/eventTracingConfig.sh         ./release/scripts/
cp -p ./scripts/genTimeSlots                  ./release/scripts/
cp -p ./scripts/getNextMinSlots               ./release/scripts/
cp -p ./scripts/getInputs                     ./release/scripts/
tar -cvf event_tracing_release.tar            ./release/
gzip event_tracing_release.tar
