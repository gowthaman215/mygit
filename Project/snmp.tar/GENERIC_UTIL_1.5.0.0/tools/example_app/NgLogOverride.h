#ifndef __NG_LOG_OVERRIDE_H
#define __NG_LOG_OVERRIDE_H

#include <LogOverride.h>

class NgLogOverride : public LogOverride
{
   public:
      bool override(char p_logLevel, char *p_data);
};

extern NgLogOverride *g_nlo;

#endif

