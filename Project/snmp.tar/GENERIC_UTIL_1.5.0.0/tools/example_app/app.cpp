#include <stdio.h>
#include <GenUtils.h>
#include <StatisticsGenerator.h>
#include <StatisticsInitializationHelper.h>
#include <GUtilThreadHeartBeat.h>
#include <NgLogOverride.h>
#include <SnmpInterface.h>
#include <list>

int l_columnA;
int l_columnB;
int l_columnC;
int l_columnD;
int l_columnE;
int l_numberOfNetworks=1;

class HLRStatisticsInitializer : public StatisticsInitializationHelper
{
   public:

      bool applicationInitializationCallback(StatisticsGenerator *p_sg);
      static HLRStatisticsInitializer *HLRStatisticsInitializer::instance()
      {
         if(NULL == m_ds)
         {
            m_ds = new HLRStatisticsInitializer;
            g_sih = m_ds;
            return m_ds;
         }
         else
         {
            return m_ds;
         }
      };

   private:
      static HLRStatisticsInitializer* m_ds;
      HLRStatisticsInitializer();
      ~HLRStatisticsInitializer();
};
HLRStatisticsInitializer* HLRStatisticsInitializer::m_ds=NULL;


HLRStatisticsInitializer::HLRStatisticsInitializer()
{
   printf("\nHLRStatisticsInitializer :cons:");
   m_ds=NULL;
}

HLRStatisticsInitializer::~HLRStatisticsInitializer()
{
   printf("\nHLRStatisticsInitializer :des:");
}

bool HLRStatisticsInitializer::applicationInitializationCallback(StatisticsGenerator *p_sg)
{
   printf("\nHLRStatisticsInitializer applicationInitializationCallback called");

   p_sg->setApplicationName("HLR");
   p_sg->setApplicationVersion("1.0.12.0 Rev0");
   l_columnA = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"updateLocation", "v1Total", '0');
   if(0 == l_columnA)
   {
      printf("\ncolumnA adding failed");
   }
   l_columnB = p_sg->addHeader(PEG_TYPE_VALUE,"valuecounter", "", '0');
   if(0 == l_columnB)
   {
      printf("\ncolumnB adding failed");
   }


   MultiDimensionalData l_mdd;
   l_mdd.m_numOfColumns = 2;
   l_mdd.m_header1 = "Network";
   l_mdd.m_header2 = "Tariff";

   HeaderData l_hd;

   l_hd.m_h1 = "1";
   l_hd.m_h2 = "Bucketed";
   l_mdd.m_hd.push_back(l_hd);
   l_hd.m_h1 = "1";
   l_hd.m_h2 = "Non-Bucketed";
   l_mdd.m_hd.push_back(l_hd);
   l_hd.m_h1 = "2";
   l_hd.m_h2 = "Bucketed";
   l_mdd.m_hd.push_back(l_hd);
   l_hd.m_h1 = "2";
   l_hd.m_h2 = "Non-Bucketed";
   l_mdd.m_hd.push_back(l_hd);
   l_hd.m_h1 = "3";
   l_hd.m_h2 = "Bucketed";
   l_mdd.m_hd.push_back(l_hd);
   l_hd.m_h1 = "3";
   l_hd.m_h2 = "Non-Bucketed";
   l_mdd.m_hd.push_back(l_hd);
   l_hd.m_h1 = "3";
   l_hd.m_h2 = "Testing";
   l_mdd.m_hd.push_back(l_hd);


   l_columnC = p_sg->addHeader(PEG_TYPE_4D_INCREMENT_COUNTER,"columnC", "v1Total", '0', &l_mdd);
   if(0 == l_columnC)
   {
      printf("\ncolumnC adding failed");
   }

   MultiDimensionalData l_mdd2;
   l_mdd2.m_numOfColumns = 1;
   l_mdd2.m_header1 = "Network";
   HeaderData l_hd1;
   for(int l_n=1; l_n<=l_numberOfNetworks; l_n++)
   {
      char l_temp[10+1];
      snprintf(l_temp, sizeof(l_temp), "%d", l_n);
      l_hd1.m_h1 = l_temp;
      l_mdd2.m_hd.push_back(l_hd1);
   }

   l_columnD = p_sg->addHeader(PEG_TYPE_4D_INCREMENT_COUNTER,"columnD", "v1Total", '0', &l_mdd2);
   if(0 == l_columnD)
   {
      printf("\ncolumnD adding failed");
   }
   /*
      l_columnE = p_sg->addHeader("columnE", "v1Total", '0');
      if(0 == l_columnE)
      {
      printf("\ncolumnE adding failed");
      }
      l_columnD = p_sg->addHeader(PEG_TYPE_INCREMENT_COUNTER,"columnD", "v1Total", '0');
      if(0 == l_columnD)
      {
      printf("\ncolumnD adding failed");
      }
      */
   return true;
}



int main()
{
   g_nlo = new NgLogOverride;
   bool l_status;
   int l_trap1;
   int l_trap2;
   int l_trap3;
#if 1
   l_status = g_si.initialize("TEST", "192.168.151.74", 1500, g_nlo, 1, 5, "HLR");
   if (!l_status)
   {
      printf("\nERROR!! Unable to initialize the SnmpInterface");
      exit(504);
   }
   l_trap1 = g_si.registerSnmpTrap("TRAP1", "Trap1 Desc",1);
   l_trap2 = g_si.registerSnmpTrap("TRAP2", "Trap2 Desc",2);
   l_trap3 = g_si.registerSnmpTrap("TRAP3", "Trap2 Desc",1);
   g_si.sendSnmpTrap(l_trap1, TRAP_TYPE_PASS, TRAP_SEVERITY_CRITICAL);
   g_si.sendSnmpTrap(l_trap2, TRAP_TYPE_PASS, TRAP_SEVERITY_CRITICAL);
#endif
   HLRStatisticsInitializer::instance()->initializeStatistics("./stats/", "TEST");

   g_thb.initialize(THREAD_HANGED_ACTION_DO_NOTHING);

   HLRStatisticsInitializer::instance()->logStatistics(l_columnA);
   HLRStatisticsInitializer::instance()->logStatistics(l_columnB, 3443);
   HLRStatisticsInitializer::instance()->logStatistics(l_columnC, 6);
   HLRStatisticsInitializer::instance()->logStatistics(l_columnC, 7);
   HLRStatisticsInitializer::instance()->logStatistics(l_columnC, 5);
   HLRStatisticsInitializer::instance()->logStatistics(l_columnC, 8);
   HLRStatisticsInitializer::instance()->logStatistics(l_columnC, 1);
   HLRStatisticsInitializer::instance()->logStatistics(l_columnC, -5);
   /*
      HLRStatisticsInitializer::instance()->logStatistics(l_columnD);
      HLRStatisticsInitializer::instance()->logStatistics(l_columnD);
      HLRStatisticsInitializer::instance()->logStatistics(l_columnE);
      */
   g_si.sendSnmpTrap(l_trap1, TRAP_TYPE_PASS, TRAP_SEVERITY_CRITICAL);

   g_thb.registerMe(60, "MYMAIN");
   int l_i=0;
   int l_k=0;
   do
   {
      l_k++;
      if(l_k%10 == 0)
      {
         l_numberOfNetworks++;
         HLRStatisticsInitializer::instance()->reInitializeStatistics();
      }
      sleep(1);
      g_si.sendSnmpTrap(l_trap1, TRAP_TYPE_PASS, TRAP_SEVERITY_CRITICAL);
      ParameterData l_hd;
      l_hd.m_p1 = "1";
      l_hd.m_p2 = "Bucketed";
      HLRStatisticsInitializer::instance()->logStatistics(l_columnC, 0, &l_hd);
      l_i++;
      if(l_i%2 ==0)
      {
         ParameterData l_hd;
         l_hd.m_p1 = "3";
         l_hd.m_p2 = "Testing";
         HLRStatisticsInitializer::instance()->logStatistics(l_columnC, 0, &l_hd);
      }
      if(l_i%3 ==0)
      {
         ParameterData l_hd;
         l_hd.m_p1 = "4";
         l_hd.m_p2 = "Testing";
         HLRStatisticsInitializer::instance()->logStatistics(l_columnC, 0, &l_hd);

         printf("\nLogging columnD\n");
         ParameterData l_hd1;
         l_hd1.m_p1 = "5";
         HLRStatisticsInitializer::instance()->logStatistics(l_columnD, 0, &l_hd1);
      }
      //g_thb.iAmAlive();
   }
   while(1);
   return 0;

}



