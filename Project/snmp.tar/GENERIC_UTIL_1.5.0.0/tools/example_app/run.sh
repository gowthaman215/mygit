export LD_LIBRARY_PATH=../..//gen-util/lib/:/usr/sfw/lib/64/
