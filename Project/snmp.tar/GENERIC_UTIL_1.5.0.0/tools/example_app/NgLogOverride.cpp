#include <NgLogOverride.h>
#include <string.h>
#include <stdio.h>

NgLogOverride *g_nlo;

bool NgLogOverride::override(char p_logLevel, char *p_data)
{
   if('\n' == p_data[ strlen(p_data) -1])
   {
      p_data[strlen(p_data) -1] = '\0';
   }
   if(strstr(p_data, "Unable connect to SNMP Agent"))
   {
      return true;
   }
   switch(p_logLevel)
   {
      case 'D':
         printf("\nD|%s",p_data);
         break;
      case 'E':
         printf("\nE|%s",p_data);
         break;
      case 'T':
         printf("\nT|%s",p_data);
         break;
      case 'W':
         printf("\nW|%s",p_data);
         break;
      case 'C':
         printf("\nC|%s",p_data);
         break;
      case 'L':
         printf("\nL|%s",p_data);
         break;
      default:
         printf("\nunable to log: %s", p_data);
         break;
   }
   return true;
}
