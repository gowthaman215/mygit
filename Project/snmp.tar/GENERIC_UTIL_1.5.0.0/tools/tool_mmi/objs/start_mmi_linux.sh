export LD_LIBRARY_PATH=/home/sangeetha/SACHI/argtable2-12/ARGTABLE_INSTALL/lib/:/usr/sfw/lib/
./mmi.Linux
