/*********************************************************************

ValidateReload.cpp

 **********************************************************************/
#include <argtable2.h>
#include <regex.h>      /* REG_ICASE */
#include <strings.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <NgMmlMain.h>

extern char g_response[];

extern char g_globalSent[];

#define LPRINTF(...)  { memset(g_globalSent, '\0', 100); sprintf(g_globalSent, __VA_ARGS__); strcat(g_response, g_globalSent); }


/* mymain3 implements the actions for syntax 3 */
int mymain_5(const char *pattern, const char *p_file)
{
   if (strlen(pattern)==0)
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("Module name should be present");
      return -1;
   }

   if (strlen(p_file)==0)
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("File name should be present");
      return -1;
   }
   /*printf("syntax 3 matched OK:\n");
     printf("pattern1=\"%s\"\n", pattern);
     printf("pattern2=\"%s\"\n", pattern2);*/

   return 0;
}

int mymain_6(const char *pattern, const char *p_file="")
{
   if (strlen(pattern)==0)
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("Module name should be present");
      return -1;
   }


   return 0;
}



int parseReload(char *p_command);


int parseReload(char *p_command)
{

   int p_argc=0; 
   char **p_argv;

   //char str[] ="- This, a    sample string.";
   char * pch;
   pch = strtok (p_command," ");
   p_argv = (char**)malloc(1000);

   while (pch != NULL)
   {
      //printf ("-%s-\n",pch);
      p_argv[p_argc] = (char *) malloc(40);
      //printf("\n allocated\n");

      //p_argv[p_argc] = (char*)malloc(strlen(pch));
      strcpy(p_argv[p_argc], pch);
      p_argc++;

      pch = strtok (NULL, " ");
   }

   //printf("\n tokenizing done \n\n");
   /*
      int i=0;
      for (i=0; i<p_argc; i++)
      {
      printf("\n printing -%s-", p_argv[i]);
      }*/



   /* SYNTAX 5: reload start [-m <msisdn>] [-i <imsi>] */
   struct arg_rex  *cmd5      = arg_rex1(NULL,  NULL,  "library", NULL, REG_ICASE, NULL);
   struct arg_str  *pattern5_m = arg_str1("m", NULL, "<module>", "the module to be effected");
   struct arg_str  *pattern7_f = arg_str1("f", NULL, "<library-name>", "the name of the library file");
   struct arg_end  *end5     = arg_end(20);
   void* argtable5[] = {cmd5,pattern5_m,pattern7_f,end5};
   int nerrors5;

   /* SYNTAX 6: reload stop [-m <msisdn>] [-i <imsi>] */
   struct arg_rex  *cmd6      = arg_rex1(NULL,  NULL,  "configuration", NULL, REG_ICASE, NULL);
   struct arg_str  *pattern6_m = arg_str1("m", NULL, "<module>", "the module whose configuration to be reloaded");
   struct arg_end  *end6     = arg_end(20);
   void* argtable6[] = {cmd6,pattern6_m,end6};
   int nerrors6;

   /* SYNTAX 7: reload profiles */
   struct arg_rex  *cmd7      = arg_rex1(NULL,  NULL,  "profiles", NULL, REG_ICASE, NULL);
   struct arg_end  *end7     = arg_end(20);
   void* argtable7[] = {cmd7,end7};
   int nerrors7;


   /* SYNTAX 4: [--help] [-h] */
   struct arg_lit  *help4    = arg_lit1("h","help", "print this help and go back to command prompt");
   struct arg_end  *end4     = arg_end(20);
   void* argtable4[] = {help4,end4};
   int nerrors4;

   const char* progname = "reload";
   int exitcode=0;

   memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);

   /* verify all argtable[] entries were allocated sucessfully */
   if (arg_nullcheck(argtable5)!=0 ||
         arg_nullcheck(argtable6)!=0 ||
         arg_nullcheck(argtable7)!=0 ||
         arg_nullcheck(argtable4)!=0 )
   {
      /* NULL entries were detected, some allocations must have failed */
      LPRINTF("%s: insufficient memory\n",progname);
      exitcode=1;
   }


   FILE *l_fp = fopen("dummy.txt",  "w+");


   /* Above we defined a separate argtable for each possible command line syntax */
   /* and here we parse each one in turn to see if any of them are successful    */
   nerrors4 = arg_parse(p_argc,(char**)p_argv,argtable4);
   nerrors5 = arg_parse(p_argc,(char**)p_argv,argtable5);
   nerrors6 = arg_parse(p_argc,(char**)p_argv,argtable6);
   nerrors7 = arg_parse(p_argc,(char**)p_argv,argtable7);

   /* Execute the appropriate main<n> routine for the matching command line syntax */
   /* In this example program our alternate command line syntaxes are mutually     */
   /* exclusive, so we know in advance that only one of them can be successful.    */
   if (nerrors5==0)
      exitcode = mymain_5(pattern5_m->sval[0], pattern7_f->sval[0]);
   else if (nerrors6==0)
      exitcode = mymain_6(pattern6_m->sval[0]);
   else if (nerrors7==0)
      exitcode = 0;
   else
   {
      fprintf(l_fp, "\n%s: missing <library|configuration|profiles> command.\n",progname); 
      fprintf(l_fp, "\tusage 1: %s",  progname);  arg_print_syntax(l_fp,argtable4,"\n");
      fprintf(l_fp, "\tusage 2: %s",  progname);  arg_print_syntax(l_fp,argtable5,"\n");
      fprintf(l_fp, "\tusage 3: %s",  progname);  arg_print_syntax(l_fp,argtable6,"\n");
      fprintf(l_fp, "\tusage 4: %s",  progname);  arg_print_syntax(l_fp,argtable7,"\n\n\n");

      arg_print_glossary(l_fp,argtable4,"\t%s     %s\n");
      arg_print_glossary(l_fp,argtable5,"\t%s     %s\n");
      //arg_print_glossary(l_fp,argtable6,"\t%s     %s\n");
      arg_print_glossary(l_fp,argtable7,"\t%s     %s\n");

      fseek(l_fp, 0, SEEK_SET);
      char l_sent[200];
      memset(l_sent, '\0', 200);
      while (1)
      {
         if (NULL == fgets(l_sent, 200, l_fp))
         {
            break;
         }
         else
         {
            strcat(g_response, l_sent);
         }
      }
      fclose(l_fp);
      exitcode =-1;
   }

exit:
   /* deallocate each non-null entry in each argtable */
   arg_freetable(argtable4,sizeof(argtable4)/sizeof(argtable4[0]));
   arg_freetable(argtable5,sizeof(argtable5)/sizeof(argtable5[0]));
   arg_freetable(argtable6,sizeof(argtable6)/sizeof(argtable6[0]));
   arg_freetable(argtable7,sizeof(argtable6)/sizeof(argtable7[0]));

   return exitcode;
}
