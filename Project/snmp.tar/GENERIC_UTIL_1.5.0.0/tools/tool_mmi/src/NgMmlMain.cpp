#include <Logger.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <panel.h>
#include <menu.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <NgMmlMain.h>
#include <signal.h>


#define TC_UNI          1			/* indication/request	*/
#define TC_BEGIN        2			/* indication/request	*/
#define TC_CONTINUE     3			/* indication/request	*/
#define TC_END          4			/* indication/request	*/
#define TC_U_ABORT      5			/* indication/request	*/
#define TC_P_ABORT      6			/* indication		*/
#define TC_NOTICE       7			/* indication		*/
#define TC_INVOKE       8			/* indication/request	  */
#define TC_RESULT_L     9			/* indication/request	  */
#define TC_RESULT_NL    10			/* indication/request	  */
#define TC_U_ERROR      11			/* indication/request	  */
#define TC_L_CANCEL     12			/* indication		  */
#define TC_U_CANCEL     13			/* request		  */
#define TC_R_REJECT     14			/* indication		  */
#define TC_L_REJECT     15			/* indication		  */
#define TC_U_REJECT     16			/* indication/request	  */




char *getTcapPrimChar(int p_prim)
{
   switch (p_prim)
   {
      case TC_UNI:
         return "TC_UNI";
      case TC_BEGIN:
         return "TC_BEGIN";
      case TC_CONTINUE:
         return "TC_CONTINUE";
      case TC_END:
         return "TC_END";
      case TC_U_ABORT:
         return "TC_U_ABORT";
      case TC_P_ABORT:
         return "TC_P_ABORT";
      case TC_NOTICE:
         return "TC_NOTICE";
      case TC_INVOKE:
         return "TC_INVOKE";
      case TC_RESULT_L:
         return "TC_RESULT_L";
      case TC_RESULT_NL:
         return "TC_RESULT_NL";
      case TC_U_ERROR:
         return "TC_U_ERROR";
      case TC_L_CANCEL:
         return "TC_L_CANCEL";
      case TC_U_CANCEL:
         return "TC_U_CANCEL";
      case TC_R_REJECT:
         return "TC_R_REJECT";
      case TC_L_REJECT:
         return "TC_L_REJECT";
      case TC_U_REJECT:
         return "TC_U_REJECT";
      default:
         return "UNKNOWN";

   }
}


#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))
#define MAXDATASIZE 100 // max number of bytes we can get at once 
#define MAX_HISTORY_STORED 1000

char *choices[] = {
   "Conversations",
   "Operation Codes",
   "Application Contexts",
   (char *)NULL,
};

ITEM **g_menu_items;
MENU *g_menu;
WINDOW *g_menu_win;
extern int g_TotalFilesSelected;


char g_MapApplCtxtMappingChar[][50]=
{
   //////////////////////////////////////////////////////////////////////////////////////////////////////
   //                                                                          Appl Ctxt Name
   //////////////////////////////////////////////////////////////////////////////////////////////////////
   /* 00 */   /* MAP_AC_UNKNOWN=0 */                                           "ac_unknown",                             
   /* 01 */   /* MAP_AC_CODE_networkLocUp */                                   "networkLocUp",                                          
   /* 02 */   /* MAP_AC_CODE_locationCancel */                                 "locationCancel",                          
   /* 03 */   /* MAP_AC_CODE_roamingNbEnquiry */                               "roamingNbEnquiry",                        
   /* 04 */   /* MAP_AC_CODE_IST_Alerting */                                   "ISTAlerting",                            
   /* 05 */   /* MAP_AC_CODE_locInfoRetrieval */                               "locInfoRetrieval",                        
   /* 06 */   /* MAP_AC_CODE_callControlTransfer */                            "callControlTransfer",                     
   /* 07 */   /* MAP_AC_CODE_reporting */                                      "reporting",                               
   /* 08 */   /* MAP_AC_CODE_callCompletion */                                 "callCompletion",                          
   /* 09 */   /* MAP_AC_CODE_ServiceTermination */                             "ServiceTermination",                      
   /* 10 */   /* MAP_AC_CODE_reset */                                          "reset",                                   
   /* 11 */   /* MAP_AC_CODE_handoverControl */                                "handoverControl",                         
   /* 12 */   /* MAP_AC_CODE_sIWFSAllocation */                                "sIWFSAllocation",                         
   /* 13 */   /* MAP_AC_CODE_equipmentMngt */                                  "equipmentMngt",                           
   /* 14 */   /* MAP_AC_CODE_infoRetrieval */                                  "infoRetrieval",                           
   /* 15 */   /* MAP_AC_CODE_interVlrInfoRetrieval */                          "interVlrInfoRetr",                   
   /* 16 */   /* MAP_AC_CODE_subscriberDataMngt */                             "subscriberDataMngt",                      
   /* 17 */   /* MAP_AC_CODE_tracing */                                        "tracing",                                 
   /* 18 */   /* MAP_AC_CODE_networkFunctionalSs */                            "nwFunctionalSs",                     
   /* 19 */   /* MAP_AC_CODE_networkUnstructuredSs */                          "nwUnstructuredSs",                   
   /* 20 */   /* MAP_AC_CODE_shortMsgGateway */                                "shortMsgGateway",                         
   /* 21 */   /* MAP_AC_CODE_shortMsgMORelay */                                "shortMsgMORelay",                         
   /* 22 */   /* MAP_AC_CODE_subscriberDataModificationNotification */         "subsDataModifNotif",  
   /* 23 */   /* MAP_AC_CODE_shortMsgAlert */                                  "shortMsgAlert",                           
   /* 24 */   /* MAP_AC_CODE_mwdMngt */                                        "mwdMngt",                                 
   /* 25 */   /* MAP_AC_CODE_shortMsgMTRelay */                                "shortMsgMTRelay",                         
   /* 26 */   /* MAP_AC_CODE_imsiRetrieval */                                  "imsiRetrieval",                           
   /* 27 */   /* MAP_AC_CODE_msPurging */                                      "msPurging",                               
   /* 28 */   /* MAP_AC_CODE_subscriberInfoEnquiry */                          "subsInfoEnquiry",                   
   /* 29 */   /* MAP_AC_CODE_anyTimeEnquiry */                                 "anyTimeEnquiry",                          
   /* 30 */   /* MAP_AC_CODE_dummy_30 */                                       "dummy_30",                                
   /* 31 */   /* MAP_AC_CODE_groupCallControl */                               "groupCallControl",                        
   /* 32 */   /* MAP_AC_CODE_gprsLocationUpdate */                             "gprsLocationUpdate",                      
   /* 33 */   /* MAP_AC_CODE_gprsLocationInfoRetrieval */                      "gprsLocInfoRetr",               
   /* 34 */   /* MAP_AC_CODE_failureReport */                                  "failureReport",                           
   /* 35 */   /* MAP_AC_CODE_gprsNotify */                                     "gprsNotify",                              
   /* 36 */   /* MAP_AC_CODE_ssInvocationNotification */                       "ssInvocNotification",                
   /* 37 */   /* MAP_AC_CODE_locationSvcGateway */                             "locationSvcGateway",                      
   /* 38 */   /* MAP_AC_CODE_locationSvcEnquiry */                             "locationSvcEnquiry",                      
   /* 39 */   /* MAP_AC_CODE_authenticationFailureReport */                    "authFailureReport",             
   /* 40 */   /* MAP_AC_CODE_dummy_40 */                                       "dummy_40",                                
   /* 41 */   /* MAP_AC_CODE_shortMsgMT_Relay_VGCS */                          "shMsgMTRelayVGCS",                   
   /* 42 */   /* MAP_AC_CODE_mm_EventReporting */                              "mm_EventReporting",                       
   /* 43 */   /* MAP_AC_CODE_anyTimeInfoHandling */                            "anyTimeInfoHandling",                     
   /* 44 */   /* MAP_AC_CODE_resourceManagement */                             "resourceManagement",                      
   /* 45 */   /* MAP_AC_CODE_groupCallInfoRetrieval */                         "groupCallInfoRetr"                  
};

char g_MapOpCodeChar[][50]=                                                            
{                                                                                       
   ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   //                                                                                  OP Code Name
   ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   /* 00 */    /* MAP_OP_CODE_UNKNOWN=0 */                                             "UNKNOWN",                             
   /* 01 */    /* MAP_OP_CODE_dummy_1 */                                               "dummy_1",                          
   /* 02 */    /* MAP_OP_CODE_updateLocation */                                        "updateLocation",                   
   /* 03 */    /* MAP_OP_CODE_cancelLocation */                                        "cancelLocation",                   
   /* 04 */    /* MAP_OP_CODE_provideRoamingNumber */                                  "provideRoamingNum",             
   /* 05 */    /* MAP_OP_CODE_noteSubscriberDataModified */                            "noteSubsDataMod",       
   /* 06 */    /* MAP_OP_CODE_resumeCallHandling */                                    "resumeCallHandl",               
   /* 07 */    /* MAP_OP_CODE_insertSubscriberData */                                  "insertSubsData",             
   /* 08 */    /* MAP_OP_CODE_deleteSubscriberData */                                  "deleteSubsData",             
   /* 09 */    /* MAP_OP_CODE_sendParameters */                                        "sendParameters",                          
   /* 10 */    /* MAP_OP_CODE_registerSS */                                            "registerSS",                       
   /* 11 */    /* MAP_OP_CODE_eraseSS */                                               "eraseSS",                          
   /* 12 */    /* MAP_OP_CODE_activateSS */                                            "activateSS",                       
   /* 13 */    /* MAP_OP_CODE_deactivateSS */                                          "deactivateSS",                     
   /* 14 */    /* MAP_OP_CODE_interrogateSS */                                         "interrogateSS",                    
   /* 15 */    /* MAP_OP_CODE_authenticationFailureReport */                           "authFailureReport",      
   /* 16 */    /* MAP_OP_CODE_dummy_16 */                                              "dummy_16",                         
   /* 17 */    /* MAP_OP_CODE_registerPassword */                                      "registerPassword",                 
   /* 18 */    /* MAP_OP_CODE_getPassword */                                           "getPassword",                      
   /* 19 */    /* MAP_OP_CODE_dummy_19 */ /* Just trying to use */                     "dummy_19",                         
   /* 20 */    /* MAP_OP_CODE_releaseResources */                                      "releaseResources",                 
   /* 21 */    /* MAP_OP_CODE_mtForwardSMVGCS */                                       "mtForwardSMVGCS",                  
   /* 22 */    /* MAP_OP_CODE_sendRoutingInfo */                                       "sendRoutingInfo",                  
   /* 23 */    /* MAP_OP_CODE_updateGprsLocation */                                    "updateGprsLocation",               
   /* 24 */    /* MAP_OP_CODE_sendRoutingInfoForGprs */                                "sendRoutInfoForGprs",           
   /* 25 */    /* MAP_OP_CODE_failureReport */                                         "failureReport",                    
   /* 26 */    /* MAP_OP_CODE_noteMsPresentForGprs */                                  "noteMsPresForGprs",             
   /* 27 */    /* MAP_OP_CODE_dummy_27 */                                              "dummy_27",                         
   /* 28 */    /* MAP_OP_CODE_dummy_28 */                                              "dummy_28",                         
   /* 29 */    /* MAP_OP_CODE_sendEndSignal */                                         "sendEndSignal",                    
   /* 30 */    /* MAP_OP_CODE_dummy_30 */                                              "dummy_30",                         
   /* 31 */    /* MAP_OP_CODE_ProvideSIWFSNumber */                                    "ProvideSIWFSNumber",               
   /* 32 */    /* MAP_OP_CODE_SIWFSSignallingModify */                                 "SIWFSSignalModify",            
   /* 33 */    /* MAP_OP_CODE_processAccessSignalling */                               "processAccSignal",          
   /* 34 */    /* MAP_OP_CODE_forwardAccessSignalling */                               "forwardAccSignal",          
   /* 35 */    /* MAP_OP_CODE_dummy_35 */                                              "dummy_35",                         
   /* 36 */    /* MAP_OP_CODE_dummy_36 */                                              "dummy_36",                         
   /* 37 */    /* MAP_OP_CODE_reset */                                                 "reset",                            
   /* 38 */    /* MAP_OP_CODE_forwardCheckSSIndication */                              "fwdCheckSSIndic",         
   /* 39 */    /* MAP_OP_CODE_prepareGroupCall */                                      "prepareGroupCall",                 
   /* 40 */    /* MAP_OP_CODE_sendGroupCallEndSignal */                                "sendGroupCallEndSig",           
   /* 41 */    /* MAP_OP_CODE_processGroupCallSignalling */                            "processGroupCallSig",       
   /* 42 */    /* MAP_OP_CODE_forwardGroupCallSignalling */                            "forwardGroupCallSig",       
   /* 43 */    /* MAP_OP_CODE_checkIMEI */                                             "checkIMEI",                        
   /* 44 */    /* MAP_OP_CODE_mtForwardSM */                                           "mtForwardSM",                      
   /* 45 */    /* MAP_OP_CODE_sendRoutingInfoForSM */                                  "sendRoutInfoForSM",             
   /* 46 */    /* MAP_OP_CODE_moForwardSM */                                           "moForwardSM",                      
   /* 47 */    /* MAP_OP_CODE_reportSMDeliveryStatus */                                "reportSMDelivStat",           
   /* 48 */    /* MAP_OP_CODE_dummy_48 */                                              "dummy_48",                         
   /* 49 */    /* MAP_OP_CODE_dummy_49 */                                              "dummy_49",                         
   /* 50 */    /* MAP_OP_CODE_activateTraceMode */                                     "activateTraceMode",                
   /* 51 */    /* MAP_OP_CODE_deactivateTraceMode */                                   "deactivateTraceMode",              
   /* 52 */    /* MAP_OP_CODE_dummy_52 */                                              "dummy_52",                         
   /* 53 */    /* MAP_OP_CODE_dummy_53 */                                              "dummy_53",                         
   /* 54 */    /* MAP_OP_CODE_beginSubscriberActivity */                               "beginSubsActivity",          
   /* 55 */    /* MAP_OP_CODE_sendIdentification */                                    "sendIdentification",               
   /* 56 */    /* MAP_OP_CODE_sendAuthenticationInfo */                                "sendAuthInfo",           
   /* 57 */    /* MAP_OP_CODE_restoreData */                                           "restoreData",                      
   /* 58 */    /* MAP_OP_CODE_sendIMSI */                                              "sendIMSI",                         
   /* 59 */    /* MAP_OP_CODE_processUnstructuredSSRequest */                          "pUSSR",     
   /* 60 */    /* MAP_OP_CODE_unstructuredSSRequest */                                 "unstructuredSSReq",            
   /* 61 */    /* MAP_OP_CODE_unstructuredSSNotify */                                  "unstructuredSSNot",             
   /* 62 */    /* MAP_OP_CODE_anyTimeSubscriptionInterrogation */                      "anyTimeSubsInter", 
   /* 63 */    /* MAP_OP_CODE_informServiceCentre */                                   "informServiceCentre",              
   /* 64 */    /* MAP_OP_CODE_alertServiceCentre */                                    "alertServiceCentre",               
   /* 65 */    /* MAP_OP_CODE_anyTimeModification */                                   "anyTimeModification",              
   /* 66 */    /* MAP_OP_CODE_readyForSM */                                            "readyForSM",                       
   /* 67 */    /* MAP_OP_CODE_purgeMS */                                               "purgeMS",                          
   /* 68 */    /* MAP_OP_CODE_prepareHandover */                                       "prepareHandover",                  
   /* 69 */    /* MAP_OP_CODE_prepareSubsequentHandover */                             "prepareSubsHandover",        
   /* 70 */    /* MAP_OP_CODE_provideSubscriberInfo */                                 "provideSubsInfo",            
   /* 71 */    /* MAP_OP_CODE_anyTimeInterrogation */                                  "anyTimeInterrogat",             
   /* 72 */    /* MAP_OP_CODE_ssInvocationNotification */                              "ssInvocNotif",         
   /* 73 */    /* MAP_OP_CODE_setReportingState */                                     "setReportingState",                
   /* 74 */    /* MAP_OP_CODE_statusReport */                                          "statusReport",                     
   /* 75 */    /* MAP_OP_CODE_remoteUserFree */                                        "remoteUserFree",                   
   /* 76 */    /* MAP_OP_CODE_registerCCEntry */                                       "registerCCEntry",                  
   /* 77 */    /* MAP_OP_CODE_eraseCCEntry */                                          "eraseCCEntry",                     
   /* 78 */    /* MAP_OP_CODE_dummy_78 */                                              "dummy_78",                         
   /* 79 */    /* MAP_OP_CODE_dummy_79 */                                              "dummy_79",                         
   /* 80 */    /* MAP_OP_CODE_dummy_80 */                                              "dummy_80",                         
   /* 81 */    /* MAP_OP_CODE_dummy_81 */                                              "dummy_81",                         
   /* 82 */    /* MAP_OP_CODE_dummy_82 */                                              "dummy_82",                         
   /* 83 */    /* MAP_OP_CODE_provideSubscriberLocation */                             "provideSubsLoc",        
   /* 84 */    /* MAP_OP_CODE_sendGroupCallInfo */                                     "sendGroupCallInfo",                
   /* 85 */    /* MAP_OP_CODE_sendRoutingInfoForLCS */                                 "sendRoutInfoFLCS",            
   /* 86 */    /* MAP_OP_CODE_subscriberLocationReport */                              "subsLocReport",         
   /* 87 */    /* MAP_OP_CODE_istAlert */                                              "istAlert",                         
   /* 88 */    /* MAP_OP_CODE_istCommand */                                            "istCommand",                       
   /* 89 */    /* MAP_OP_CODE_noteMMEvent */                                           "noteMMEvent"                       
};  

char g_ErrorCodeChar[][100]=                                                            
{
   /* 00 */    "UNKNOWN",
   /* 01 */    "unknownSubscriber",
   /* 02 */    "dummy_2",
   /* 03 */    "unknownMSC",
   /* 04 */    "dummy_4",
   /* 05 */    "unidentifiedSub",
   /* 06 */    "noGroupCallNb",
   /* 07 */    "unknownEquipment",
   /* 08 */    "roamingNotAllowed",
   /* 09 */    "illegalSubscriber",
   /* 10 */    "bearerServNotProv",
   /* 11 */    "teleservNotProv",
   /* 12 */    "illegalEquipment",
   /* 13 */    "callBarred",
   /* 14 */    "forwardingViolation",
   /* 15 */    "CUG_Reject",
   /* 16 */    "illegalSS_Operation",
   /* 17 */    "ss_ErrorStatus",
   /* 18 */    "ssNotAvailable",
   /* 19 */    "ssSubscriptionViolation",
   /* 20 */    "ssIncompatibilityCause",
   /* 21 */    "facilityNotSup",
   /* 22 */    "unauthorizedLCSClient",
   /* 23 */    "dummy_23",
   /* 24 */    "dummy_24",
   /* 25 */    "noHandoverNumberAvailable",
   /* 26 */    "subsequentHandoverFailure",
   /* 27 */    "absentSubscriber",
   /* 28 */    "incompatibleTerminal",
   /* 29 */    "shortTermDenial",
   /* 30 */    "longTermDenial",
   /* 31 */    "subBusyForMT_SMS",
   /* 32 */    "smDeliveryFailureCause",
   /* 33 */    "absentSubscriberSM",
   /* 34 */    "systemFailure",
   /* 35 */    "dataMissing",
   /* 36 */    "unexpectedData",
   /* 37 */    "pwRegistrationFailureCause",
   /* 38 */    "negativePW_Check",
   /* 39 */    "noRoamingNb",
   /* 40 */    "tracingBufferFull",
   /* 41 */    "dummy_41",
   /* 42 */    "dummy_42",
   /* 43 */    "numberOfPW_AttemptsViolation",
   /* 44 */    "numberChanged",
   /* 45 */    "busySubscriber",
   /* 46 */    "noSubscriberReply",
   /* 47 */    "forwardingFailed",
   /* 48 */    "orNotAllowed",
   /* 49 */    "atiNotAllowed",
   /* 50 */    "unauthorizedRequestingNetwork",
   /* 51 */    "resourceLimitation",
   /* 52 */    "positionMethodFailure",
   /* 53 */    "unknownOrUnreachableLCSClient",
   /* 54 */    "dummy_54",
   /* 55 */    "dummy_55",
   /* 56 */    "dummy_56",
   /* 57 */    "dummy_57",
   /* 58 */    "dummy_58",
   /* 59 */    "dummy_59",
   /* 60 */    "atsiNotAllowed",
   /* 61 */    "atmNotAllowed",
   /* 62 */    "informationNotAvailable",
   /* 63 */    "dummy_63",
   /* 64 */    "dummy_64",
   /* 65 */    "dummy_65",
   /* 66 */    "dummy_66",
   /* 67 */    "dummy_67",
   /* 68 */    "dummy_68",
   /* 69 */    "dummy_69",
   /* 70 */    "dummy_70",
   /* 71 */    "unknownAlphabet",
   /* 72 */    "ussd_Busy",
   /* 73 */    "MAXIMUM"
};




int g_sockfd=-1;
bool g_statsRefreshFlag=false;
bool g_executeCommandFlag=true;
char g_historyArr[MAX_HISTORY_STORED][256];
char g_historyRes[MAX_HISTORY_STORED][256];
char g_historyTime[MAX_HISTORY_STORED][30];
int  g_historyInd=-1;
char g_response[MAX_OUTPUT_WINDOW_SIZE];
char g_outputWindowSpace[2*MAX_OUTPUT_WINDOW_SIZE];
char g_commandLineSpace[110];
char g_previousCommand[256];

extern int parseTrace(char *p_command);
extern int parseReload(char *p_command);
extern int parseModifyConf(char *p_command);
extern int parseStats(char *p_command);

int RecvAll(int &s, char *buf, unsigned long len);
void init_wins(WINDOW **wins, int n);
void win_show(WINDOW *win, char *label, int label_color);
void print_in_middle(WINDOW *win, int starty, int startx, int width, char *string, chtype color);

WINDOW *g_wins[3];

void myexit(int p)
{
   endwin();
   exit(1);
}




/* Put all the windows */
void init_wins(WINDOW **wins, int n)
{ 
   int x, y, i;
   char label[80];
   y = 2;
   x = 10;
   for(i = 0; i < n; ++i)
   { 
      switch (i)
      {
         case 0:
            wins[i] = newwin(6, 120, 2, 5);
            wattron(wins[i], A_UNDERLINE);
            mvwprintw(wins[i], 5, 1, "%s", "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t");
            wattroff(wins[i], A_UNDERLINE);
            break;
         case 1:
            wins[i] = newwin(80, 157, 8, 0);
            break;
         case 2:
            wins[i] = newwin(10, 40, 0, 105);
            break;
         default:
            break;
      }

   }
}
/* Show the window with a border and a label */
void win_show(WINDOW *win, char *label, int label_color)
{ int startx, starty, height, width;
   getbegyx(win, starty, startx);
   getmaxyx(win, height, width);
   box(win, 0, 0);
   mvwaddch(win, 2, 0, ACS_LTEE);
   mvwhline(win, 2, 1, ACS_HLINE, width - 2);
   mvwaddch(win, 2, width - 1, ACS_RTEE);
   print_in_middle(win, 1, 0, width, label, COLOR_PAIR(label_color));
}
void print_in_middle(WINDOW *win, int starty, int startx, int width, char *string, chtype color)
{ int length, x, y;
   float temp;
   if(win == NULL)
      win = stdscr;
   getyx(win, y, x);
   if(startx != 0)
      x = startx;
   if(starty != 0)
      y = starty;
   if(width == 0)
      width = 80;
   length = strlen(string);
   temp = (width - length)/ 2;
   x = startx + (int)temp;
   wattron(win, color);
   mvwprintw(win, y, x, "%s", string);
   wattroff(win, color);
   refresh();
}

void printWindow(WINDOW *win, int y, int x, char *string)
{
   attron(COLOR_PAIR(4));
   mvwprintw(win, y, x, string);
   attroff(COLOR_PAIR(4));
   update_panels();
}

void printOutputWindow(char *string)
{
   char *l_dateString = NULL;
   struct tm *tm_ptr=NULL;
   time_t l_tim =time(NULL);
   tm_ptr = localtime(&l_tim);
   l_dateString = asctime(tm_ptr);
   l_dateString[strlen(l_dateString)-1] = '\0';

   mvwprintw(g_wins[1], 1, 0, g_outputWindowSpace);
   mvwprintw(g_wins[1], 1, 0, l_dateString);

   wattron(g_wins[1], A_BOLD);
   mvwprintw(g_wins[1], 2, 0, g_outputWindowSpace);
   mvwprintw(g_wins[1], 2, 0, string);
   wattroff(g_wins[1], A_BOLD);
   update_panels();
}

void printConnStatus(char *string)
{
   printWindow(g_wins[0], 0, 2, g_commandLineSpace);
   wattron(g_wins[0], A_UNDERLINE);
   printWindow(g_wins[0], 0, 2, (char*)string);
   wattroff(g_wins[0], A_UNDERLINE);
}


// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
   if (sa->sa_family == AF_INET) {
      return &(((struct sockaddr_in*)sa)->sin_addr);
   }

   return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

void printCommands()
{
   memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
   sprintf(g_response, "\n\tList of commands\n");
   strcat(g_response, "\t________________\n");

   strcat(g_response, "\n\n\tCommands which execute locally");
   strcat(g_response, "\n\t\tclear\t\t- clears the output pane");
   strcat(g_response, "\n\t\thelp\t\t- shows this list");
   strcat(g_response, "\n\t\thistory\t\t- shows the history of commands executed in this session");
   strcat(g_response, "\n\t\texit\t\t- graceful exit of the tool");

   strcat(g_response, "\n\n\n\tCommands used for managing connection with the application");
   strcat(g_response, "\n\t\tconnect\t\t- create connection to the application using IP address and Port");
   strcat(g_response, "\n\t\tclose\t\t- closes an existing connection with the application");


   strcat(g_response, "\n\n\n\tCommands which would be sent to the application with an existing connection");
   strcat(g_response, "\n\t\tgetinfo\t\t- display the application info (modules, versions etc)");
   strcat(g_response, "\n\t\tgetmoduleinfo\t- display the application modules information");
   //strcat(g_response, "\n\t\tgetconf\t\t- display the existing configuration values");
   strcat(g_response, "\n\t\tmodifyconf\t- modify a configuration value (log-level, log-media, map-versions supported etc)");
   strcat(g_response, "\n\t\tstats\t\t- displays statistics for the current slot in the day ");
   strcat(g_response, "\n\t\ttrace\t\t- enabling or disabling tracing the logs of a subscriber through msisdn or imsi");
   strcat(g_response, "\n\t\treload\t\t- reload a module/ a module's configuration / profiles");
   //strcat(g_response, "\n\t\treload oamtransactions\t- reload non-processed oam transactions");
   strcat(g_response, "\n\t\tshutdown\t- initiate a graceful shutdown trigger to the application");
   strcat(g_response, "\n");


   strcat(g_response, "\n\n\tPress \"Ctrl+C\" to erase the contents of the command pane");
   strcat(g_response, "\n\n\tEnter \"/\" to execute the previous command");

   printOutputWindow(g_response);
}


void catch_sig(int sig_num)
{
   //printf("\nDon't do that\n");
   printWindow(g_wins[0], 2, 12, g_commandLineSpace);
   (void)signal(SIGINT, catch_sig);
   g_executeCommandFlag=false;
   g_statsRefreshFlag=false;
}

void catch_exit(int sig_num)
{
   DLOG(0,0,(char*)"exit signal received");
   endwin();
   printf("\nQuitted on user request signal %d\n\n", sig_num);
   exit(1);
}


struct reg_msg
{
   uid_t  m_uid;
   time_t m_time;
};


bool connectToApp(char *p_hostName, char *p_port, char *p_AppRegResp, char *p_ErrMsg)
{
   int numbytes;  
   char buf[MAXDATASIZE];
   struct addrinfo hints, *servinfo, *p;
   int rv;
   char s[INET6_ADDRSTRLEN];
   int l_sock;


   if ( (atoi(p_port) < 1024) ||
         (atoi(p_port) > 99999) )
   {
      sprintf(p_ErrMsg, "port should be between 1024 and 99999");
      return false;
   }

   memset(&hints, 0, sizeof hints);
   hints.ai_family = AF_UNSPEC;
   hints.ai_socktype = SOCK_STREAM;

   if ((rv = getaddrinfo(p_hostName, p_port, &hints, &servinfo)) != 0) 
   {
      sprintf(p_ErrMsg, "getaddrinfo: %s", gai_strerror(rv));
      return false;
   }

   // loop through all the results and connect to the first we can
   for(p = servinfo; p != NULL; p = p->ai_next) 
   {
      if ((l_sock = socket(p->ai_family, p->ai_socktype,
                  p->ai_protocol)) == -1) {
         sprintf(p_ErrMsg, "error in socket creation");
         continue;
      }

      if (connect(l_sock, p->ai_addr, p->ai_addrlen) == -1) 
      {
         close(l_sock);
         sprintf(p_ErrMsg, "connect: %s", strerror(errno));
         continue;
      }

      break;
   }

   if (p == NULL) 
   {
      sprintf(p_ErrMsg, "connect: %s", strerror(errno));
      return false;
   }

   inet_ntop(p->ai_family, get_in_addr((struct sockaddr *)p->ai_addr), s, sizeof s);
   //printf("\nConnection Succesfull.");

   freeaddrinfo(servinfo); // all done with this structure


   // Add code for sending system time

   char l_reg_msg[50];
   memset(l_reg_msg, '\0', sizeof(l_reg_msg));
   char l_reg_msg_length[10];
   memset(l_reg_msg_length, '\0', sizeof(l_reg_msg_length));

   sprintf(l_reg_msg, "%d:%d", getuid(), time(NULL));
   sprintf(l_reg_msg_length, "%09d", strlen(l_reg_msg));


   if (send(l_sock, l_reg_msg_length, 9, 0) == -1) 
   {
      sprintf(p_ErrMsg, "Unable to send the registration msg");
      close(l_sock);
      l_sock=-1;
      return false;
   }

   if (send(l_sock, l_reg_msg, strlen(l_reg_msg), 0) == -1) 
   {
      sprintf(p_ErrMsg, "Unable to send the registration msg");
      close(l_sock);
      l_sock=-1;
      return false;
   }

   char l_recv_reg_size[10];
   memset(l_recv_reg_size, '\0', 10);
   int l_bytes = RecvAll(l_sock, l_recv_reg_size, 9);
   if (l_bytes != 9)
   {
      sprintf(p_ErrMsg, "connection closed at reg length");
      close(l_sock);
      l_sock=-1;
      return false;
   }

   char l_recv_reg[100];
   memset(l_recv_reg, '\0', 100);
   l_bytes = RecvAll(l_sock, l_recv_reg, atoi(l_recv_reg_size));
   if (l_bytes != atoi(l_recv_reg_size))
   {
      sprintf(p_ErrMsg, "connection closed at reg");
      close(l_sock);
      l_sock=-1;
      return false;
   }

   g_sockfd = l_sock;
   strncpy(p_AppRegResp, l_recv_reg, strlen(l_recv_reg));
   return true;
}


void print_in_middle(WINDOW *win, int starty, int startx, int width, char *string, chtype color);



bool initializeMenu()
{
   /* Create items */
   int n_choices = (sizeof(choices) / sizeof(choices[0]));

   g_menu_items = (ITEM **)calloc(n_choices, sizeof(ITEM *));
   for(int i = 0; i < n_choices; ++i)
      g_menu_items[i] = new_item(choices[i], "");

   /* Crate menu */
   g_menu = new_menu((ITEM **)g_menu_items);

   /* Create the window to be associated with the menu */
   g_menu_win = newwin(6, 30, 1, 110);
   keypad(g_menu_win, TRUE);

   /* Set main window and sub window */
   set_menu_win(g_menu, g_menu_win);

   /* Set menu mark to the string " * " */
   set_menu_mark(g_menu, "> ");

   refresh();

   /* Post the menu */
   post_menu(g_menu);
   wrefresh(g_menu_win);

   int c;
   while((c = wgetch(g_menu_win)) != KEY_F(1))
   {  
      switch(c)
      {	
         case KEY_DOWN:
            menu_driver(g_menu, REQ_DOWN_ITEM);
            break;
         case KEY_UP:
            menu_driver(g_menu, REQ_UP_ITEM);
            break;
         case ' ':
            return false;
            break;
         case 10:	/* Enter */
            ITEM *cur_item = current_item(g_menu);
            move(LINES - 2, 0);
            clrtoeol();
            mvprintw(LINES - 2, 0, "You have chosen %d item with name %s and description %s", 
                  item_index(cur_item) + 1,  item_name(cur_item), 
                  item_description(cur_item));

            refresh();
            pos_menu_cursor(g_menu);
            break;
      }
      wrefresh(g_menu_win);
   }	
   return true;
}
bool validString(char const* p_string)
{
   char const validChars[] = "abcdefghijklmnopqrstuvwxyz"
                              "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                              "0123456789"
                              "./-_"
                              " ";
   return strspn(p_string, validChars) == strlen(p_string);
}


bool destroyMenu()
{
   char l_space100[101];
   memset(l_space100, '\0', 101);
   for (int i=0; i<100; i++)
   {
      strcat(l_space100, " ");
   }
   mvwprintw(g_menu_win, 0, 0, l_space100);
   mvwprintw(g_menu_win, 1, 10, l_space100);
   mvwprintw(g_menu_win, 2, 10, l_space100);
   mvwprintw(g_menu_win, 3, 10, l_space100);
   mvwprintw(g_menu_win, 4, 10, l_space100);
   wrefresh(g_menu_win);

   int n_choices = (sizeof(choices) / sizeof(choices[0]));
   /* Unpost and free all the memory taken up */
   unpost_menu(g_menu);
   free_menu(g_menu);
   for(int i = 0; i < n_choices; ++i)
      free_item(g_menu_items[i]);

   return true;
}



int g_emptyCommandCounter=0;


int main(int argc, char *argv[])
{


   bool l_status = g_LoggerObj.initialize(LOG_LEVEL_DEBUG, LOG_MEDIA_FILE, (char*)"./log/", (char*)"TOOL_", (char*)"./log/", 100000000, 0);
   if (!l_status)
   {
      printf("\nUnable to initialize Logger");
      exit(1);
   }

   DLOG(0,0,(char*)"Ng MML tool started");

   memset(g_previousCommand, '\0', 256);


   (void)signal(SIGINT, catch_sig);
   (void)signal(SIGTSTP, SIG_IGN);
   (void)signal(SIGABRT, SIG_IGN);
   (void)signal(SIGPIPE, SIG_IGN);
   (void)signal(SIGHUP, SIG_IGN);
   (void)signal(SIGTERM, SIG_IGN);
   (void)signal(SIGALRM, SIG_IGN);
   (void)signal(SIGUSR1, SIG_IGN);
   (void)signal(SIGUSR2, SIG_IGN);
   (void)signal(SIGPOLL, SIG_IGN);
   (void)signal(SIGSTOP, SIG_IGN);
   (void)signal(SIGTSTP, SIG_IGN);
   (void)signal(SIGTTOU, SIG_IGN);
   (void)signal(SIGTTIN, SIG_IGN);
   (void)signal(SIGVTALRM, SIG_IGN);
   (void)signal(SIGPROF, SIG_IGN);
   //(void)signal(SIGLOST, SIG_IGN);

   for (int i=0; i<MAX_HISTORY_STORED; i++)
   {
      memset(g_historyArr[i], '\0', 256);
      memset(g_historyRes[i], '\0', 256);
      memset(g_historyTime[i],'\0', 30);
   }

   PANEL *my_panels[3];
   PANEL *top;
   int ch;
   /* Initialize curses */
   initscr();
   start_color();
   cbreak();
   keypad(stdscr, TRUE);


   /* Initialize all the colors */
   init_pair(1, COLOR_RED, COLOR_BLACK);
   init_pair(2, COLOR_GREEN, COLOR_BLACK);
   init_pair(3, COLOR_BLUE, COLOR_BLACK);
   init_pair(4, COLOR_CYAN, COLOR_BLACK);
   init_wins(g_wins, 2);
   //wborder(g_wins[0], '|', '|', '-', '-', '-', '-', '-', '-');
   //wborder(g_wins[1], '|', '|', '-', '-', '-', '-', '-', '-');
   /* Attach a panel to each window */ /* Order is bottom up */
   my_panels[0] = new_panel(g_wins[0]); /* Push 0, order: stdscr-0 */
   my_panels[1] = new_panel(g_wins[1]); /* Push 1, order: stdscr-0-1 */
   /* Set up the user pointers to the next panel */
   set_panel_userptr(my_panels[0],(char*) my_panels[1]);
   set_panel_userptr(my_panels[1],(char*) my_panels[2]);
   set_panel_userptr(my_panels[2],(char*) my_panels[0]);




   /* Update the stacking order. 2nd panel will be on top */
   update_panels();

   DLOG(0,0,(char*)"Windows Initialized");




   memset(g_commandLineSpace, '\0', 110);
   for (int i=0; i<110; i++)
   {
      strcat(g_commandLineSpace, " ");
   }


   memset(g_outputWindowSpace, '\0', 2*MAX_OUTPUT_WINDOW_SIZE);
   for (int i=0; i<2*MAX_OUTPUT_WINDOW_SIZE; i++)
   {
      strcat(g_outputWindowSpace, " ");
   }


   // End of sending system time
   memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
   sprintf(g_response, "%c Copyrights Reserved PLINTRON 2015 (Linux v1)", 169);
   mvprintw(0, 90, g_response);

   printCommands();
   printConnStatus((char*)"NOT CONNECTED");

   DLOG(0,0,(char*)"Starting the while loop");

   char l_presentCommand[256];

   int l_retry=1;
   if(getenv("RETRY_TIMER") != NULL)
   {
      DLOG(0,0,(char*)"Found RETRY_TIMER in env");
      l_retry = atoi(getenv("RETRY_TIMER"));
      if (l_retry > 3600)
      {
         l_retry=3600;
      }
      if (l_retry < 1)
      {
         l_retry=1;
      }
   }

   //initializeMenu();

   while (1)
   {
      memset(l_presentCommand, '\0', 256);
      g_executeCommandFlag=true;

      //printWindow(g_wins[0], 0, 90, g_commandLineSpace);
      //wattron(g_wins[0], A_DIM);
      //printWindow(g_wins[0], 0, 90, (char*)"Press \"Ctrl+C\" to exit");
      //wattroff(g_wins[0], A_DIM);

      printWindow(g_wins[0], 1, 80, g_commandLineSpace);
      wattron(g_wins[0], A_DIM);
      printWindow(g_wins[0], 1, 80, (char*)"Enter \"help\" for the list of commands");
      wattroff(g_wins[0], A_DIM);

      printWindow(g_wins[0], 2, 3, g_commandLineSpace);
      wattron(g_wins[0], A_STANDOUT);
      printWindow(g_wins[0], 2, 3, (char*)"command>");
      wattroff(g_wins[0], A_STANDOUT);
      printWindow(g_wins[0], 3, 12, g_commandLineSpace);

      DLOG(0,0,(char*)"Windows are ready");

      char buf[6000+1], l_commandToBeSent[256];
      memset(buf, '\0', 256);
      bool l_avoidHistoryFlag=false;

      if (false == g_statsRefreshFlag)
      {
         wattron(g_wins[0], A_BOLD);
         wmove(g_wins[0], 2, 12);
         DLOG(0,0,(char*)"Ready for input");
         wgetnstr(g_wins[0], buf, 80);
         wattroff(g_wins[0], A_BOLD);

         // Trimming the buffer
         char l_trimmed_buf[256];
         memset(l_trimmed_buf, '\0', 256);
         bool l_foundFlag = false;
         for (int i=0, j=0; i<80; i++)
         {
            if ( (buf[i] != ' ') || (true == l_foundFlag) )
            {
               l_foundFlag = true;
               l_trimmed_buf[j++] = buf[i];
            }
         }
         for (int j=strlen(l_trimmed_buf)-1; j>=0; j--)
         {
            if (l_trimmed_buf[j] == ' ')
            {
               l_trimmed_buf[j] = '\0';
            }
            else
            {
               break;
            }
         }
         strcpy(buf, l_trimmed_buf);
         // End of Trimming the buffer
      }
      else
      {
         DLOG(0,0,(char*)"Not reading the input. g_statsRefreshFlag is true");
         wmove(g_wins[0], 2, 12);
         printWindow(g_wins[0], 2, 12, g_commandLineSpace);
         wattron(g_wins[0], A_DIM);
         memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
         sprintf(g_response, (char*)"%s    ... executing approximately every %d sec(s). Press \"Ctrl+C\" to stop", g_previousCommand, l_retry);
         printWindow(g_wins[0], 2, 12, g_response);
         wattroff(g_wins[0], A_DIM);
         refresh();

         //sleep(2);
         struct timeval tv;
         tv.tv_sec = l_retry;
         tv.tv_usec = 0;
         select( 0, (fd_set *)NULL, (fd_set *)NULL, (fd_set *)NULL, &tv );
         strcpy(buf, "/");
         g_statsRefreshFlag=false;
         l_avoidHistoryFlag=true;
      }

      if(0 == strcmp(buf, "/"))
      {
         strcpy(buf, g_previousCommand);
      }

      DLOG(0,0,(char*)"Command to be executed [%s]", buf);

      if (strlen(buf) ==0)
      {
         DLOG(0,0,"Empty Command");
         if (g_emptyCommandCounter++ == 100)
         {
            ELOG(0,0,"Expecting a corruption here!! Exiting");
            endwin();
            exit(1);
         }
      }

      // To check whether an existing connection is really existing
      if (g_sockfd > 0)
      {
         fd_set read_mask;
         FD_ZERO(&read_mask);    
         FD_SET(g_sockfd, &read_mask);  
         struct timeval tv;
         tv.tv_sec = 0;          
         tv.tv_usec = 5000;
         DLOG(0,0, "Checking to see if the connection is closed");
         int nfd = select(g_sockfd+1, &read_mask, (fd_set *)NULL, (fd_set *)NULL, (struct timeval *)&tv);/* will block */
         if (nfd > 0)
         {
            DLOG(0,0,"select breaked. assuming connection closed");
            close(g_sockfd);
            g_sockfd=-1;
            printConnStatus((char*)"NOT CONNECTED");
            printOutputWindow((char*)"connection broken");
         }
      }
      // End of checking the connection

      memset(l_commandToBeSent, '\0', 256);
      strcpy(l_commandToBeSent, buf);
      strcpy(g_previousCommand, l_commandToBeSent);

      char *l_dateString=NULL;
      struct tm *tm_ptr=NULL;
      time_t l_tim =time(NULL);
      tm_ptr = localtime(&l_tim);
      l_dateString = asctime(tm_ptr);
      l_dateString[strlen(l_dateString)-1] = '\0';

      if ( (strlen(buf) > 0) && (false == l_avoidHistoryFlag))
      {
         g_historyInd++;
         if (g_historyInd == MAX_HISTORY_STORED)
         {
            g_historyInd=0;
         }
         strcpy(g_historyArr[g_historyInd], buf);
         memset(g_historyRes[g_historyInd], '\0', 256);
         memset(g_historyTime[g_historyInd],'\0', 30);
         strcpy(g_historyTime[g_historyInd], l_dateString);
      }

      int l_length = strlen(buf);

      if (false == g_executeCommandFlag)
      {
         DLOG(0,0,(char*)"g_executeCommandFlag is false. Not executing. Continuing");
         continue;
      }


      char l_temp[200+1];
      memset(l_temp, '\0', sizeof(l_temp));
      strncpy(l_temp, buf, 200);


      if (l_length >= 1)
      {
         printWindow(g_wins[0], 4, 2, g_commandLineSpace);
         int l_validCommand =-2;

         // Validate Command
         if(false == validString(l_temp))
         {
            memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
            sprintf(g_response, "Invalid symbols found in the command");
         }
         else if (strncmp(buf, "trace", 5) == 0)
         {
            DLOG(0,0,(char*)"trace command. parsing");
            l_validCommand = parseTrace(l_temp);
         }
         else if (strncmp(buf, "reload", 6) == 0)
         {
            DLOG(0,0,(char*)"reload command. parsing");
            l_validCommand = parseReload(l_temp);
         }
         else if (strncmp(buf, "reload profiles", strlen("reload profiles")) == 0)
         {
            DLOG(0,0,(char*)"reload profiles command");
            l_validCommand = 0;
         }
         else if (strncmp(buf, "reload configurations", strlen("reload configurations")) == 0)
         {
            DLOG(0,0,(char*)"reload configurations command");
            l_validCommand = 0;
         }
         else if (strncmp(buf, "reload module", strlen("reload module")) == 0)
         {
            DLOG(0,0,(char*)"reload module command");
            l_validCommand = 0;
         }
         else if (strncmp(buf, "reload oamtransactions", strlen("reload oamtransactions")) == 0)
         {
            DLOG(0,0,(char*)"reload oamtransactions command");
            l_validCommand = 0;
         }
         else if (strncmp(buf, "shutdown", 8) == 0)
         {
            DLOG(0,0,(char*)"shutdown command");
            //printOutputWindow((char*)"shutdown: not implemented yet");
            l_validCommand = 0;
         }
         else if (strncmp(buf, "modifyconf", 9) == 0)
         {
            DLOG(0,0,(char*)"modifyconf command");
            l_validCommand = parseModifyConf(l_temp);
         }
         /*else if (strcmp(buf, "getconf") == 0)
           {
           DLOG(0,0,(char*)"getconf command");
           printOutputWindow((char*)"getconf: not implemented yet");
           l_validCommand = -3;
           }*/
         else if (strcmp(buf, "quit") == 0)
         {
            DLOG(0,0,(char*)"quit command");
            endwin();
            printf("\nQuitted on user request\n\n");
            exit(1);
         }
         else if (strcmp(buf, "exit") == 0)
         {
            DLOG(0,0,(char*)"exit command");
            endwin();
            printf("\nQuitted on user request\n\n");
            exit(1);
         }
         else if (strncmp(buf, "getinfo", 7) == 0)
         {
            DLOG(0,0,(char*)"getinfo command");
            //printOutputWindow((char*)"getinfo: not implemented yet");
            l_validCommand = 0;
         }
         else if (strncmp(buf, "simulate", 8) == 0)
         {
            DLOG(0,0,(char*)"simulate command");
            //printOutputWindow((char*)"getinfo: not implemented yet");
            l_validCommand = 0;
         }
         else if (strncmp(buf, "quantify start", strlen("quantify start")) == 0)
         {
            DLOG(0,0,(char*)"quantify start");
            //printOutputWindow((char*)"getinfo: not implemented yet");
            l_validCommand = 0;
         }
         else if (strncmp(buf, "quantify stop", strlen("quantify stop")) == 0)
         {
            DLOG(0,0,(char*)"quantify start");
            //printOutputWindow((char*)"getinfo: not implemented yet");
            l_validCommand = 0;
         }
         else if (strncmp(buf, "getmoduleinfo", 13) == 0)
         {
            DLOG(0,0,(char*)"getmoduleinfo command");
            //printOutputWindow((char*)"getinfo: not implemented yet");
            l_validCommand = 0;
         }
         else if (strncmp(buf, "resources", 9) == 0)
         {
            DLOG(0,0,(char*)"resources command");
            //printOutputWindow((char*)"getinfo: not implemented yet");
            l_validCommand = 0;

            if (0 == l_validCommand)
            {
               if(strstr(buf, "-r"))
               {
                  DLOG(0,0,(char*)"resources command has the -r option. So setting the statsRefreshFlag to true");
                  g_statsRefreshFlag=true;
               }
            }

         }
         else if (strncmp(buf, "stats", 5) == 0)
         {
            DLOG(0,0,(char*)"stats command");
            l_validCommand = 0;
            l_validCommand = parseStats(l_temp);

            if (0 == l_validCommand)
            {
               if(strstr(buf, "-r"))
               {
                  DLOG(0,0,(char*)"stats command has the -r option. So setting the statsRefreshFlag to true");
                  g_statsRefreshFlag=true;
               }
            }

         }

         // End of Validation

         if (0 == l_validCommand)
         {
            DLOG(0,0,(char*)"Command Valid");
            if (-1 == g_sockfd)
            {
               printOutputWindow((char*)"\nNo existing connection with the application.\n\nUse \"connect\" command to create a connection");
               DLOG(0,0,(char*)"No existing connection with the application. Command not executed. Continuing");
               g_statsRefreshFlag=false;
               continue;
            }
            printWindow(g_wins[0], 4, 2, g_commandLineSpace);
            printWindow(g_wins[0], 4, 2, (char*) "Sending command");
            printOutputWindow((char*)"Waiting for response ...");

            char l_lengthChar[10];
            memset(l_lengthChar, '\0', 10);
            sprintf(l_lengthChar, "%09d", l_length);



            if (send(g_sockfd, l_lengthChar, 9, 0) == -1) 
            {
               CLOG(0,0,(char*)"send failed at length. closing connection. continuing.");               
               close(g_sockfd);
               g_sockfd=-1;
               printConnStatus((char*)"NOT CONNECTED");
               printOutputWindow((char*)"send failed. connection closed");
               continue;
            }
            TLOG(0,0,(char*)"Command Length [%s] sent", l_lengthChar);


            if (send(g_sockfd, buf, strlen(buf), 0) == -1) 
            {
               CLOG(0,0,(char*)"send failed. closing connection. continuing.");               
               close(g_sockfd);
               g_sockfd=-1;
               printConnStatus((char*)"NOT CONNECTED");
               printOutputWindow((char*)"send failed. connection closed");
               continue;
            }
            TLOG(0,0,(char*)"Command Buf [%s] sent", buf);


            char l_commandSent[1000];
            memset(l_commandSent, '\0', 1000);
            sprintf(l_commandSent, "%s   Command [%s] Sent.", l_dateString, buf);
            printWindow(g_wins[0], 4, 2, g_commandLineSpace);
            printWindow(g_wins[0], 4, 2, l_commandSent);

            printOutputWindow((char*)"Waiting for response ...");
            //update_panels();

            TLOG(0,0,(char*)"Receiving  response");

            memset(buf, '\0', 256);
            int l_bytes = RecvAll(g_sockfd, buf, 9);
            if (l_bytes <= 0)
            {
               CLOG(0,0,(char*)"recv failed at length. closing connection. continuing.");               
               close(g_sockfd);
               g_sockfd=-1;
               printConnStatus((char*)"NOT CONNECTED");
               printOutputWindow((char*)"recv failed. connection closed");
               g_executeCommandFlag=false;//This is added for suspecting the infinite loop at the application exit
               g_statsRefreshFlag=false;//This is added for suspecting the infinite loop at the application exit
               continue;
            }
            TLOG(0,0,(char*)"Received Command Resp Length [%s]", buf);



            int l_receivedLength = atoi(buf);
            if (l_receivedLength)
            {

               if (l_receivedLength > 6000)
               {
                  unsigned char *l_statsData = new unsigned char[l_receivedLength];
                  l_bytes = RecvAll(g_sockfd, (char*)l_statsData, l_receivedLength);
                  if (l_bytes != l_receivedLength)
                  {
                     CLOG(0,0,(char*)"recv failed at length=%d. closing connection. continuing.", l_receivedLength);               
                     close(g_sockfd);
                     g_sockfd=-1;
                     memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
                     sprintf(g_response, "Received length %d not equal to expected %d", l_bytes, l_receivedLength);
                     printOutputWindow(g_response);
                     g_executeCommandFlag=false;//This is added for suspecting the infinite loop at the application exit
                     g_statsRefreshFlag=false;//This is added for suspecting the infinite loop at the application exit
                     continue;
                  }
                  else
                  {
#if 0
                     DLOG(0,0,(char*)"Received Stats data: %d", ((Stats*)l_statsData)->m_Respondingappls[14].m_TotalCount[1]);
                     Cu_Stats l_cuStats;
                     memset(&l_cuStats, '\0', sizeof(Cu_Stats));
                     for (int i=0; i<STATS_MAX_OP_CODES; i++)
                     {
                        l_cuStats.m_Respondingops[i].m_TotalCount[0]   = ((Stats*)l_statsData)->m_Respondingops[i].m_TotalCount[0];   
                        l_cuStats.m_Respondingops[i].m_SuccessCount[0] = ((Stats*)l_statsData)->m_Respondingops[i].m_SuccessCount[0]; 
                        l_cuStats.m_Respondingops[i].m_TotalCount[1]   = ((Stats*)l_statsData)->m_Respondingops[i].m_TotalCount[1];     
                        l_cuStats.m_Respondingops[i].m_SuccessCount[1] = ((Stats*)l_statsData)->m_Respondingops[i].m_SuccessCount[1]; 
                        l_cuStats.m_Respondingops[i].m_TotalCount[2]   = ((Stats*)l_statsData)->m_Respondingops[i].m_TotalCount[2];     
                        l_cuStats.m_Respondingops[i].m_SuccessCount[2] = ((Stats*)l_statsData)->m_Respondingops[i].m_SuccessCount[2]; 
                        l_cuStats.m_Initiatingops[i].m_TotalCount[0]   = ((Stats*)l_statsData)->m_Initiatingops[i].m_TotalCount[0];     
                        l_cuStats.m_Initiatingops[i].m_SuccessCount[0] = ((Stats*)l_statsData)->m_Initiatingops[i].m_SuccessCount[0]; 
                        l_cuStats.m_Initiatingops[i].m_TotalCount[1]   = ((Stats*)l_statsData)->m_Initiatingops[i].m_TotalCount[1];     
                        l_cuStats.m_Initiatingops[i].m_SuccessCount[1] = ((Stats*)l_statsData)->m_Initiatingops[i].m_SuccessCount[1]; 
                        l_cuStats.m_Initiatingops[i].m_TotalCount[2]   = ((Stats*)l_statsData)->m_Initiatingops[i].m_TotalCount[2];      
                        l_cuStats.m_Initiatingops[i].m_SuccessCount[2] = ((Stats*)l_statsData)->m_Initiatingops[i].m_SuccessCount[2];  
                     }
                     for (int i=0; i<STATS_MAX_APPL_CTXTS; i++)
                     {
                        l_cuStats.m_Respondingappls[i].m_TotalCount[0]   = ((Stats*)l_statsData)->m_Respondingappls[i].m_TotalCount[0];   
                        l_cuStats.m_Respondingappls[i].m_SuccessCount[0] = ((Stats*)l_statsData)->m_Respondingappls[i].m_SuccessCount[0]; 
                        l_cuStats.m_Respondingappls[i].m_TotalCount[1]   = ((Stats*)l_statsData)->m_Respondingappls[i].m_TotalCount[1];     
                        l_cuStats.m_Respondingappls[i].m_SuccessCount[1] = ((Stats*)l_statsData)->m_Respondingappls[i].m_SuccessCount[1]; 
                        l_cuStats.m_Respondingappls[i].m_TotalCount[2]   = ((Stats*)l_statsData)->m_Respondingappls[i].m_TotalCount[2];     
                        l_cuStats.m_Respondingappls[i].m_SuccessCount[2] = ((Stats*)l_statsData)->m_Respondingappls[i].m_SuccessCount[2]; 
                        l_cuStats.m_Initiatingappls[i].m_TotalCount[0]   = ((Stats*)l_statsData)->m_Initiatingappls[i].m_TotalCount[0];     
                        l_cuStats.m_Initiatingappls[i].m_SuccessCount[0] = ((Stats*)l_statsData)->m_Initiatingappls[i].m_SuccessCount[0]; 
                        l_cuStats.m_Initiatingappls[i].m_TotalCount[1]   = ((Stats*)l_statsData)->m_Initiatingappls[i].m_TotalCount[1];     
                        l_cuStats.m_Initiatingappls[i].m_SuccessCount[1] = ((Stats*)l_statsData)->m_Initiatingappls[i].m_SuccessCount[1]; 
                        l_cuStats.m_Initiatingappls[i].m_TotalCount[2]   = ((Stats*)l_statsData)->m_Initiatingappls[i].m_TotalCount[2];      
                        l_cuStats.m_Initiatingappls[i].m_SuccessCount[2] = ((Stats*)l_statsData)->m_Initiatingappls[i].m_SuccessCount[2];  
                     }

                     for (int i=0; i<STATS_MAX_OP_CODES; i++)
                     {
                        for (int j=0; j<STATS_MAX_ERROR_CODES; j++)
                        {
                           l_cuStats.m_OpCodeErrorCodeCounts[i][j] = ((Stats*)l_statsData)->m_OpCodeErrorCodeCounts[i][j];

                        }
                     }
                     for (int i=0; i<STATS_MAX_TCAP_PRIMITIVES; i++)
                     {
                        l_cuStats.m_RespondingTcapPrimCount[i] = ((Stats*)l_statsData)->m_RespondingTcapPrimCount[i];
                        l_cuStats.m_InitiatingTcapPrimCount[i] = ((Stats*)l_statsData)->m_InitiatingTcapPrimCount[i];
                     }

                     if (strstr(l_commandToBeSent, "-t"))
                     {
                        printStats('t', ' ', &l_cuStats, 0);
                     }
                     else if (strstr(l_commandToBeSent, "-a"))
                     {
                        printStats('a', ' ', &l_cuStats, 0);
                     }
                     else if (strstr(l_commandToBeSent, "-o") ||
                           strstr(l_commandToBeSent, "-p")
                           )
                     {
                        if (strstr(l_commandToBeSent, "-o"))
                        {
                           if (strstr(l_commandToBeSent, "-n"))
                           {
                              printStats('o', 'n', &l_cuStats, 0);
                           }
                           else
                           {
                              printStats('o', 'e', &l_cuStats, 0);
                           }
                        }
                        else
                        {
                           if (strstr(l_commandToBeSent, "-n"))
                           {
                              printStats('p', 'n', &l_cuStats, 0);
                           }
                           else
                           {
                              printStats('p', 'e', &l_cuStats, 0);
                           }

                        }
                     }
                     else
                     {
                        memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
                        strcpy(g_response, "stats: -c option is not implemented yet.");
                        printOutputWindow(g_response);
                     }
                     refresh();
#endif
                  }
               }
               else
               {
                  memset(buf, '\0', sizeof(buf));
                  l_bytes = RecvAll(g_sockfd, buf, l_receivedLength);
                  if (l_bytes <= 0)
                  {
                     close(g_sockfd);
                     g_sockfd=-1;
                     memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
                     printConnStatus((char*)"NOT CONNECTED");
                     printOutputWindow((char*)"recv failed here. connection closed");
                     g_executeCommandFlag=false;//This is added for suspecting the infinite loop at the application exit
                     g_statsRefreshFlag=false;//This is added for suspecting the infinite loop at the application exit
                     continue;
                  }
                  TLOG(0,0,(char*)"Received Command Resp [%s]", buf);



                  memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
                  sprintf(g_response, "Command Response : %s", buf);

                  if ( (strncmp(l_commandToBeSent, "trace", 5) == 0) ||
                        (strncmp(l_commandToBeSent, "modifyconf", 9) == 0) 
                     )
                  {
                     strcpy(g_historyRes[g_historyInd],buf);
                  }

                  printOutputWindow(g_response);
               }

            }
         }
         else if (l_validCommand == -1)
         {
            CLOG(0,0,(char*)"validCommand is -1");               
            printOutputWindow(g_response);
         }
         else if (l_validCommand == -3)
         {
         }
         else
         {
            if (strcmp("help", buf)==0)
            {
               DLOG(0,0,(char*)"help command");               
               printCommands();
            }
            else if (strcmp("history", buf)==0)
            {
               DLOG(0,0,(char*)"history command");               
               memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
               sprintf(g_response, "      Date                   No.   Command                                                                           Status\n");
               char l_historyText[512];
               memset(l_historyText, '\0', 512);

               /*endwin();
                 printf("\nIndex %d", g_historyInd);
                 exit(1);*/



               int l_totalHistoryPrinted=0;
               for (int k=g_historyInd; (k>=0) && (l_totalHistoryPrinted < 45); k--)
               {
                  sprintf(l_historyText, "\n%s    %04d.  %-80s\t%s", g_historyTime[k], k+1, g_historyArr[k], g_historyRes[k]);
                  strcat(g_response, l_historyText);
                  l_totalHistoryPrinted++;
               }
               printOutputWindow(g_response);
            }
            else if (strcmp("clear", buf)==0)
            {
               DLOG(0,0,(char*)"clear command");               
               printOutputWindow(g_outputWindowSpace);
            }
            else if (strncmp(buf, "connect", 7) == 0)
            {
               DLOG(0,0,(char*)"connect command");               
               // parse the connect command here
               char l_command[1000];
               memset(l_command, '\0', 1000);
               strcpy(l_command, buf);

               int l_conn_argc=0; 
               char **l_conn_argv;
               char *pch = NULL;
               pch = strtok (l_command," ");
               l_conn_argv = (char**)malloc(100);
               while (pch != NULL)
               {
                  l_conn_argv[l_conn_argc] = (char *) malloc(100);
                  memset(l_conn_argv[l_conn_argc], '\0', 100);
                  strcpy(l_conn_argv[l_conn_argc], pch);
                  l_conn_argc++;
                  pch = strtok(NULL, " ");
               }
               // end of parsing

               if (2 == l_conn_argc)
               {
                  if (-1 == g_sockfd)
                  {
                     printOutputWindow((char*)"Connecting...");

                     char l_conn_res[100];
                     char l_err_msg[1000];
                     memset(l_conn_res, '\0', 100);
                     memset(l_err_msg, '\0', 1000);
                     bool l_connectStatus = connectToApp("localhost", l_conn_argv[1], l_conn_res, l_err_msg);
                     if (false == l_connectStatus)
                     {
                        CLOG(0,0,(char*)"Connection failure: %s", l_err_msg);               
                        printOutputWindow(l_err_msg);
                     }
                     else
                     {
                        char l_displayMsg[100];
                        memset(l_displayMsg, '\0', 100);
                        sprintf(l_displayMsg, "CONNECTED TO:   [ %s ] (%s:%d) ", l_conn_res, "localhost", atoi(l_conn_argv[1]));

                        printConnStatus(l_displayMsg);
                        printOutputWindow((char*)"Successfully connected.");
                        CLOG(0,0,(char*)"Connection successfull");               
                     }
                  }
                  else
                  {
                     CLOG(0,0,(char*)"Connection already exists!!!");               
                     printOutputWindow((char*)"Connection already exists!!!");
                  }
               }
               else
               {
                  CLOG(0,0,(char*)"Invalid Connect command");               
                  printOutputWindow((char*)"usage: connect <Port>");
               }


            }
            else if (strcmp("close", buf)==0)
            {
               DLOG(0,0,(char*)"close command");
               if (-1 == g_sockfd)
               {
                  printOutputWindow((char*)"No existing connection present with the application");
                  CLOG(0,0,(char*)"No existing connection present with the application");
               }
               else
               {
                  DLOG(0,0,(char*)"Closing the connection with the application");
                  close(g_sockfd);
                  g_sockfd=-1;
                  printConnStatus((char*)"NOT CONNECTED");
                  printOutputWindow((char*)"Successfully closed the connection with the application");
               }
            }
            else
            {
               CLOG(0,0,(char*)"Invalid Command");
               memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
               sprintf(g_response, "Invalid Command [%s]\n", buf);
               strcat(g_response, "\nType \"help\" for the list of commands\n");
               printOutputWindow(g_response);
            }
         }
      }
      else
      {
         //printf("\nNo input entered");
      }

   }
   CLOG(0,0,(char*)"End of while loop");
   return 0;
}


int RecvAll(int &s, char *buf, unsigned long len)
{
   int total = 0;
   int bytesleft = len;
   int n;
   while(total < len)
   {
      if(0>s)
         return -1;

      n = recv(s, buf+total, bytesleft,0);
      if (0 >= n)
      {
         if(0 > n)
         {
            //printf("\nrecv failed with errno: %d.", errno);
            if (EINTR == errno)
               continue;
         }
         else
         {
            //printf("\nSocket closed by Peer.");
         }
         //close(s);
         return n;
      }
      total += n;
      bytesleft -= n;
      //printf("\nreceived bytes %d, bytesleft %d, len %d, g_sockfd: %d",n,bytesleft,len, s);
   }
   len = total; // return number actually sent here
   return len;
}


#if 0
//bool printStats(char p_type, Cu_Stats *p_stats, int);
void printStats(char p_type, char p_opcodeType, Cu_Stats *p_stats, int p_StatsType)
{
   memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);

   char l_temp[1000];
   int l_start=0, l_end=0;
   if ('o' == p_type)
   {
      l_start = 2;
      l_end = 45;
   }
   else
   {
      l_start = 46;
      l_end = 90;
   }
   memset(l_temp, '\0', 1000);

   switch (p_type)
   {
      case 'a':
         sprintf(l_temp, "\nStatistics:: Application Contexts wise\n\n");
         break;

      case 't':
         sprintf(l_temp, "\nStatistics:: TCAP Primitives wise\n\n");
         break;

      case 'o':
      case 'p':
         switch (p_opcodeType)
         {
            case 'n':
               sprintf(l_temp, "\nStatistics:: Op Code wise Counts (Op Codes: %02d till %02d)\n\n", l_start, l_end);
               break;
            case 'e':
               sprintf(l_temp, "\nStatistics:: Op Code vs Error Codes Counts (Op Codes: %02d till %02d)\n\n", l_start, l_end);
               break;
            default:
               ELOG(0,1,"Unknown p_opcodeType -%c-", p_opcodeType);
               return;
               break;

         }
         break;
      default:
         ELOG(0,1,"Unknown p_type -%c-", p_type);
         return;
         break;
   }
   strcpy(g_response, l_temp);

   if ('t' == p_type)
   {
      memset(l_temp, '\0', 1000);
      sprintf(l_temp, "%-2s  %-20s   %-10s %-10s    \n", "No", "TCAP Primitive", "Received", "Sent");
      strlcat(g_response, l_temp, MAX_OUTPUT_WINDOW_SIZE);

      memset(l_temp, '\0', 1000);
      sprintf(l_temp, "\n\nDialogue Primitives:\n");
      strlcat(g_response, l_temp, MAX_OUTPUT_WINDOW_SIZE);

      for (int i=1; i<STATS_MAX_TCAP_PRIMITIVES; i++)
      {

         if (8 == i)
         {
            memset(l_temp, '\0', 1000);
            sprintf(l_temp, "\n\nComponent Primitives:\n");
            strlcat(g_response, l_temp, MAX_OUTPUT_WINDOW_SIZE);
         }



         if (strcmp("UNKNOWN", getTcapPrimChar(i)) != 0)
         {
            memset(l_temp, '\0', 1000);
            sprintf(l_temp, "\n%02d  %-20s   %7d %7d", 
                  i,
                  getTcapPrimChar(i),
                  p_stats->m_RespondingTcapPrimCount[i],
                  p_stats->m_InitiatingTcapPrimCount[i]);
            strlcat(g_response, l_temp, MAX_OUTPUT_WINDOW_SIZE);
         }
      }
      printOutputWindow(g_response);

   }
   else if ('a' == p_type)
   {
      memset(l_temp, '\0', 1000);
      sprintf(l_temp, "%-2s  %-20s   %-7s %-7s    %-7s %-7s    %-7s %-7s    %-7s %-7s    %-7s %-7s    %-7s %-7s\n", 
            "No", "Application Context", "v1-Tot", "v1-Suc", "v2-Tot", "v2-Suc", "v3-Tot", "v3-Suc",
            "v1-Tot", "v1-Suc", "v2-Tot", "v2-Suc", "v3-Tot", "v3-Suc");
      strlcat(g_response, l_temp, MAX_OUTPUT_WINDOW_SIZE);

      memset(l_temp, '\0', 1000);
      sprintf(l_temp, "%-2s  %-20s   %-7s %-7s    %-7s %-7s    %-7s %-7s    %-7s %-7s    %-7s %-7s    %-7s %-7s", 
            " ", "     ", "(Resp)", "(Resp)", "(Resp)", "(Resp)", "(Resp)", "(Resp)",
            "(Init)", "(Init)", "(Init)", "(Init)", "(Init)", "(Init)");
      strlcat(g_response, l_temp, MAX_OUTPUT_WINDOW_SIZE);

      for (int i=1; i<46; i++)
      {
         if (!strstr(g_MapApplCtxtMappingChar[i], "dummy"))
         {
            memset(l_temp, '\0', 1000);
            sprintf(l_temp, "\n%02d  %-20s   %7d %7d    %7d %7d    %7d %7d    %7d %7d    %7d %7d    %7d %7d", 
                  i, 
                  g_MapApplCtxtMappingChar[i],
                  p_stats->m_Respondingappls[i].m_TotalCount[0], 
                  p_stats->m_Respondingappls[i].m_SuccessCount[0], 
                  p_stats->m_Respondingappls[i].m_TotalCount[1], 
                  p_stats->m_Respondingappls[i].m_SuccessCount[1], 
                  p_stats->m_Respondingappls[i].m_TotalCount[2],
                  p_stats->m_Respondingappls[i].m_SuccessCount[2],
                  p_stats->m_Initiatingappls[i].m_TotalCount[0], 
                  p_stats->m_Initiatingappls[i].m_SuccessCount[0], 
                  p_stats->m_Initiatingappls[i].m_TotalCount[1], 
                  p_stats->m_Initiatingappls[i].m_SuccessCount[1], 
                  p_stats->m_Initiatingappls[i].m_TotalCount[2],
                  p_stats->m_Initiatingappls[i].m_SuccessCount[2]
                  );
            strlcat(g_response, l_temp, MAX_OUTPUT_WINDOW_SIZE);
         }
      }
      printOutputWindow(g_response);

   }
   else if ( ('o' == p_type) || ('p' == p_type) )
   {
      memset(l_temp, '\0', 1000);

      if ('n' == p_opcodeType)
      {
         sprintf(l_temp, "%-2s  %-20s   %-7s %-7s    %-7s %-7s    %-7s %-7s    %-7s %-7s    %-7s %-7s    %-7s %-7s\n", 
               "No", "Operation", "v1-Tot", "v1-Suc", "v2-Tot", "v2-Suc", "v3-Tot", "v3-Suc",
               "v1-Tot", "v1-Suc", "v2-Tot", "v2-Suc", "v3-Tot", "v3-Suc");
         strlcat(g_response, l_temp, MAX_OUTPUT_WINDOW_SIZE);

         memset(l_temp, '\0', 1000);
         sprintf(l_temp, "%-2s  %-20s   %-7s %-7s    %-7s %-7s    %-7s %-7s    %-7s %-7s    %-7s %-7s    %-7s %-7s\n", 
               " ", "     ", "(Resp)", "(Resp)", "(Resp)", "(Resp)", "(Resp)", "(Resp)",
               "(Init)", "(Init)", "(Init)", "(Init)", "(Init)", "(Init)");
         strlcat(g_response, l_temp, MAX_OUTPUT_WINDOW_SIZE);
      }
      else
      {
         memset(l_temp, '\0', 1000);
         strcpy(l_temp, "ER: ");
         for (int j=1; j<72; j++)
         {
            if (!strstr(g_ErrorCodeChar[j], "dummy"))
            {
               char l_errorCode[20];
               memset(l_errorCode, '\0', 20);
               sprintf(l_errorCode, "%02d ", j);
               strlcat(l_temp, l_errorCode, 1000);
            }
         }
         strlcat(g_response, l_temp, MAX_OUTPUT_WINDOW_SIZE);
      }




      if ('n' == p_opcodeType)
      {
         for (int i=l_start; i<l_end; i++)
         {
            memset(l_temp, '\0', 1000);

            if (!strstr(g_MapOpCodeChar[i], "dummy"))
            {
               sprintf(l_temp, "\n%02d  %-20s   %7d %7d    %7d %7d    %7d %7d    %7d %7d    %7d %7d    %7d %7d", 
                     i, 
                     g_MapOpCodeChar[i],
                     p_stats->m_Respondingops[i].m_TotalCount[0], 
                     p_stats->m_Respondingops[i].m_SuccessCount[0], 
                     p_stats->m_Respondingops[i].m_TotalCount[1], 
                     p_stats->m_Respondingops[i].m_SuccessCount[1], 
                     p_stats->m_Respondingops[i].m_TotalCount[2],
                     p_stats->m_Respondingops[i].m_SuccessCount[2],
                     p_stats->m_Initiatingops[i].m_TotalCount[0], 
                     p_stats->m_Initiatingops[i].m_SuccessCount[0], 
                     p_stats->m_Initiatingops[i].m_TotalCount[1], 
                     p_stats->m_Initiatingops[i].m_SuccessCount[1], 
                     p_stats->m_Initiatingops[i].m_TotalCount[2],
                     p_stats->m_Initiatingops[i].m_SuccessCount[2]
                     );
               strlcat(g_response, l_temp, MAX_OUTPUT_WINDOW_SIZE);
            }
         }
      }
      else
      {
         for (int i=l_start; i<l_end; i++)
         {
            memset(l_temp, '\0', 1000);

            if (!strstr(g_MapOpCodeChar[i], "dummy"))
            {
               sprintf(l_temp, "\n%02d:", i);
               for (int j=1; j<72; j++)
               {
                  if (!strstr(g_ErrorCodeChar[j], "dummy"))
                  {
                     char l_errorString[20];
                     memset(l_errorString, '\0', 20);
                     if (p_stats->m_OpCodeErrorCodeCounts[i][j] > 99)
                     {
                        strcpy(l_errorString, " XX");
                     }
                     else
                     {
                        sprintf(l_errorString, " %2d", p_stats->m_OpCodeErrorCodeCounts[i][j]);
                     }
                     strlcat(l_temp, l_errorString, 1000);
                  }
               }

               strlcat(g_response, l_temp, MAX_OUTPUT_WINDOW_SIZE);
            }
         }
      }
      printOutputWindow(g_response);
   }
}
#endif
