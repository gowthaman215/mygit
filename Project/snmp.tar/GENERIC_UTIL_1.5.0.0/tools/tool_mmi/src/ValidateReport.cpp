#include <NgMmlMain.h>
#include <Logger.h>
#include <argtable2.h>
#include <regex.h>      /* REG_ICASE */
#include <strings.h>
#include <stdlib.h>
#include <curses.h>
#include <dirent.h>
#include <stddef.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>


#define FILE_SIZE 300



const char* g_progNameGenerate="generate";
FILE* outputFile=NULL;
int g_TotalFilesSelected=0;

extern char g_response[];
bool processFile(char*,int,int,int,int,int,FILE *,const char*,char*);


extern void printOutputWindow(char *string);

extern char g_MapApplCtxtMappingChar[][50];
extern char g_MapOpCodeChar[][50];




extern char g_globalSent[];

#define LPRINTF(...)  { sprintf(g_response, __VA_ARGS__); }

void printGenerateUsage(void **g_generateCommands, void **g_generateHelp)
{

   DLOG(0,0,(char*)"Enter into printGenerateUsage fun");   
   strcat(g_response, "\n\n");

   FILE *l_fp = NULL;
   l_fp = fopen("dummy.txt",  "w+");
   if (l_fp)
   {
      fprintf(l_fp, "usage 1:  %s",  g_progNameGenerate);  arg_print_syntax(l_fp,g_generateHelp,"\n");
      fprintf(l_fp,"usage 2:  %s",  g_progNameGenerate);  arg_print_syntax(l_fp,g_generateCommands,"\n\n");
      arg_print_glossary(l_fp,g_generateHelp,"      %s %s\n");
      arg_print_glossary(l_fp,g_generateCommands,"      %s %s\n");

      fseek(l_fp, 0, SEEK_SET);
      char l_sent[200];
      memset(l_sent, '\0', 200);
      while (1)
      {
         if (NULL == fgets(l_sent, 200, l_fp))
         {
            break;
         }
         else
         {
            strcat(g_response, l_sent);
         }
      }
      fclose(l_fp);
   }
   else
   {
      strcpy(g_response,"Internal Error !! Unable to open dummy.txt");
   }
   DLOG(0,0,(char*)"Exit  From  printGenerateUsage fun");
}


int mymain10(const char* f_path,const char *start_date,
      const char* end_date,int p_applicationContxt,
      int p_opCodeFirst,int p_opcodeLast,int p_conversation,int p_slotwise,
      int p_aggregate,int p_redirectFile,int p_totalCounts, int p_errorCounts, void** g_generateCommands,void** g_generateHelp)
{
   DLOG(0,0,(char*)"Enter Into mymain fun");
   if((strlen(f_path)==0) || (strlen(start_date)==0) || (strlen(end_date)==0))
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("All PATH  Name ,START Date END Date Should be Present");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }

   if((strlen(start_date)!=8) && (strlen(end_date)!=8))
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("Date incorrect entered");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }

   if(atoi(start_date)> atoi(end_date))
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("Start date is Greater than end date");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }
   int l_start_year,l_end_year;
   int l_start_month,l_end_month;
   int l_start_date,l_end_date;
   char l_temp[10];
   memset(l_temp,'\0',10);
   l_start_year=atoi(strncpy(l_temp,start_date,4));
   memset(l_temp,'\0',10);
   l_start_month=atoi(strncpy(l_temp,start_date+4,2));
   memset(l_temp,'\0',10);
   l_start_date=atoi(strncpy(l_temp,start_date+6,2));
   memset(l_temp,'\0',10);
   l_end_year=atoi(strncpy(l_temp,end_date,4));
   memset(l_temp,'\0',10);
   l_end_month=atoi(strncpy(l_temp,end_date+4,2));
   memset(l_temp,'\0',10);
   l_end_date=atoi(strncpy(l_temp,end_date+6,2));
   if((l_start_date == 0  ||l_start_date >31) || (l_end_date ==0 ||l_end_date >31))
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("Date should be between 1-31");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }
   if((l_start_month == 0|| l_start_month>12) || (l_end_month == 0 ||l_end_month>12))
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("Month should be between 1-12");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }
   if((l_start_year == 0 || (l_start_year <= 2009 && l_start_year > 2051)) || (l_end_year == 0 || (l_end_year < 2009 && l_end_year > 2051 )))
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("Year should be between 2010-2050");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }

   if((p_applicationContxt == 0)&&(p_opCodeFirst == 0)&&(p_opcodeLast == 0)&&(p_conversation == 0))
   {
      DLOG(0,0,(char*)"p_applicationContxt | p_opCodeFirst | p_opcodeLast | p_conversation %d %d %d %d",p_applicationContxt,p_opCodeFirst,
            p_opcodeLast,p_conversation);
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("Ethier of Aplication context,Op-Code First,Op-Code Last or Conversation option should be present");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }
   int l_optionCount=0;
   if(p_applicationContxt !=0)
      l_optionCount++;
   if(p_opCodeFirst !=0)
      l_optionCount++;
   if(p_opcodeLast != 0)
      l_optionCount++;
   if(p_conversation != 0)
      l_optionCount++;
   if(l_optionCount != 1)
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("Too many options are selected,only one option among -a,-o,-l,-c required");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }
   if((p_aggregate == 0) && (p_slotwise == 0))
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("Ethier Aggregate or Slotwise present");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }
   if((p_slotwise !=0) && (p_aggregate !=0))
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("Both  Aggregate and  Slotwise should not Present");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }
   if(p_slotwise !=0)
   {
      DLOG(0,0,(char*)"p_aggregate |p_slotwise %d %d",p_aggregate,p_slotwise); 
      if(p_redirectFile == 0)
      { 
         memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
         LPRINTF("File name required to redirect");
         printGenerateUsage(g_generateCommands,g_generateHelp);
         return -1;
      }
   }

   if( (p_opCodeFirst != 0) || (p_opcodeLast != 0))
   {
      if( (p_errorCounts ==0) && (p_totalCounts == 0))
      {
         memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
         LPRINTF("(-o) and (-p) options should be used along with (-t) or (-e)");
         printGenerateUsage(g_generateCommands,g_generateHelp);
         return -1;
      }
      if( (p_errorCounts ==1) && (p_totalCounts == 1))
      {
         memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
         LPRINTF("(-t) and (-e) options should not co-exist in the same command");
         printGenerateUsage(g_generateCommands,g_generateHelp);
         return -1;
      }
   }
   DLOG(0,0,(char*)"Exit from mymain fun");
   return 0;
}

int parseGenerate(char *p_command)
{
   DLOG(0,0,(char*)"Enter into parseGenerate fun");
   g_TotalFilesSelected=0;
   int p_argc=0; 
   char **p_argv;
   DLOG(0,0,(char*)"parseGenerate called");               
   char * pch;
   pch = strtok (p_command," ");
   p_argv = (char**)malloc(1000);
   while (pch != NULL)
   {
      p_argv[p_argc] = (char *) malloc(40);
      strcpy(p_argv[p_argc], pch);
      p_argc++;
      pch = strtok (NULL, " ");
   }



   /*SYNTAX 6:changelog*/

   struct arg_str  *pattern1 = arg_str1("d",NULL,  "<directory>", "Directory where the stats files are present");
   struct arg_str  *pattern2 = arg_str1("f",NULL,  "<from-date>", "From date in YYYYMMDD format");
   struct arg_str  *pattern3 = arg_str1("l",NULL,  "<last-date>", "Last date in YYYYMMDD format");
   //////////////////////////////////////////////////////////////////////////////////////////
   struct arg_lit  *pattern4 = arg_lit0("a",NULL,"Application Contexts wise");
   struct arg_lit  *pattern5 = arg_lit0("o",NULL,"OP codes wise (first page)");
   struct arg_lit  *pattern6 = arg_lit0("p",NULL,"OP codes wise (last page)");
   struct arg_lit  *pattern7 = arg_lit0("c",NULL,"Conversations wise (not implemented yet)");
   //////////////////////////////////////////////////////////////////////////////////////////
   struct arg_lit  *pattern8 = arg_lit0("s",NULL,"Slot wise totals");
   struct arg_lit  *pattern9 = arg_lit0("g",NULL,"Grand totals");
   /////////////////////////////////////////////////////////////////////////////////////////////////
   struct arg_str  *pattern10 =arg_str0("r",NULL,"<redirect-file-name>","Redirection file name (the report would be generated into this file)");
   struct arg_lit  *pattern11 =arg_lit0("t",NULL,"Total Success/Failure counts");
   struct arg_lit  *pattern12 =arg_lit0("e",NULL,"Error counts");
   struct arg_end  *end1     = arg_end(20);
   void* g_generateCommands[] = {pattern1,pattern2,pattern3,pattern10,pattern4,pattern5,
      pattern6,pattern7,pattern8,pattern9,pattern11,pattern12,end1};
   int nerrors1;

   /* SYNTAX 4: [--help] [-h] */
   struct arg_lit  *help4    = arg_lit1("h","", "print this help");
   struct arg_end  *end4     = arg_end(20);
   void* g_generateHelp[] = {help4,end4};
   int nerrors4;
   int exitcode=0;
   memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
   if(arg_nullcheck(g_generateCommands)!=0 || arg_nullcheck(g_generateHelp)!=0 )
   {
      LPRINTF("%s: insufficient memory\n",g_progNameGenerate);
      exitcode=1;
   }
   FILE *l_fp = fopen("dummy.txt",  "w+");
   nerrors4 = arg_parse(p_argc,(char**)p_argv,g_generateHelp);
   nerrors1= arg_parse(p_argc,(char**)p_argv,g_generateCommands);
   if (nerrors1==0)
   {
      DLOG(0,0,(char*)"No Errors"); 
      exitcode = mymain10(pattern1->sval[0], pattern2->sval[0],
            pattern3->sval[0], pattern4->count, pattern5->count, pattern6->count,
            pattern7->count, pattern8->count, pattern9->count, pattern10->count,
            pattern11->count, pattern12->count,
            (void**)&g_generateCommands,(void**)&g_generateHelp); 

      if (0 == exitcode)
      {
         memset(g_response, '\0', 3000);
         /*
         generateReport(pattern1->sval[0],pattern2->sval[0],pattern3->sval[0],
               pattern4->count,pattern5->count,pattern6->count,pattern7->count,
               pattern8->count,pattern9->count,pattern10->sval[0],
               pattern11->count, pattern12->count,g_response);
               */
      }

   }
   else
   {
      printGenerateUsage(g_generateCommands,g_generateHelp);
      /*
         fprintf(l_fp,"usage 1:  %s",  g_progNameGenerate);  arg_print_syntax(l_fp,g_generateHelp,"\n");    
         fprintf(l_fp,"usage 2:  %s",  g_progNameGenerate);  arg_print_syntax(l_fp,g_generateCommands,"\n\n");
         arg_print_glossary(l_fp,g_generateCommands,"      %-20s %s\n");
         fseek(l_fp, 0, SEEK_SET);
         char l_sent[200];
         memset(l_sent, '\0', 200);
         while (1)
         {
         if (NULL == fgets(l_sent, 200, l_fp))
         {
         break;
         }
         else
         {
         strcat(g_response, l_sent);
         }
         }
         fclose(l_fp);
         */
      exitcode =-1;
   }
exit:
   /* deallocate each non-null entry in each argtable */
   arg_freetable(g_generateHelp,sizeof(g_generateHelp)/sizeof(g_generateHelp[0]));
   arg_freetable(g_generateCommands,sizeof(g_generateCommands)/sizeof(g_generateCommands[0]));


   DLOG(0,0,(char*)"Exit from  parseGenerate fun");
   return exitcode;
}



#if 0
bool generateReport(const char* p_directoryPath, const char* p_fromDate,const  char* p_toDate,
      int p_applicationContext,int p_opCode,int  p_opCodeLast,int p_conversation,
      int p_slotWise,int p_aggregateWise,const char* p_fileName, int p_totalCounts, int p_errorCounts, char *p_output)
{
   DLOG(0,0,(char*)"Enter into generateReport "); 
   memset(&g_aggStates, '\0', sizeof(g_aggStates));
   memset(&g_slotAggCounts, '\0', sizeof(g_slotAggCounts));
   struct dirent **filelist = {0};

   int f_count = -1;
   int l_counter = 0;

   f_count = scandir(p_directoryPath, &filelist, 0, alphasort);

   if(f_count < 0) {
      sprintf(p_output, "scandir failed for directory [%s] %s", p_directoryPath, strerror(errno));
      return false;
   }

   char l_filename[FILE_SIZE];
   memset(l_filename, '\0', FILE_SIZE);
   if(strlen(p_fileName)!=0)
   {
      if ((outputFile = fopen(p_fileName,"w" )) == NULL) {
         ELOG(0,0,(char*)" Redirect output  file create unsuccessful", p_fileName);
         return false;
      }
      else
      {
         DLOG(0,0,(char*)" Redirect output file create successful", p_fileName);
      }
   }

   DLOG(0,0,(char*)"starting the for loop with files %d", f_count); 
   for(l_counter = 0; l_counter < f_count; l_counter++)  
   {
      sprintf(l_filename,"%s",  filelist[l_counter]->d_name);
      DLOG(0,0,(char*)"file %d %s", l_counter, l_filename); 

      if(strncmp(l_filename,"stats_I",7)==0)
      {
         DLOG(0,0,(char*)"  matched %s ", l_filename); 
         char lfilename1[FILE_SIZE];
         memset(lfilename1, '\0', FILE_SIZE);
         strncpy(lfilename1,l_filename,strlen(l_filename));

         int p_argc=0;
         char **p_argv;

         char * pch;
         pch = strtok (lfilename1,"_");
         p_argv = (char**)malloc(40);

         while (pch != NULL)
         {
            p_argv[p_argc] = (char *) malloc(40);
            memset(p_argv[p_argc] , '\0', 40);

            strcpy(p_argv[p_argc], pch);
            p_argc++;

            pch = strtok (NULL, "_");
         }

         char l_fileDate[20];
         memset(l_fileDate,'\0',20);
         sprintf(l_fileDate,"%s%s%s ",p_argv[2],p_argv[3],p_argv[4]);
         DLOG(0,0,"Current File Date %d, From Date %d, To Date %d", 
               atoi(l_fileDate),
               atoi(p_fromDate),
               atoi(p_toDate));
         if(atoi(l_fileDate)>=atoi(p_fromDate) && atoi(l_fileDate)<=atoi(p_toDate))
         {
            DLOG(0,0,(char*)"    SELECTED %s for report", l_filename); 
            g_TotalFilesSelected++;
            char l_fileName[FILE_SIZE];
            memset(l_fileName, '\0', FILE_SIZE);

            sprintf(l_fileName,"%s/%s",p_directoryPath,l_filename);
            if(false == processFile(l_fileName,p_applicationContext,p_opCode,p_opCodeLast,p_conversation,p_slotWise,outputFile,p_fileName,p_output))
            {
               ELOG(0,0,(char*)"  process file failure %s",l_fileName);
            }
            else
            {
               DLOG(0,0,(char*)"  process file success");
            }
         }
         else
         {
            ELOG(0,0,(char*)"  no file in search criteria");
         }
      }
      else
      {
         ELOG(0,0,(char*)"  no file in directory"); 
      }

      //free(filelist[l_counter]);
   }
   //free(filelist);

   DLOG(0,0,(char*)"  Aggregate wise selected");
   if(p_aggregateWise != 0)
   {
      if (p_applicationContext != 0)
      {
         DLOG(0,0,(char*)"  p_applicationContext selected for Aggregate" );
         printStats('a', ' ', &g_aggStates, 0);
      }
      if (p_opCode != 0)
      {
         DLOG(0,0,(char*)"  Op_code First  selected for Aggregate " );
         if (p_totalCounts != 0)
         {
             printStats('o', 't', &g_aggStates, 0);
         }
         else
         {
             printStats('o', 'e', &g_aggStates, 0);
         }
      }

      if(p_opCodeLast != 0)
      {
         DLOG(0,0,(char*)"  Op_code Last  selected for Aggregate" );
         if (p_totalCounts != 0)
         {
             printStats('p', 't', &g_aggStates, 0);
         }
         else
         {
             printStats('p', 'e', &g_aggStates, 0);
         }
      }
      if(p_conversation != 0)
      {
         DLOG(0,0,(char*)"  Conversation   selected for Aggregate" );
         printStats('c', ' ', &g_aggStates, 0);
      }
      if(outputFile != NULL)
      {
         DLOG(0,0,(char*)"  inside redirect aggaregate " );
         size_t filesizewriten=0;
         filesizewriten=fputs(g_response,outputFile);
         DLOG(0,0,(char*)"  after redirect printing aggaregate " );
      }
   }
   else if(p_slotWise != 0)
   {
      for(int i=0; i<24; i++)
      {
         if (p_applicationContext != 0)
         {
            DLOG(0,0,(char*)"  p_applicationContext  selected for Slotwise" );
            printStats('a', ' ', &(g_slotAggCounts[i]), 0);
         }
         if (p_opCode != 0)
         {
            DLOG(0,0,(char*)"  op-code first selected for Slotwise" );
            if (p_totalCounts != 0)
            {
                printStats('o', 't', &(g_slotAggCounts[i]), 0);
            }
            else
            {
                printStats('o', 'e', &(g_slotAggCounts[i]), 0);
            }
         }
         if(p_opCodeLast != 0)
         {
            DLOG(0,0,(char*)"  op_code Last   selected for Slotwise" );
            if (p_totalCounts != 0)
            {
                printStats('p', 't', &(g_slotAggCounts[i]), 0);
            }
            else
            {
                printStats('p', 'e', &(g_slotAggCounts[i]), 0);
            }
         }
         if(p_conversation != 0)
         {
            DLOG(0,0,(char*)"  conversation   selected for Slotwise" );
            printStats('c', ' ', &(g_slotAggCounts[i]), 0);
         }
         if(outputFile != NULL)
         {
            char l_slotDetails[200];
            memset(l_slotDetails, '\0', 200);
            sprintf(l_slotDetails, "\nSlot %d\n", i);
            fputs(l_slotDetails, outputFile);

            DLOG(0,0,(char*)"  inside redirect aggaregate " );
            size_t filesizewriten=0;
            filesizewriten=fputs(g_response,outputFile);
            DLOG(0,0,(char*)"  after redirect printing aggaregate " );
         }
      }
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      strcpy(g_response, "Report Generated");
      DLOG(0,0,(char*)"  Report generated" );

   }

   DLOG(0,0,(char*)"  Exit from generateReport fun ");
   return true;
}

bool processFile(char* p_filename,int p_applicationContext,int p_opCode,int p_opCodeLast,int p_conversation,int p_slotWise,FILE* l_outputFile,const char* outFileName,char* p_output)
{
   DLOG(0,0,(char*)"  Enter into process file ");
   struct stat sbuf;
   int fd;
   if ((fd = open(p_filename, O_RDONLY)) == -1) {
      sprintf(p_output, "open  failed for file [%s] %s", p_filename, strerror(errno));
      return false;
   }

   if (stat(p_filename, &sbuf) == -1) {
      perror("stat");
      return false;
   }

   int l_slotsInADay =24;

   int i=0;
   for(i=0; i<l_slotsInADay; i++)
   {
      int l_amt;
      Stats l_buf;
      memset(&l_buf, '\0', sizeof(Stats));
      if ((l_amt= read(fd, (unsigned char*)(&l_buf), sizeof(Stats))) == -1)
      {
         sprintf(p_output, "read  failed for file [%s] %s", p_filename, strerror(errno));
         return false;
      }
      if(p_slotWise == 0)
      {
         DLOG(0,0,(char*)"  aggregate is selected %d ", p_slotWise);
         if(false==aggregate(&l_buf, -1))
         { 
            DLOG(0,0,(char*)"  aggregate return false %d ", i);
         }
         else
            continue; 
      }
      else
      {
         DLOG(0,0,(char*)"  slotwise is selected %d ", p_slotWise);
         if(false==aggregate(&l_buf, i))
         { 
            DLOG(0,0,(char*)"  slotwise return false %d ", i);
         }
         else
            continue; 
      }
   }

   close(fd);
   DLOG(0,0,(char*)" Exit from  process file ");
   return true;
}

bool  aggregate(Stats* m_stats, int p_slotNumber)
{
   DLOG(0,0,(char*)"  inside the aggreagte func ");
   if(NULL == m_stats)
   {
      ELOG(0,0,(char*)"  m_stats NULL ");
      return false;
   }

   if(-1 == p_slotNumber)
   {
      DLOG(0,0,(char*)"  Total Aggregate ");
      for(int i=0;i<46;i++)
      {

         g_aggStates.m_Respondingappls[i].m_TotalCount[0]   +=m_stats->m_Respondingappls[i].m_TotalCount[0];
         g_aggStates.m_Respondingappls[i].m_SuccessCount[0] +=m_stats->m_Respondingappls[i].m_SuccessCount[0];
         g_aggStates.m_Respondingappls[i].m_TotalCount[1]   +=m_stats->m_Respondingappls[i].m_TotalCount[1];
         g_aggStates.m_Respondingappls[i].m_SuccessCount[1] +=m_stats->m_Respondingappls[i].m_TotalCount[1];
         g_aggStates.m_Respondingappls[i].m_TotalCount[2]   +=m_stats->m_Respondingappls[i].m_TotalCount[2];
         g_aggStates.m_Respondingappls[i].m_TotalCount[2]   +=m_stats->m_Respondingappls[i].m_TotalCount[2];
         g_aggStates.m_Initiatingappls[i].m_TotalCount[0]   +=m_stats->m_Initiatingappls[i].m_TotalCount[0];
         g_aggStates.m_Initiatingappls[i].m_SuccessCount[0] +=m_stats->m_Initiatingappls[i].m_SuccessCount[0];
         g_aggStates.m_Initiatingappls[i].m_TotalCount[1]   +=m_stats->m_Initiatingappls[i].m_TotalCount[1];
         g_aggStates.m_Initiatingappls[i].m_SuccessCount[1] +=m_stats->m_Initiatingappls[i].m_SuccessCount[1];
         g_aggStates.m_Initiatingappls[i].m_TotalCount[2]   +=m_stats->m_Initiatingappls[i].m_TotalCount[2];
         g_aggStates.m_Initiatingappls[i].m_SuccessCount[2] +=m_stats->m_Initiatingappls[i].m_SuccessCount[2];
      }

      for (int i=0; i<90; i++)
      {
         g_aggStates.m_Respondingops[i].m_TotalCount[0]     +=m_stats->m_Respondingops[i].m_TotalCount[0]; 
         g_aggStates.m_Respondingops[i].m_SuccessCount[0]   +=m_stats->m_Respondingops[i].m_SuccessCount[0];
         g_aggStates.m_Respondingops[i].m_TotalCount[1]     +=m_stats->m_Respondingops[i].m_TotalCount[1]; 
         g_aggStates.m_Respondingops[i].m_SuccessCount[1]   += m_stats->m_Respondingops[i].m_SuccessCount[1]; 
         g_aggStates.m_Respondingops[i].m_TotalCount[2]     +=m_stats->m_Respondingops[i].m_TotalCount[2];
         g_aggStates.m_Respondingops[i].m_SuccessCount[2]   +=m_stats->m_Respondingops[i].m_SuccessCount[2];
         g_aggStates.m_Initiatingops[i].m_TotalCount[0]     += m_stats->m_Initiatingops[i].m_TotalCount[0];
         g_aggStates.m_Initiatingops[i].m_SuccessCount[0]   += m_stats->m_Initiatingops[i].m_SuccessCount[0];
         g_aggStates.m_Initiatingops[i].m_TotalCount[1]     += m_stats->m_Initiatingops[i].m_TotalCount[1];
         g_aggStates.m_Initiatingops[i].m_SuccessCount[1]   += m_stats->m_Initiatingops[i].m_SuccessCount[1];
         g_aggStates.m_Initiatingops[i].m_TotalCount[2]     += m_stats->m_Initiatingops[i].m_TotalCount[2];
         g_aggStates.m_Initiatingops[i].m_SuccessCount[2]   += m_stats->m_Initiatingops[i].m_SuccessCount[2];
      }
   }
   if(p_slotNumber > 23)
   {
      ELOG(0,1,"slot number %d invalid", p_slotNumber);
      return false;
   }
   else 
   {
      DLOG(0,0,(char*)"  slotwise aggregate ");
      for(int i=0;i<46;i++)
      {

         g_slotAggCounts[p_slotNumber].m_Respondingappls[i].m_TotalCount[0]   +=m_stats->m_Respondingappls[i].m_TotalCount[0];
         g_slotAggCounts[p_slotNumber].m_Respondingappls[i].m_SuccessCount[0] +=m_stats->m_Respondingappls[i].m_SuccessCount[0];
         g_slotAggCounts[p_slotNumber].m_Respondingappls[i].m_TotalCount[1]   +=m_stats->m_Respondingappls[i].m_TotalCount[1];
         g_slotAggCounts[p_slotNumber].m_Respondingappls[i].m_SuccessCount[1] +=m_stats->m_Respondingappls[i].m_TotalCount[1];
         g_slotAggCounts[p_slotNumber].m_Respondingappls[i].m_TotalCount[2]   +=m_stats->m_Respondingappls[i].m_TotalCount[2];
         g_slotAggCounts[p_slotNumber].m_Respondingappls[i].m_TotalCount[2]   +=m_stats->m_Respondingappls[i].m_TotalCount[2];
         g_slotAggCounts[p_slotNumber].m_Initiatingappls[i].m_TotalCount[0]   +=m_stats->m_Initiatingappls[i].m_TotalCount[0];
         g_slotAggCounts[p_slotNumber].m_Initiatingappls[i].m_SuccessCount[0] +=m_stats->m_Initiatingappls[i].m_SuccessCount[0];
         g_slotAggCounts[p_slotNumber].m_Initiatingappls[i].m_TotalCount[1]   +=m_stats->m_Initiatingappls[i].m_TotalCount[1];
         g_slotAggCounts[p_slotNumber].m_Initiatingappls[i].m_SuccessCount[1] +=m_stats->m_Initiatingappls[i].m_SuccessCount[1];
         g_slotAggCounts[p_slotNumber].m_Initiatingappls[i].m_TotalCount[2]   +=m_stats->m_Initiatingappls[i].m_TotalCount[2];
         g_slotAggCounts[p_slotNumber].m_Initiatingappls[i].m_SuccessCount[2] +=m_stats->m_Initiatingappls[i].m_SuccessCount[2];
      }

      for (int i=0; i<90; i++)
      {
         g_slotAggCounts[p_slotNumber].m_Respondingops[i].m_TotalCount[0]     +=m_stats->m_Respondingops[i].m_TotalCount[0]; 
         g_slotAggCounts[p_slotNumber].m_Respondingops[i].m_SuccessCount[0]   +=m_stats->m_Respondingops[i].m_SuccessCount[0];
         g_slotAggCounts[p_slotNumber].m_Respondingops[i].m_TotalCount[1]     +=m_stats->m_Respondingops[i].m_TotalCount[1]; 
         g_slotAggCounts[p_slotNumber].m_Respondingops[i].m_SuccessCount[1]   += m_stats->m_Respondingops[i].m_SuccessCount[1]; 
         g_slotAggCounts[p_slotNumber].m_Respondingops[i].m_TotalCount[2]     +=m_stats->m_Respondingops[i].m_TotalCount[2];
         g_slotAggCounts[p_slotNumber].m_Respondingops[i].m_SuccessCount[2]   +=m_stats->m_Respondingops[i].m_SuccessCount[2];
         g_slotAggCounts[p_slotNumber].m_Initiatingops[i].m_TotalCount[0]     += m_stats->m_Initiatingops[i].m_TotalCount[0];
         g_slotAggCounts[p_slotNumber].m_Initiatingops[i].m_SuccessCount[0]   += m_stats->m_Initiatingops[i].m_SuccessCount[0];
         g_slotAggCounts[p_slotNumber].m_Initiatingops[i].m_TotalCount[1]     += m_stats->m_Initiatingops[i].m_TotalCount[1];
         g_slotAggCounts[p_slotNumber].m_Initiatingops[i].m_SuccessCount[1]   += m_stats->m_Initiatingops[i].m_SuccessCount[1];
         g_slotAggCounts[p_slotNumber].m_Initiatingops[i].m_TotalCount[2]     += m_stats->m_Initiatingops[i].m_TotalCount[2];
         g_slotAggCounts[p_slotNumber].m_Initiatingops[i].m_SuccessCount[2]   += m_stats->m_Initiatingops[i].m_SuccessCount[2];
      }
   }
   DLOG(0,0,(char*)"  exit from the aggreagte  ");
   return true;
}


#endif




/*void convertStats(Stats *l_statsData,Cu_Stats* p_states)
  {

  DLOG(0,0,(char*)" enter to convertStats function");
  DLOG(0,0,(char*)" slotnumber in fun %d ", l_statsData->m_slotNumber);
  p_states->m_slotNumber=((Stats*)l_statsData)->m_slotNumber;
  for (int i=0; i<STATS_MAX_OP_CODES; i++)
  {
  p_states->m_Respondingops[i].m_TotalCount[0]   = ((Stats*)l_statsData)->m_Respondingops[i].m_TotalCount[0];
  p_states->m_Respondingops[i].m_SuccessCount[0] = ((Stats*)l_statsData)->m_Respondingops[i].m_SuccessCount[0];
  p_states->m_Respondingops[i].m_TotalCount[1]   = ((Stats*)l_statsData)->m_Respondingops[i].m_TotalCount[1];
  p_states->m_Respondingops[i].m_SuccessCount[1] = ((Stats*)l_statsData)->m_Respondingops[i].m_SuccessCount[1];
  p_states->m_Respondingops[i].m_TotalCount[2]   = ((Stats*)l_statsData)->m_Respondingops[i].m_TotalCount[2];
  p_states->m_Respondingops[i].m_SuccessCount[2] = ((Stats*)l_statsData)->m_Respondingops[i].m_SuccessCount[2];
  p_states->m_Initiatingops[i].m_TotalCount[0]   = ((Stats*)l_statsData)->m_Initiatingops[i].m_TotalCount[0];
  p_states->m_Initiatingops[i].m_SuccessCount[0] = ((Stats*)l_statsData)->m_Initiatingops[i].m_SuccessCount[0];
  p_states->m_Initiatingops[i].m_TotalCount[1]   = ((Stats*)l_statsData)->m_Initiatingops[i].m_TotalCount[1];
  p_states->m_Initiatingops[i].m_SuccessCount[1] = ((Stats*)l_statsData)->m_Initiatingops[i].m_SuccessCount[1];
  p_states->m_Initiatingops[i].m_TotalCount[2]   = ((Stats*)l_statsData)->m_Initiatingops[i].m_TotalCount[2];
  p_states->m_Initiatingops[i].m_SuccessCount[2] = ((Stats*)l_statsData)->m_Initiatingops[i].m_SuccessCount[2];
  }
  for (int i=0; i<STATS_MAX_APPL_CTXTS; i++)
  {
  p_states->m_Respondingappls[i].m_TotalCount[0]   = ((Stats*)l_statsData)->m_Respondingappls[i].m_TotalCount[0];
  p_states->m_Respondingappls[i].m_SuccessCount[0] = ((Stats*)l_statsData)->m_Respondingappls[i].m_SuccessCount[0];
  p_states->m_Respondingappls[i].m_TotalCount[1]   = ((Stats*)l_statsData)->m_Respondingappls[i].m_TotalCount[1];
  p_states->m_Respondingappls[i].m_SuccessCount[1] = ((Stats*)l_statsData)->m_Respondingappls[i].m_SuccessCount[1];
  p_states->m_Respondingappls[i].m_TotalCount[2]   = ((Stats*)l_statsData)->m_Respondingappls[i].m_TotalCount[2];
  p_states->m_Respondingappls[i].m_SuccessCount[2] = ((Stats*)l_statsData)->m_Respondingappls[i].m_SuccessCount[2];
  p_states->m_Initiatingappls[i].m_TotalCount[0]   = ((Stats*)l_statsData)->m_Initiatingappls[i].m_TotalCount[0];
  p_states->m_Initiatingappls[i].m_SuccessCount[0] = ((Stats*)l_statsData)->m_Initiatingappls[i].m_SuccessCount[0];
  p_states->m_Initiatingappls[i].m_TotalCount[1]   = ((Stats*)l_statsData)->m_Initiatingappls[i].m_TotalCount[1];
  p_states->m_Initiatingappls[i].m_SuccessCount[1] = ((Stats*)l_statsData)->m_Initiatingappls[i].m_SuccessCount[1];
  p_states->m_Initiatingappls[i].m_TotalCount[2]   = ((Stats*)l_statsData)->m_Initiatingappls[i].m_TotalCount[2];
  p_states->m_Initiatingappls[i].m_SuccessCount[2] = ((Stats*)l_statsData)->m_Initiatingappls[i].m_SuccessCount[2];

  }

  DLOG(0,0,(char*)" out slotnumber in fun %d ", p_states->m_slotNumber);
  DLOG(0,0,(char*)" exit  from convertStats  function");
  }


*/
