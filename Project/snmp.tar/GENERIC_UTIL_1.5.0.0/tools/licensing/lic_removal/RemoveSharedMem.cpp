#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <iostream.h>
#include <unistd.h>
#include <errno.h>
#include <fstream>
key_t g_Key;

int main(int argc, char *argv[])
{
   char l_FileName[100];
   char l_commd[40];
   char l_prodName[20];

   memset(l_commd,'\0',sizeof(l_commd));
   memset(l_prodName,'\0',sizeof(l_prodName));
   if(argc != 2 )
   {
      printf("\n Usage: ./licRemover <Product Name>\n\n");
      exit(1);
   }
   strncpy(l_prodName,argv[1],sizeof(l_prodName)-1);

   snprintf(l_FileName, sizeof(l_FileName), "/etc/%s.lic", l_prodName);
   g_Key = ftok(l_FileName, 1);
   sprintf(l_commd,"ipcrm -M %d",g_Key);
   system(l_commd);
   return 0;
}

