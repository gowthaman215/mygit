g++ -m64 RemoveSharedMem.cpp -o licRemover 
