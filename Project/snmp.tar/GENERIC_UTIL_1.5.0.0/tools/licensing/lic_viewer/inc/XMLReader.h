#ifndef XMLREADER_H
#define XMLREADER_H
#include<string>
#include<iostream>

using namespace std;
class XMLReader
{
   private:
      bool   IsString(char *);
      bool readInteger(string parent, string child, unsigned  int &value , unsigned int min, unsigned int max);
      bool  readInteger(string parent, string child, int &value , int min,int max);
      bool  readInteger(string parent, string child, short &value , int min, int max);
      bool  readString(string parent, string child,  char * ConfigValue,unsigned int min, unsigned int max);
      string readValue (string parent, string child);
      bool  readHex(string parent, string child, unsigned  int &value , unsigned int min, unsigned int max);
      unsigned int hexToInt(char *s, int len);
   public:
      XMLReader();
      ~XMLReader();
      char m_McaAddress[20];
      char m_HostId[20];
      char m_ProductName[20];
      int m_LicType;
      unsigned int m_NumSubscriber;
      int m_TransPsec;
      int m_NumInstance;
      char m_Action[2];
      bool readXMLData(char *p_xmldata);

      int m_ExitStatus;
};
extern XMLReader g_xmlData;

#endif

