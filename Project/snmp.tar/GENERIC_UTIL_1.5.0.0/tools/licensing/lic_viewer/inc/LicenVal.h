#ifndef INCL_LICENVAL_H
#define INCL_LICENVAL_H

#include <Codec.h>
#include <pthread.h>

#define BUF_LEN 500
#define KEY_LEN 8


class LicenVal: public Codec
{
   protected:
      char                 m_PlainData[BUF_LEN];
      char                 m_LFileData[BUF_LEN];
      static int s_Count;
      static int s_MaxInstance;


   public:
      ~LicenVal();
      LicenVal(){}
      static LicenVal* GetInstance();
      bool getInstanceNumber(char* p_MacAddr, char* p_HostId, char* p_ProdName,int& p_NumOfInst);
};
#endif

