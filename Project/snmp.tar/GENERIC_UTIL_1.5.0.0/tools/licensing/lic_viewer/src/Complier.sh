rm *.o
g++ ViewSharedMem.cpp -o ViewShamem  -lnsl -lpthread -lrt -lm -lstdc++ -lsocket -lcrypto -L/usr/local/ssl/lib/
