#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <iostream.h>
#include <unistd.h>
#include <errno.h>
#include <fstream>
#include <net/if.h>
#include <net/if_arp.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/sockio.h>
#include <errno.h>
#include <LicenVal.h>
key_t g_Key;
int g_NumOfInst;
char                 m_MacAddressList[10][30];
char                 m_HostId[20];
struct ProcDetails1
{
   pid_t m_PID;
   time_t m_TIME;
};
bool GetAllMacAddresses()
{
   char l_MacAddress[30];
   int   i,j,sock,nicount;
   char  octet[3];
   struct   arpreq arpreq;
   struct   ifreq nicnumber[24];
   struct   ifconf ifconf;

   memset(nicnumber,'\0',sizeof(nicnumber));
   memset(m_MacAddressList, '\0', sizeof(m_MacAddressList));
   memset(l_MacAddress, '\0', sizeof(l_MacAddress));

   if ((sock=socket(AF_INET,SOCK_DGRAM,0)) > -1) {
      ifconf.ifc_buf = (caddr_t)nicnumber;
      ifconf.ifc_len = sizeof(nicnumber);
   } else {
      printf("Could not create socket. [errno:%d, err:%s]\n", errno, strerror(errno));
      return false;
   }

   if (!ioctl(sock,SIOCGIFCONF,(char*)&ifconf)) 
   {
      nicount = ifconf.ifc_len/(sizeof(struct ifreq));

      for (i = 0; i <= nicount; i++) 
      { 
         memset(l_MacAddress,'\0',sizeof(l_MacAddress));
         //printf("Interface: %s\n", nicnumber[i].ifr_name);

         ((struct sockaddr_in*)&arpreq.arp_pa)->sin_addr.s_addr=
            ((struct sockaddr_in*)&nicnumber[i].ifr_addr)->sin_addr.s_addr;
         if (!(ioctl(sock,SIOCGARP,(char*)&arpreq))) {

            for (j = 0; j <= 5; j++) {
               snprintf(octet,sizeof(octet),"%02x",
                     (unsigned char)arpreq.arp_ha.sa_data[j]);
               strcat (l_MacAddress,octet);
            }
         }

         snprintf(m_MacAddressList[i], 30, "%s", l_MacAddress);
         //printf("MAC Address: %s\n", l_MacAddress);
      }
      close(sock);
   } 
   else {
      close(sock);
      printf("ioctl error. [errno:%d, err:%s]\n", errno, strerror(errno));
      return false;
   }

   //Host Id

   struct in_addr in;
   in.s_addr = gethostid();

   if (in.s_addr == INADDR_NONE) {
      printf("gethostid failed. [errno:%d, err:%s]\n", errno, strerror(errno));
      return false;
   }
   sprintf(m_HostId, "%x", in.s_addr);
   //printf("hostid: %x\n", in.s_addr);

   return true;
}

int main(int argc, char *argv[])
{
   char l_FileName[20];
   char l_commd[20];
   char l_prodName[20];

   memset(l_commd,'\0',sizeof(l_commd));
   memset(l_prodName,'\0',sizeof(l_prodName));
   if(argc != 2 )
   {
      printf(" \nUsage: ./Licenview <Product Name>\n\n");
      sleep(1);
      exit(1);
   }
   char l_prodname[20];
   memset(l_prodname,'\0',sizeof(l_prodname));
   strncpy(l_prodname,argv[1],20);
   if(false == GetAllMacAddresses())
   {
      printf("Getting MAC address & host id failed.");
      return 0;
   }

   for(int i=0; i<10; i++)
   {
      if(strlen(m_MacAddressList[i]) > 0)
      {
         //printf( "Validating MAC address %d\n", i+1);

         char l_lowerMac[30];
         memset(l_lowerMac, '\0', sizeof(l_lowerMac));
         char l_lowerHostid[20];
         memset(l_lowerHostid, '\0', sizeof(l_lowerHostid));
         for(int l_k=0; l_k<strlen(m_MacAddressList[i]); l_k++)
         {
            l_lowerMac[l_k] = tolower(m_MacAddressList[i][l_k]);
         }
         for(int l_k=0; l_k<strlen(m_HostId); l_k++)
         {
            l_lowerHostid[l_k] = tolower(m_HostId[l_k]);
         }
         LicenVal l_licenval;

         if(true == l_licenval.getInstanceNumber(l_lowerMac, l_lowerHostid, l_prodname,g_NumOfInst))
         {
            //printf( "Get Number Instance [%d] for MacAddress [%s]\n", g_NumOfInst,m_MacAddressList[i]);
            break;
         }
         else
         {
            //printf("Not Able not get the Number of Instance  for Mac Address%s.\n", m_MacAddressList[i]);
         }
      }
   }
   strcpy(l_prodName,argv[1]);
   snprintf(l_FileName, sizeof(l_FileName), "/etc/%s.lic", l_prodName);
   g_Key = ftok(l_FileName, 1);
   int l_ShmId;
   ProcDetails1 *l_ProcDetails;
   if (0 > (l_ShmId = shmget(g_Key, sizeof(ProcDetails1)*g_NumOfInst, 0)))
   {
      printf("\nError in getting mmm. [errno:%d, err:%s]\n", errno, strerror(errno));
      return false;
   }

   if((l_ProcDetails = (ProcDetails1*)shmat(l_ShmId, NULL, 0)) == (ProcDetails1*) -1)
   {
      printf("\nError in attaching mmm. [errno:%d, err:%s]\n", errno, strerror(errno));
      return false;
   }
   int l_activeInstance=0;
   printf("Process id\tStatus\tLast Updated Time\n");
   printf("**********\t******\t******************\n");
   for (int l_index=0 ;l_index < g_NumOfInst ;l_index++)
   {
      struct tm * timeinfo;
      timeinfo = localtime ( &(l_ProcDetails+l_index)->m_TIME );

      char l_status='I';
      int l_currTime = time(NULL);
      if(l_currTime < (11+((l_ProcDetails+l_index)->m_TIME)))
      {
         l_status='A';
      }

      printf("%d\t\t%c\t\%s",(l_ProcDetails+l_index)->m_PID,l_status, asctime(timeinfo));
      if((l_ProcDetails+l_index)->m_PID > 0)
      {
         l_activeInstance++;
      }
   }
   //printf("\t\tNumber of Active Instance [%d]\n",l_activeInstance);

   return 0;
}

