/************************************************************************
 ** FILE NAME    : ConfigReader.cpp
 ** AUTHOR       : 
 ** DEFINTION    : 
 ** REMARKS      :
 ************************************************************************/

#include "XMLReader.h"
#include "LicenseParser.h"
//#include "LicenVal.h"



XMLReader g_xmlData ; 

XMLReader::XMLReader()
{
   memset(m_McaAddress,'\0',sizeof(m_McaAddress));
   memset(m_HostId,'\0',sizeof(m_HostId));
   memset(m_ProductName,'\0',sizeof(m_ProductName));
   memset(m_Action,'\0',sizeof(m_Action));
   m_LicType=-1;
   m_NumSubscriber=0;
   m_TransPsec=0;
   m_ExitStatus=0;
}
XMLReader::~XMLReader()
{

}
bool XMLReader::IsString(char *st)
{
   int l_StrLength = strlen(st);

   for(int l_index=0; l_index < l_StrLength; l_index++)
      if (isalpha(st[l_index]))
         return false;

   return true;
}

string XMLReader::readValue (string parent, string child)
{
   string n = LicenseParser::getChildString (parent, child);
   string v = LicenseParser::getValue (n, child);
   return v;
}

bool XMLReader::readInteger(string parent, 
      string child, 
      int &ConfigValue,
      int min, 
      int max)
{
   string temp = readValue (parent, child);
   //cout << "\t" << child << " = " << temp << endl;

   if (false == IsString((char *)temp.c_str()))
   {
      cout << " Configuration Value not numeric." << endl;
      return false;
   }

   ConfigValue  = atoi(temp.c_str());
   if (min > ConfigValue  || max < ConfigValue)
   {
      cout <<  " Configuration Value not in valid range" << endl;
      return false;
   }
   return true;
}

bool  XMLReader::readInteger(string parent, 
      string child, 
      unsigned int &ConfigValue,
      unsigned int min, 
      unsigned int max)
{
   string temp = readValue (parent, child);
   //cout << "\t" << child << " = " << temp <<endl;

   if (false == IsString((char *)temp.c_str()))
   {
      cout << " Configuration Value not numeric." << endl;
      return false;
   }

   ConfigValue  = atoi(temp.c_str());
   if (min > ConfigValue  || max < ConfigValue)
   {
      cout << "  Configuration Value not in valid range" << endl; 
      return false;
   }
   return true;
}

bool  XMLReader::readInteger(string parent, 
      string child, 
      short &ConfigValue,
      int min, 
      int max)
{
   string temp = readValue (parent, child);
   //cout << "\t" << child << " = " << temp <<endl;

   if (false == IsString((char *)temp.c_str()))
   {
      cout <<"Configuration Value not numeric."<<endl;
      return false;
   }

   ConfigValue  = atoi(temp.c_str());
   if (min > ConfigValue  || max < ConfigValue)
   {
      cout <<"Configuration Value not in valid range"<<endl; 
      return false;
   }
   return true;
}

bool  XMLReader::readString(string  parent, string child,  char  *ConfigValue ,unsigned int min, unsigned int max) 
{
   string temp = readValue (parent, child);
   //cout <<"\t"<< child << " = " << temp <<endl;

   strcpy((char *)ConfigValue , temp.c_str()); 
   if(min > temp.size()|| max < temp.size())
   {
      cout <<"Invalid Configuration value length"<<endl;
      return false;
   }
   return true;
}
bool  XMLReader::readHex(string  parent, string child,  unsigned int  &ConfigValue ,unsigned int min, unsigned int max) 
{
   string temp = readValue (parent, child);
   //cout << "\t" << child << " = " << temp <<endl;

   //strcpy((char *)ConfigValue , temp.c_str()); 

   if(min > temp.size()|| max < temp.size())
   {
      cout <<"Invalid Configuration value length"<<endl;
      return false;
   }
   ConfigValue = hexToInt( (char *)temp.c_str(), temp.size()); 
   //cout << "Converted Int Value for Hex  "<<ConfigValue<<"  "<<temp.c_str()<<endl;
   return true;
}


unsigned int XMLReader::hexToInt(char *s, int len)
{
   int firsttime = 1;
   int found = 0;
   //int z=0;

   typedef   struct
   {
      char chr;
      int value;
   } CHexMap;

   int HexMapL = 22, i = 0;
   char *temp = s;

   CHexMap HexMap[22] =
   {
      {'0', 0}, {'1', 1},

      {'2', 2}, {'3', 3},

      {'4', 4}, {'5', 5},

      {'6', 6}, {'7', 7},

      {'8', 8}, {'9', 9},

      {'A', 10}, {'B', 11},

      {'a', 10}, {'b', 11},

      {'C', 12}, {'D', 13},

      {'c', 12}, {'d', 13},

      {'E', 14}, {'F', 15},

      {'e', 14}, {'f', 15}
   };

   //char *mstr = strdup(value);
   //char *s = mstr;

   unsigned int result = 0;//,j;
   //char ip[20],c;

   if (*s == '0' && *(s + 1) == 'X') s += 2;

#if 0
   IF IT IS IN BCD
      for(z=0; z<len; z++)
      {
         for(j=0; j<2; j++)
         {
            if(j==0)
               c = ( (*s & 0xF0) >> 4);
            else
               c = (*s & 0x0F);
            if(c<10)
               c+=48;
            else
               c+=55;
            ip[i]=c;
            i++;
         }
         s++;
      }
   ip[i]='\0';
   s=ip;
#endif
   while (*s != '\0')
   {
      for (i = 0; i < HexMapL; i++)
      {
         if (*s == HexMap[i].chr)
         {
            if (!firsttime) result <<= 4;
            result |= HexMap[i].value;
            found = 1;
            break;
         }
      }

      if (!found) break;

      s++;
      firsttime = 0;
   }  //End of while
   s = temp;
   return result;
}
bool  XMLReader::readXMLData(char *l_xmlstring)
{
   string l_string;
   l_string=l_xmlstring;
   string l_temp=LicenseParser::getChildString (l_string, "L");

   if(false == readString(l_temp, "M", (char *)g_xmlData.m_McaAddress, 8, sizeof(g_xmlData.m_McaAddress)-1))
   {
      printf("Unable to read MAC address from Lic");
      return false;
   }
   if(false == readString(l_temp, "H", (char *)g_xmlData.m_HostId, 6, sizeof(g_xmlData.m_HostId)-1))
   {
      printf("Unable to read Host Id from Lic");
      return false;
   }
   if(false == readString(l_temp, "P", (char *)g_xmlData.m_ProductName, 2, sizeof(g_xmlData.m_ProductName)-1))
   {
      printf("Unable to read Product Name from Lic");
      return false;
   }
   if(false == readInteger(l_temp, "T", g_xmlData.m_LicType, 0, 1))
   { 
      printf("Unable to read License Type from Lic");
      return false;
   }
   if(false == readInteger(l_temp, "S", g_xmlData.m_NumSubscriber, 1, 100000000))
   {
      printf("Unable to read Number of subscribers from Lic");
      return false;
   }
   if(false == readInteger(l_temp, "R", g_xmlData.m_TransPsec, 1, 200))
   {
      printf("Unable to read Trans per second from Lic");
      return false;
   }
   if(false == readInteger(l_temp, "I", g_xmlData.m_NumInstance, 1, 50))
   {
      printf("Unable to read Number of instances from Lic");
      return false;
   }
   if(false == readString(l_temp, "A", g_xmlData.m_Action, 1, 1))
   {
      printf("Unable to read Action from Lic");
      return false;
   }
   return true;
}
