/************************************************************************************
 * FILE NAME      : LicenVal.cpp
 * REMARKS        :
 *************************************************************************************/

#include <LicenVal.h>
#include "des.h"
#include "string.h"
#include <stdio.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/sockio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fstream>
#include <XMLReader.h>

using namespace std;
extern char       g_RandKey[10];
int LicenVal::s_Count = 0;
int LicenVal::s_MaxInstance = 1;
extern XMLReader  g_xmlData;


LicenVal *g_lic = NULL;

LicenVal::~LicenVal()
{
   --s_Count;
}

LicenVal* LicenVal::GetInstance()
{
   LicenVal* ptr = NULL;

   //if(s_MaxInstance > s_Count)
   if(g_lic == NULL)
   {
      g_lic = new LicenVal();
      ++s_Count;                           // Increment no of instances
   }
   return g_lic;
}


bool LicenVal::getInstanceNumber(char* p_MacAddr, char* p_HostId, char* p_ProdName, int& p_NumOfInst)
{
   //printf( "Validating license with MacAddr:%s\n", p_MacAddr);
   atohx(m_Key1, p_MacAddr);
   strcpy(m_Key2, p_HostId);
   memcpy(m_Key3, g_RandKey, sizeof(m_Key3));

   //Read the license file and store in m_LFileData and size in l_Len
   memset(m_PlainData, 0, sizeof(m_PlainData));
   memset(m_LFileData, 0, sizeof(m_LFileData));

   int l_Len=0;
   ifstream fp;
   char l_FileName[15];
   snprintf(l_FileName, sizeof(l_FileName), "/etc/%s.lic", p_ProdName);
   //printf( "Reading File: %s\n", l_FileName);
   fp.open(l_FileName,ifstream::binary);
   fp.seekg (0, ios::end);
   l_Len = fp.tellg();
   if(l_Len <= 0 )
   {
      fp.close();
      printf( "Unable to read the file: %s\n", l_FileName);
      return false;
   }
   //printf( "Len of data:%d\n", l_Len);
   fp.seekg(0, ios::beg);

   fp.read(m_LFileData, l_Len);
   fp.close();

   Cipher(m_LFileData, l_Len, m_PlainData, DES_DECRYPT);

   if(NULL == strstr(m_PlainData, p_MacAddr))
   {
      //printf( "MAC Address Validation failed\n");
      return false;
   }

   if(false == g_xmlData.readXMLData(m_PlainData))
   {
      printf( "XML parsing failed\n");
      return false;
   }

   if(!strcmp(g_xmlData.m_McaAddress,p_MacAddr))
   {
      //printf( "MAC Address Validated.\n");
   }
   else
   {
      //printf( "MAC Address Validation failed\n");
      return false;
   }
   if(!strcmp(g_xmlData.m_ProductName, p_ProdName))
   {
      //printf( "Product Name has been validated.\n");
   }
   else
   {
      printf( "Product Name Validation failed.\n");
      return false;
   }
   p_NumOfInst=g_xmlData.m_NumInstance;

   //Parse the m_PlainData and get the outputs LicenseType, SubscriberBase, TransactionBase, NumOfInst along with MAC address and host id

   //Compare MAC address, Host id and Product Name

   printf( "\nLicense Key : [ %s ]\n\n", m_PlainData);

   return true;
}
