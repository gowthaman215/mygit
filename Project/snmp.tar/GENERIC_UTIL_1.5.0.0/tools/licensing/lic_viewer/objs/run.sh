#LD_LIBRARY_PATH=/usr/sfw/lib/sparcv9/:/usr/local/ossasn1/solaris7-64bit/8.3.1/lib/:/export/home/sachi/CodeBase/PLATFORM_1.0.0.0/DB_CONN_STRING/translator_lib/libs/
LD_LIBRARY_PATH=/usr/sfw/lib/sparcv9/:/opt/product/mohan/HLR/license/generator/pkg/

