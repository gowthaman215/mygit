#ifndef __CONFIG_READER_H
#define __CONFIG_READER_H

#include <string.h>
#include <iostream.h>
#include <stdio.h>

#include <Parser.h>
#include <Logger.h>
#include <CommonDefines.h>
#include <DataType.h>
#define MAXAPPCONF			           99
#define MAX_TEMPLATES_COUNT           99
#define MAX_ADDRESS_COUNT           99
#define MAX_TRAPS_PER_TEMPLATE_COUNT  99
#define MAX_PART_COUNT                99

using namespace std;

extern Logger g_LoggerObj;

class ConfigData
{
   public:

      ConfigData();
      ~ConfigData();
      char	m_OID[100+1];
      int	m_SnmpAgentPort;
      int	m_ListenQSize;
      int   m_Traptime;
      int   m_DisableConnectionTrapsAtStartup;
      int   m_TrapSenderPoolSize;
      char  m_SnmpAgentName[100+1];

      string m_FilePath;
      string m_Prefix;
      string m_LogLevel;
      string m_LogMedia;
      int m_MaxFileSize;

      //Alarm related
      string m_alrm_entity;
      string m_alrm_id;
      string m_alrm_text;
      string m_alrm_type;
      string m_alrm_severity;
      string m_alrm_time;
      string m_alrm_agent_name;
      string m_alrm_threshold_info;

      int m_ToolEnabledFlag;
      int m_ToolPort;
};


class DynamicConfigData
{
   public:
      DynamicConfigData();
      ~DynamicConfigData();

      int                      m_defaultAgentServerId;
      int                      m_defaultAgentClientId;
      int                      m_defaultCountryId;
      map<string,DeviceInfo>   m_MasterDeviceName;
      list<PartitionInfo>      m_PartitionList;
      list<MangInfo>           m_ManIpPortList;
      map<int,list<TrapInfo> >  m_TrapInfoMap;
      map<string,list<string> > m_mail_listmap;
      Email_Address             m_email_Address;
};


class ConfigReader
{
   private:
      bool IsString(char *);
      bool IsInteger(char *);
      string readValue (string parent, string child);

   public:
      bool initStaticData();
      bool initDynamicData(DynamicConfigData **p_dcd, char *p_errorMsg);
      string i_errorMsg;
      bool readInteger(string parent, string child, unsigned  int &value , unsigned int min, unsigned int max);
      bool readInteger(string parent, string child, int &value , int min,int max);
      bool readInteger(string parent, string child, short &value , int min, int max);
      bool readString(string parent, string child,  char * ConfigValue,unsigned int min, unsigned int max);
      bool setSeverityDetails(string p_configstr,severity_Details *p_severity, char *p_errorMsg);
      char *getConfigPrint();
};



extern DynamicConfigData *g_dcd;
extern ConfigData *g_ConfigData;
extern ConfigReader g_ConfigReader;



#endif /* __CONFIG_READER_H */
