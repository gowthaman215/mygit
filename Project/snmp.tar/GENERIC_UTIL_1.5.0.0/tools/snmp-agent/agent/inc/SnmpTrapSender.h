#ifndef __SNMP_TRAP_SENDER_H
#define __SNMP_TRAP_SENDER_H

#include <DataType.h>

class SnmpTrapSender
{
   private:
      bool formSnmpPacketAndSend(ClientTrapRequest *l_clireq);

   public:
      SnmpTrapSender();
      ~SnmpTrapSender();
      bool sendHeartBeatTrap(char *p_DeviceNameWithIp, ETrapType p_TrapType, EHeartBeatType p_HeartBeatType, char*, DeviceInfo *p_di);
      bool sendClientTrap(char *p_XmlRequest);
      bool sendPartitionLimitTrap(char *p_path, ETrapType p_TrapType, int, int);
      bool sendSnmpAgentFailureTrap(char *p_trap_id, char *p_trap_desc, int p_trap_id);
      bool  emailTrapCheck(ClientTrapRequest *l_clireq, bool &p_seversitycheck, string &p_to, string &p_cc, string &p_bcc);
      bool setemailAddress(severity_Details p_severity, string &p_to , string &p_cc, string &p_bcc);
};

#endif
