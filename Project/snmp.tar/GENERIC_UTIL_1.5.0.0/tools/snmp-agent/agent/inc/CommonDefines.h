#ifndef COMMONDEFINES_H
#define COMMONDEFINES_H

#include <map>
#include <math.h>

#include "UniTypes.h"

#define MAXMSGS_MIN            1
#define MAXMSGS_MAX            32000
#define MAXSMSCOUNT_MIN        1
#define MAXSMSCOUNT_MAX        500
#define BLACKLIST_FILENAME_MIN 1
#define BLACKLIST_FILENAME_MAX 256 
#define STACK_NAME_MIN         1
#define STACK_NAME_MAX         20 
#define CONTROL_PROCESS_NAME_MIN         2 
#define CONTROL_PROCESS_NAME_MAX         30 
#define FILEPATH_MIN            2
#define FILEPATH_MAX            100
#define PREFIX_MIN              1
#define PREFIX_MAX              20
#define MAXFILESIZE_MIN         1000
#define CDRPATH_MIN            2
#define CDRPATH_MAX            100
#define MAXFILESIZE_MAX         1000000000
#define MAXCDRFILESIZE_MIN      1000
#define MAXCDRFILESIZE_MAX      10000000
#define DATABASESCHEMA_MIN   1
#define DATABASESCHEMA_MAX   20
#define HEARTBEATTIME_MIN 5
#define HEARTBEATTIME_MAX 20
#define TARIFFTIME_MIN 1
#define TARIFFTIME_MAX 5
#define INSTANCEID_MIN 1
#define INSTANCEID_MAX 5
#define PREFIXCODE_MIN 2
#define PREFIXCODE_MAX 5

#define MAXPOOLSIZE_MIN          0
#define MAXPOOLSIZE_MAX          400
#define MAXCDRFILETIME_MIN      50
#define MAXCDRFILETIME_MAX      300
#define LSSN_MIN      1
#define LSSN_MAX      254
#define IPADDR_MIN 4 
#define IPADDR_MAX 50
#define USERID_MIN 1
#define USERID_MAX 15
#define PASSWDDB_MIN 6
#define PASSWDB_MAX 15
#define DOMAIN_MIN 2
#define DOMAIN_MAX 6
#define SITEID_MIN  2
#define SITEID_MAX  4
#define MACHINEID_MIN 2
#define MACHINEID_MAX 4
#define TRUNKCODE_MIN 0
#define TRUNKCODE_MAX 10
#define OTHERDOMAIN_MIN 0
#define OTHERDOMAIN_MAX 4 
#define SRCINT_MIN 2
#define SRCINT_MAX 10
#define SRCINTGRP_MIN 2
#define SRCINTGRP_MAX 65
#define PORT_MAX   54000
#define PORT_MIN   1500
#define IPADDR_MIN1 4
#define IPADDR_MAX1 50
#define PORT_MAX1   55000
#define PORT_MIN1   1600

//SMSC Relay
#define     TC_SUCCESS                          1
#define     TC_FAILURE                          -1

#define     SMS_FACILITY_NOT_SUPPORTED          21
#define     SMS_SYSTEM_FAILURE                  34
#define     SMS_UNEXPECTED_DATA_VALUE           36
#define     SMS_SM_DELIVERY_FAILURE             32

#define     ALPHA_NUMERIC                       0x05

#define     SMSC_MSISDN_RANGE_MIN               9
#define     SMSC_MSISDN_RANGE_MAX               18

#endif /* COMMONDEFINES_H */
