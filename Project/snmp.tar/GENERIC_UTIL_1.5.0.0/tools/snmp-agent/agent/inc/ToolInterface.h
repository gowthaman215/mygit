#ifndef __TOOL_INTERFACE_H
#define __TOOL_INTERFACE_H

#include <MessageQueue.h>
#include <map>
using namespace std;

class ToolInterface
{
    public:
        ToolInterface();
        ~ToolInterface();

        bool initialize(int p_port);
    
};

extern ToolInterface g_ti;
extern MessageQueue *g_commandQueue;
extern bool processCommand(char *p_command);
extern map<string, int> g_TraceImsiMap;
extern map<string, int> g_TraceMsisdnMap;

#endif

