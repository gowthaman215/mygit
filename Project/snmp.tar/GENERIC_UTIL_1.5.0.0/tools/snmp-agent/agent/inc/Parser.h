#ifndef __PARSER_H
#define __PARSER_H

#include <string>
#include <list>
#include <map>

//#include "UniTypes.h"
#include <string>
using namespace std;

class Parser
{
public:
	// comments for the methods are in cpp file
	//	static string readXMLFile (char * filename);
	static string readXMLFile (char * filename);

	static string getRootName (string aI_sXMLFileString);
	
	static string getChildString (string aI_sParentString, string aI_sChildName);
	static string getValue (string aI_sParentString, string aI_sChildName);
	static list<string> getAllValues (string aI_sParentString, string aI_sChildName);

	static map <string, string> getAttributes (string aI_sParentString);
	static list<string> getAllChildStrings (string aI_sParentString, string aI_sChildName);


	static string trimString (string aI_sParentString);

private:
	Parser ();

};

#endif /* __PARSER_H */
