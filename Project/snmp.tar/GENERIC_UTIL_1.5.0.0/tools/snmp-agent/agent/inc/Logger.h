/***************************************************************
File:			Logger.h

Purpose		:	General Purpose Logging class. It can log data to 
4 different logging media, viz.
1) File			              -> LOG_MEDIA_FILE
2) Console		            -> LOG_MEDIA_CONSOLE
3) Visual Studio IDE	    -> LOG_MEDIA_IDE
4) Create New Console If  -> LOG_MEDIA_NEW_CONSOLE
Non Console Application.

Date		:	20/04/2008

Author	:	Sadiq
 ***************************************************************/
#ifndef LOGGER_H
#define LOGGER_H

#include <stdio.h>
#include <time.h>
#include <string>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdarg.h>
#include <dirent.h>

#include "UniTypes.h"

#ifdef SNMP_ENABLED
#include "Snmp.h"
#endif /* SNMP_ENABLED */

using namespace std;
// Logging Mode Constants
#define LOG_MEDIA_LOWER_LIMIT	1	// Define valid lower range for Logging Media
#define LOG_MEDIA_FILE		    1	// File Mode Logging
#define	LOG_MEDIA_CONSOLE	    2	// Console Mode Logging
#define	LOG_MEDIA_IDE		      3	// IDE Mode Logging
#define	LOG_MEDIA_NEW_CONSOLE	4	// New Console Window Mode Logging
#define LOG_MEDIA_UPPER_LIMIT	4	// Define valid upper range for Logging Mode

// Logging Level Constants
/*
#define LOG_LEVEL_LOWER_LIMIT	1	// Define valid lower range for Logging Level
#define	LOG_LEVEL_CRITICAL	  1	// Highest Priority (useful for delivered code) 
#define	LOG_LEVEL_WARNING	    2	// 
#define LOG_LEVEL_PERFORMANCE	    3	// 
#define LOG_LEVEL_NORMAL	    4	// 
#define LOG_LEVEL_DEBUG		    5	// Lowest Priority (useful for debugging purposes)
#define LOG_LEVEL_UPPER_LIMIT	5	// Define valid upper range for Logging Level
*/

#define LOG_LEVEL_LOWER_LIMIT	1	// Define valid lower range for Logging Level
#define LOG_LEVEL_ERROR	    1	// 
#define LOG_LEVEL_CRITICAL	  2	// Highest Priority (useful for delivered code) 
#define LOG_LEVEL_WARNING	    3	// 
#define LOG_LEVEL_TRACE	    4	// 
#define LOG_LEVEL_DEBUG		    5	// Lowest Priority (useful for debugging purposes)
#define LOG_LEVEL_UPPER_LIMIT	5	// Define valid upper range for Logging Level

// Error Code Defined for initialization routine
#define LOGGER_ERR_LEVEL	      1
#define LOGGER_ERR_MODE		      2
#define LOGGER_ERR_FILE		      3
#define LOGGER_ERR_NEW_CONSOLE	4
#define LOGGER_ERR_SEMAPHORE	  5
#define LOGGER_ERR_BUFFER	      6

// This is the max amount of time calling thread waits for the Logger mutex
#define LOGGER_WAIT_TIME 	    5000		// = 5 seconds

// Internal Buffer size 
#define	LOGGER_BUFFER_SIZE	  20000	// = 3 KBytes buffer

// Date string len used in log method
#define DATE_STRING_LEN		    25

// mPath maximum string size
#define PATH_MAX_SIZE		      260

// mModuleName maximum string size
#define MODULE_NAME_MAX_SIZE	50

// mModuleName maximum string size
#define LOG_MESSAGE_MAX_SIZE	LOGGER_BUFFER_SIZE - 100	// 2900

class Logger
{
   public:
      // UNIX specific Code
      unsigned long iLoggingThreshold;   // Stores currently selected Logging Threshold.
      unsigned long iLoggingMedia;       // Stores currently selected Logging Media.
      int iLoggerFileHandle;             // Stores file handle in case of File Mode Logging (LOG_MEDIA_FILE).
      char iLoggerBuffer[LOGGER_BUFFER_SIZE]; // Stores pointer to internal buffer.
      int  iLoggerConsoleHandle;         // Store new console window handle in case
                                          // of New Console Mode Logging(LOG_MEDIA_NEW_CONSOLE).
      pthread_mutex_t  cdrMutex;         // Store new console window handle in case
      
      pthread_mutexattr_t mattr;
      // This method resets the internal members
      void resetMembers();
      
      // Makes time stamp in string form
      char * makeTimeStamp();
      // Makes file name using specified path & file name
      char * makeFileName(char * mFileNameBuffer, char * mPath, char * mFilePrefix);
      // To preserve file name for relocation of file.
      char iFileName[200];
      // To specify at what size the file should be archived.
      long double iMaxFileSize;
      // Specifies the location where files are archived.
      char * iArchivalDirPath;
      char * iFilePath;
      char * iModuleName;
      
      volatile long i_SyncCount;
      
   public:	

      // Default Constructor
      Logger();	
      ~Logger();	

      /********************************************************************************
      //This method initailizes the Logger. All initializations such as opening a file, 
      //memory allocation, creating new console window etc. are done here.	
      //
      //Parameters:
      //
      //mLoggingThreshold -> Decides the logging threshold, all messages above this 
      //		threshold are ignored. Must be one of the log level constants 
      //		described above.
      //
      //mLoggingMedia -> Target Media. Must be one of the media constants described above.
      //
      //mPath -> Directory where the logging file has to be created. Required when logging 
      //		media is file, otherwise ignored.
      //
      // *****IMPORTANT: mPath string length should not exceed PATH_MAX_SIZE, 
      //	which is currently set to 260 characters.*****
      //		
      //mModuleName -> Module name, which has created this logger object. Required when 
      //		logging media is a file, otherwise ignored. 
      //		It is used for creating the file name for logging
      //
      // *****IMPORTANT: mModuleName string length should not exceed MODULE_NAME_MAX_SIZE, 
      //		which is currently set to 50 characters.*****
      //
      //File name format: "ModuleName_DD_MM_YYYY.log"
      //E.g. if the module name is rating engine & current date is 
      //10th December 2001 then the file name would be 
      //"RatingEngine_10_12_2001.log" 
      //
      //Return Value:
      //If the function succeeds, the return value is nonzero(TRUE).
       ********************************************************************************/
      bool initialize(unsigned long mLoggingThreshold, unsigned long mLoggingMedia, char * mPath, char * mModuleName,char * mArchivalDirPath,unsigned long mMaxFileSize); 

      /********************************************************************************
      // This method performs deallocation of resources such as closing files, 
      // memory deallocation, closing console window etc. 
      // Note: Subsequent  calls to log() method will return false.
       ********************************************************************************/
      void terminate();

      bool changeLogLevel(unsigned long mLoggingThreshold);
  
      /********************************************************************************
      //This method logs the message to the appropriate media. If the specified log level 
      //is greater (lower priority) than threshold set in initialize() method then message 
      //is simply ignored & false is returned. False value is also returned when log() method 
      //is called before a call to initialize() method has been made.
      //	
      //This method is implemented as printf() in C language & hence accepts any no. 
      //of arguments.E.g.
      //e.g Normal string passed, 
      //ratLogger->log(LOG_LEVEL_NORMAL, "THIS IS TEST DATA NO 1");
      //	
      //Something similar to printf() in C language
      //ratLogger->log(LOG_LEVEL_WARNING, "THIS IS TEST DATA NO %i",2);
      //	
      //Important: It is strongly recommended that the calling thread should pass the class 
      //name & method name as part of the message, so that logs are clear enough. e.g.	
      //ratLogger->log(LOG_LEVEL_WARNING, "RatingController:rate(): THIS IS 
      //							TEST DATA NO %i",2);
      //
      //where "RatingController" is the class name and "rate()" is the method name.
      //	
      //Parameters:
      //
      //mLoggingLevel -> The log level of the current message.
      //
      //mLogMessage -> Message to be logged.
      // *****IMPORTANT: mLogMessage string length should not exceed LOG_MESSAGE_MAX_SIZE, 
      //		which is currently set to LOGGER_BUFFER_SIZE - 100, i.e  2900 characters.*****	
      //
      //Return Value:
      //If the function succeeds, the return value is nonzero(TRUE).
       ********************************************************************************/
      bool log(unsigned long mLoggingLevel, char * mLogMessage, ...);

      long getLoggerSyncCount();
      //TLGB0113 (SB - 80)
      unsigned long getLoggingThreshold();
      bool setLoggingThreshold(unsigned long m_newLogLevel);


};

// Declare the global Logger class object
extern Logger g_LoggerObj;

#define ENTER_FUNC g_LoggerObj.log(LOG_LEVEL_DEBUG, "%s<Line: %d> Entered.", __FUNCTION__, __LINE__);
#define EXIT_FUNC g_LoggerObj.log(LOG_LEVEL_DEBUG, "%s<Line: %d> Exit.", __FUNCTION__, __LINE__);

#define DLOG(...)  if(LOG_LEVEL_DEBUG   <= g_LoggerObj.iLoggingThreshold) { g_LoggerObj.log(LOG_LEVEL_DEBUG,    __VA_ARGS__);  }   
#define TLOG(...)  if(LOG_LEVEL_TRACE   <= g_LoggerObj.iLoggingThreshold) { g_LoggerObj.log(LOG_LEVEL_TRACE,    __VA_ARGS__);  }   
#define LLOG(...)  if(LOG_LEVEL_LOAD    <= g_LoggerObj.iLoggingThreshold) { g_LoggerObj.log(LOG_LEVEL_LOAD,     __VA_ARGS__);  }   
#define WLOG(...)  if(LOG_LEVEL_WARNING <= g_LoggerObj.iLoggingThreshold) { g_LoggerObj.log(LOG_LEVEL_WARNING,  __VA_ARGS__);  }   
#define CLOG(...)  if(LOG_LEVEL_CRITICAL<= g_LoggerObj.iLoggingThreshold) { g_LoggerObj.log(LOG_LEVEL_CRITICAL, __VA_ARGS__);  }   
#define ELOG(...)  if(LOG_LEVEL_ERROR   <= g_LoggerObj.iLoggingThreshold) { g_LoggerObj.log(LOG_LEVEL_ERROR,    __VA_ARGS__);  } 




#endif	/* LOGGER_H */
