#ifndef __DATA_TYPE__H_
#define __DATA_TYPE__H_

#include<string>
#include<map>
#include<list>
using namespace std;

typedef enum
{
   DISC_TRAP=1,
   NOT_REGISTERED_TRAP
}ETrapType;

typedef enum
{
   HEART_BEAT_NORMAL=1,
   HEART_BEAT_SCHEDULED,
   HEART_BEAT_AGENT
}EHeartBeatType;

typedef enum
{
   ST_NOT_REGISTERED,
   ST_REGISTERED
}DeviceState;

struct DeviceInfo 
{
   string ip_address;
   string device_name;
   int templateid;
   int instance_seq_id;
   int server_id;
   int country_id;
   int product_id;
   int client_id;
   int sub_product_id;
};

struct FdInfo
{
   DeviceState state;
   string device_name;
   string device_on_off;
   string ip_address;
   list<string> commandsupport;
   DeviceInfo device_info;
   FdInfo();
};
struct TrapInfo
{
   char  id[64];
   int interval;
};

struct Address_String
{
   int add_flag;
   list<string> recipient_name;
};

struct severity_Details
{
   int flag;
   Address_String to_recipient_name;
   Address_String cc_recipient_name;
   Address_String bcc_recipient_name;
};
struct Email_Address
{
   int flag;
   string ip_address;
   string s_from_address;
   severity_Details critical_email_list;
   severity_Details major_email_list;
   severity_Details minor_email_list;
   severity_Details warning_email_list;
};

struct ClientTrapRequest
{
   string m_orig_equip;
   string m_clalrm_id;
   string m_clitext;
   string m_clitype;
   string m_cliseverity;
   string m_clitime;
   string m_ipaddress;
   string m_threshold_info;
   string m_server_id;
   string m_country_id;
   string m_product_id;
   string m_instance_seq_id;
   string m_unique_trap_seq_id;
   string m_client_id;
   string m_sub_product_id;
};

typedef struct MangInfo
{
   string ip;
   string port;
   string device_on_off;
};


typedef struct PartitionInfo
{
   string dir_on_off;
   string dir;
   int    limit;
   int    fail_sent;
};
#endif
