#ifndef __MESSAGE_QUEUE_H
#define __MESSAGE_QUEUE_H

#include <deque>
#include <semaphore.h>
#include <pthread.h>

using namespace std;

enum EQueueType
{
    QUEUE_TYPE_BLOCKING=0,
    QUEUE_TYPE_NON_BLOCKING
};


class MessageQueue
{
    public:
        MessageQueue(EQueueType p_QueueType);
        ~MessageQueue();

        bool initialize();
        bool push(void *p_qm);
        bool pop(void **p_qm);
        int size();

    private:
        deque<void*> m_q;
        pthread_mutex_t m_q_mutex;
        sem_t m_semaphore;


        EQueueType m_QueueType;

};

#endif

