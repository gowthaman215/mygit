#ifndef __BUFFER_DATA_H
#define __BUFFER_DATA_H

class BufferData
{
    public:
        BufferData();
        ~BufferData();

        int m_length;
        unsigned char *m_data;
};

#endif

