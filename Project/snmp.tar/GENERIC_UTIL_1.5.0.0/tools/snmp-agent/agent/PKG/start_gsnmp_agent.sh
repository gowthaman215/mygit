#PATH should contain the path where the binary snmptrap is present
PATH=$PATH:/usr/sfw/lib/:
echo $PATH

export LD_LIBRARY_PATH=/opt/ulcm/library/
echo $LD_LIBRARY_PATH

./gsnmpagent
