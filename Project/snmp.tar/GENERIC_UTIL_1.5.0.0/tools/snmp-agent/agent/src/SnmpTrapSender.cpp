#include <string>
#include <strings.h>
#include <time.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <ConfigReader.h>
#include <SnmpTrapSender.h>
#include <Logger.h>
#include <DataType.h>
#include <MessageQueue.h>
using namespace std;


map<int,FdInfo> g_FdInfoMap;
extern MessageQueue *g_snmpTrapQueue;
extern MessageQueue *g_snmpEmailQueue;
extern DynamicConfigData *g_dcd;

FdInfo::FdInfo()
{
   state=ST_NOT_REGISTERED;
}



SnmpTrapSender::SnmpTrapSender()
{

}

SnmpTrapSender::~SnmpTrapSender()
{

}




//code for snmp trap command formation based on the client request through xml file
bool SnmpTrapSender::formSnmpPacketAndSend(ClientTrapRequest *l_clireq)
{

   list<MangInfo>::iterator l_mi;

   l_mi=g_dcd->m_ManIpPortList.begin();
   while(l_mi!=g_dcd->m_ManIpPortList.end())
   {

      string str="";
      string mailstr="";
      string mailstr1="";
      string mailstr2="";
      string mailstr3="";
      string manip="";
      string manport="";

      manip=((*l_mi).ip);
      manport=((*l_mi).port);
      string tostr="";
      string ccstr="";
      string bccstr="";
      bool l_emailtrapcheck = false;

      emailTrapCheck(l_clireq, l_emailtrapcheck, tostr, ccstr, bccstr);

      string l_oidToBeSent = g_ConfigData->m_OID;
      if(l_clireq->m_instance_seq_id.size() > 0)
      {
         l_oidToBeSent += ".";
         l_oidToBeSent += l_clireq->m_client_id; 
         l_oidToBeSent += ".";
         l_oidToBeSent += l_clireq->m_server_id; 
         l_oidToBeSent += ".";
         l_oidToBeSent += l_clireq->m_country_id;
         l_oidToBeSent += ".";
         l_oidToBeSent += l_clireq->m_product_id; 
         l_oidToBeSent += ".";
         l_oidToBeSent += l_clireq->m_sub_product_id; 
         l_oidToBeSent += ".";
         l_oidToBeSent += l_clireq->m_instance_seq_id;
         l_oidToBeSent += ".";
         l_oidToBeSent += l_clireq->m_unique_trap_seq_id;
         l_oidToBeSent += ".";
         if(0 == strcmp(l_clireq->m_clitype.c_str(), "fail"))
         {
            l_oidToBeSent += "0";
         }
         else if(0 == strcmp(l_clireq->m_clitype.c_str(), "pass"))
         {
            l_oidToBeSent += "1";
         }
         else 
         {
            l_oidToBeSent += "2";
         }
      }




      str += string("snmptrap -v 2c -d -c Plintron ") + manip + ":" + manport + string(" ") + (" 1753 ") + l_oidToBeSent + \
             string(" ") + string(g_ConfigData->m_alrm_entity) + string(" s ") + \
             string(l_clireq->m_orig_equip)+ string(" ") + string(g_ConfigData->m_alrm_id) + string(" s ") + string(l_clireq->m_clalrm_id)  + \
             string(" ") + string(g_ConfigData->m_alrm_type) + string(" s ") + \
             string(l_clireq->m_clitype)+ string(" ")+  string(g_ConfigData->m_alrm_text) + \
             string(" s ") + string("\"") + string(l_clireq->m_clitext)+ string("\"")  + string(" ") + string(g_ConfigData->m_alrm_severity) + \
             string(" s ") + string(l_clireq->m_cliseverity)+ string(" ") + \
             string(g_ConfigData->m_alrm_time) + string(" s ") + string("\"") + \
             string(l_clireq->m_clitime) + string("\"") + \
             string(" ") + string(g_ConfigData->m_alrm_agent_name) + string(" s ") + string("\"") + \
             string(g_ConfigData->m_SnmpAgentName) + string("\"") + string(" ") + string(g_ConfigData->m_alrm_threshold_info) + \
             string(" s ") + string("\"") + string(l_clireq->m_threshold_info) + string("\"") + string(" 2>&1");

      DLOG("snmp trap command formation based on the client request: [%s]", str.c_str());
      char *l_temp = new char[str.length()+1];
      memset(l_temp, '\0', str.length()+1);
      strncpy(l_temp, str.c_str(), str.length());

#if 0
      if(true == l_emailtrapcheck )
      {
         mailstr +=  string("./mailsend") + string(" " ) + string("-f") + string(" ") + string(g_dcd->m_email_Address.s_from_address) + \
                     string(" ") +("-smtp") + string(" ") + \
                     string(g_dcd->m_email_Address.ip_address) + string(" ") + string("-t") + string(" ") + tostr  + string(" ") + string("-sub") + \
                     string(" ") + string(l_clireq->m_cliseverity) + string(g_ConfigData->m_alrm_entity) + string(l_clireq->m_clalrm_id) + string(" ");
         if(ccstr.empty())
         {
            mailstr1 += mailstr + string("+cc") + string(" ") ;
         }
         else 
         {
            mailstr1 += mailstr + string("-cc") + string(" ") + ccstr + string(" ") ;
         }
         if(bccstr.empty())
         {
            mailstr2 += mailstr1 + string("+bcc") + string(" ") ;
         }
         else
         {
            mailstr2 += mailstr1 + string("-bc") + string(" ") +  bccstr + string(" ");
         }

         mailstr3 += mailstr2 + string("-M") + string(" ") + string("\"") + string(g_ConfigData->m_OID) + string(" ") + string(g_ConfigData->m_alrm_entity) +  \
                     string(" s ") + string(l_clireq->m_orig_equip)+ string(" ") + string(g_ConfigData->m_alrm_id) +  string(" s ") + \
                     string(l_clireq->m_clalrm_id) + string(" ") + string(g_ConfigData->m_alrm_type) + string(" s ") + \
                     string(l_clireq->m_clitype) + string(" ")+  string(g_ConfigData->m_alrm_text) + \
                     string(" s ") + string (" " )+ string(l_clireq->m_clitext) +  string(" ") + string(g_ConfigData->m_alrm_severity) + \
                     string(" s ") + string(l_clireq->m_cliseverity) + string(" ") + \
                     string(g_ConfigData->m_alrm_time) + string(" s ") + string(" ") + string(l_clireq->m_clitime) + \
                     string(" ") + string(g_ConfigData->m_alrm_agent_name) + string(" s ") + string(" ") + string(g_ConfigData->m_SnmpAgentName) + \
                     string(" ") + string(g_ConfigData->m_alrm_threshold_info) + string(" ") + string(" s ") + string(" ") + \
                     string(l_clireq->m_threshold_info) + string(" ") + string(" 2>&1") + string("\""); 

         char *l_temp1 = new char[mailstr3.length()+1];
         memset(l_temp1, '\0', mailstr3.length()+1);
         strncpy(l_temp1, mailstr3.c_str(), mailstr3.length());
         g_snmpEmailQueue->push(l_temp1);
         DLOG("Sending email based on the client request: [%s]", mailstr3.c_str());
      }
#endif

      g_snmpTrapQueue->push(l_temp);
      l_mi++;

   }
   return true;
}
bool SnmpTrapSender::emailTrapCheck(ClientTrapRequest *l_clireq, bool &p_seversitycheck, string &p_to, string &p_cc, string &p_bcc)
{

   DLOG("Client Severity :[%s]",l_clireq->m_cliseverity.c_str());
   if(NULL != strstr(l_clireq->m_cliseverity.c_str(), "Critical"))
   {
      if(1 == g_dcd->m_email_Address.critical_email_list.flag)
      {
         p_seversitycheck = true;
         setemailAddress(g_dcd->m_email_Address.critical_email_list,p_to, p_cc, p_bcc);
         return p_seversitycheck;
      }
   }
   else if(NULL != strstr(l_clireq->m_cliseverity.c_str(), "Major"))
   {
      if(1 == g_dcd->m_email_Address.major_email_list.flag)
      {
         p_seversitycheck = true;
         setemailAddress(g_dcd->m_email_Address.major_email_list,p_to, p_cc, p_bcc);
         return p_seversitycheck;
      }
   }
   else if(NULL != strstr(l_clireq->m_cliseverity.c_str(), "Minor"))
   {
      DLOG("Minor Trap Email enable: [%d] ",g_dcd->m_email_Address.minor_email_list.flag);
      if(1 == g_dcd->m_email_Address.minor_email_list.flag)
      {
         p_seversitycheck = true;
         setemailAddress(g_dcd->m_email_Address.minor_email_list,p_to, p_cc, p_bcc);
         return p_seversitycheck;
      }
   }
   else if(NULL != strstr(l_clireq->m_cliseverity.c_str(), "Warning"))
   {
      if(1 == g_dcd->m_email_Address.warning_email_list.flag)
      {
         p_seversitycheck = true;
         setemailAddress(g_dcd->m_email_Address.warning_email_list,p_to, p_cc, p_bcc);
         return p_seversitycheck;
      }
   }
   return p_seversitycheck;
}
bool SnmpTrapSender::setemailAddress(severity_Details p_severity, string &p_to , string &p_cc, string &p_bcc)
{
   if(1 == p_severity.to_recipient_name.add_flag)
   {
      DLOG("To Recipient flag enabel ");
      list<string>::iterator i_itr;
      for(i_itr = p_severity.to_recipient_name.recipient_name.begin(); i_itr != p_severity.to_recipient_name.recipient_name.end(); i_itr++)
      {
         map<string, list<string> >::iterator l_mtr;
         l_mtr = g_dcd->m_mail_listmap.find(*i_itr);
         if(l_mtr != g_dcd->m_mail_listmap.end())
         {
            list<string>::iterator l_itr;
            for(l_itr = l_mtr->second.begin(); l_itr != l_mtr->second.end(); l_itr++)
            {
               DLOG("Group Name :%s Size of the list: %s",(*i_itr).c_str(),(*l_itr).c_str());
               p_to += (*l_itr) + string(",");
            }
         }
      }
   }
   if(1 == p_severity.cc_recipient_name.add_flag)
   {
      DLOG("CC Recipient flag enabel ");
      list<string>::iterator i_itr;
      for(i_itr = p_severity.cc_recipient_name.recipient_name.begin(); i_itr != p_severity.cc_recipient_name.recipient_name.end(); i_itr++)
      {
         map<string, list<string> >::iterator l_mtr;
         l_mtr = g_dcd->m_mail_listmap.find(*i_itr);
         if(l_mtr != g_dcd->m_mail_listmap.end())
         {
            list<string>::iterator l_itr;
            for(l_itr = l_mtr->second.begin(); l_itr != l_mtr->second.end(); l_itr++)
            {
               p_cc += (*l_itr) + string(",");
            }
         }
      }
   }
   if(1 == p_severity.bcc_recipient_name.add_flag)
   {
      DLOG("Bcc Recipient flag enabel ");
      list<string>::iterator i_itr;
      for(i_itr = p_severity.bcc_recipient_name.recipient_name.begin(); i_itr != p_severity.bcc_recipient_name.recipient_name.end(); i_itr++)
      {
         map<string, list<string> >::iterator l_mtr;
         l_mtr = g_dcd->m_mail_listmap.find(*i_itr);
         if(l_mtr != g_dcd->m_mail_listmap.end())
         {
            list<string>::iterator l_itr;
            for(l_itr = l_mtr->second.begin(); l_itr != l_mtr->second.end(); l_itr++)
            {
               p_bcc += (*l_itr) + string(",");
            }
         }
      }
   }
   return true;
}
//Sending the heart beat traps in the case of client disconnected state and client not registered state.
bool SnmpTrapSender::sendHeartBeatTrap(char *p_DeviceNameWithIp, ETrapType p_TrapType, EHeartBeatType p_HeartBeatType, char *p_clientDate,
      DeviceInfo *p_di)
{

   DLOG( "Entered the sendHeartBeatTrap");
   if (0 == strlen(p_DeviceNameWithIp))
   {
      printf("\np_DeviceNameWithIp is NULL");
      return false;
   }

   ClientTrapRequest l_clireq;
   if(p_TrapType==DISC_TRAP)
   {
      l_clireq.m_clitype="fail";
      l_clireq.m_cliseverity="Critical";

   }
   else if(p_TrapType==NOT_REGISTERED_TRAP)
   {
      l_clireq.m_clitype="pass";
      l_clireq.m_cliseverity="Minor";
   }

   l_clireq.m_orig_equip=p_DeviceNameWithIp;
   l_clireq.m_clalrm_id="HEALTH";
   if(HEART_BEAT_NORMAL == p_HeartBeatType)
   {
      l_clireq.m_clitext= "The health of the entity sent at entity connection/disconnection time";
   }
   else if(HEART_BEAT_AGENT == p_HeartBeatType)
   {
      l_clireq.m_clitext= "Agent Startup";
   }
   else
   {
      l_clireq.m_clitext= "The health of the entity sent at Heart-Beat check interval";
   }
   //l_clireq.m_cliseverity="Minor";

   if (p_clientDate != NULL)
   {
      l_clireq.m_clitime=p_clientDate;
   }
   else
   {
      char *l_dateString=NULL;
      struct tm *tm_ptr=NULL;
      time_t l_tim =time(NULL);
      tm_ptr = localtime(&l_tim);
      l_dateString = asctime(tm_ptr);
      l_dateString[24] = 0;

      l_clireq.m_clitime=l_dateString;
   }
   l_clireq.m_threshold_info = "Not Applicable";

   char l_text[1000+1];
   if(NULL != p_di)
   {
      snprintf(l_text, sizeof(l_text), "%d", p_di->client_id);
   }
   else
   {
      snprintf(l_text, sizeof(l_text), "%d", g_dcd->m_defaultAgentClientId);
   }
   l_clireq.m_client_id= l_text;

   if(NULL != p_di)
   {
      snprintf(l_text, sizeof(l_text), "%d", p_di->server_id);
   }
   else
   {
      snprintf(l_text, sizeof(l_text), "%d", g_dcd->m_defaultAgentServerId);
   }
   l_clireq.m_server_id= l_text;

   if(NULL != p_di)
   {
      snprintf(l_text, sizeof(l_text), "%d", p_di->country_id);
   }
   else
   {
      snprintf(l_text, sizeof(l_text), "%d", g_dcd->m_defaultCountryId);
   }
   l_clireq.m_country_id= l_text;

   if(NULL != p_di)
   {
      snprintf(l_text, sizeof(l_text), "%d", p_di->product_id);
   }
   else
   {
      snprintf(l_text, sizeof(l_text), "%d", 0);
   }
   l_clireq.m_product_id= l_text; 

   if(NULL != p_di)
   {
      snprintf(l_text, sizeof(l_text), "%d", p_di->sub_product_id);
   }
   else
   {
      snprintf(l_text, sizeof(l_text), "%d", 1);
   }
   l_clireq.m_sub_product_id= l_text; 

   if(NULL != p_di)
   {
      snprintf(l_text, sizeof(l_text), "%d", p_di->instance_seq_id);
   }
   else
   {
      snprintf(l_text, sizeof(l_text), "%d", 1);
   }
   l_clireq.m_instance_seq_id= l_text; //Assuming single instance of the SNMP Agent

   l_clireq.m_unique_trap_seq_id = "0";

   TLOG( "Sending HeartBeat Trap: %s  %s", p_DeviceNameWithIp,l_clireq.m_clitype.c_str());

   return formSnmpPacketAndSend(&l_clireq);
}

//Sending the partition trap
bool SnmpTrapSender::sendPartitionLimitTrap(char *p_path, ETrapType p_TrapType, int p_currentSize, int p_configuredLimit)
{
   DLOG( "Entered the sendPartitionLimitTrap");

   ClientTrapRequest l_clireq;
   char l_text[1000];
   memset(l_text, '\0', sizeof(l_text));
   if(p_TrapType==DISC_TRAP)
   {
      l_clireq.m_clitype="fail";
      l_clireq.m_cliseverity="Critical";
      sprintf(l_text, "Partition Limit exceeded. Currently %d%% (Configured Threshold is %d%%)", p_currentSize, p_configuredLimit);
   }
   else if(p_TrapType==NOT_REGISTERED_TRAP)
   {
      l_clireq.m_clitype="pass";
      l_clireq.m_cliseverity="Minor";
      sprintf(l_text, "Partition Limit is now available. Currently %d%% (Configured Threshold is %d%%)", p_currentSize, p_configuredLimit);
   }

   l_clireq.m_orig_equip=p_path;
   l_clireq.m_clalrm_id="PARTITION";
   l_clireq.m_clitext= l_text;

   snprintf(l_text, sizeof(l_text), "%d", g_dcd->m_defaultAgentServerId);
   l_clireq.m_server_id= l_text;

   snprintf(l_text, sizeof(l_text), "%d", g_dcd->m_defaultCountryId);
   l_clireq.m_country_id= l_text;

   snprintf(l_text, sizeof(l_text), "%d", g_dcd->m_defaultAgentClientId);
   l_clireq.m_client_id= l_text;

   l_clireq.m_product_id= "0"; //Since Generic Utilities itself
   l_clireq.m_sub_product_id= "1"; //Since Generic Utilities itself
   l_clireq.m_instance_seq_id= "1"; //Assuming single instance of the SNMP Agent
   l_clireq.m_unique_trap_seq_id = "1";

   char *l_dateString=NULL;
   struct tm *tm_ptr=NULL;
   time_t l_tim =time(NULL);
   tm_ptr = localtime(&l_tim);
   l_dateString = asctime(tm_ptr);
   l_dateString[24] = 0;

   l_clireq.m_clitime=l_dateString;
   l_clireq.m_threshold_info = "Not Applicable";

   return formSnmpPacketAndSend(&l_clireq);
}

//Sending the failures from SNMP Agent traps
bool SnmpTrapSender::sendSnmpAgentFailureTrap(char *p_trap_id, char *p_trap_desc, int p_trap_unique_id)
{
   DLOG( "Entered the sendSnmpAgentFailureTrap");

   ClientTrapRequest l_clireq;
   l_clireq.m_clitype="fail";
   l_clireq.m_cliseverity="Critical";
   l_clireq.m_orig_equip="ERRORS";
   l_clireq.m_clalrm_id=p_trap_id;
   l_clireq.m_clitext= p_trap_desc;

   char *l_dateString=NULL;
   struct tm *tm_ptr=NULL;
   time_t l_tim =time(NULL);
   tm_ptr = localtime(&l_tim);
   l_dateString = asctime(tm_ptr);
   l_dateString[24] = 0;

   l_clireq.m_clitime=l_dateString;

   l_clireq.m_threshold_info = "Not Applicable";

   char l_text[100+1];

   snprintf(l_text, sizeof(l_text), "%d", g_dcd->m_defaultAgentServerId);
   l_clireq.m_server_id= l_text;

   snprintf(l_text, sizeof(l_text), "%d", g_dcd->m_defaultCountryId);
   l_clireq.m_country_id= l_text;

   snprintf(l_text, sizeof(l_text), "%d", g_dcd->m_defaultAgentClientId);
   l_clireq.m_client_id= l_text;

   l_clireq.m_product_id= "0"; //Since Generic Utilities itself
   l_clireq.m_sub_product_id= "0"; //Since Generic Utilities itself
   l_clireq.m_instance_seq_id= "1"; //Assuming single instance of the SNMP Agent

   snprintf(l_text, sizeof(l_text), "%d", p_trap_unique_id);
   l_clireq.m_unique_trap_seq_id = l_text;
   return formSnmpPacketAndSend(&l_clireq);
}


//parsing the client xml request,storing the parsed values in ClientTrapRequest structure and sending to formSnmpPacketAndSend()
bool SnmpTrapSender::sendClientTrap(char *p_XmlRequest)
{
   if (p_XmlRequest == NULL)
   {
      printf("\nInvalid XML Request. Not Sending the trap");
      return false;
   }

   ClientTrapRequest l_clireq;

   char l_temp[128+1];
   string l_cliRequestAttr = Parser::getChildString(p_XmlRequest,"REQUEST");

   memset(l_temp,'\0',128+1);
   if(false == g_ConfigReader.readString(l_cliRequestAttr, "ORIG_EQUIP",l_temp, 1, 128))
   {
      printf("\nORIG_EQUIP not present in the XML request");
      return false;
   }

   l_clireq.m_orig_equip=l_temp;

   memset(l_temp,'\0',128+1);
   if(false == g_ConfigReader.readString(l_cliRequestAttr, "ALARM_ID",l_temp, 1, 128))
   {
      printf("\nALRM_ID not present in the XML request");
      return false;
   }
   l_clireq.m_clalrm_id=l_temp;

   memset(l_temp,'\0',128+1);
   if(false == g_ConfigReader.readString(l_cliRequestAttr, "TEXT",l_temp, 1, 128))
   {
      printf("\nTEXT not present in the XML request");
      return false;
   }
   l_clireq.m_clitext=l_temp;

   memset(l_temp,'\0',128+1);
   if(false == g_ConfigReader.readString(l_cliRequestAttr, "TYPE",l_temp, 1, 128))
   {
      printf("\nTYPE not present in the XML request");
      return false;
   }
   l_clireq.m_clitype=l_temp;

   memset(l_temp,'\0',128+1);
   if(false == g_ConfigReader.readString(l_cliRequestAttr, "SEVERITY",l_temp, 1, 128))
   {
      printf("\nSEVERITY not present in the XML request");
      return false;
   }
   l_clireq.m_cliseverity=l_temp;

   memset(l_temp,'\0',128+1);
   if(false == g_ConfigReader.readString(l_cliRequestAttr, "DATETIME",l_temp, 0, 128))
   {
      printf("\nDATETIME not present in the XML request");
      return false;
   }
   l_clireq.m_clitime=l_temp;

   memset(l_temp,'\0',128+1);
   if(false == g_ConfigReader.readString(l_cliRequestAttr, "IP_ADDRESS",l_temp, 0, 128))
   {
      printf("\nIP_ADDRESS not present in the XML request");
      return false;
   }
   l_clireq.m_ipaddress=l_temp;

   memset(l_temp,'\0',128+1);
   if(false == g_ConfigReader.readString(l_cliRequestAttr, "THRESHOLD_INFO",l_temp, 0, 128))
   {
      printf("\nTHRESHOLD_INFO not present in the XML request");
      return false;
   }
   l_clireq.m_threshold_info=l_temp;


   if(NULL != strstr(p_XmlRequest, "<SERVER_DATA>"))
   {
      memset(l_temp,'\0',128+1);
      if(false == g_ConfigReader.readString(l_cliRequestAttr, "SERVER_ID",l_temp, 0, 128))
      {
         printf("\nSERVER_ID not present in the XML request");
         return false;
      }
      l_clireq.m_server_id=l_temp;

      memset(l_temp,'\0',128+1);
      if(false == g_ConfigReader.readString(l_cliRequestAttr, "COUNTRY_ID",l_temp, 0, 128))
      {
         printf("\nCOUNTRY_ID not present in the XML request");
         return false;
      }
      l_clireq.m_country_id=l_temp;

      memset(l_temp,'\0',128+1);
      if(false == g_ConfigReader.readString(l_cliRequestAttr, "CLIENT_ID",l_temp, 0, 128))
      {
         printf("\nCLIENT_ID not present in the XML request");
         return false;
      }
      l_clireq.m_client_id=l_temp;

      memset(l_temp,'\0',128+1);
      if(false == g_ConfigReader.readString(l_cliRequestAttr, "SUB_PRODUCT_ID",l_temp, 0, 128))
      {
         printf("\nSUB_PRODUCT_ID not present in the XML request");
         return false;
      }
      l_clireq.m_sub_product_id=l_temp;

      memset(l_temp,'\0',128+1);
      if(false == g_ConfigReader.readString(l_cliRequestAttr, "UNIQUE_INSTANCE_ID",l_temp, 0, 128))
      {
         printf("\nUNIQUE_INSTANCE_ID not present in the XML request");
         return false;
      }
      l_clireq.m_instance_seq_id=l_temp;

      memset(l_temp,'\0',128+1);
      if(false == g_ConfigReader.readString(l_cliRequestAttr, "PRODUCT_ID",l_temp, 0, 128))
      {
         printf("\nPRODUCT_ID not present in the XML request");
         return false;
      }
      l_clireq.m_product_id=l_temp;

      memset(l_temp,'\0',128+1);
      if(false == g_ConfigReader.readString(l_cliRequestAttr, "UNIQ_TRAP_SEQ_ID",l_temp, 0, 128))
      {
         printf("\nUNIQ_TRAP_SEQ_ID not present in the XML request");
         return false;
      }
      l_clireq.m_unique_trap_seq_id=l_temp;
   }

   string l_oe = l_clireq.m_orig_equip;
   l_clireq.m_orig_equip= l_oe + ":" + l_clireq.m_ipaddress;


   //printf("\nSending Client Trap: %s %s %s %s %s", l_clireq.m_orig_equip.c_str(),l_clireq.m_clitext.c_str(),l_clireq.m_clitype.c_str(),l_clireq.m_cliseverity.c_str(),l_clireq.m_clitime.c_str());
   TLOG( "Sending Client Trap:%s %s %s %s %s %s %s ServerData %s %s %s %s", 
         l_clireq.m_orig_equip.c_str(),l_clireq.m_clalrm_id.c_str(),l_clireq.m_clitext.c_str(),l_clireq.m_clitype.c_str(),l_clireq.m_cliseverity.c_str(),l_clireq.m_clitime.c_str(),l_clireq.m_threshold_info.c_str(),l_clireq.m_server_id.c_str(),l_clireq.m_country_id.c_str(),l_clireq.m_product_id.c_str(),l_clireq.m_instance_seq_id.c_str());

   return formSnmpPacketAndSend(&l_clireq);
}





