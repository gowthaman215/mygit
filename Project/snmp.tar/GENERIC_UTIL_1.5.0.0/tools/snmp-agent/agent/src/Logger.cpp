/************************************************************************
 ** FILE NAME    : Logger.cpp
 ** AUTHOR       : 
 ** DEFINTION    :
 ** REMARKS      :
 ************************************************************************/

volatile long g_LoggerCounter = 0;

#include <pthread.h>

#include "Logger.h"
#include "ConfigReader.h"


Logger g_LoggerObj; // definition for the global Logger object

Logger::Logger()
{
   resetMembers();
   pthread_mutexattr_init(&mattr);
   pthread_mutexattr_setpshared(&mattr,PTHREAD_PROCESS_SHARED);
   pthread_mutex_init(&cdrMutex, NULL);
}

Logger::~Logger()
{
   pthread_mutexattr_destroy(&mattr);
   pthread_mutex_destroy(&cdrMutex);
}

void Logger::resetMembers()
{
   iLoggingMedia		= 0;
   iLoggingThreshold	= 0;
   iLoggerFileHandle	= 0;
   iLoggerConsoleHandle	= 0;
   iArchivalDirPath	= NULL;
   iMaxFileSize		= 1000000;
   iFilePath		= NULL;
   iModuleName		= NULL;
   i_SyncCount		= 0;
   memset(iLoggerBuffer, '\0', sizeof(iLoggerBuffer));
} 

char * Logger::makeFileName(char * mFileNameBuffer, char * mPath, char * mFilePrefix)
{
   struct tm *tm_ptr;
   time_t the_time;
   (void) time(&the_time);
   tm_ptr = localtime(&the_time);
//   sprintf(mFileNameBuffer, "%s/%s_%02u_%02u_%04u_%02u_%02u_%02u.log", mPath, mFilePrefix, tm_ptr->tm_mday, tm_ptr->tm_mon+1, tm_ptr->tm_year+1900, tm_ptr->tm_hour, tm_ptr->tm_min, tm_ptr->tm_sec);
   sprintf(mFileNameBuffer, "%s/%s_%04u_%02u_%02u_%02u_%02u_%02u_P%05d.log", 
            mPath, mFilePrefix, tm_ptr->tm_year+1900, tm_ptr->tm_mon+1, tm_ptr->tm_mday, tm_ptr->tm_hour, tm_ptr->tm_min, tm_ptr->tm_sec, getpid());

   if((this->iFilePath == NULL) ||(strcmp(mPath, this->iFilePath)==0))
   {
      strcpy(this->iFileName,mFileNameBuffer);
   }
   return mFileNameBuffer;
}

char * Logger::makeTimeStamp()
{
   long timeInSeconds;
   struct tm *timeStruct;
   char * dateString;
   time(&timeInSeconds);
   timeStruct = localtime(&timeInSeconds);
   dateString = asctime(timeStruct);
   dateString[24] = 0;
   return dateString;
}

bool Logger::changeLogLevel(unsigned long mLoggingThreshold)
{
  if( (mLoggingThreshold < LOG_LEVEL_LOWER_LIMIT) || (mLoggingThreshold > LOG_LEVEL_UPPER_LIMIT) )
  {
    printf("Dynamic Log Level change not possible\n");
    return false;
  }
  else
    iLoggingThreshold = mLoggingThreshold;
          
  return true;
}

bool Logger::initialize(unsigned long mLoggingThreshold, unsigned long mLoggingMedia, char * mPath, char * mModuleName,char * mArchivalDirPath, unsigned long mMaxFileSize)
{
   iArchivalDirPath = (char *)malloc(strlen(mArchivalDirPath) + 1);
   strcpy(iArchivalDirPath, mArchivalDirPath);

   iMaxFileSize = mMaxFileSize;

   iFilePath = (char *)malloc(strlen(mPath) + 1);
   strcpy(iFilePath, mPath);

   iModuleName = (char *)malloc(strlen(mModuleName) + 1);
   strcpy(iModuleName, mModuleName);

   i_SyncCount = 0;
   bool mRetVal = false;
   char mFileNameBuffer[500];

   try
   { 
      if((mLoggingMedia < LOG_MEDIA_LOWER_LIMIT) || (mLoggingMedia > LOG_MEDIA_UPPER_LIMIT) )
      {
         throw LOGGER_ERR_MODE;
      }
      else
         iLoggingMedia = mLoggingMedia;

      if( (mLoggingThreshold < LOG_LEVEL_LOWER_LIMIT) || (mLoggingThreshold > LOG_LEVEL_UPPER_LIMIT) )
      {
         throw LOGGER_ERR_LEVEL;
      }
      else
         iLoggingThreshold = mLoggingThreshold;

      switch((int)iLoggingMedia)
      {
         case LOG_MEDIA_FILE :	
            {
               if((!mPath) || (!mModuleName) || (PATH_MAX_SIZE < (int)strlen(mPath)) || (MODULE_NAME_MAX_SIZE < (int)strlen(mModuleName)) )
                  throw LOGGER_ERR_FILE;
               makeFileName(&mFileNameBuffer[0], this->iFilePath, this->iModuleName);
               int retd;
               int iUmask = S_IWGRP | S_IWOTH;
               int iFileCreationMode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH; 
               int iFlags = O_WRONLY | O_CREAT | O_APPEND;
               int iOldUmask = umask(iUmask);
               retd = open(mPath, O_RDONLY);
               if (retd == -1)			
               {
                  int iDirCreationMode = iFileCreationMode | S_IXUSR | S_IXGRP | S_IXOTH;
                  int p = mkdir(mPath, iDirCreationMode);
                  if(p == -1) 
                  {
                     perror("Error in Creating Directory");
                     throw LOGGER_ERR_FILE;
                  }
               }

               // The actual permission will be iFileCreationMode & ~iUmask
               iLoggerFileHandle = open(mFileNameBuffer, iFlags, iFileCreationMode);

               // If unable to open the file than throw error
               if(iLoggerFileHandle == -1)
               {
                  throw LOGGER_ERR_FILE;
               }

               // Restore the original umask value.
               umask(iOldUmask);
            }
            break;
      } // end switch

      mRetVal = true;
      log(LOG_LEVEL_CRITICAL, "*******************************\n \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t LOGGING STARTED \n\t\t\t\t\t\t\t\t\t\t\t\t*****************************************");
   }
   catch (int err_code) 
   {
      iLoggingMedia	= 0;
      iLoggingThreshold	= 0;

      switch (err_code)
      {
         case LOGGER_ERR_FILE :			// File path is not correct
            iLoggerFileHandle		= 0;
            break;

         case LOGGER_ERR_NEW_CONSOLE :	// Console window problem
            iLoggerConsoleHandle	= 0;
            break;

         case LOGGER_ERR_BUFFER :		// Insufficient memory
            break;
      } //end of switch 
   } /* End of Catch */
   return mRetVal;
}

void Logger::terminate()
{
   log(LOG_LEVEL_CRITICAL, "*****************************************\n \t\t\t\t\t\t LOGGING STOPPED \n*****************************************");

   switch ((int)iLoggingMedia) 
   {
      // If LoggingMedia is file then close file handle
      case LOG_MEDIA_FILE :		
         if(iLoggerFileHandle)
         {
            //CloseHandle(iLoggerFileHandle);
            close(iLoggerFileHandle);
         }
         break;
   };

   if(iModuleName)
      free(iModuleName);

   if(iFilePath )
      free(iFilePath);

   if(iArchivalDirPath)
      free(iArchivalDirPath);

   resetMembers();
}

bool Logger::log(unsigned long mLoggingLevel, char* mLogMessage, ...)
{
   try 
   {
      //return true;
      int debugTagLen;
      char* dateString;
      char* debugTag;
      unsigned long  ulThreadID = pthread_self();
      char m_buffer[20000];
      if( (mLoggingLevel<LOG_LEVEL_LOWER_LIMIT) || (mLoggingLevel>LOG_LEVEL_UPPER_LIMIT) || (mLoggingLevel>iLoggingThreshold))
      {
         return false;
      }
      if(!mLogMessage || (LOG_MESSAGE_MAX_SIZE<(int)strlen(mLogMessage)) )	
         return false;

      pthread_mutex_lock(&cdrMutex);
      this->i_SyncCount++;
      dateString = makeTimeStamp();
      va_list args = 0;
      va_start(args, mLogMessage);

      switch(mLoggingLevel)
      {
         case LOG_LEVEL_CRITICAL:
            debugTag = "[C]:";
            debugTagLen = sizeof("[C]:");
            break;

         case LOG_LEVEL_WARNING:
            debugTag = "[W]:";
            debugTagLen = sizeof("[W]:");
            break;

         case LOG_LEVEL_TRACE:
            debugTag = "[T]:";
            debugTagLen = sizeof("[T]:");
            break;

         case LOG_LEVEL_ERROR:
            debugTag = "[E]:";
            debugTagLen = sizeof("[E]:");
            break;

         case LOG_LEVEL_DEBUG:
            debugTag = "[D]:";
            debugTagLen = sizeof("[D]:");
            break;

         default:
            debugTag = "[E]:";
            debugTagLen = sizeof("[E]:");
            break;
      }/* End of switch */

      strcpy( iLoggerBuffer + vsprintf(iLoggerBuffer + 
               sprintf(iLoggerBuffer,"%s:%s ",dateString, debugTag), mLogMessage, args) + DATE_STRING_LEN + debugTagLen, "\n");

      sprintf(m_buffer,"T<%lu>",ulThreadID);
      strcat(m_buffer,iLoggerBuffer);
      strcpy(iLoggerBuffer,m_buffer);
      unsigned long m_FileSize;
      switch (iLoggingMedia)
      {
         case LOG_MEDIA_FILE :			
            {
               struct stat fileStat;

               fstat(this->iLoggerFileHandle, &fileStat);
               m_FileSize = fileStat.st_size;
               chmod(iFileName,0644);
               if(m_FileSize >= this->iMaxFileSize)
               {
                  char mFileNameBuffer[500];
                  close(this->iLoggerFileHandle);
                  makeFileName(&mFileNameBuffer[0],this->iArchivalDirPath,this->iModuleName);

                  rename(this->iFileName,mFileNameBuffer);
                  makeFileName(&mFileNameBuffer[0],this->iFilePath,this->iModuleName);

                  iLoggerFileHandle = creat(mFileNameBuffer,O_CREAT|O_RDWR);
                  chmod(iFileName,0644);
                  if(iLoggerFileHandle == -1) 
                  {
                     throw LOGGER_ERR_FILE;
                  }
                  else // Point to end of the file
                  {
                     lseek(iLoggerFileHandle,0,SEEK_END);
                  }
               }
               write(iLoggerFileHandle, iLoggerBuffer, strlen(iLoggerBuffer));

               chmod(iFileName,0444);
            }
            break;
         case LOG_MEDIA_CONSOLE :
            {
               printf("\n");
               printf(iLoggerBuffer);
            }
            break;
      };
      this->i_SyncCount--;
      pthread_mutex_unlock(&cdrMutex);
      return true;
   }
   catch(...)
   {
      cout<<"**************Unknown exception occured in Logger*************"<<endl;
      if(this->i_SyncCount)
      {
         this->i_SyncCount--;
         pthread_mutex_unlock(&cdrMutex);
      }
      return false;
   }
}

long Logger::getLoggerSyncCount()
{
   return this->i_SyncCount;
}

unsigned long Logger::getLoggingThreshold()
{
   return iLoggingThreshold;
}

bool Logger::setLoggingThreshold(unsigned long m_newLoglevel)
{

   iLoggingThreshold = m_newLoglevel;
   cout<<"NEWLOGLEVEL:"<<iLoggingThreshold<<endl;
   return true;
}

