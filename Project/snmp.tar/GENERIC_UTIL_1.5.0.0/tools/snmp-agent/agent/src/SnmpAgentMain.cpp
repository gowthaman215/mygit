#include <stdio.h>
#include <iostream>
#include <fstream>
#include <deque>
#include <stdlib.h>
#include <string>
#include <strings.h>
#include <time.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <ConfigReader.h>
#include <DataType.h>
#include <SnmpTrapSender.h>
#include <Logger.h>
#include <ctype.h>
#include <netdb.h>
#include <MessageQueue.h>
#include <ToolInterface.h>
#define SNMP_CLIENT_l_buf 1024
#define SIZE_OF_LENGTH_FIELD 9   // This should always be 9 bytes
#define MAX_OUTPUT_SIZE  5000

#define SNMP_AGENT_RELEASE_VERSION  "1.5.0.0 Rev1" //"1.1.2.0 Rev1"

extern bool sendData(unsigned char *p_data, int p_length);

bool g_EntityNotRecognizedInWindowFlag=false;
bool g_EntityAlreadyExistsInWindowFlag=false;
bool g_EntityProductIdInvalidInWindowFlag=false;
bool g_EntityInstanceIdInvalidInWindowFlag=false;

uid_t g_uid;

SnmpTrapSender g_SnmpTrapSender;
ToolInterface g_ti;
DynamicConfigData *g_dcd;
list<int> g_sockFdList;

int RecvAll(int &s, char *l_buf, int len);
extern map<int,FdInfo> g_FdInfoMap;


void catch_sig(int sig_num)
{
   printf("\n\nReceived a Ctrl-C signal. Closing the application...\n\n\n");
   exit(1);
}

MessageQueue *g_snmpTrapQueue = NULL;
MessageQueue *g_snmpEmailQueue = NULL;

bool snmpSendDataToNetwork(int p_sockFd, unsigned char *p_data, int p_length)
{
   unsigned char *l_data = (unsigned char *)"Some Error";
   int l_length=strlen((char*)l_data);

   if (NULL != p_data)
   {
      l_data = p_data;
      l_length = p_length;
   }

   if (0 == l_length)
   {
      return false;
   }
   if (p_sockFd != 0)
   {
      char l_lengthChar[10];
      memset(l_lengthChar, '\0', 10);
      sprintf(l_lengthChar, "%09d", l_length);

      DLOG("Sending Length [%s]", l_lengthChar);

      if (send(p_sockFd, l_lengthChar, 9, 0) == -1) 
      {
         WLOG("sending length failed on fd:[%d]", p_sockFd);
         return false;
      }

      if (send(p_sockFd, l_data, l_length, 0) == -1) 
      {
         WLOG("sending data failed on fd:[%d]", p_sockFd);
         return false;
      }

      printf("\n <=== %s\n", l_data);
      DLOG("Sending data successfull");
   }
   return true;
}


bool executeCommand(char *p_command, char *p_output)
{
   //TLOG( "Entered in the executeCommand() function");
   FILE *ptr = NULL;

   //char l_output[MAX_OUTPUT_SIZE+1];
   //memset(l_output, '\0', MAX_OUTPUT_SIZE+1);
   //strcpy(l_output, ":");

   char path[BUFSIZ+1];
   memset(path,'\0',BUFSIZ);

   if((ptr = popen(p_command, "r"))!=NULL)
   {
      while (fgets(path, BUFSIZ, ptr) != NULL)
      {
         strlcat(p_output, path, MAX_OUTPUT_SIZE);
      }
      if(-1 == pclose(ptr))
      {
         ELOG("Error in popen() closing");
      }
      TLOG("snmp trap output%s.", p_output);
      int l_length=strlen(p_output);
      if( (l_length>0) && ('\n' == p_output[l_length-1]))
      {
         p_output[l_length-1]='\0';
      }

      //printf("\nOutput of command is [%s]", p_output);
      return true;
   }
   else
   {
      printf("\nERROR:: Failed to execute the SNMP trap command");
      ELOG("failed to execute the SNMP trap command ", p_output);
      return false;
   }
   return false;
}
bool executeMailCommand(char *p_command, char *p_output)
{
   FILE *ptr = NULL;


   char path[BUFSIZ+1];
   memset(path,'\0',BUFSIZ+1);

   if((ptr = popen(p_command, "r"))!=NULL)
   {
      while (fgets(path, BUFSIZ, ptr) != NULL)
      {
         strlcat(p_output, path, MAX_OUTPUT_SIZE);
      }
      if(-1 == pclose(ptr))
      {
         ELOG("Error in popen() closing");
      }
      TLOG("snmp Email output%s", p_output);
      int l_length=strlen(p_output);
      if( (l_length>0) && ('\n' == p_output[l_length-1]))
      {
         p_output[l_length-1]='\0';
      }

      return true;
   }
   else
   {
      printf("\nERROR:: Failed to execute the SNMP trap command");
      ELOG("failed to execute the SNMP trap command ", p_output);
      return false;
   }
   return false;
}

void *snmpTrapSendingThrFunc(void*)
{
   //printf("\nsnmpTrapSendingThrFunc: start");
   TLOG( "Entered in the snmpTrapSendingThrFunc()");
   bool l_status = false;
   do
   {
      void *l_snmpRequest = NULL;
      l_status = g_snmpTrapQueue->pop(&l_snmpRequest);
      if (true == l_status)
      {
         char *l_req = (char *)l_snmpRequest;
         TLOG( "Sending trap: [%s]", l_req);
         char l_output[MAX_OUTPUT_SIZE+1];
         memset(l_output, '\0', sizeof(l_output));
         executeCommand(l_req, l_output);
         delete []l_req;
      }
      else
      {
         ELOG( "Error in pop");
      }
   }while(1);
}
void *emailSendingThrFunc(void*)
{
   TLOG( "Entered in the emailSendingThrFunc()");
   bool l_status = false;
   do
   {
      void *l_snmpEmail = NULL;
      l_status = g_snmpEmailQueue->pop(&l_snmpEmail);
      if (true == l_status)
      {
         char *l_req = (char *)l_snmpEmail;
         TLOG( "Sending Email Message : [%s]", l_req);
         char l_output[MAX_OUTPUT_SIZE+1];
         memset(l_output, '\0', sizeof(l_output));
         executeMailCommand(l_req, l_output);
         if(NULL != strstr(l_output, "Mail sent successfully"))
         {
            TLOG( "Email send successfully: [%s]", l_output);
         }
         else
         {
            TLOG( "Email is not able send: [%s]", l_output);
         }
         delete []l_req;
      }
      else
      {
         ELOG( "Error in pop");
      }
   }while(1);
}


int getPartitionValue(char *p_path)
{
   char l_command[1000];
   memset(l_command, '\0', sizeof(l_command));
   sprintf(l_command, "df -kh %s | grep -v capacity | awk '{print $5}' | sed s/'\%%'//g", p_path);
   //printf("\ncommand is [%s]", l_command);
   char l_output[MAX_OUTPUT_SIZE+1];
   memset(l_output, '\0', sizeof(l_output));
   executeCommand(l_command, l_output);
   printf("\nOutput is [%s]\n", l_output);
   if( strlen(l_output) > 0)
   {
      return atoi(l_output);
   }
   else
   {
      return -1;
   }
}

bool partitionMonitoring()
{
   //printf("\npartitionMonitorThr: start");
   TLOG( "Entered in the partitionMonitoring()");
   bool l_status = false;
   list<PartitionInfo>::iterator l_manipport_itr; 
   for(l_manipport_itr=g_dcd->m_PartitionList.begin();l_manipport_itr!=g_dcd->m_PartitionList.end();l_manipport_itr++)
   {
      int l_partitionValue= getPartitionValue((char*)(*l_manipport_itr).dir.c_str());
      printf("\nPartition [%s] Limit [%d] Current [%d]", (*l_manipport_itr).dir.c_str(), (*l_manipport_itr).limit, l_partitionValue);
      if(l_partitionValue > (*l_manipport_itr).limit)
      {
         printf("\nSending trap for partition ...");
         g_SnmpTrapSender.sendPartitionLimitTrap((char *)(*l_manipport_itr).dir.c_str(),DISC_TRAP, l_partitionValue, (*l_manipport_itr).limit);
         (*l_manipport_itr).fail_sent=1;
      }
      else
      {
         printf("\nLimit not exceeded");
         if(1 == (*l_manipport_itr).fail_sent)
         {
            (*l_manipport_itr).fail_sent=0;
            g_SnmpTrapSender.sendPartitionLimitTrap((char *)(*l_manipport_itr).dir.c_str(),NOT_REGISTERED_TRAP, l_partitionValue, (*l_manipport_itr).limit);
         }
      }

   }
}

bool prepareCommandRequest(char *p_command, char *p_reqType, char *l_completeRequest)
{
   string l_temp;
   l_temp.assign("<REQUEST>");
   l_temp.append("<HEADER>");
   l_temp.append("<TRANSACTION_ID>");
   l_temp.append("TRANS");
   l_temp.append("</TRANSACTION_ID>");
   l_temp.append("<REQUEST_TYPE>");
   l_temp.append(p_reqType);
   l_temp.append("</REQUEST_TYPE>");
   l_temp.append("</HEADER>");
   l_temp.append("<BODY>");
   l_temp.append(p_command);
   l_temp.append("</BODY>");
   l_temp.append("</REQUEST>");
   strcpy(l_completeRequest, l_temp.c_str());
   return true;
}


bool prepareTemplateData(char *p_devicename, char *p_trap)
{
   TLOG( "Preparing template data for device:%s", p_devicename);

   int l_templateid=0;

   map<string,DeviceInfo>:: iterator d_itr=g_dcd->m_MasterDeviceName.find(p_devicename);
   if(d_itr != g_dcd->m_MasterDeviceName.end())
   {
      l_templateid = d_itr->second.templateid;

      char l_serverData[200+1];
      snprintf(l_serverData, sizeof(l_serverData), "<SERVER_DATA><SERVER_ID>%d</SERVER_ID><COUNTRY_ID>%d</COUNTRY_ID><CLIENT_ID>%d</CLIENT_ID><SUB_PRODUCT_ID>%d</SUB_PRODUCT_ID></SERVER_DATA>",
            d_itr->second.server_id, d_itr->second.country_id, d_itr->second.client_id,
            d_itr->second.sub_product_id);
      strcat(p_trap, l_serverData);
   }
   else
   {
      ELOG("Device name not found from the g_MasterDeviceName");
      return false;
   }

   if (0 == l_templateid)
   {
      TLOG( "No Template data to be sent");
      return true;
   }

   TLOG( "Preparing template data with Template id :%d", l_templateid);

   map<int,list<TrapInfo> >:: iterator t_itr=g_dcd->m_TrapInfoMap.find(l_templateid);
   if(t_itr != g_dcd->m_TrapInfoMap.end())
   {
      list<TrapInfo>:: iterator l_itr;
      int cnt=1;
      char l_trap[10];
      char l_temp[32];
      memset(l_temp,'\0',sizeof(l_temp));
      for(l_itr = t_itr->second.begin(); l_itr != t_itr->second.end(); l_itr++)
      {
         memset(l_trap,'\0',sizeof(l_trap));
         sprintf(l_trap,"<TRAP_%02d>",cnt);
         strcat(p_trap,l_trap);
         sprintf(l_temp,"<ID>%s</ID>",l_itr->id);
         strcat(p_trap,l_temp);
         sprintf(l_temp,"<INTERVAL>%d</INTERVAL>",l_itr->interval);
         strcat(p_trap,l_temp);
         sprintf(l_temp,"</TRAP_%02d>",cnt);
         strcat(p_trap,l_temp);
         cnt++;
      }
   }
   else
   {
      ELOG("Template id not found from the g_TrapInfoMap");
      return false;
   }
   TLOG( "Prepared template data [%s]", p_trap);
   return true;
}

bool prepareRegistrationResponse(char *p_devicename, char *p_errorCode, char *p_errorDesc, char *l_completeResponse)
{
   char l_trapTemplateChar[9999 +1];
   memset(l_trapTemplateChar, '\0', sizeof(l_trapTemplateChar));
   if(0 == strcmp(p_errorCode, "0"))
   {
      DLOG("Adding template data");
      prepareTemplateData(p_devicename, l_trapTemplateChar);
   }
   else
   {
      DLOG("Not adding template data");
   }

   string l_temp;
   l_temp.assign("<REGISTRATION_RESPONSE>");
   l_temp.append("<HEADER>");
   l_temp.append("<ERROR_CODE>");
   l_temp.append(p_errorCode);
   l_temp.append("</ERROR_CODE>");
   l_temp.append("<ERROR_DESC>");
   l_temp.append(p_errorDesc);
   l_temp.append("</ERROR_DESC>");
   l_temp.append("</HEADER>");
   l_temp.append("<BODY>");
   l_temp.append("<TRAPS_FILTER>");
   l_temp.append(l_trapTemplateChar);
   l_temp.append("</TRAPS_FILTER>");
   l_temp.append("</BODY>");
   l_temp.append("</REGISTRATION_RESPONSE>");
   strcpy(l_completeResponse, l_temp.c_str());
   return true;
}



bool processCommand(char *p_command)
{
   char l_responseToBeSent[4000+1];
   memset(l_responseToBeSent, '\0', sizeof(l_responseToBeSent));
   sprintf(l_responseToBeSent, "Unknown Command [%s]", p_command);

   if(0 == strcmp(p_command,"reload configuration"))
   {
      DynamicConfigData *l_dcd=NULL;
      char l_tempConfigError[1000+1];
      memset(l_tempConfigError, '\0', sizeof(l_tempConfigError));
      if(false == g_ConfigReader.initDynamicData(&l_dcd, l_tempConfigError))
      {
         ELOG("There are errors in the Dynamic Configuration file. No changes done to the SNMP Agent [%s]", l_tempConfigError);
         sprintf(l_responseToBeSent, "Unable to Reload: [%s]", l_tempConfigError);
         if (l_dcd != NULL)
         {
            delete(l_dcd);
         }
      }
      else
      {
         g_dcd=l_dcd;
         TLOG( "Closing all existing connections");
         map<int,FdInfo>::iterator f_itr;
         for(f_itr = g_FdInfoMap.begin() ; f_itr != g_FdInfoMap.end(); f_itr++)
         {
            TLOG( "Close the Client Socket fd :%d",f_itr->first);
            close(f_itr->first);
            g_FdInfoMap.erase(f_itr);
         }
         list<int>::iterator itr;
         for(itr = g_sockFdList.begin(); itr != g_sockFdList.end(); itr++)
         {
            g_sockFdList.erase(itr);
         }
         TLOG( "END of closing all existing connections");
         strcpy(l_responseToBeSent, "Dynamic Configurations Reload Success");

         g_ConfigData->m_DisableConnectionTrapsAtStartup=1; // From this time, assuming to disable the Traps for previously connected Applications
         g_EntityNotRecognizedInWindowFlag=false;
         g_EntityAlreadyExistsInWindowFlag=false;
         g_EntityProductIdInvalidInWindowFlag=false;
         g_EntityInstanceIdInvalidInWindowFlag=false;
      }
   }
   else if(0 == strcmp(p_command,"getinfo"))
   {
      char *l_config = g_ConfigReader.getConfigPrint();
      strcpy(l_responseToBeSent, l_config);
      TLOG( "Sending MMI tool getinfo response [%s]", l_config);
      if(NULL != l_config)
      {
         delete[] l_config;
      }
   }

   sendData((unsigned char *)l_responseToBeSent, strlen(l_responseToBeSent));
   return true;
}

time_t g_lastExecutedTime=0;


int main(int argc, char ** argv)
{
   g_uid = getuid();

   printf("\n\nStarting Generic SNMP Agent v%s\n\n", SNMP_AGENT_RELEASE_VERSION);
   //Read Configuration Files
   if(false == g_ConfigReader.initStaticData())
   {
      printf("\n\nThere are errors in the Static Configuration file\n\n");
      exit(1);
   }

   SnmpTrapSender l_SnmpTrapSender;

   int l_logLevel;
   int l_media;


   if(strcmp(g_ConfigData->m_LogLevel.c_str(),"D") == 0)
   {
      l_logLevel=LOG_LEVEL_DEBUG;
   }
   else if(strcmp(g_ConfigData->m_LogLevel.c_str(),"C") == 0)
   {
      l_logLevel=LOG_LEVEL_CRITICAL;
   }
   else if(strcmp(g_ConfigData->m_LogLevel.c_str(),"W") == 0)
   {
      l_logLevel=LOG_LEVEL_WARNING;
   }
   else if(strcmp(g_ConfigData->m_LogLevel.c_str(),"T") == 0)
   {
      l_logLevel=LOG_LEVEL_TRACE;
   }
   else if(strcmp(g_ConfigData->m_LogLevel.c_str(),"E") == 0)
   {
      l_logLevel=LOG_LEVEL_ERROR;
   }
   else
   {
      printf("\n\nLog level problem\n\n");
      exit(1);
   }


   if(strcmp(g_ConfigData->m_LogMedia.c_str(),"F") == 0)
   {
      l_media=LOG_MEDIA_FILE;
   }
   else if(strcmp(g_ConfigData->m_LogMedia.c_str(),"C") == 0)
   {

      l_media=LOG_MEDIA_CONSOLE;
   }
   else
   {
      printf("\n\nLog Media problem\n\n");
      exit(1);
   }

   printf("\n\n\nInitializing SNMP Agent ...");

   printf("\n\tInitializing Loggers ..");

   bool l_status=g_LoggerObj.initialize(l_logLevel,l_media,(char *)g_ConfigData->m_FilePath.c_str(),(char *)g_ConfigData->m_Prefix.c_str(),(char *)g_ConfigData->m_FilePath.c_str(),(long int)g_ConfigData->m_MaxFileSize);
   if(l_status == false)
   {
      printf("\n\tLogger Initialisation Failed\n");
      exit(1);
   }

   char l_tempConfigError[1000+1];
   memset(l_tempConfigError, '\0', sizeof(l_tempConfigError));
   if(false == g_ConfigReader.initDynamicData(&g_dcd, l_tempConfigError))
   {
      ELOG("There are errors in the Dynamic  Configuration file [%s]", l_tempConfigError);
      exit(1);
   }

   CLOG( "Starting Generic SNMP Agent v%s", SNMP_AGENT_RELEASE_VERSION);

   TLOG( "Config file details:%s",g_ConfigReader.getConfigPrint());

   printf("\n\tInitializing Signals ..");
   (void)signal(SIGINT,     catch_sig);
   (void)signal(SIGTSTP,    SIG_IGN);
   (void)signal(SIGABRT,    SIG_IGN);
   (void)signal(SIGPIPE,    SIG_IGN);
   (void)signal(SIGHUP,     SIG_IGN);
   (void)signal(SIGTERM,    SIG_IGN);
   (void)signal(SIGALRM,    SIG_IGN);
   (void)signal(SIGUSR1,    SIG_IGN);
   (void)signal(SIGUSR2,    SIG_IGN);
   (void)signal(SIGPOLL,    SIG_IGN);
   (void)signal(SIGSTOP,    SIG_IGN);
   (void)signal(SIGTSTP,    SIG_IGN);
   (void)signal(SIGTTOU,    SIG_IGN);
   (void)signal(SIGTTIN,    SIG_IGN);
   (void)signal(SIGVTALRM,  SIG_IGN);
   (void)signal(SIGPROF,    SIG_IGN);
   (void)signal(SIGLOST,    SIG_IGN);

   list<PartitionInfo>::iterator l_manipport_itr; 
   for(l_manipport_itr=g_dcd->m_PartitionList.begin();l_manipport_itr!=g_dcd->m_PartitionList.end();l_manipport_itr++)
   {
      if(-1 == getPartitionValue((char*)(*l_manipport_itr).dir.c_str()))
      {
         printf("\nPartition [%s] could not be found\n");
         exit(1);
      }
   }



   int l_ServerSocket;
   int l_ClientSocket;
   int client_len = sizeof(struct sockaddr);
   struct sockaddr_in addr, client_addr;
   unsigned int val = 1;
   socklen_t clientAddrLength=sizeof(client_addr);;

   if (-1 == (l_ServerSocket = socket(AF_INET, SOCK_STREAM, 0)))
   {

      ELOG("Error in socket Call");
      return false;
   }
   memset(&addr, 0, sizeof(addr));
   addr.sin_family = AF_INET;
   addr.sin_addr.s_addr = INADDR_ANY;
   addr.sin_port = htons(g_ConfigData->m_SnmpAgentPort);


   setsockopt(l_ServerSocket, SOL_SOCKET, SO_REUSEADDR , &val, sizeof(val));

   if(bind(l_ServerSocket, (struct sockaddr *)&addr,  sizeof(addr)) < 0)
   {
      close(l_ServerSocket);
      ELOG("Error in Binding with the listen port: %d.", g_ConfigData->m_SnmpAgentPort);
      exit(1);
   }

   if (listen(l_ServerSocket, 40) < 0)
   {
      ELOG("Error in Listen fd:[%d]",l_ServerSocket);
      close(l_ServerSocket);
      exit(1);
   }


   fd_set l_cli_fdset;
   int l_max_fd = l_ServerSocket;
   struct timeval tv;

   list<int>::iterator l_sockfd_it;
   g_lastExecutedTime=time(NULL)-g_ConfigData->m_Traptime+5; //This will ensure that the heart beat logic starts after 5 seconds of the EXE startup

   ClientTrapRequest l_clireq;


   g_snmpTrapQueue = new MessageQueue(QUEUE_TYPE_BLOCKING);
   l_status = g_snmpTrapQueue->initialize();
   if (!l_status)
   {
      ELOG("ERROR!! Unable to initialize the SNMP Trap Queue");
      exit(1);
   }
   g_snmpEmailQueue = new MessageQueue(QUEUE_TYPE_BLOCKING);
   l_status = g_snmpEmailQueue->initialize();
   if (!l_status)
   {
      ELOG("ERROR!! Unable to initialize the SNMP Trap Queue");
      exit(1);
   }

   printf("\n\tInitializing %d Trap thread(s) ..", g_ConfigData->m_TrapSenderPoolSize);

   for (int l_i=0; l_i<g_ConfigData->m_TrapSenderPoolSize; l_i++)
   {
      pthread_t l_thread;
      if(0 !=  pthread_create(&l_thread, NULL, snmpTrapSendingThrFunc, NULL))
      {
         ELOG("Unable to create thread");
         sleep(2);
         exit(1);
      }
   }
   printf("Create thread for e-mail send therad \n");
   pthread_t l_emailthread;
   if(0 !=  pthread_create(&l_emailthread, NULL, emailSendingThrFunc, NULL))
   {
      ELOG("Unable to create thread");
      sleep(2);
      exit(1);
   }

   printf("\nInitialization of SNMP Agent Successfull ..\n\n");

   if (true == g_ConfigData->m_ToolEnabledFlag)
   {
      printf("\n\tInitializing Tool Interface ...\n");
      l_status = g_ti.initialize(g_ConfigData->m_ToolPort);
      if (!l_status)
      {
         ELOG("ERROR!! Unable to initialize the ToolInterface");
         sleep(2);
         exit(2);
      }
   }

   DeviceInfo l_tempDeviceInfo;

   //Starting to send Agent up trap to all managers
   l_SnmpTrapSender.sendHeartBeatTrap((char *)g_ConfigData->m_SnmpAgentName,NOT_REGISTERED_TRAP,HEART_BEAT_AGENT, NULL, NULL);
   //Ending to send Agent up trap to all managers

   while (1)
   {
      if (g_commandQueue != NULL)
      {
         void *l_command = NULL;
         l_status = g_commandQueue->pop(&l_command);
         if (l_status)
         {
            TLOG( "Received a tool command [%s]", (char*)l_command);
            processCommand((char*)l_command);

            delete[] (char*)l_command;
         }
      }

      FD_ZERO(&l_cli_fdset);
      FD_SET(l_ServerSocket, &l_cli_fdset);
      l_max_fd = l_ServerSocket;

      for(l_sockfd_it = g_sockFdList.begin(); l_sockfd_it != g_sockFdList.end(); l_sockfd_it++)
      {
         FD_SET(*l_sockfd_it, &l_cli_fdset);
         if(l_max_fd<*l_sockfd_it)
            l_max_fd = *l_sockfd_it;
      }

      tv.tv_sec = 1;
      tv.tv_usec = 0;


      DLOG("DescriptorsSize:[%d] FdInfoMapSize:[%d]", g_sockFdList.size(), g_FdInfoMap.size());
      if(0 < select(l_max_fd+1, &l_cli_fdset, NULL, NULL, &tv))
      {
         if(FD_ISSET(l_ServerSocket, &l_cli_fdset))
         {
            client_len = sizeof(client_addr);

            if(0 <= (l_ClientSocket = accept(l_ServerSocket, (struct sockaddr *)&client_addr, (socklen_t *)&client_len)))
            {
               g_sockFdList.push_back(l_ClientSocket);
               FdInfo l_FdInfo;
               g_FdInfoMap.insert(pair<int,FdInfo>(l_ClientSocket,l_FdInfo));
               printf("\nAccepted a new connection with sock fd:%d",l_ClientSocket);
               TLOG( "Accepted a new connection with sock fd:[%d]",l_ClientSocket);

            }
            else if(l_ClientSocket < 0)
            {
               WLOG("Error in accept: %d.", errno);
            }
         }//if FD_ISSET
         else
         {
            for(l_sockfd_it = g_sockFdList.begin(); l_sockfd_it != g_sockFdList.end();)
            {
               if(FD_ISSET(*l_sockfd_it, &l_cli_fdset))
               {
                  DLOG( "Received message from Client");

                  char l_buf[SNMP_CLIENT_l_buf+1];
                  memset(l_buf, 0, SNMP_CLIENT_l_buf+1);

                  map<int,FdInfo>::iterator l_fdinfo_itr;
                  l_fdinfo_itr = g_FdInfoMap.find(*l_sockfd_it);
                  if(l_fdinfo_itr == g_FdInfoMap.end())
                  {
                     TLOG( "Severe Error fd:[%d]",*l_sockfd_it);
                     l_sockfd_it++;
                     continue;
                  }

                  int recdLen = RecvAll(*l_sockfd_it, l_buf, SIZE_OF_LENGTH_FIELD);
                  if(recdLen <= 0)
                  {
                     printf("\nEntity [%s] got disconnected. recv length failed. fd[%d]",(char*)l_fdinfo_itr->second.device_name.c_str(), *l_sockfd_it);
                     WLOG( "Entity [%s] got disconnected. recv length failed. fd:[%d].",
                           (char*)l_fdinfo_itr->second.device_name.c_str(), *l_sockfd_it);
                     l_SnmpTrapSender.sendHeartBeatTrap((char*)l_fdinfo_itr->second.device_name.c_str(), DISC_TRAP, HEART_BEAT_NORMAL, NULL,
                           &l_fdinfo_itr->second.device_info);
                     // Close the connection
                     close(*l_sockfd_it);
                     g_FdInfoMap.erase(*l_sockfd_it);
                     l_sockfd_it = g_sockFdList.erase(l_sockfd_it);
                     continue;
                  }

                  DLOG( "Received Length [%s]\n", l_buf);
                  int l_length = atoi(l_buf);

                  if (SNMP_CLIENT_l_buf < l_length)
                  {
                     printf("\nClosing the connection. received length invalid. fd:[%d]",*l_sockfd_it);
                     WLOG( "Closing the connection. received length invalid.: fd:[%d].", *l_sockfd_it);
                     l_SnmpTrapSender.sendHeartBeatTrap((char*)l_fdinfo_itr->second.device_name.c_str(), DISC_TRAP, HEART_BEAT_NORMAL, NULL,
                           &l_fdinfo_itr->second.device_info);
                     // Close the connection
                     close(*l_sockfd_it);
                     g_FdInfoMap.erase(*l_sockfd_it);
                     l_sockfd_it = g_sockFdList.erase(l_sockfd_it);
                     continue;
                  }

                  memset(l_buf, '\0', SNMP_CLIENT_l_buf+1);

                  recdLen = RecvAll(*l_sockfd_it, l_buf, l_length);
                  if(recdLen <= 0)
                  {
                     printf("\nEntity got disconnected. recv data failed. fd:[%d]",*l_sockfd_it);
                     WLOG( "Entity got disconnected. recv data failed.: fd:[%d].", *l_sockfd_it);
                     l_SnmpTrapSender.sendHeartBeatTrap((char*)l_fdinfo_itr->second.device_name.c_str(), DISC_TRAP, HEART_BEAT_NORMAL, NULL,
                           &l_fdinfo_itr->second.device_info);
                     // Close the connection
                     close(*l_sockfd_it);
                     g_FdInfoMap.erase(*l_sockfd_it);
                     l_sockfd_it = g_sockFdList.erase(l_sockfd_it);
                     continue;
                  }

                  if(l_fdinfo_itr->second.state==ST_NOT_REGISTERED)
                  {
                     char l_deviceName[100];
                     memset(l_deviceName, '\0', sizeof(l_deviceName));
                     char l_deviceDate[100];
                     memset(l_deviceDate, '\0', sizeof(l_deviceDate));
                     int  l_deviceStartUpFlag=-1;
                     char l_version[20+1];
                     memset(l_version, '\0', sizeof(l_version));

                     printf("\nRegistration Message: %s", l_buf);
                     TLOG("Registration Message: [%s], fd:[%d]", l_buf, *l_sockfd_it);

                     string l_buf_string = l_buf;
                     if (false == g_ConfigReader.readString(l_buf_string, "ENTITY_NAME",  l_deviceName, 1, 30))
                     {
                        ELOG("ENTITY_NAME not found in REGISTRATION message");
                     } 

                     if (false == g_ConfigReader.readString(l_buf_string, "DATE",  l_deviceDate, 1, 30))
                     {
                        ELOG("DATE not found in REGISTRATION message");
                     } 

                     bool l_versionMismatch = false;
                     if (false == g_ConfigReader.readString(l_buf_string, "VERSION",  l_version, 1, 20))
                     {
                        ELOG("VERSION not found in REGISTRATION message");
                        l_versionMismatch=true;
                     } 

                     if (false == g_ConfigReader.readInteger(l_buf_string, "START_FLAG",  l_deviceStartUpFlag, 0, 1))
                     {
                        ELOG("START_FLAG not found in REGISTRATION message");
                     } 

                     TLOG("Registration Details: Name: [%s], Date: [%s], StartFlag: [%d], fd:[%d]", l_deviceName, l_deviceDate, l_deviceStartUpFlag,*l_sockfd_it);

                     //code for checking the incoming client with already present map
                     bool l_clientValid = true;
                     map<int,FdInfo>::iterator l_fdinfo_check_list_itr;
                     for(l_fdinfo_check_list_itr=g_FdInfoMap.begin();l_fdinfo_check_list_itr!=g_FdInfoMap.end();l_fdinfo_check_list_itr++)
                     {
                        if(((l_fdinfo_check_list_itr->second.device_name).compare(l_deviceName))==0)
                        {
                           l_clientValid=false;
                           break;
                        }
                     }

                     //code for checking the device presence in xml file
                     map<string,DeviceInfo> ::iterator l_masterDevice_check_itr;
                     bool l_devicePresentInxml = false;
                     for(l_masterDevice_check_itr=g_dcd->m_MasterDeviceName.begin();l_masterDevice_check_itr!=g_dcd->m_MasterDeviceName.end();l_masterDevice_check_itr++)
                     {
                        /*printf("\nComparing [%s] and [%s]\n", (*l_masterDevice_check_itr).first.c_str(),
                          l_deviceName);*/
                        if(((l_masterDevice_check_itr->first).compare(l_deviceName))==0)
                        {
                           l_devicePresentInxml=true;
                           break;
                        }
                     }

                     char l_tempRegResponse[9999 + 200 +1];
                     memset(l_tempRegResponse, '\0', sizeof(l_tempRegResponse));

                     if ((true == l_clientValid) && (true == l_devicePresentInxml))
                     {
                        if(NULL != strstr(l_buf_string.c_str(), "<VERSION>1.5")) //v1.5 and above
                        {
                           //l_clientValid = false;
                           DLOG("Version 1.5 and above client");

                           int l_product_id;
                           if (false == g_ConfigReader.readInteger(l_buf_string, "PRODUCT_ID",  l_product_id, 1, 200))
                           {
                              ELOG("PRODUCT_ID not found in REGISTRATION request");
                           }

                           int l_instance_seq_id;
                           if (false == g_ConfigReader.readInteger(l_buf_string, "INSTANCE_SEQ_ID",  l_instance_seq_id, 1, 200))
                           {
                              ELOG("INSTANCE_SEQ_ID not found in REGISTRATION request");
                           }

                           if(l_product_id == l_masterDevice_check_itr->second.product_id)
                           {
                              if(l_instance_seq_id == l_masterDevice_check_itr->second.instance_seq_id)
                              {
                                 DLOG(0,0,"Product and Instance Seq IDs matched");
                                 //l_clientValid = true;
                              }
                              else
                              {
                                 char l_tempData[1000+1];
                                 snprintf(l_tempData, sizeof(l_tempData), "!!CRITICAL!! Instance Seq ID configured in SNMP Agent is [%d], but the instance seq id [%d] is coming from application", l_masterDevice_check_itr->second.instance_seq_id, l_instance_seq_id);
                                 CLOG("!!CRITICAL!! %s",l_tempData);
                                 prepareRegistrationResponse(l_deviceName,"4", l_tempData, l_tempRegResponse);
                                 snmpSendDataToNetwork(*l_sockfd_it, (unsigned char*)l_tempRegResponse, strlen(l_tempRegResponse));
                                 g_EntityInstanceIdInvalidInWindowFlag = true;

                                 // Close the connection
                                 close(*l_sockfd_it);
                                 g_FdInfoMap.erase(*l_sockfd_it);
                                 l_sockfd_it = g_sockFdList.erase(l_sockfd_it);
                                 continue;
                              }
                           }
                           else
                           {
                              char l_tempData[1000+1];
                              snprintf(l_tempData, sizeof(l_tempData), "!!CRITICAL!! Product ID configured in SNMP Agent is [%d], but the product [%d] is coming from application", l_masterDevice_check_itr->second.product_id, l_product_id);
                              CLOG("!!CRITICAL!! %s",l_tempData);
                              prepareRegistrationResponse(l_deviceName,"3", l_tempData, l_tempRegResponse);
                              snmpSendDataToNetwork(*l_sockfd_it, (unsigned char*)l_tempRegResponse, strlen(l_tempRegResponse));
                              g_EntityProductIdInvalidInWindowFlag = true;

                              // Close the connection
                              close(*l_sockfd_it);
                              g_FdInfoMap.erase(*l_sockfd_it);
                              l_sockfd_it = g_sockFdList.erase(l_sockfd_it);
                              continue;
                           }
                        }

                        if(false == l_versionMismatch)
                        {
                           prepareRegistrationResponse(l_deviceName,"0", "", l_tempRegResponse);
                           TLOG( "Sending Registration to client on fd:[%d] with Reg Response [%s] device name:[%s]", *l_sockfd_it,l_tempRegResponse,l_deviceName);
                           snmpSendDataToNetwork(*l_sockfd_it, (unsigned char*)l_tempRegResponse, strlen(l_tempRegResponse));
                        }
                        else
                        {
                           TLOG( "Sending Registration to client on fd:[%d] with Reg Response [0] device name:[%s]", *l_sockfd_it,l_deviceName);
                           snmpSendDataToNetwork(*l_sockfd_it, (unsigned char *)"0", 1);
                        }

                        l_fdinfo_itr->second.device_name = l_deviceName;
                        l_fdinfo_itr->second.state=ST_REGISTERED;
                        l_fdinfo_itr->second.device_info=l_masterDevice_check_itr->second;

                        if(1 == g_ConfigData->m_DisableConnectionTrapsAtStartup)
                        {
                           if (0 == l_deviceStartUpFlag)
                           {
                              printf("Disabling the trap");
                              TLOG( "Disabling the trap");
                           }
                           else
                           {
                              TLOG( "Module registration when connected to SnmpTrapSender:%s Recv fd:[%d]", l_deviceName,*l_sockfd_it);
                              l_SnmpTrapSender.sendHeartBeatTrap(l_deviceName, NOT_REGISTERED_TRAP, HEART_BEAT_NORMAL, l_deviceDate,
                                    &l_fdinfo_itr->second.device_info);
                           }
                        }
                        else
                        {
                           TLOG( "Module registration when connected to SnmpTrapSender:%s Recv fd:[%]", l_deviceName,*l_sockfd_it);
                           l_SnmpTrapSender.sendHeartBeatTrap(l_deviceName, NOT_REGISTERED_TRAP, HEART_BEAT_NORMAL, l_deviceDate, 
                                 &l_fdinfo_itr->second.device_info);
                        }
                     }
                     else
                     {
                        if(false == l_devicePresentInxml)
                        {
                           g_EntityNotRecognizedInWindowFlag=true;
                           if(false == l_versionMismatch)
                           {
                              prepareRegistrationResponse(l_deviceName,"1", "Entity not recognized", l_tempRegResponse);
                              snmpSendDataToNetwork(*l_sockfd_it, (unsigned char*)l_tempRegResponse, strlen(l_tempRegResponse));
                           }
                           else
                           {
                              snmpSendDataToNetwork(*l_sockfd_it, (unsigned char *)"1", 1);
                           }
                           printf("\nClosing the connection. Entity [%s] not configured. fd:[%d]",l_deviceName, *l_sockfd_it);
                           TLOG( "Closing the connection. entity [%s] not configured.fd:[%d].", l_deviceName, *l_sockfd_it);
                        }
                        else if (false == l_clientValid)
                        {
                           g_EntityAlreadyExistsInWindowFlag=true;
                           if(false == l_versionMismatch)
                           {
                              prepareRegistrationResponse(l_deviceName,"2", "Entity already exists", l_tempRegResponse);
                              snmpSendDataToNetwork(*l_sockfd_it, (unsigned char*)l_tempRegResponse, strlen(l_tempRegResponse));
                           }
                           else
                           {
                              snmpSendDataToNetwork(*l_sockfd_it, (unsigned char *)"2", 1);
                           }
                           printf("\nClosing the connection. Entity [%s] already exists. fd:[%d]",l_deviceName,*l_sockfd_it);
                           TLOG( "Closing the connection. entity [%s] already exists.: fd:[%d].", l_deviceName, *l_sockfd_it);
                        }
                        // Close the connection
                        close(*l_sockfd_it);
                        g_FdInfoMap.erase(*l_sockfd_it);
                        l_sockfd_it = g_sockFdList.erase(l_sockfd_it);
                        continue;
                     }
                  }
                  else if(l_fdinfo_itr->second.state==ST_REGISTERED)
                  {

                     //printf("\nInside of ST_REGISTERED");
                     if (strstr(l_buf, "<REQUEST>"))
                     {
                        TLOG("Client Registered XML string: %s. Recv fd:[%d]", l_buf,*l_sockfd_it);
                        l_SnmpTrapSender.sendClientTrap(l_buf);
                     }
                     else
                     {
                        TLOG("Client response for mml command: %s Recv df:[%d].", l_buf,*l_sockfd_it);
                        sendData((unsigned char*)l_buf, strlen(l_buf));
                     }
                  }
               }
               l_sockfd_it++;
            }//for
         }//else
      }//if)select

      time_t l_currentTime= time(NULL);
      if(l_currentTime > g_lastExecutedTime+g_ConfigData->m_Traptime)
      {
         g_lastExecutedTime=l_currentTime;
         //comparing the masterlist and registerd list for sending the heartbeat traps
         TLOG("Executing Heart Beat checks now ...");

         partitionMonitoring();
         map<int,FdInfo>:: iterator l_client_fdinfo_it;
         map<string,DeviceInfo> ::iterator l_masterDevice_it;

         for ( l_masterDevice_it=g_dcd->m_MasterDeviceName.begin() ; l_masterDevice_it != g_dcd->m_MasterDeviceName.end(); l_masterDevice_it++ )
         {
            bool l_devicePresent=false;
            for(l_client_fdinfo_it=g_FdInfoMap.begin();l_client_fdinfo_it!=g_FdInfoMap.end();l_client_fdinfo_it++)
            {
               /* printf("\nComparing [%s] and [%s]\n", (*l_masterDevice_it).first.c_str(),
                  (*l_client_fdinfo_it).second.device_name.c_str());*/
               if((*l_masterDevice_it).first == (*l_client_fdinfo_it).second.device_name)
               {
                  l_devicePresent=true;
                  break;
               }
            }

            if(l_devicePresent == false)
            {
               l_SnmpTrapSender.sendHeartBeatTrap((char *)((*l_masterDevice_it).first.c_str()), DISC_TRAP, HEART_BEAT_SCHEDULED, NULL, &l_masterDevice_it->second);
            }
         }


         TLOG( "Flags EntityNotRecognizedInWindowFlag:[%d], EntityAlreadyExistsInWindowFlag:[%d], EntityNotRecognizedInWindowFlag:[%d], EntityAlreadyExistsInWindowFlag:[%d]", 
               g_EntityNotRecognizedInWindowFlag, g_EntityAlreadyExistsInWindowFlag, g_EntityProductIdInvalidInWindowFlag, g_EntityInstanceIdInvalidInWindowFlag);
         if(true == g_EntityNotRecognizedInWindowFlag)
         {
            g_EntityNotRecognizedInWindowFlag=false;
            l_SnmpTrapSender.sendSnmpAgentFailureTrap("NOT_RECOG", "Entity Not Recognized Error", 2);
         }
         if(true == g_EntityAlreadyExistsInWindowFlag)
         {
            g_EntityAlreadyExistsInWindowFlag=false;
            l_SnmpTrapSender.sendSnmpAgentFailureTrap("ALRDY_EXIST", "Entity Already Exists Error", 3);
         }
         if(true == g_EntityProductIdInvalidInWindowFlag)
         {
            g_EntityProductIdInvalidInWindowFlag=false;
            l_SnmpTrapSender.sendSnmpAgentFailureTrap("PROD_INVLD", "Entity Product ID Invalid", 4);
         }
         if(true == g_EntityInstanceIdInvalidInWindowFlag)
         {
            g_EntityInstanceIdInvalidInWindowFlag=false;
            l_SnmpTrapSender.sendSnmpAgentFailureTrap("INST_INVLD", "Entity Instance ID Invalid", 5);
         }
      }
      else
      {
         DLOG("Diff is just %d", l_currentTime-g_lastExecutedTime);
      }
   }//while
   ELOG( "Error!!! Returning from snmpServer()\n");
   exit(1);
}

int RecvAll(int &s, char *l_buf, int len)
{
   int total = 0;
   int bytesleft = len;
   int n;

   if(0>s)
      return -1;

   while(total < len)
   {
      n = recv(s, l_buf+total, bytesleft,0);
      if (0 >= n)
      {
         if(0 > n)
         {
            CLOG("recv failed with errno: %d.to fd:[%d]", errno,s);
            if (EINTR == errno || EWOULDBLOCK == errno )
               continue;
         }
         else
            CLOG("Socket closed by Peer to fd:[%d].",s);
         //close(s);
         return n;
      }
      total += n;
      bytesleft -= n;
      DLOG( "received bytes %d, bytesleft %d, len %d, fd:[%d]",n,bytesleft,len, s);
   }
   len = total; // return number actually sent here
   return len;

}


