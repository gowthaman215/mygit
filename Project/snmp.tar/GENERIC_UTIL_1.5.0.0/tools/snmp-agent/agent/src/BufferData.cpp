#include <BufferData.h>
#include <stdio.h>
#include <Logger.h>

BufferData::BufferData()
{
   //DLOG(0,1,"BufferData :cons:");
   m_length=-1;
   m_data=NULL;
}

BufferData::~BufferData()
{
   //DLOG(0,1,"BufferData :des:");
   if (m_data != NULL)
   {
      delete[] m_data;
   }
}

