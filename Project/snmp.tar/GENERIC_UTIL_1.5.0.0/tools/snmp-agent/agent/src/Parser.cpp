/************************************************************************
** FILE NAME    : Parser.cpp
** AUTHOR       : 
** DEFINTION    : 
** REMARKS      :
************************************************************************/

#include <fstream>

#include "Parser.h"

/*****************************************************************************
** FUNCTION NAME  : Parser::readXMLFile()
** DEFINITON      : It opens the file and read the file contents and store in
** 								: string and returns it.
** ARGUMENTS      : fileName
** RETURN         : fileContents
** REMARKS        :
*****************************************************************************/
string Parser::readXMLFile (char *filename)
{
	string l_sFileContents;

	ifstream l_ifsXMLFile (filename);

	char l_cTmpChar;

	while (l_ifsXMLFile.get(l_cTmpChar))
		l_sFileContents += l_cTmpChar;

	l_ifsXMLFile.close ();

	return trimString (l_sFileContents);
}

/*****************************************************************************
** FUNCTION NAME  : Parser::getRootName()
** DEFINITON      : Initializes the Member variables and Mutex.
** ARGUMENTS      : aI_sXMLFileString
** RETURN         : 
** REMARKS        :
*****************************************************************************/
string Parser::getRootName (string aI_sXMLFileString)
{
	int l_iPatternBeginIndex = aI_sXMLFileString.find ("<");
	if (l_iPatternBeginIndex != (int)string::npos)
	{
		int l_iPatternEndIndex = aI_sXMLFileString.find (">", l_iPatternBeginIndex);
		if (l_iPatternEndIndex != (int)string::npos)
		{
			return  (aI_sXMLFileString.substr (l_iPatternBeginIndex+1, l_iPatternEndIndex-l_iPatternBeginIndex-1));
		}
	}
	return "";
}

// returns the substring of 'parent'
// that contains the tag (whose name is indicated by child)
string Parser::getChildString (string aI_sParentString, string aI_sChildName)
{
	string l_sBeginTag = "<" + aI_sChildName;
	string l_sEndTag = "</" + aI_sChildName + ">";

	int l_iPatternBeginIndex = aI_sParentString.find (l_sBeginTag);
	if (l_iPatternBeginIndex != (int)string::npos)
	{
		int l_iPatternEndIndex = aI_sParentString.rfind (l_sEndTag);
		if (l_iPatternEndIndex != (int)string::npos)
		{
			return  (aI_sParentString.substr (l_iPatternBeginIndex, l_iPatternEndIndex-l_iPatternBeginIndex+l_sEndTag.length()));
		}
	}
	return "";
}

list<string> Parser::getAllChildStrings (string aI_sParentString, string aI_sChildName)
{
	list<string> lp_lRetValue;

	string l_sBeginTag = "<" + aI_sChildName;
	string l_sEndTag = "</" + aI_sChildName + ">";

	int l_iPatternBeginIndex = aI_sParentString.find (l_sBeginTag);
	while (l_iPatternBeginIndex != (int)string::npos)
	{
		int l_iPatternEndIndex = aI_sParentString.find (l_sEndTag, l_iPatternBeginIndex);
		if (l_iPatternEndIndex != (int)string::npos)
		{
			 lp_lRetValue.push_back (aI_sParentString.substr (l_iPatternBeginIndex, l_iPatternEndIndex-l_iPatternBeginIndex+l_sEndTag.length()));
			 aI_sParentString = aI_sParentString.substr (l_iPatternEndIndex + l_sEndTag.length (), aI_sParentString.length ());
			 l_iPatternBeginIndex = aI_sParentString.find (l_sBeginTag);
		}
	}
	return lp_lRetValue;
}

// aI_sChildName -- the tag name
// aI_sParentString -- contains multiple instances of the tag 
// returns that value
string Parser::getValue (string aI_sParentString, string aI_sChildName)
{
	string l_sBeginTag = "<" + aI_sChildName;
	string l_sEndTag = "</" + aI_sChildName + ">";

	int l_iPatternBeginIndex = aI_sParentString.find (l_sBeginTag);
	if (l_iPatternBeginIndex != (int)string::npos)
	{
		int l_iTmpIndex = aI_sParentString.find (">", l_iPatternBeginIndex);
		if (l_iTmpIndex != (int)string::npos)
		{
			l_sBeginTag = aI_sParentString.substr (l_iPatternBeginIndex, l_iTmpIndex-l_iPatternBeginIndex+1);
			int l_iPatternEndIndex = aI_sParentString.find (l_sEndTag);
			if (l_iPatternEndIndex != (int)string::npos)
			{
				return  aI_sParentString.substr (l_iPatternBeginIndex+l_sBeginTag.length(), l_iPatternEndIndex-l_iPatternBeginIndex-l_sBeginTag.length());
			}
		}
	}
	return "";
}

// aI_sChildName -- the tag name
// aI_sParentString -- contains multiple instances of the tag 
// returns all the values as a list..
list<string> Parser::getAllValues (string aI_sParentString, string aI_sChildName)
{
	list <string> lst;

	string l_sBeginTag = "<" + aI_sChildName;
	string l_sEndTag = "</" + aI_sChildName + ">";

	int l_iPatternBeginIndex = aI_sParentString.find (l_sBeginTag);
	while (l_iPatternBeginIndex != (int)string::npos)
	{
		int l_iTmpIndex = aI_sParentString.find (">", l_iPatternBeginIndex);
		if (l_iTmpIndex != (int)string::npos)
		{
			l_sBeginTag = aI_sParentString.substr (l_iPatternBeginIndex, l_iTmpIndex-l_iPatternBeginIndex+1);
			int l_iPatternEndIndex = aI_sParentString.find (l_sEndTag);
			if (l_iPatternEndIndex != (int)string::npos)
			{
				lst.push_back (aI_sParentString.substr (l_iPatternBeginIndex+l_sBeginTag.length(), l_iPatternEndIndex-l_iPatternBeginIndex-l_sBeginTag.length()));
				aI_sParentString = aI_sParentString.substr (l_iPatternEndIndex+l_sEndTag.length (), aI_sParentString.length ());
				l_sBeginTag = "<" + aI_sChildName;
				l_iPatternBeginIndex = aI_sParentString.find (l_sBeginTag);
			}
		}
		else
			break;
	}
	return lst;
}

//returns a map of the <attribute, attributeValue>
//For Example: if input is the string
//"<Service Status="Subscribed">
//       <Name>ISD</Name>
//</Service>"
//Output will be a map containing <Status, Subscribed>
//ASSUMPTION: it is assumed here that the attribute value doesn't contain any " "
map <string, string> Parser::getAttributes (string aI_sParentString)
{
	map <string, string> lp_mRetValue;

	string l_sRootString = Parser::getRootName (aI_sParentString);

	string l_sAttributeName, l_sAttributeValue;

	int n = l_sRootString.find (" "); // " " separates tag_name and the following attributes
	if (n != (int)string::npos) // there is atleast one attribute
	{
		//remove the tag_name from the string
		//so, we are left with attributes only
		l_sRootString = l_sRootString.substr (n+1, l_sRootString.length());
		while (l_sRootString.length () != 0)
		{
			// "=" separates a attribute and the corresponding l_sAttributeValue
			int l_iAttrNameEndsAt = l_sRootString.find ("="); 
			if (l_iAttrNameEndsAt != (int)string::npos)
			{
				l_sAttributeName = l_sRootString.substr (0, l_iAttrNameEndsAt);
				int l_iAttrValueEndsAt = l_sRootString.find (" ", l_iAttrNameEndsAt);
				// no more additional attributes
				if (l_iAttrValueEndsAt == (int)string::npos)
				{
					l_sAttributeValue = l_sRootString.substr (l_iAttrNameEndsAt+1, l_sRootString.length());
					l_sRootString = ""; // to exit from the while loop
					
				}
				else
				{
					l_sAttributeValue = l_sRootString.substr (l_iAttrNameEndsAt+1, l_iAttrValueEndsAt-l_iAttrNameEndsAt-1);
					l_sRootString = l_sRootString.substr (l_iAttrValueEndsAt+1, l_sRootString.length ());
				}
				l_sAttributeValue = l_sAttributeValue.substr (1, l_sAttributeValue.length () - 2); // remove leading & trailing "
				lp_mRetValue.insert(map<string, string>::value_type(l_sAttributeName, l_sAttributeValue));
      }
		}
	}
	return lp_mRetValue;
}

// 1)remove the lines containing the <?xml version...
// 2)and <!DOCTYPE
// 3) also remove the comments..
// presently removes only one comment
// the argument: aI_sRawString may contain one or more of the above mentioned
// three patterns.
string Parser::trimString (string aI_sRawString)
{
	//remove <? xml version... ?>
	int l_iPatternBeginIndex = aI_sRawString.find ("<?");
	if (l_iPatternBeginIndex != (int)string::npos)
	{
		int l_iPatternEndIndex = aI_sRawString.find ("?>", l_iPatternBeginIndex);
		if (l_iPatternEndIndex != (int)string::npos)
		{
			aI_sRawString = aI_sRawString.substr (0, l_iPatternBeginIndex) + aI_sRawString.substr (l_iPatternEndIndex+2, aI_sRawString.length());
		}
	}

	//remove <!DOCTYPE
	l_iPatternBeginIndex = aI_sRawString.find ("<!DOCTYPE");
	if (l_iPatternBeginIndex != (int)string::npos)
	{
		int l_iPatternEndIndex = aI_sRawString.find (">", l_iPatternBeginIndex);
		if (l_iPatternEndIndex != (int)string::npos)
		{
			aI_sRawString = aI_sRawString.substr (0, l_iPatternBeginIndex) + aI_sRawString.substr (l_iPatternEndIndex+1, aI_sRawString.length());
		}
	}
	// remove <!-- .... -->
	// removes multiple comments
	// NOTE: nested comments not allowed.
	l_iPatternBeginIndex = aI_sRawString.find ("<!--");
	while (l_iPatternBeginIndex != (int)string::npos)
	{
		int l_iPatternEndIndex = aI_sRawString.find ("-->", l_iPatternBeginIndex);
		if (l_iPatternEndIndex != (int)string::npos)
		{
			aI_sRawString = aI_sRawString.substr (0, l_iPatternBeginIndex) + aI_sRawString.substr (l_iPatternEndIndex+3, aI_sRawString.length());
			l_iPatternBeginIndex = aI_sRawString.find ("<!--");
		}
		else
			return aI_sRawString;
	}

	return aI_sRawString;
}
