#include <ToolInterface.h>
#include <Logger.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <strings.h>
#include <MessageQueue.h>
#include <ConfigReader.h>
#include <BufferData.h>


extern uid_t g_uid;





map<string, int> g_TraceImsiMap;
map<string, int> g_TraceMsisdnMap;
MessageQueue *g_commandQueue = NULL;
MessageQueue *g_commandResponseQueue = NULL;
extern MessageQueue *g_OamTransactionsList;
char g_port[10];
bool initializeserver();
bool g_sameUser=false;
bool g_TracingPresentAtAll=false;

#define INVALID_USER_STRING  "WARNING!! You are not allowed to execute this command"

void *toolThrFunc(void*)
{
   if (false == initializeserver())
   {
      printf("\nUnable to initialize the Tool Interface Server");
      exit(560);
   }
   printf("\nend of toolThrFunc\n");
   return NULL;
}

ToolInterface::ToolInterface()
{
}

ToolInterface::~ToolInterface()
{
}

bool ToolInterface::initialize(int p_port)
{
   if ( (p_port <= 1024) ||
         (p_port > 99999) )
   {
      printf("\nInvalid Port %d", p_port);
      return false;
   }

   memset(g_port, '\0', 10);
   sprintf(g_port, "%d", p_port);

   g_commandQueue = new MessageQueue(QUEUE_TYPE_NON_BLOCKING);
   bool l_status = g_commandQueue->initialize();
   if (!l_status)
   {
      printf("\nERROR!! Unable to initialize the Command Queue");
      return false;
   }

   g_commandResponseQueue = new MessageQueue(QUEUE_TYPE_NON_BLOCKING);
   l_status = g_commandResponseQueue->initialize();
   if (!l_status)
   {
      printf("\nERROR!! Unable to initialize the Command Response Queue");
      return false;
   }

   pthread_t l_thread = pthread_create(&l_thread, NULL, toolThrFunc, NULL);

   return true;
}

// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
   if (sa->sa_family == AF_INET) {
      return &(((struct sockaddr_in*)sa)->sin_addr);
   }

   return &(((struct sockaddr_in6*)sa)->sin6_addr);
}



int RecvAll(int &s, char *buf, unsigned long len);
bool sendData(unsigned char *p_data, int p_length);
bool sendDataToNetwork(unsigned char *p_data, int p_length);

int g_clientDesc=0;
bool g_clientRegDoneFlag=false;




#if 0
bool processCommand(char *p_command)
{
   DLOG( "MMI Tool Called processCommand for command [%s]", p_command);
   char l_responseToBeSent[10000];
   memset(l_responseToBeSent, '\0', sizeof(l_responseToBeSent));
   strcpy(l_responseToBeSent, "Unable to process the command");


   char l_argv[100][40];

   int l_argc=0; 
   //char **l_argv;
   char * pch;
   pch = strtok (p_command," ");
   while (pch != NULL)
   {
      memset(l_argv[l_argc], '\0', 40);
      strncpy(l_argv[l_argc], pch, 39);
      l_argc++;
      pch = strtok (NULL, " ");
   }

   /*int i=0;
     for (i=0; i<l_argc; i++)
     {
     printf("\n printing -%s-", l_argv[i]);
     }*/

   char l_imsi[20+1];
   memset(l_imsi, '\0', 20+1);
   char l_msisdn[20+1];
   memset(l_msisdn, '\0', 20+1);


   char l_commandType = ' ';
   char l_commandSubType = ' ';
   char l_TraceType = ' ';
   char l_logLevel[20+1];
   memset(l_logLevel, '\0', 20+1);

   char l_opCode[3+1];
   memset(l_opCode, '\0', 3+1);
   char l_opVersion[3+1];
   memset(l_opVersion, '\0', 3+1);

   char l_file[100];
   memset(l_file, '\0', sizeof(l_file));


   char l_log_key[50+1];
   memset(l_log_key, '\0', sizeof(l_log_key));
   char l_log_value[50+1];
   memset(l_log_value, '\0', sizeof(l_log_value));



   for (int i = 0; i < l_argc; i++)
   {
      if (strcmp (l_argv[i], "-i") == 0)
      {
         memset(l_imsi, '\0', 20+1);
         strcpy (l_imsi, l_argv[++i]);
      }
      if (strcmp (l_argv[i], "-t") == 0)
      {
         memset(l_log_key, '\0', 50+1);
         strncpy (l_log_key, l_argv[++i], 50);
      }
      if (strcmp (l_argv[i], "-d") == 0)
      {
         memset(l_log_value, '\0', 50+1);
         strncpy (l_log_value, l_argv[++i], 50);
      }
      if (strcmp (l_argv[i], "-l") == 0)
      {
         memset(l_logLevel, '\0', 20+1);
         strcpy (l_logLevel, l_argv[++i]);
      }
      if (strcmp (l_argv[i], "-m") == 0)
      {
         memset(l_logLevel, '\0', 20+1);
         strcpy (l_logLevel, l_argv[++i]);
         strcpy (l_msisdn, l_logLevel);
      }
      if (strcmp (l_argv[i], "-r") == 0)
      {
         memset(l_logLevel, '\0', 20+1);
         strcpy (l_logLevel, l_argv[++i]);
      }
      if (strcmp (l_argv[i], "-v") == 0)
      {
         memset(l_opCode, '\0', 3+1);
         strncpy (l_opCode, l_argv[++i], 3);
      }
      if (strcmp (l_argv[i], "-s") == 0)
      {
         memset(l_opVersion, '\0', 3+1);
         strncpy (l_opVersion, l_argv[++i], 3);
      }
      if (strcmp (l_argv[i], "-f") == 0)
      {
         memset(l_file, '\0', sizeof(l_file));
         strcpy (l_file, l_argv[++i]);
      }
      if (strcmp (l_argv[i], "trace") == 0)
      {
         l_commandType = 'T';
      }
      if (strcmp (l_argv[i], "shutdown") == 0)
      {
         l_commandType = 'E';
      }
      if (strcmp (l_argv[i], "quantify") == 0)
      {
         l_commandType = 'Q';
      }
      if (strcmp (l_argv[i], "modifyconf") == 0)
      {
         l_commandType = 'M';
      }
      if (strcmp (l_argv[i], "reload") == 0)
      {
         l_commandType = 'R';
      }
      if (strcmp (l_argv[i], "profiles") == 0)
      {
         l_commandSubType = 'P';
      }
      if (strcmp (l_argv[i], "configuration") == 0)
      {
         l_commandSubType = 'C';
      }
      if (strcmp (l_argv[i], "library") == 0)
      {
         l_commandSubType = 'M';
      }
      if (strcmp (l_argv[i], "oamtransactions") == 0)
      {
         l_commandSubType = 'O';
      }
      if (strcmp (l_argv[i], "changelog") == 0)
      {
         l_commandSubType = 'L';
      }
      if (strcmp (l_argv[i], "changeopcode") == 0)
      {
         l_commandSubType = 'O';
      }
      if (strcmp (l_argv[i], "changeval") == 0)
      {
         l_commandSubType = 'V';
      }
      if (strcmp (l_argv[i], "stats") == 0)
      {
         l_commandType = 'S';
      }
      if (strcmp (l_argv[i], "getinfo") == 0)
      {
         l_commandType = 'I';
      }
      if (strcmp (l_argv[i], "getmoduleinfo") == 0)
      {
         l_commandType = 'G';
      }
      if (strcmp (l_argv[i], "resources") == 0)
      {
         l_commandType = 'Z';
      }
      if (strcmp (l_argv[i], "start") == 0)
      {
         l_TraceType = 'B';
      }
      if (strcmp (l_argv[i], "stop") == 0)
      {
         l_TraceType = 'E';
      }
   }


   CLOG( "MMI Tool: Sending response : [%s]", l_responseToBeSent);

   return sendData((unsigned char *)l_responseToBeSent, strlen(l_responseToBeSent));
}
#endif



bool sendData(unsigned char *p_data, int p_length)
{
   BufferData *l_bd = new BufferData;

   if ( (p_length < 1) ||
         (NULL == p_data)
      )
   {
      CLOG( "sendData called some error");
      l_bd->m_data = new unsigned char[20];
      memset(l_bd->m_data, '\0', 20);
      strcpy((char*)l_bd->m_data, "Some Error");
      l_bd->m_length = strlen((char*)l_bd->m_data);
   }
   else
   {
      DLOG( "sendData called normal [%d]", p_length);
      l_bd->m_data = new unsigned char[p_length];
      memset(l_bd->m_data, '\0', p_length);
      memcpy(l_bd->m_data, p_data, p_length);
      l_bd->m_length = p_length;

   }

   g_commandResponseQueue->push(l_bd);
   DLOG( "sendData end");
   return true;
}


bool sendDataToNetwork(unsigned char *p_data, int p_length)
{
   DLOG( "sendDataToNetwork called");
   unsigned char *l_data = (unsigned char *)"Some Error";
   int l_length=strlen((char*)l_data);

   if (NULL != p_data)
   {
      l_data = p_data;
      l_length = p_length;
   }

   if (0 == l_length)
   {
      ELOG( "sendDataToNetwork failed. Invalid length");
      return false;
   }
   if (g_clientDesc != 0)
   {
      char l_lengthChar[10];
      memset(l_lengthChar, '\0', 10);
      sprintf(l_lengthChar, "%09d", l_length);

      CLOG( "MMI Tool Sending Length [%s]", l_lengthChar);

      if (send(g_clientDesc, l_lengthChar, 9, 0) == -1) 
      {
         perror("send");
         return false;
      }

      if (send(g_clientDesc, l_data, l_length, 0) == -1) 
      {
         perror("send");
         return false;
      }
      DLOG( "MMI Tool Sending data successfull\n");      
   }
   else
   {
      CLOG( "No Client Desc present");
   }
   return true;
}

struct reg_msg
{
   uid_t  m_uid;
   time_t m_time;
};


bool initializeserver()
{
   DLOG( "Initializing the Tool Interface server socket");
   fd_set master;    // master file descriptor list
   fd_set read_fds;  // temp file descriptor list for select()
   int fdmax;        // maximum file descriptor number

   int listener;     // listening socket descriptor
   int newfd;        // newly accept()ed socket descriptor
   struct sockaddr_storage remoteaddr; // client address
   socklen_t addrlen;

   char buf[256];    // buffer for client data
   char buf_length[256];    // buffer for client data
   int nbytes;

   char remoteIP[INET6_ADDRSTRLEN];

   int yes=1;        // for setsockopt() SO_REUSEADDR, below
   int i, rv;

   struct addrinfo hints, *ai, *p;



   FD_ZERO(&master);    // clear the master and temp sets
   FD_ZERO(&read_fds);

   DLOG( "Calling getaddrinfo");

   // get us a socket and bind it
   memset(&hints, 0, sizeof hints);
   hints.ai_family = AF_UNSPEC;
   hints.ai_socktype = SOCK_STREAM;
   hints.ai_flags = AI_PASSIVE;
   if ((rv = getaddrinfo(NULL, g_port, &hints, &ai)) != 0) {
      fprintf(stderr, "selectserver: %s\n", gai_strerror(rv));
      ELOG( "selectserver: %s", gai_strerror(rv));
      return false;
   }

   for(p = ai; p != NULL; p = p->ai_next) 
   {
      DLOG( "Creating socket");
      listener = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
      if (listener < 0) 
      { 
         continue;
      }

      // lose the pesky "address already in use" error message
      setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));

      if (bind(listener, p->ai_addr, p->ai_addrlen) < 0) 
      {
         close(listener);
         ELOG( "MMI TOOL Interface: Unable to bind on port %s", g_port);
         return false;
      }

      break;
   }

   // if we got here, it means we didn't get bound
   if (p == NULL) {
      ELOG( "MMI TOOL Interface: Unable to bind on port %s", g_port);
      return false;
   }

   freeaddrinfo(ai); // all done with this

   // listen
   if (listen(listener, 10) == -1) {
      perror("listen");
      ELOG( "listen failed");
      return false;
   }

   CLOG( "Ready to accept commands from the MMI Tool");

   // add the listener to the master set
   FD_SET(listener, &master);

   // keep track of the biggest file descriptor
   fdmax = listener; // so far, it's this one

   // main loop
   for(;;) {
      read_fds = master; // copy it
      struct timeval tv;
      tv.tv_sec = 0;
      tv.tv_usec = 500000;

      DLOG( "MMI Tool calling select");

      if (select(fdmax+1, &read_fds, NULL, NULL, &tv) == -1) {
         //perror("select");
         sleep(1);
         continue;
      }

      if (g_commandResponseQueue != NULL)
      {
         void *l_pop = NULL;
         bool l_status = g_commandResponseQueue->pop(&l_pop);
         if (l_status)
         {
            BufferData *l_bd = (BufferData *)l_pop;
            CLOG( "Got a response to be sent %d", l_bd->m_length);
            sendDataToNetwork(l_bd->m_data, l_bd->m_length);
            delete(l_bd);
         }
      }

      // run through the existing connections looking for data to read
      for(i = 0; i <= fdmax; i++) {
         if (FD_ISSET(i, &read_fds)) { // we got one!!
            if (i == listener) {
               // handle new connections
               addrlen = sizeof remoteaddr;
               newfd = accept(listener,
                     (struct sockaddr *)&remoteaddr,
                     &addrlen);


               if (newfd == -1) {
                  perror("accept");
               } else {

                  //printf("\ng_clientDesc %d", g_clientDesc);
                  if (g_clientDesc != 0)
                  {
                     close(g_clientDesc);
                     FD_CLR(g_clientDesc, &master); // remove from master set
                     g_clientDesc=0;
                  }

                  g_clientDesc = newfd;
                  g_clientRegDoneFlag = false;

                  FD_SET(newfd, &master); // add to master set
                  if (newfd > fdmax) {    // keep track of the max
                     fdmax = newfd;
                  }
                  CLOG( "New connection from %s on socket %d\n",
                        inet_ntop(remoteaddr.ss_family, get_in_addr((struct sockaddr*)&remoteaddr), remoteIP, INET6_ADDRSTRLEN),
                        newfd);
               }
            } else {
               // handle data from a client
               memset(buf_length, '\0', 256);
               if ((nbytes = RecvAll(i, buf_length, 9)) <= 0) {
                  // got error or connection closed by client
                  if (nbytes == 0) {
                     // connection closed
                     CLOG( "MMI Tool disconnected (socket-fd %d)", i);
                  } else {
                     perror("recv");
                  }
                  close(i); // bye!
                  g_clientDesc=0;
                  FD_CLR(i, &master); // remove from master set
               } else {

                  //printf("\nTool recv len [%s]", buf_length);
                  DLOG( "Tool recv len [%s]", buf_length);

                  memset(buf, '\0', 256);
                  nbytes = RecvAll(i, buf, atoi(buf_length));
                  if (nbytes != atoi(buf_length))
                  {
                     //printf("\nCould not receive all %d bytes", atoi(buf_length));
                     CLOG( "MMI Tool disconnected (socket-fd %d)", i);
                     close(g_clientDesc);
                     FD_CLR(g_clientDesc, &master); // remove from master set
                     g_clientDesc=0;
                  }
                  else
                  {
                     if(false == g_clientRegDoneFlag)
                     {
                        DLOG( "Received buf [%s]", buf);

                        char l_temp_buf[256];
                        memset(l_temp_buf, '\0', sizeof(l_temp_buf));
                        strcpy(l_temp_buf, buf);

                        // Parse the Registration message
                        char l_received_time[10];
                        char l_received_uid[10];
                        char *l_colon = NULL;

                        l_colon = strchr(l_temp_buf, ':');
                        if(l_colon != NULL)
                        {
                           strncpy(l_received_uid, l_temp_buf, strlen(l_temp_buf) - strlen(l_colon));
                           strncpy(l_received_time, &l_temp_buf[strlen(l_temp_buf) - strlen(l_colon)+1], strlen(l_colon)-1);

                           DLOG( "UID [%s] [%s]", l_received_uid, l_received_time);

                           time_t l_tim_first =time(NULL);
                           DLOG( "l_tim_first %d got %d", l_tim_first, atoi(l_received_time));
                           int l_diff = abs(l_tim_first/10-atoi(l_received_time)/10);
                           if (l_diff > 10)
                           {
                              CLOG( "MMI Tool Invalid Registration. Closing the connection. Diff [%d]", l_diff);
                              close(g_clientDesc);
                              FD_CLR(g_clientDesc, &master); // remove from master set
                              g_clientDesc=0;
                              g_clientRegDoneFlag=false;
                           }
                           else
                           {
                              CLOG( "MMI Tool connected (socket-fd %d)", g_clientDesc);
                              char l_instance[100];
                              memset(l_instance, '\0', 100);
                              //sprintf(l_instance, "%s%03d_%05d", g_ConfigData->m_EntityName, g_ConfigData->m_InstanceId, getpid());
                              sprintf(l_instance, "%s_%06d", g_ConfigData->m_SnmpAgentName, getpid());
                              sendDataToNetwork((unsigned char*)l_instance, strlen(l_instance));
                              g_clientRegDoneFlag=true;
                              if (g_uid == atoi(l_received_uid))
                              {
                                 g_sameUser=true;
                              }
                              else
                              {
                                 g_sameUser=false;
                              }
                           }
                        }
                        else
                        {
                           CLOG( "MMI Tool Invalid Registration Format. Closing the connection.");
                           close(g_clientDesc);
                           FD_CLR(g_clientDesc, &master); // remove from master set
                           g_clientDesc=0;
                           g_clientRegDoneFlag=false;
                        }
                     }
                     else
                     {
                        DLOG( "command [%s]\n", buf);

                        char *l_newBuffer = new char[nbytes+1];
                        memset(l_newBuffer, '\0', nbytes+1);
                        strncpy(l_newBuffer, buf, nbytes);

                        DLOG( "pushing into queue");

                        g_commandQueue->push(l_newBuffer);
                     }
                  }
               }
            } // END handle data from client
         } // END got new incoming connection
      } // END looping through file descriptors
   } // END for(;;)--and you thought it would never end!

   return false;
}


int RecvAll(int &s, char *buf, unsigned long len)
{
   unsigned long total = 0;
   int bytesleft = len;
   int n;
   while(total < len)
   {
      if(0>s)
         return -1;

      n = recv(s, buf+total, bytesleft,0);
      if (0 >= n)
      {
         if(0 > n)
         {
            printf("\nrecv failed with errno: %d.", errno);
            if (EINTR == errno)
               continue;
         }
         else
            printf("\nSocket closed by Peer.");
         //close(s);
         return n;
      }
      total += n;
      bytesleft -= n;
      //printf("\nreceived bytes %d, bytesleft %d, len %d, sockFd: %d",n,bytesleft,len, s);
   }
   len = total; // return number actually sent here
   return len;
}

