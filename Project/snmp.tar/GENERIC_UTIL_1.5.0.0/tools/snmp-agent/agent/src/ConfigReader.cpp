/************************************************************************
 ** FILE NAME    : ConfigReader.cpp
 ** AUTHOR       : 
 ** DEFINTION    : 
 ** REMARKS      :
 ************************************************************************/

#include "Logger.h"
#include "ConfigReader.h"
#include "DataType.h"
#include "Parser.h"
#include "map"
#include "list"
#include "iterator"
#include "iostream"
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <netdb.h>
using namespace std;

extern int getPartitionValue(char *p_path);

ConfigData *g_ConfigData;
ConfigReader g_ConfigReader;


bool ValidateIpv4(char *p_ipadd)
{
   unsigned b1, b2, b3, b4;
   unsigned char c;

   if (sscanf(p_ipadd, "%3u.%3u.%3u.%3u%c", &b1, &b2, &b3, &b4, &c) != 4)
      return false;

   if ((b1 | b2 | b3 | b4) > 255)
      return  false;

   if (strspn(p_ipadd, "0123456789.") < strlen(p_ipadd))
      return false;

   return true;
}

ConfigData::ConfigData()
{
   memset(m_OID,0x00,100);
   memset(m_SnmpAgentName,'\0',sizeof(m_SnmpAgentName));
   m_SnmpAgentPort=0;
   m_ListenQSize=0;
   m_LogMedia="";
   m_LogLevel="";
   m_FilePath="";
   m_Prefix="";
   m_Traptime=0;
   m_MaxFileSize = 0;

}

ConfigData::~ConfigData()
{
}

bool ConfigReader::IsString(char *st)
{
   int l_StrLength = strlen(st);

   for(int l_index=0; l_index < l_StrLength; l_index++)
      if (isalpha(st[l_index]))
         return false;

   return true;
}

bool ConfigReader::IsInteger(char *st)
{
   int l_StrLength = strlen(st);

   for(int l_index=0; l_index < l_StrLength; l_index++)
   {

      if( (st[l_index] < '0') || (st[l_index] > '9'))
         return false;
   }

   return true;
}

string ConfigReader::readValue (string parent, string child)
{
   string n = Parser::getChildString (parent, child);
   string v = Parser::getValue (n, child);
   return v;
}

bool ConfigReader::readInteger(string parent, 
      string child, 
      int &ConfigValue,
      int min, 
      int max)
{
   string temp = readValue (parent, child);
   //cout << child << " = " << temp << endl;

   if (false == IsString((char *)temp.c_str()))
   {
      printf("\nConfiguration Value %s not numeric", child.c_str());
      return false;
   }

   if(false == IsInteger((char *)temp.c_str()))
   {
      printf("\nConfiguration Value %s not integer", child.c_str());
      return false;
   }

   ConfigValue  = atoi(temp.c_str());
   if (min > ConfigValue  || max < ConfigValue)
   {
      cout <<"Configuration Value [" << child << "] not in valid range. Should be between " << min << " and " << max << endl;
      return false;
   }
   return true;
}

bool ConfigReader::readInteger(string parent, 
      string child, 
      unsigned int &ConfigValue,
      unsigned int min, 
      unsigned int max)
{
   string temp = readValue (parent, child);
   //cout << child << " = " << temp <<endl;

   if (false == IsString((char *)temp.c_str()))
   {
      cout <<"Configuration Value not numeric." << endl;
      return false;
   }

   if(false == IsInteger((char *)temp.c_str()))
   {
      printf("\nConfiguration Value %s not integer", child.c_str());
      return false;
   }

   if (min > ConfigValue  || max < ConfigValue)
   {
      cout <<"Configuration Value not in valid range" << endl; 
      cout<<"For the Verification:"<<endl;
      return false;
   }
   ConfigValue  = atoi(temp.c_str());
   return true;
}

bool ConfigReader::readInteger(string parent, 
      string child, 
      short &ConfigValue,
      int min, 
      int max)
{
   string temp = readValue (parent, child);
   //cout << child << " = " << temp <<endl;

   if (false == IsString((char *)temp.c_str()))
   {
      cout <<"Configuration Value not numeric."<<endl;
      return false;
   }

   if(false == IsInteger((char *)temp.c_str()))
   {
      printf("\nConfiguration Value %s not integer", child.c_str());
      return false;
   }


   if (min > ConfigValue  || max < ConfigValue)
   {
      cout <<"Configuration Value not in valid range"<<endl; 
      return false;
   }
   ConfigValue  = atoi(temp.c_str());
   return true;
}

bool ConfigReader::readString(string  parent, string child,  char  *ConfigValue ,unsigned int min, unsigned int max) 
{
   string temp = readValue (parent, child);
   //cout << child << " = " << temp <<endl;

   if(min > temp.size()|| max < temp.size())
   {
      printf("\nInvalid %s Configuration value length", child.c_str());
      return false;
   }
   strcpy((char *)ConfigValue , temp.c_str()); 
   return true;
}


char *getLogLevel(char *p_level)
{
   switch (p_level[0])
   {
      case 'D':
         return "DEBUG";
         break;
      case 'T':
         return "TRACE";
         break;
      case 'W':
         return "WARNING";
         break;
      case 'C':
         return "CRITICAL";
         break;
      case 'E':
         return "ERROR";
         break;
      default:
         return "UNKNOWN";
         break;
   }
}

char *getLogMedia(char *p_media)
{
   switch (p_media[0])
   {
      case 'F':
         return "FILE";
         break;
      case 'C':
         return "CONSOLE";
         break;
      default:
         return "UNKNOWN";
         break;
   }
}

void getIpAddress(char *p_ipAddress)
{
   int x, ip_len = 16;
   char * str = NULL, * ip = NULL;
   struct hostent * hent = NULL;

   char l_name[51];
   memset(l_name, '\0', 51);
   size_t l_nameLength=0;
   gethostname(l_name, 50);

   hent = gethostbyname(l_name);
   str = hent -> h_addr_list[0];

   x = (*str < 0) ? (256 + *str) : *str;
   sprintf(p_ipAddress, "%d",x); str++;
   x = (*str < 0) ? (256 + *str) : *str;
   sprintf(p_ipAddress, "%s.%d",p_ipAddress, x); str++;
   x = (*str < 0) ? (256 + *str) : *str;
   sprintf(p_ipAddress, "%s.%d",p_ipAddress, x); str++;
   x = (*str < 0) ? (256 + *str) : *str;
   sprintf(p_ipAddress, "%s.%d%c",p_ipAddress, x, 0x00);

   return;
} 




bool ConfigReader::initStaticData()
{
   g_ConfigData = new ConfigData;
   string xmlFile;

   try
   {
      s8 m_filepath[80];
      char l_temp[128+1];
      char l_send_mail_path[256];
      memset(l_send_mail_path, '\0', sizeof(l_send_mail_path));


      sprintf(m_filepath, "./config/SnmpAgentStaticData.xml");
      //printf("\n***************************************************************************************************");
      //printf("\n\tEntered in Configuration file"); 
      if(!strcmp(m_filepath, ""))
      {
         printf("\nConfiguration file not found\n");
         return false;
      }
      else
         printf("\nReading the configuration file:  %s\n",m_filepath);
      //cout<<"Configuration File Path: "<<m_filepath<<endl;

      xmlFile = Parser::readXMLFile(m_filepath);

      string i_String = xmlFile;
      string networkserver = Parser::getChildString (i_String, "GSNMP_STATIC_DATA");

      /* Logger related starting */
      char l_log_attr[128];
      memset(l_log_attr,'\0',128);
      string nsLogger = Parser::getChildString(networkserver,"LOGGER");

      if(false == readString(nsLogger, "LOG_LEVEL", l_temp,1, 1))
         return false;
      g_ConfigData->m_LogLevel=l_temp;

      /*if(!(
        (strcmp(g_ConfigData->m_LogLevel.c_str(),"D")==0) || 
        (strcmp(g_ConfigData->m_LogLevel.c_str(),"W")==0) || 
        (strcmp(g_ConfigData->m_LogLevel.c_str(),"T")==0) || 
        (strcmp(g_ConfigData->m_LogLevel.c_str(),"E")==0) || 
        (strcmp(g_ConfigData->m_LogLevel.c_str(),"C")==0))
        {
        cout<<"Loglevel should be either of D or W or T or C or E"<<endl;
        return false;
        }
        */


      switch (g_ConfigData->m_LogLevel[0])
      {
         case 'D':
         case 'T':
         case 'W':
         case 'C':
         case 'E':
            //printf("\nLog level [%c]", g_ConfigData->m_LogLevel[0]);
            break;

         default:
            cout<<"Loglevel should be either of D or W or T or C or E"<<endl;
            return false;

            break;


      }



      if(false == readString(nsLogger, "LOG_MEDIA", l_temp,1, 1 ))
         return false;
      g_ConfigData->m_LogMedia=l_temp;

      switch (g_ConfigData->m_LogMedia[0])
      {
         case 'F':
         case 'C':
            //printf("\nLog Media [%c]", g_ConfigData->m_LogMedia[0]);
            break;

         default:

            cout<<"\nLog media should be either F or C"<<endl;
            return false;
            break;
      }

      if(false == readString( nsLogger, "FILE_PATH", l_temp,1,100))
         return false;
      g_ConfigData->m_FilePath=l_temp;

      if(false == readString( nsLogger, "FILE_PREFIX", l_temp,1,50))
         return false;
      g_ConfigData->m_Prefix=l_temp;

      if( false == readInteger(nsLogger, "MAX_FILE_SIZE", g_ConfigData->m_MaxFileSize,1,52428800 )) //50 MB
         return false;

      //printf("\n\tLOG_LEVEL=%s\n\tLOG_MEDIA=%s\n\tFILE_PATH=%s\n\tFILE_PREFIX=%s\n\tFILE_PREFIX=%d\n",
      //    g_ConfigData->m_LogLevel.c_str(),
      //g_ConfigData->m_LogMedia.c_str(),
      //g_ConfigData->m_FilePath.c_str(),
      //g_ConfigData->m_Prefix.c_str(),
      //g_ConfigData->m_MaxFileSize);

      printf("\n\nLoggers\t\t\t: Level:%s  Media:%s  Path:%s  Prefix:%s  MaxSize:%d",
            getLogLevel((char*)g_ConfigData->m_LogLevel.c_str()),
            getLogMedia((char*)g_ConfigData->m_LogMedia.c_str()),
            g_ConfigData->m_FilePath.c_str(),
            g_ConfigData->m_Prefix.c_str(),
            g_ConfigData->m_MaxFileSize);

      /* Logger related ending */

      //printf("\n\tSnmpAgentConfigData.xml Configuration values\n");


      if(false == readString(networkserver, "AGENT_NAME", g_ConfigData->m_SnmpAgentName, 1, 10))
         return false;
      printf("\nAgent Entity Name\t: %s",g_ConfigData->m_SnmpAgentName);

      char l_ipAddress[20];
      memset(l_ipAddress, '\0', 20);
      getIpAddress(l_ipAddress); 
      strcat(g_ConfigData->m_SnmpAgentName, ":");
      strcat(g_ConfigData->m_SnmpAgentName, l_ipAddress);

      if(false == readInteger(networkserver, "LISTEN_PORT", g_ConfigData->m_SnmpAgentPort, 1024,65535))
         return false;
      printf("\nEntity Listen Port\t: %d",g_ConfigData->m_SnmpAgentPort);

      if(false == readString(networkserver, "TRAP_OID", g_ConfigData->m_OID, 1, 100))
         return false;


      if(false == readInteger(networkserver, "HEART_BEAT_INTERVAL", g_ConfigData->m_Traptime, 60, 86400))
         return false;
      printf("\nHeart Beat Interval\t: %d",g_ConfigData->m_Traptime);

      if(false == readInteger(networkserver, "TRAP_SENDER_POOL_SIZE", g_ConfigData->m_TrapSenderPoolSize, 1, 50))
         return false;
      printf("\nTrap Sender Pool Size\t: %d",g_ConfigData->m_TrapSenderPoolSize);


      if(false == readInteger(networkserver, "DISABLE_CLIENT_CONNECTION_TRAPS_AT_STARTUP", g_ConfigData->m_DisableConnectionTrapsAtStartup, 0, 1))
         return false;
      printf("\nDisable Client Connection Traps (at startup)\t: %d",g_ConfigData->m_DisableConnectionTrapsAtStartup);

      string l_alarmAttr = Parser::getChildString(networkserver,"TRAP_ATTRIBUTES");
      printf("\nTrap OID \t\t: %s", g_ConfigData->m_OID);

      printf("\nTrap Parameters: ");

      memset(l_temp,'\0',128+1);

      if(false == readString(l_alarmAttr, "ENTITY",l_temp, 1, 50))
         return false;
      g_ConfigData->m_alrm_entity=l_temp;

      if(false == readString(l_alarmAttr, "ID",l_temp, 1, 50))
         return false;
      g_ConfigData->m_alrm_id=l_temp;


      if(false == readString(l_alarmAttr, "DESC",l_temp, 1, 50))
         return false;
      g_ConfigData->m_alrm_text=l_temp;

      if(false == readString(l_alarmAttr, "TYPE",l_temp, 1, 50))
         return false;
      g_ConfigData->m_alrm_type=l_temp;

      if(false == readString(l_alarmAttr, "SEVERITY",l_temp, 1, 50))
         return false;
      g_ConfigData->m_alrm_severity=l_temp;

      if(false == readString(l_alarmAttr, "DATETIME",l_temp, 1, 50))
         return false;
      g_ConfigData->m_alrm_time=l_temp;

      if(false == readString(l_alarmAttr, "AGENT_NAME",l_temp, 1, 50))
         return false;
      g_ConfigData->m_alrm_agent_name=l_temp;

      if(false == readString(l_alarmAttr, "THRESHOLD_INFO",l_temp, 1, 50))
         return false;
      g_ConfigData->m_alrm_threshold_info=l_temp;

      printf("\n\tEntity\t\t: %s\n\tId\t\t: %s\n\tDesc\t\t: %s\n\tType\t\t: %s\n\tSeverity\t: %s\n\tDateTime\t: %s\n\tAgentName\t: %s\nThresholdInfo\t: %s\n",g_ConfigData->m_alrm_entity.c_str(),g_ConfigData->m_alrm_id.c_str(),g_ConfigData->m_alrm_text.c_str(),g_ConfigData->m_alrm_type.c_str(),g_ConfigData->m_alrm_severity.c_str(),g_ConfigData->m_alrm_time.c_str(),g_ConfigData->m_alrm_agent_name.c_str(),g_ConfigData->m_alrm_threshold_info.c_str());


      // Tool Related
      string tool = Parser::getChildString(networkserver, "MML_TOOL");
      if (0 == tool.size())
      {
         return false;
      }

      if( false == readInteger(tool, "FLAG", g_ConfigData->m_ToolEnabledFlag, 0, 1))
         return false;

      if (1 == g_ConfigData->m_ToolEnabledFlag)
      {
         if( false == readInteger(tool, "LISTEN_PORT", g_ConfigData->m_ToolPort, 1024, 65535))
            return false;
      }
      // End of Tool Relate
      return true;
   }
   catch(...)
   {
      cout<<"[ERROR]: Failed to read from configuration file."<<endl;
      return false;
   }
}
bool ConfigReader::setSeverityDetails(string p_configstr,severity_Details *p_severity, char *p_errorMsg)
{
   int l_critical_flag = 0;
   int l_to_flag = 0;
   if(false == readInteger(p_configstr, "F",l_critical_flag , 0, 1))
   {
      snprintf(p_errorMsg, 1000, "Flag address not present  between '0' and '1'[%s]", p_configstr.c_str());
      return false;
   }
   TLOG("Enable Flag :[%d]",l_critical_flag);
   printf("\n\tTO\t\t:");
   string l_to = Parser::getChildString(p_configstr,"TO");
   Address_String l_add;
   if(false == readInteger(l_to, "F",l_to_flag , 0, 1))
   {
      snprintf(p_errorMsg, 1000, " TO flag address not present  between '0' and '1'[%s]", l_to.c_str());
      return false;
   }
   TLOG("Enable Flag :[%d]",l_to_flag);
   list<string> l_to_list;
   for(int l_cnt1 = 1;l_cnt1 <= MAX_ADDRESS_COUNT; ++l_cnt1)
   {
      char temp1[20];
      memset(temp1,'\0',sizeof(temp1));
      sprintf(temp1,"REC_%02d",l_cnt1);

      TLOG("Reading RECIPIENTS Address [%s]", temp1);

      string l_rec = Parser::getChildString(l_to, temp1);
      if(l_rec.empty())
      {
         CLOG(0,1,"Didnt found [%s]", temp1);
         break;

      }
      char l_name1[100+1];

      memset(l_name1, '\0', sizeof(l_name1));
      if(false == readString(l_rec, temp1, l_name1, 1, 100))
      {
         snprintf(p_errorMsg, 1000, "TO Address Name is not present");
         return false;
      }
      printf("\n\t%s\t\t:  %s",temp1, l_name1);
      TLOG("Pushing TO Into the list with Flag: [%d] To Name: [%s]",l_to_flag, l_name1);
      l_to_list.push_back(l_name1);
   }
   p_severity->to_recipient_name.add_flag = l_to_flag;
   p_severity->to_recipient_name.recipient_name.assign(l_to_list.begin(), l_to_list.end());
   //Critical CC
   printf("\n\tCC\t\t:");
   int l_cc_flag =0;
   string l_cc = Parser::getChildString(p_configstr,"CC");
   Address_String l_ccadd;
   if(false == readInteger(l_cc, "F",l_cc_flag , 0, 1))
   {
      snprintf(p_errorMsg, 1000, " TO Critical flag address not present  between '0' and '1'[%s]", l_cc.c_str());
      return false;
   }
   list<string> l_cc_list;
   for(int l_cnt2 = 1;l_cnt2 <= MAX_ADDRESS_COUNT; ++l_cnt2)
   {
      char temp2[20];
      memset(temp2,'\0',sizeof(temp2));
      sprintf(temp2,"REC_%02d",l_cnt2);

      TLOG("Reading RECIPIENTS Address [%s]", temp2);

      string l_ccrec = Parser::getChildString(l_cc, temp2);
      if(l_ccrec.empty())
      {
         CLOG(0,1,"Didnt found [%s]", temp2);
         break;

      }
      char l_name2[100+1];
      memset(l_name2, '\0', sizeof(l_name2));
      if(false == readString(l_ccrec, temp2, l_name2, 1, 100))
      {
         snprintf(p_errorMsg, 1000, "CC Address Name is not present");
         return false;
      }
      printf("\n\t%s\t\t:  %s",temp2, l_name2);
      TLOG("Pushing CC Into the list with Flag: [%d] To Name: [%s]",l_cc_flag, l_name2);
      l_cc_list.push_back(l_name2);
   }
   p_severity->cc_recipient_name.add_flag = l_cc_flag;
   p_severity->cc_recipient_name.recipient_name.assign(l_cc_list.begin(), l_cc_list.end());
   //Critical BCC
   printf("\n\tBCC\t\t:");
   string l_bcc = Parser::getChildString(p_configstr,"BCC");
   Address_String l_bccadd;
   int l_bcc_flag = 0;
   if(false == readInteger(l_bcc, "F",l_bcc_flag , 0, 1))
   {
      snprintf(p_errorMsg, 1000, " TO Critical flag address not present  between '0' and '1'[%s]", l_bcc.c_str());
      return false;
   }
   list<string> l_bcc_list;
   for(int l_cnt3 = 1;l_cnt3 <= MAX_ADDRESS_COUNT; ++l_cnt3)
   {
      char temp3[20];
      memset(temp3,'\0',sizeof(temp3));
      sprintf(temp3,"REC_%02d",l_cnt3);

      TLOG("Reading RECIPIENTS Address [%s]", temp3);

      string l_bccrec = Parser::getChildString(l_bcc, temp3);
      if(l_bccrec.empty())
      {
         CLOG(0,1,"Didnt found [%s]", temp3);
         break;

      }
      char l_name3[100+1];
      memset(l_name3, '\0', sizeof(l_name3));
      if(false == readString(l_bccrec, temp3, l_name3, 1, 100))
      {
         snprintf(p_errorMsg, 1000, "BCC Address Name is not present");
         return false;
      }
      printf("\n\t%s\t\t:  %s",temp3, l_name3);
      TLOG("Pushing BCC Into the list with Flag: [%d] To Name: [%s]",l_bcc_flag, l_name3);
      l_bcc_list.push_back(l_name3);
   }
   p_severity->flag = l_critical_flag;
   p_severity->bcc_recipient_name.add_flag = l_bcc_flag;
   p_severity->bcc_recipient_name.recipient_name.assign(l_bcc_list.begin(), l_bcc_list.end());
}



bool ConfigReader::initDynamicData(DynamicConfigData **p_dcd, char *p_errorMsg)
{
   *p_dcd = new DynamicConfigData;
   DynamicConfigData *l_dcd = *p_dcd;

   string xmlFile;

   try
   {
      s8 m_filepath[80];
      char l_temp[128+1];


      sprintf(m_filepath, "./config/SnmpAgentDynamicData.xml");
      //printf("\n***************************************************************************************************");
      //printf("\n\tEntered in Configuration file"); 
      if(!strcmp(m_filepath, ""))
      {
         snprintf(p_errorMsg, 1000, "Configuration file [%s] not found", m_filepath);
         return false;
      }
      else
         printf("\nReading the configuration file:  %s\n",m_filepath);
      //cout<<"Configuration File Path: "<<m_filepath<<endl;

      xmlFile = Parser::readXMLFile(m_filepath);

      string i_String = xmlFile;
      string networkserver = Parser::getChildString (i_String, "GSNMP_DYNAMIC_DATA");

      if(false == readInteger(networkserver, "AGENT_SERVER_ID",l_dcd->m_defaultAgentServerId , 1, 99999))
      {
         snprintf(p_errorMsg, 1000, "AGENT_SERVER_ID should be between 1 and 99999");
         return false;
      }

      if(false == readInteger(networkserver, "AGENT_CLIENT_ID",l_dcd->m_defaultAgentClientId , 1, 99999))
      {
         snprintf(p_errorMsg, 1000, "AGENT_CLIENT_ID should be between 1 and 99999");
         return false;
      }

      if(false == readInteger(networkserver, "AGENT_COUNTRY_ID",l_dcd->m_defaultCountryId , 1, 99999))
      {
         snprintf(p_errorMsg, 1000, "AGENT_COUNTRY_ID should be between 1 and 99999");
         return false;
      }

#if 0
      printf("\nMailing list:");
      TLOG("Reading EMAIL");
      string l_email = Parser::getChildString(networkserver, "EMAIL");
      int l_flag = 0;

      if(false == readInteger(l_email, "F",l_flag , 0, 1))
      {
         snprintf(p_errorMsg, 1000, "EMAIL Sending Flag is not Present between '0' and '1'[%s]", l_email.c_str());
         return false;
      }
      if( 0 == l_flag)
      {
         ELOG("EMAIL Sending Flag is not Present between '0' and '1'[%s]",l_email.c_str());
         return false; 
      }
      else 
      {
         printf("\n\tFLAG:%\t\t:  %d",l_flag);
         char l_ipaddress[50];
         char l_fromaddress[100];
         memset(l_fromaddress, '\0', sizeof(l_fromaddress));
         memset(l_ipaddress, '\0', sizeof(l_ipaddress));
         int l_emailtrapseverity = 0;
         if(false == readString(l_email, "MAIL_SERVER_IP", l_ipaddress, 7, 30))
         {
            snprintf(p_errorMsg, 1000, "IP_ADDRESS not present");
            return false;
         }
         printf("\n\tMAIL_SERVER_IP\t:  %s",l_ipaddress);
         if(false == readString(l_email, "FROM_ADDRESS", l_fromaddress, 1, 100))
         {
            snprintf(p_errorMsg, 1000, "FROM_ADDRESS not present");
            return false;
         }
         printf("\n\tFROM_ADDRESS\t:  %s",l_fromaddress);
         printf("\nRECIPIENT_LISTS:");
         for(int l_cnt=1;l_cnt<=MAX_ADDRESS_COUNT;++l_cnt)
         {
            char temp[20];
            memset(temp,'\0',sizeof(temp));
            sprintf(temp,"LIST_%02d",l_cnt);
            TLOG("Reading To Address [%s]", temp);
            string l_recipient_list  = Parser::getChildString(l_email, "RECIPIENT_LISTS");
            string l_list = Parser::getChildString(l_recipient_list, temp);
            if(l_list.empty())
            {
               CLOG(0,1,"Didnt found [%s]", temp);
               break;

            }
            printf("\n\t%s\t\t:",temp);
            char l_name[100 + 1];
            memset(l_name, '\0', sizeof(l_name));
            if(false == readString(l_list, "NAME",l_name, 1, 100))
            {
               snprintf(p_errorMsg, 1000, "Name is  not present");
               return false;
            }
            printf("\n\tNAME\t\t:  %s",l_name);
            list<string> l_email;
            for(int l_cnt1=1;l_cnt1 <= MAX_ADDRESS_COUNT; ++l_cnt1)
            {
               char temp1[20];
               memset(temp1,'\0',sizeof(temp1));
               sprintf(temp1,"ADDRESS_%02d",l_cnt1);
               TLOG("Reading To Address [%s]", temp1);
               string l_address = Parser::getChildString(l_list,temp1);
               if(l_address.empty())
               {
                  CLOG(0,1,"Didnt found [%s]", temp1);
                  break;

               }
               char l_email_add[101];
               memset(l_email_add, '\0', sizeof(l_email_add));
               if(false == readString(l_address, temp1,l_email_add, 1, 100))
               {
                  snprintf(p_errorMsg, 1000, "Name is  not present");
                  return false;
               }
               printf("\n\t%s\t:  %s\t",temp1, l_email_add);
               l_email.push_back(l_email_add);
            }
            l_dcd->m_mail_listmap.insert(pair<string,list<string> >(l_name, l_email));
            l_email.clear();
         }
         printf("\nRECIPIENT TRAP SEVERITY:");

         string l_recipient  = Parser::getChildString(l_email, "RECIPIENTS");
         string l_critical = Parser::getChildString(l_recipient,"CRITICAL");

         printf("\nCRITICAL\t:");
         DLOG("CRITICAL");
         setSeverityDetails(l_critical, &l_dcd->m_email_Address.critical_email_list, p_errorMsg);

         string l_major = Parser::getChildString(l_recipient,"MAJOR");
         printf("\nMAJOR\t:");
         DLOG("MAJOR");
         setSeverityDetails(l_major, &l_dcd->m_email_Address.major_email_list, p_errorMsg);

         string l_minor = Parser::getChildString(l_recipient,"MINOR");
         printf("\nMINOR\t:");
         DLOG("MINOR");
         setSeverityDetails(l_minor, &l_dcd->m_email_Address.minor_email_list, p_errorMsg);


         string l_warning = Parser::getChildString(l_recipient,"WARNING");
         printf("\nWARNING\t:");
         DLOG("WARNING");
         setSeverityDetails(l_warning, &l_dcd->m_email_Address.warning_email_list, p_errorMsg);

         l_dcd->m_email_Address.flag = 1;
         l_dcd->m_email_Address.ip_address = l_ipaddress;
         l_dcd->m_email_Address.s_from_address = l_fromaddress;
      }
#endif

      printf("\nEntity Templates :");
      TLOG("Reading ENTITY_TEMPLATES");
      string l_templates_string = Parser::getChildString(networkserver, "ENTITY_TEMPLATES");
      map<int,list<TrapInfo> >::iterator t_itr;
      for(int l_cnt=1;l_cnt<=MAX_TEMPLATES_COUNT;++l_cnt)
      {
         char temp[20];
         memset(temp,'\0',sizeof(temp));
         sprintf(temp,"TEMPLATE_%02d",l_cnt);

         TLOG("Reading Entity Template [%s]", temp);

         string l_nsApp2 = Parser::getChildString(l_templates_string,temp);
         if(l_nsApp2.empty())
         {
            CLOG(0,1,"Didnt found [%s]", temp);
            break;
         }

         list<TrapInfo> l_traplist;
         for(int l_innCnt=1;l_innCnt<=MAX_TRAPS_PER_TEMPLATE_COUNT;++l_innCnt)
         {
            TrapInfo l_trapInfo;
            memset(&l_trapInfo,'\0',sizeof(l_trapInfo));
            char l_trapChar[20];
            memset(l_trapChar,'\0',sizeof(l_trapChar));
            sprintf(l_trapChar,"TRAP_%02d",l_innCnt);
            string l_nsApp3 = Parser::getChildString(l_nsApp2,l_trapChar);
            if(l_nsApp3.empty())
            {
               CLOG(0,1,"Didnt found [%s]", l_trapChar);
               break;
            }
            if(false == readString(l_nsApp3, "ID",l_trapInfo.id , 2, 20))
            {
               snprintf(p_errorMsg, 1000, "ID not present in [%s]", l_nsApp3.c_str());
               return false;
            }
            if(false == readInteger(l_nsApp3, "INTERVAL",l_trapInfo.interval , 0, 24*60*60))
            {
               snprintf(p_errorMsg, 1000, "INTERVAL not present in [%s]", l_nsApp3.c_str());
               return false;
            }
            l_traplist.push_back(l_trapInfo);
            printf("\n\tTEMPLATE%_%02d \t:  %s:%d",l_cnt,l_trapInfo.id,l_trapInfo.interval);

         }
         l_dcd->m_TrapInfoMap.insert(pair<int,list<TrapInfo> >(l_cnt,l_traplist));
      }

      TLOG("Total Number of Entity Templates: %d", l_dcd->m_TrapInfoMap.size());


      /*Entities Related Information Started*/
      string l_nsApp = Parser::getChildString(networkserver, "ENTITIES");


      printf("\nEntities :");
      for(int l_appCnt=1;l_appCnt<=MAXAPPCONF;++l_appCnt)
      {
         DeviceInfo l_device_parms;
         char index[20];
         memset(index,0x00,20);
         sprintf(index,"ENTITY_%02d",l_appCnt);

         string l_nsAppCnt = Parser::getChildString(l_nsApp,index);
         if(l_nsAppCnt.empty())
            break;

         char  l_dev_name[20];
         char  l_ip_address[20];

         memset(l_dev_name,0x00,20);
         memset(l_ip_address, '\0', 20);


         if(false == readString(l_nsAppCnt, "F",l_temp, 1, 1))
         {
            snprintf(p_errorMsg, 1000, "F not present");
            return false;
         }
         if((atoi(l_temp)==0) ||  (atoi(l_temp)==1))
         {

            if(false == readString(l_nsAppCnt, "NAME",l_dev_name , 2, 19))
            {
               snprintf(p_errorMsg, 1000, "NAME not present");
               return false;
            }


            l_device_parms.device_name=l_dev_name;

            if(false == readString(l_nsAppCnt, "IP_ADDRESS",l_ip_address , 7, 19))
            {
               snprintf(p_errorMsg, 1000, "IP_ADDRESS not present");
               return false;
            }

            if (false == ValidateIpv4(l_ip_address))
            {
               printf("\nInvalid IP Address [%s]", l_ip_address);
               snprintf(p_errorMsg, 1000, "Invalid IP Address [%s]", l_ip_address);
               return false;
            }

            int l_productId;
            if(false == readInteger(l_nsAppCnt, "PRODUCT_ID",l_productId , 1, 200))
            {
               snprintf(p_errorMsg, 1000, "PRODUCT_ID not present");
               return false;
            }
            int l_instanceSeqId;
            if(false == readInteger(l_nsAppCnt, "INSTANCE_SEQ_ID",l_instanceSeqId , 1, 200))
            {
               snprintf(p_errorMsg, 1000, "INSTANCE_SEQ_ID not present");
               return false;
            }

            int l_serverId;
            if(false == readInteger(l_nsAppCnt, "O_SERVER_ID",l_serverId , 1, 200))
            {
               l_serverId=l_dcd->m_defaultAgentServerId;
            }

            int l_clientId;
            if(false == readInteger(l_nsAppCnt, "O_CLIENT_ID",l_clientId , 1, 200))
            {
               l_clientId=l_dcd->m_defaultAgentClientId;
            }

            int l_countryId;
            if(false == readInteger(l_nsAppCnt, "O_COUNTRY_ID",l_countryId , 1, 200))
            {
               l_countryId=l_dcd->m_defaultCountryId;
            }

            int l_subProductId=1; //Default SubProduct ID is 1
            if(false == readInteger(l_nsAppCnt, "O_SUB_PRODUCT_ID",l_subProductId , 1, 200))
            {
               l_subProductId=1;
            }

            int l_templateid =0;
            if(false == readInteger(l_nsAppCnt, "TEMPLATE",l_templateid , 0, 99))
            {
               snprintf(p_errorMsg, 1000, "TEMPLATE not present");
               return false;
            }

            if (0 != l_templateid)
            {
               map<int,list<TrapInfo> >:: iterator t_itr=l_dcd->m_TrapInfoMap.find(l_templateid);
               if(t_itr == l_dcd->m_TrapInfoMap.end())
               {
                  snprintf(p_errorMsg, 1000, "Template ID [%d] not found in the Entity Templates", l_templateid);
                  return false;
               }
            }

            string l_total_device_name = l_dev_name;
            l_total_device_name = l_total_device_name + ":" + l_ip_address;
            l_device_parms.ip_address = l_ip_address;
            l_device_parms.templateid = l_templateid;
            l_device_parms.server_id = l_serverId;
            l_device_parms.client_id = l_clientId;
            l_device_parms.country_id = l_countryId;
            l_device_parms.product_id = l_productId;
            l_device_parms.instance_seq_id = l_instanceSeqId;
            l_device_parms.sub_product_id = l_subProductId;


            if(0 == strcmp(l_temp, "1"))
            {
               l_dcd->m_MasterDeviceName.insert(pair<string,DeviceInfo>(l_total_device_name,l_device_parms));
            }

            printf("\n\tENTITY_%02d \t: %-15s %s:%s",
                  l_appCnt,l_temp[0]=='0'?"Ignoring":"Monitoring", l_dev_name,l_ip_address);
         }
         else
         {
            printf("please enter the F value either 0 or 1");
            snprintf(p_errorMsg, 1000, "please enter the F value either 0 or 1");
            return false;
         }

      }

      if(l_dcd->m_MasterDeviceName.empty())
      {
         printf("\nPlease Configure at least one entity to continue.\n");
         return false;
      }


      /*Entities Related Information Ended*/


      /* Manager Related(IP,PORT,enbled/desabled) Information Startes*/

      string l_manApp = Parser::getChildString(networkserver,"MANAGERS");

      printf("\n\nManagers:");
      for(int l_manCnt=1;l_manCnt<=MAXAPPCONF;++l_manCnt)
      {
         MangInfo l_man_params;
         char index[20];
         memset(index,'\0',20);
         sprintf(index,"MANAGER_%02d",l_manCnt);

         string l_nsManCnt = Parser::getChildString(l_manApp,index);
         if(l_nsManCnt.empty())
            break;

         if(false == readString(l_nsManCnt, "F",l_temp , 1, 1))
         {
            snprintf(p_errorMsg, 1000, "F tag is not present");
            return false;
         }

         if((atoi(l_temp)==0) ||  (atoi(l_temp)==1))
         {

            l_man_params.device_on_off = l_temp;

            if(false == readString(l_nsManCnt, "IP_ADDRESS",l_temp , 2, 16))
            {
               snprintf(p_errorMsg, 1000, "IP_ADDRESS not present");
               return false;
            }
            if (false == ValidateIpv4(l_temp))
            {
               printf("\nInvalid IP Address [%s]", l_temp);
               snprintf(p_errorMsg, 1000, "Invalid IP Address [%s]", l_temp);
               return false;
            }
            l_man_params.ip=l_temp;

            if(false == readString(l_nsManCnt, "PORT",l_temp , 1, 4))
            {
               snprintf(p_errorMsg, 1000, "PORT not present");
               return false;
            }
            if( (atoi(l_temp) < 1) || (atoi(l_temp) > 9999))
            {
               printf("\nInvalid Manager Port %d. Port should be between 1 and 9999",atoi(l_temp));
               snprintf(p_errorMsg, 1000, "Invalid Manager Port %d. Port should be between 1 and 9999",atoi(l_temp));
               return false;
            }
            l_man_params.port=l_temp;
         }
         else
         {
            printf("please enter the F value either 0 or 1");
            snprintf(p_errorMsg, 1000, "please enter the F value either 0 or 1");
            return false;
         }


         if(0 == strcmp(l_man_params.device_on_off.c_str(), "1"))
         {
            l_dcd->m_ManIpPortList.push_back(l_man_params);
            //printf("\n\tMANAGER_%02d\n\tF=1\n\tIP_ADDRESS=%s\n\tPORT=%s\n",l_manCnt,l_man_params.ip.c_str(),l_man_params.port.c_str());
         }


         printf("\n\tMANAGER_%02d \t: %-15s %s:%s",
               l_manCnt,
               (0 == strcmp(l_man_params.device_on_off.c_str(), "0")?"Ignoring":"Informing"),
               l_man_params.ip.c_str(),l_man_params.port.c_str());
      }

      if(l_dcd->m_ManIpPortList.empty())
      {
         printf("Please Configure at least one Manager to continue.\n");
         snprintf(p_errorMsg, 1000, "Please Configure at least one Manager to continue");
         return false;
      }

      /* Manager Related(IP,PORT,enbled/desabled) information ended*/

      //Adding to check the disk usage of directories

      string l_partitions = Parser::getChildString(networkserver,"PARTITIONS");

      printf("\n\nPartitions:");
      for(int l_partCount=1;l_partCount<=MAX_PART_COUNT;++l_partCount)
      {
         PartitionInfo l_man_params;
         l_man_params.fail_sent=0;
         l_man_params.limit=0;
         char index[20];
         memset(index,'\0',20);
         sprintf(index,"PARTITION_%02d",l_partCount);

         string l_nsManCnt = Parser::getChildString(l_partitions,index);
         if(l_nsManCnt.empty())
            break;

         if(false == readString(l_nsManCnt, "F",l_temp , 1, 1))
         {
            snprintf(p_errorMsg, 1000, "F not present");
            return false;
         }

         if((atoi(l_temp)==0) ||  (atoi(l_temp)==1))
         {

            l_man_params.dir_on_off = l_temp;

            if(false == readString(l_nsManCnt, "DIRECTORY",l_temp , 2, 200))
            {
               snprintf(p_errorMsg, 1000, "DIRECTORY not present");
               return false;
            }
            l_man_params.dir=l_temp;
         }
         else
         {
            printf("please enter the F value either 0 or 1");
            snprintf(p_errorMsg, 1000, "please enter the F value either 0 or 1");
            return false;
         }


         if(0 == strcmp(l_man_params.dir_on_off.c_str(), "1"))
         {
            /*
               if(-1 == getPartitionValue((char*)l_man_params.dir.c_str()))
               {
               printf("\nPartition [%s] not found\n", (char*)l_man_params.dir.c_str());
               return false;
               }
               */

            if( false == readInteger(l_nsManCnt, "LIMIT", l_man_params.limit, 1, 100 ))
            {
               snprintf(p_errorMsg, 1000, "LIMIT not present");
               return false;
            }

            l_dcd->m_PartitionList.push_back(l_man_params);
            //printf("\n\tMANAGER_%02d\n\tF=1\n\tIP_ADDRESS=%s\n\tPORT=%s\n",l_partCount,l_man_params.ip.c_str(),l_man_params.port.c_str());
         }


         printf("\n\tPARTITION_%02d \t: %-15s %s:%d",
               l_partCount,
               (0 == strcmp(l_man_params.dir_on_off.c_str(), "0")?"Ignoring":"Informing"),
               l_man_params.dir.c_str(),
               l_man_params.limit);
      }

      if(l_dcd->m_PartitionList.empty())
      {
         printf("No Partitions are configured\n");
         snprintf(p_errorMsg, 1000, "No Partitions are configured");
         return false;
      }

      /* Manager Related(IP,PORT,enbled/desabled) information ended*/
      return true ;
   }
   catch(...)
   {
      cout<<"[ERROR]: Failed to read from configuration file."<<endl;
      snprintf(p_errorMsg, 1000, "Failed to read from configuration file.");
      return false;
   }
}

char *ConfigReader::getConfigPrint()
{
   char *l_configDataChar = new char[100000];
   memset(l_configDataChar, '\0', 5000);
   strcpy(l_configDataChar, "\n");


   char l_temp[2000];
   memset(l_temp, '\0', 2000);


   sprintf(l_temp,"\n\nLoggers\t\t\t: Level:%s  Media:%s  Path:%s  Prefix:%s  MaxSize:%d",
         getLogLevel((char*)g_ConfigData->m_LogLevel.c_str()),
         getLogMedia((char*)g_ConfigData->m_LogMedia.c_str()),
         g_ConfigData->m_FilePath.c_str(),
         g_ConfigData->m_Prefix.c_str(),
         g_ConfigData->m_MaxFileSize);
   strlcat(l_configDataChar, l_temp, 5000);

   sprintf(l_temp,"\nAgent Entity Name\t: %s",g_ConfigData->m_SnmpAgentName);
   strlcat(l_configDataChar, l_temp, 5000);

   sprintf(l_temp,"\nEntity Listen Port\t: %d",g_ConfigData->m_SnmpAgentPort);
   strlcat(l_configDataChar, l_temp, 5000);

   sprintf(l_temp,"\nHeart Beat Interval\t: %d\n",g_ConfigData->m_Traptime);
   strlcat(l_configDataChar, l_temp, 5000);

   sprintf(l_temp,"\nDisables Client connection traps at the restart of the Snmp Agent\t: %d",g_ConfigData->m_DisableConnectionTrapsAtStartup);
   strlcat(l_configDataChar, l_temp, 5000);

   sprintf(l_temp,"\nTrap OID : %s", g_ConfigData->m_OID);
   strlcat(l_configDataChar, l_temp, 5000);

   sprintf(l_temp,"\nTrap Parameters: ");
   strlcat(l_configDataChar, l_temp, 5000);


   sprintf(l_temp,"\n\tEntity: %s\n\tID: %s\n\tDesc: %s\n\tType: %s\n\tSeverity: %s\n\tDateTime: %s\n\tAgentName\t: %s\nThresholdInfo\t: %s\n",g_ConfigData->m_alrm_entity.c_str(),g_ConfigData->m_alrm_id.c_str(),g_ConfigData->m_alrm_text.c_str(),g_ConfigData->m_alrm_type.c_str(),g_ConfigData->m_alrm_severity.c_str(),g_ConfigData->m_alrm_time.c_str(),g_ConfigData->m_alrm_agent_name.c_str(),g_ConfigData->m_alrm_threshold_info.c_str());
   strlcat(l_configDataChar, l_temp, 5000);

   sprintf(l_temp,"\nTemplates :");
   strlcat(l_configDataChar, l_temp, 5000);

   map<int,list<TrapInfo> >:: iterator t_itr;
   int temp=0;
   for(t_itr=g_dcd->m_TrapInfoMap.begin() ; t_itr != g_dcd->m_TrapInfoMap.end() ; t_itr++)
   {
      temp++;
      int temp1=0;
      sprintf(l_temp,"\tID:%02d (traps:%02d)",temp, t_itr->second.size());
      strlcat(l_configDataChar, l_temp, 5000);

      if(temp%5==0)
      {
         strlcat(l_configDataChar, "\n", 5000);
      }
#if 0
      //strlcat(l_configDataChar, "\n ", 5000);
      list<TrapInfo>:: iterator l_itr;
      for(l_itr=t_itr->second.begin(); l_itr != t_itr->second.end(); l_itr++)
      {
         temp1++;
         sprintf(l_temp,"\n\tTRAP_%02d %s : %d",temp1,l_itr->id,l_itr->interval);
         strlcat(l_configDataChar, l_temp, 5000);
         //strlcat(l_configDataChar, "\n ", 5000);
      }
#endif
   }
   sprintf(l_temp,"\nEntities :");
   strlcat(l_configDataChar, l_temp, 5000);
   map<string,DeviceInfo> ::iterator l_masterDevice_it;
   int l_counter=0;
   for ( l_masterDevice_it=g_dcd->m_MasterDeviceName.begin() ; l_masterDevice_it != g_dcd->m_MasterDeviceName.end(); l_masterDevice_it++ )
   {
      l_counter++;
      sprintf(l_temp,"\n\tENTITY_%02d : %-15s %s:%s:%d",
            l_counter,"Monitoring", (*l_masterDevice_it).second.device_name.c_str(),(*l_masterDevice_it).second.ip_address.c_str(),(*l_masterDevice_it).second.templateid);
      strlcat(l_configDataChar, l_temp, 5000);
      //strlcat(l_configDataChar, "\n ", 5000);
   }

   sprintf(l_temp,"\n\nManagers:");
   strlcat(l_configDataChar, l_temp, 5000);
   list<MangInfo>::iterator l_manipport_itr; 
   int counter1=0;
   for(l_manipport_itr=g_dcd->m_ManIpPortList.begin();l_manipport_itr!=g_dcd->m_ManIpPortList.end();l_manipport_itr++)
   {
      counter1++;
      sprintf(l_temp,"\n\tMANAGER_%02d : %-15s %s:%s",counter1,
            (0 == strcmp((*l_manipport_itr).device_on_off.c_str(), "0")?"Ignoring":"Informing"),
            (*l_manipport_itr).ip.c_str(),
            (*l_manipport_itr).port.c_str());

      strlcat(l_configDataChar, l_temp, 5000);
      //strlcat(l_configDataChar, "\n", 5000);
   }
   sprintf(l_temp,"\n\nPartitions:");
   strlcat(l_configDataChar, l_temp, 5000);
   list<PartitionInfo>::iterator l_part_itr; 
   int counter2=0;
   for(l_part_itr=g_dcd->m_PartitionList.begin();l_part_itr!=g_dcd->m_PartitionList.end();l_part_itr++)
   {
      counter2++;
      sprintf(l_temp,"\n\tPARTITION_%02d : %-15s %s:%d:%d",counter2,
            (0 == strcmp((*l_part_itr).dir_on_off.c_str(), "0")?"Ignoring":"Informing"),
            (*l_part_itr).dir.c_str(),
            (*l_part_itr).limit,
            (*l_part_itr).fail_sent);

      strlcat(l_configDataChar, l_temp, 5000);
      //strlcat(l_configDataChar, "\n", 5000);
   }

   return l_configDataChar;
}



DynamicConfigData::DynamicConfigData()
{
}

DynamicConfigData::~DynamicConfigData()
{
}

#if 0
<EMAIL>
    <F>1</F>
    <MAIL_SERVER_IP>192.168.151.99</MAIL_SERVER_IP>
    <FROM_ADDRESS>sanjeev.nayini@rediff.com</FROM_ADDRESS>
    <RECIPIENT_LISTS>
        <LIST_01>
            <NAME>OPERATIONS</NAME>
            <ADDRESS_01>sachidananda.sahoo@plintron.com</ADDRESS_01>
        </LIST_01>
        <LIST_02>
            <NAME>RANDD</NAME>
            <ADDRESS_01>rajagopal.maddi@plintron.com</ADDRESS_01>
            <ADDRESS_02>sachidananda.sahoo1@plintron.com</ADDRESS_02>
        </LIST_02>
        <LIST_03>
            <NAME>CEO-OFFICE</NAME>
            <ADDRESS_01>sanjeev.nayini@plintron.com</ADDRESS_01>
        </LIST_03>
    </RECIPIENT_LISTS>
    <RECIPIENTS>
        <CRITICAL>
            <F>0</F>
            <TO><F>1</F><REC_01>OPERATIONS</REC_01></TO>
            <CC><F>1</F><REC_01>OPERATIONS</REC_01><REC_02>OPERATIONS</REC_02></CC>
            <BCC><F>1</F><REC_01>OPERATIONS</REC_01><REC_02>OPERATIONS</REC_02></BCC>
        </CRITICAL>
        <MAJOR>
            <F>0</F>
            <TO><F>1</F><REC_01>OPERATIONS</REC_01></TO>
            <CC><F>1</F><REC_01>OPERATIONS</REC_01><REC_02>OPERATIONS</REC_02></CC>
            <BCC><F>1</F><REC_01>OPERATIONS</REC_01><REC_02>OPERATIONS</REC_02></BCC>
        </MAJOR>
        <MINOR>
            <F>1</F>
            <TO><F>1</F><REC_01>CEO-OFFICE</REC_01></TO>
            <CC><F>0</F><REC_01>CEO-OFFICE</REC_01><REC_02>OPERATIONS</REC_02></CC>
            <BCC><F>0</F><REC_01>OPERATIONS</REC_01><REC_02>OPERATIONS</REC_02></BCC>
        </MINOR>
        <WARNING>
            <F>0</F>
            <TO><F>1</F><REC_01>OPERATIONS</REC_01></TO>
            <CC><F>0</F><REC_01>OPERATIONS</REC_01><REC_02>OPERATIONS</REC_02></CC>
            <BCC><F>0</F><REC_01>OPERATIONS</REC_01><REC_02>OPERATIONS</REC_02></BCC>
        </WARNING>
    </RECIPIENTS>
 </EMAIL>
#endif
