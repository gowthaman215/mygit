#include <MessageQueue.h>
#include <Logger.h>

MessageQueue::MessageQueue(EQueueType p_QueueType)
{
   m_QueueType = p_QueueType;
}


MessageQueue::~MessageQueue()
{
}

int MessageQueue::size()
{
   return m_q.size();
}

bool MessageQueue::initialize()
{

   if (0 != pthread_mutex_init(&m_q_mutex, NULL))
   {
      printf("\nUnable to initialize the mutex");
      return false;
   }

   if (-1 == sem_init(&m_semaphore, 0, 0))
   {
      printf("\nUnable to initialize the semaphore [%d]", errno);
      return false;
   }
   return true;
}


bool MessageQueue::push(void *p_qm)
{
   pthread_mutex_lock(&m_q_mutex);
   m_q.push_back(p_qm);
   pthread_mutex_unlock(&m_q_mutex);
   sem_post(&m_semaphore);
   return true;
}


bool MessageQueue::pop(void **p_qm)
{
   if (m_QueueType == QUEUE_TYPE_BLOCKING)
   {
      int l_sem_result = sem_wait(&m_semaphore);
      if (-1 == l_sem_result)
      {
         g_LoggerObj.log(LOG_LEVEL_CRITICAL, "ERROR!!!!!!! Semaphore returned error [%d]", errno);
         switch (errno)
         {
            case EINVAL:
               g_LoggerObj.log(LOG_LEVEL_CRITICAL, "EINVAL received");
               break;
            case ENOSYS:
               g_LoggerObj.log(LOG_LEVEL_CRITICAL, "ENOSYS received");
               break;
            case EAGAIN:
               g_LoggerObj.log(LOG_LEVEL_CRITICAL, "EAGAIN received");
               break;
            case EDEADLK:
               g_LoggerObj.log(LOG_LEVEL_CRITICAL, "EDEADLK received");
               break;
            case EINTR:
               g_LoggerObj.log(LOG_LEVEL_CRITICAL, "EINTR received");
               break;
            default:
               g_LoggerObj.log(LOG_LEVEL_CRITICAL, "Unknown errno");
               break;
         }
         return false;
      }
   }
   else
   {
      // Do nothing
   }

   pthread_mutex_lock(&m_q_mutex);

   if (m_q.size() != 0)
   {
      //printf("\nGetting a message from the queue");
      (*p_qm) = m_q[0];
      m_q.pop_front();
      pthread_mutex_unlock(&m_q_mutex);
   }
   else
   {
      pthread_mutex_unlock(&m_q_mutex);

      if (m_QueueType == QUEUE_TYPE_BLOCKING)
      {
         g_LoggerObj.log(LOG_LEVEL_ERROR, "ERROR!!!!!!! Still No data thing coming");
         g_LoggerObj.log(LOG_LEVEL_ERROR, "ERROR!!!!!!! MessageQueue::popMessage ended");
      }
      return false;
   }
   return true;
}


