#include <stdio.h>

#include <SnmpInterface.h> // This is required for initializing, registering and sending the traps
#include <LogOverride.h>   // This is required for logging data from the SNMP client to the client application


class AppLogOverride : public LogOverride
{
   public:
      bool override(char p_logLevel, char *p_data)
      {
         //The Client Application can place their respective log statements here
         switch(p_logLevel)
         {
            case 'D':
               printf("\nDEBUG::%s", p_data);
               break;
            case 'E':
               printf("\nERROR::%s", p_data);
               break;
            case 'T':
               printf("\nTRACE::%s", p_data);
               break;
            case 'W':
               printf("\nWARNING::%s", p_data);
               break;
            case 'C':
               printf("\nCRITICAL::%s", p_data);
               break;
            default:
               printf("\nUnable to log: %s", p_data);
               break;
         }
      }
};

int g_DbConnectionTrap;
int g_TcapStackConnectionTrap;

int main()
{

   // SNMP Client Initialization
   AppLogOverride *l_alo = new AppLogOverride;

   bool l_status;
   l_status = g_si.initialize("HLR001",          // The name of the Instance which the SNMP Agent recognizes (should be configured in SNMP Agent too)
         "192.168.151.74",  // The IP Address of the SNMP Agent
         2100,              // The IP Port of the SNMP Agent
         l_alo);            // The Inherited Log Override Object (Used for logging SNMP Interface logs into Application logs)
   if(false == l_status)
   {
      printf("\nUnable to initialize the SNMP Client\n");
      exit(1);
   }
   // End of SNMP Client Initialization

   // Trap Registration
   g_DbConnectionTrap = g_si.registerSnmpTrap("DB_CONN",         // A unique id kind of a thing which represents the trap
         "DB Connection");  // A description of the trap
   g_TcapStackConnectionTrap = g_si.registerSnmpTrap("TCAP_STACK", "TCAP Stack Connection");
   // End of Trap Registration

   for(int i=0; i<5; i++)
   {
      g_si.sendSnmpTrap(g_DbConnectionTrap,              // Trap Index received in registerSnmpTrap
            TRAP_TYPE_FAIL,              // PASS or FAIL
            TRAP_SEVERITY_CRITICAL);     // The Criticality MINOR/CRITICAL/WARNING
      sleep(1);
      g_si.sendSnmpTrap(g_DbConnectionTrap, TRAP_TYPE_PASS, TRAP_SEVERITY_MINOR);
      sleep(1);
   }

   printf("\nExiting the application\n");
   return 0;
}

