LD_LIBRARY_PATH=/export/home/jubair/work/GENERIC_SNMP_1.0.0.0/client/PKG/release_gsnmpclient/lib/:/usr/sfw/lib/sparcv9/
./a.out
