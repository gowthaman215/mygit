/*********************************************************************
 **********************************************************************/
#include <argtable2.h>
#include <regex.h>      /* REG_ICASE */
#include <strings.h>
#include <stdlib.h>
#include <curses.h>
#define MAX_OUTPUT_WINDOW_SIZE  5000
extern char g_response[];

char g_globalSent1[100];

#define LPRINTF1(...)  { memset(g_globalSent1, '\0', 100); sprintf(g_globalSent1, __VA_ARGS__); strlcat(g_response, g_globalSent1, MAX_OUTPUT_WINDOW_SIZE); }


int mymain1(const char* lpattern,const char* mpattern1,const char* mpattern2)
{

   if((strlen(lpattern)==0) && (strlen(mpattern1)==0) && (strlen(mpattern2)==0))
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF1("Either Log Level or Log Media or Log Rotate Type should be present");

      return -1;
   }
   if(  (strlen(mpattern1)!=0) && (strlen(lpattern)!=0) && (strlen(mpattern2)!=0))
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF1("All options should not be present in one single command")
         return -1;
   }
   if(strlen(lpattern)!=0)
   {

      if(((strlen(lpattern)==strlen("DEBUG"))&& (strncmp(lpattern,"DEBUG",strlen(lpattern))==0)) ||
            ((strlen(lpattern)==strlen("TRACE"))&&(strncmp(lpattern,"TRACE",strlen(lpattern))==0)) || 
            ((strlen(lpattern)==strlen("LOAD"))&&(strncmp(lpattern,"LOAD",strlen(lpattern))==0)) || 
            ((strlen(lpattern)==strlen("WARNING"))&&(strncmp(lpattern,"WARNING",strlen(lpattern))==0)) || 
            ((strlen(lpattern)==strlen("CRITICAL"))&&(strncmp(lpattern,"CRITICAL",strlen(lpattern))==0)) || 
            ((strlen(lpattern)==strlen("ERROR"))&&(strncmp(lpattern,"ERROR",strlen(lpattern))==0))
        )
      {

         return 0;
      }
      else 
      {

         memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
         LPRINTF1("Incorrect Log Level option. \nShould be DEBUG / TRACE / LOAD / WARNING / CRITICAL / ERROR")
            return -1;
      }
   }
   if(strlen(mpattern1)!=0)
   {
      if(((strlen(mpattern1)==strlen("FILE"))&& (strncmp(mpattern1,"FILE",strlen(mpattern1))==0)) ||
            ((strlen(mpattern1)==strlen("CONSOLE"))&&(strncmp(mpattern1,"CONSOLE",strlen(mpattern1))==0))) 
      {
         return 0;
      }
      else
      {
         memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
         LPRINTF1("Incorrect Log Media option. \nShould be FILE / CONSOLE")
            return -1;
      }
   }

   if(strlen(mpattern2)!=0)
   {
      if(((strlen(mpattern2)==strlen("NORMAL"))&& (strncmp(mpattern2,"NORMAL",strlen(mpattern2))==0)) ||
            ((strlen(mpattern2)==strlen("ROTATE"))&&(strncmp(mpattern2,"ROTATE",strlen(mpattern2))==0))) 
      {
         return 0;
      }
      else
      {
         memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
         LPRINTF1("Incorrect Log Rotate option. \nShould be NORMAL / ROTATE")
            return -1;
      }
   }



}




int mymain2(int a,int o,int c,int *ival2)
{
   if(a==0 && o==0 && c==0)
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF1("Either of the options -a, -o, -p, -c to be present");
      return -1;
   }

   else{
      return 0;
   }
}

int mymain3(int icount,int* ival,int scount,const char* sval)
{
   if(icount==0 && scount==0)
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF1("Either OPCODE and VERSION should be present");
      return -1;
   }
   else if((*(ival)>1) && (*(ival) <=90 ) )
   {
      if(    ((sval[0] == '1') || (sval[0] == '0')) &&
             ((sval[1] == '1') || (sval[1] == '0')) &&
             ((sval[2] == '1') || (sval[2] == '0'))
        )
      {
         return 0;
      }  
      else
      {
         memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
         LPRINTF1("Versions value should be 3 digit and each digit should be either 0 or 1");
         return -1;
      }
   }
   else 
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF1("Incorrect Opcode.\nShould be between 2-90");

      return -1;
   }
}



int mymain4(int icount,const char* ival,int scount,const char* sval)
{
   if(icount==0 && scount==0)
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF1("Both tag-name and tag-value should be present");
      return -1;
   }
   else if(strlen( (char*)ival) == 0 )
   {
      LPRINTF1("Incorrect -t option");
      return -1;
   }
   else if(strlen( (char*)sval) == 0 )
   {
      LPRINTF1("Incorrect -d option");
      return -1;
   }
   else 
   {
      return 0;
   }
}



///////////////////////////////////////////////////////////////////////////////////
int parseModifyConf(char *p_command)
{

   int p_argc=0; 
   char **p_argv;


   char * pch;
   pch = strtok (p_command," ");
   p_argv = (char**)malloc(1000);

   while (pch != NULL)
   {
      p_argv[p_argc] = (char *) malloc(40);
      strcpy(p_argv[p_argc], pch);
      p_argc++;

      pch = strtok (NULL, " ");
   }



   /*SYNTAX 6:changelog*/
   struct arg_rex  *cmd1     = arg_rex1(NULL,  NULL,  "changelog", NULL, REG_ICASE, NULL);
   struct arg_str  *pattern1 = arg_str0("l", NULL, "<DEBUG,TRACE,LOAD,WARNING,CRITICAL,ERROR>", "level string");
   struct arg_str  *pattern2 = arg_str0("m", NULL, "<FILE,CONSOLE>", "format string");
   struct arg_str  *pattern3_r = arg_str0("r", NULL, "<NORMAL,ROTATE>", "format string");
   struct arg_end  *end1     = arg_end(20);
   void* argtable1[] = {cmd1,pattern1,pattern2,pattern3_r,end1};
   int nerrors1=0;

   /*SYNTAX 7:CHANGE OPCODE*/
   struct arg_rex  *cmd2 = arg_rex1(NULL,  NULL,  "changeopcode", NULL, REG_ICASE, NULL);
   struct arg_int *int1=arg_int1("v",NULL,"<int>","integer expecting");
   struct arg_str *pattern3=arg_str1("s",NULL,"<string>","string expecting");
   struct arg_end *end2=arg_end(20);
   void* argtable2[]={cmd2,int1,pattern3,end2};
   int nerrors2=0;

   /*SYNTAX 8:CHANGE VAL*/
   struct arg_rex  *cmd3 = arg_rex1(NULL,  NULL,  "changeval", NULL, REG_ICASE, NULL);
   struct arg_str *int2=arg_str1("t",NULL,"<string>","tag-name");
   struct arg_str *pattern4=arg_str1("d",NULL,"<string>","tag data");
   struct arg_end *end3=arg_end(20);
   void* argtable3[]={cmd3,int2,pattern4,end3};
   int nerrors3=0;






   /* SYNTAX 4: [--help] [-h] */
   struct arg_lit  *help4    = arg_lit1("h","help", "print this help and go back to command prompt");
   struct arg_end  *end4     = arg_end(20);
   void* argtable4[] = {help4,end4};
   int nerrors4=0;


   const char* progname1="modifyconf";

   int exitcode=0;
   memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);



   if(arg_nullcheck(argtable1)!=0 ||
         arg_nullcheck(argtable2)!=0 || arg_nullcheck(argtable3)!=0 || arg_nullcheck(argtable4)!=0 )
   {
      LPRINTF1("%s: insufficient memory\n",progname1);
      exitcode=1;
   }



   FILE *l_fp = fopen("dummy.txt",  "w+");
   nerrors4= arg_parse(p_argc,(char**)p_argv,argtable4);
   nerrors1= arg_parse(p_argc,(char**)p_argv,argtable1);
   nerrors2= arg_parse(p_argc,(char**)p_argv,argtable2);
   nerrors3= arg_parse(p_argc,(char**)p_argv,argtable3);

   if (nerrors1==0)
      exitcode = mymain1(pattern1->sval[0],pattern2->sval[0],pattern3_r->sval[0]); 
   else if (nerrors2==0)
      exitcode = mymain3(int1->count,int1->ival,pattern3->count,pattern3->sval[0]); 
   else if (nerrors3==0)
      exitcode = mymain4(int2->count,int2->sval[0],pattern4->count,pattern4->sval[0]); 
   else
   {
      fprintf(l_fp,"usage 1:  %s",  progname1);  arg_print_syntax(l_fp,argtable4,"\n");    
      fprintf(l_fp,"usage 2:  %s",  progname1);  arg_print_syntax(l_fp,argtable1,"\n");
      fprintf(l_fp,"usage 3:  %s",  progname1);  arg_print_syntax(l_fp,argtable2,"\n");
      fprintf(l_fp,"usage 4:  %s",  progname1);  arg_print_syntax(l_fp,argtable3,"\n");
      fseek(l_fp, 0, SEEK_SET);
      char l_sent[200];
      memset(l_sent, '\0', 200);
      while (1)
      {
         if (NULL == fgets(l_sent, 200, l_fp))
         {
            break;
         }
         else
         {
            strcat(g_response, l_sent);
         }
      }
      fclose(l_fp);
      exitcode =-1;
   }


exit:
   /* deallocate each non-null entry in each argtable */
   arg_freetable(argtable4,sizeof(argtable4)/sizeof(argtable4[0]));
   arg_freetable(argtable1,sizeof(argtable1)/sizeof(argtable1[0]));
   arg_freetable(argtable2,sizeof(argtable2)/sizeof(argtable2[0]));
   arg_freetable(argtable3,sizeof(argtable2)/sizeof(argtable3[0]));
   return exitcode;
}

#if 0

//////////////////////////////////////////////////////////////////////////////////
int parseStats(char *p_command)
{

   int p_argc=0; 
   char **p_argv;


   char * pch;
   pch = strtok (p_command," ");
   p_argv = (char**)malloc(1000);

   while (pch != NULL)
   {

      p_argv[p_argc] = (char *) malloc(40);



      strcpy(p_argv[p_argc], pch);
      p_argc++;

      pch = strtok (NULL, " ");
   }




   /*SYNTAX 8:SATISTICS*/

   struct arg_int *verbose1=arg_int0("a","app","<int>","integer expecting");
   struct arg_int *verbose2=arg_int0("o","opcode","<int>","integer expecting");
   struct arg_int *verbose3=arg_int0("c","ctxt","<int>","integer expecting");
   struct arg_end *end3=arg_end(20);
   void* argtable3[]={verbose1,verbose2,verbose3,end3};
   int nerrors3;




   /* SYNTAX 4: [--help] [-h] */
   struct arg_lit  *help4    = arg_lit1("h","help", "print this help and go back to command prompt");
   struct arg_end  *end4     = arg_end(20);
   void* argtable4[] = {help4,end4};
   int nerrors4;



   const char* progname2="stats";
   int exitcode=0;
   memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);



   if(arg_nullcheck(argtable3)!=0 || arg_nullcheck(argtable4)!=0 )
   {
      LPRINTF1("%s: insufficient memory\n",progname2);
      exitcode=1;
   }

   FILE *l_fp = fopen("dummy.txt",  "w+");

   /* Above we defined a separate argtable for each possible command line syntax */
   /* and here we parse each one in turn to see if any of them are successful    */
   nerrors4 = arg_parse(p_argc,(char**)p_argv,argtable4);
   nerrors3= arg_parse(p_argc,(char**)p_argv,argtable3);



   if (nerrors3==0)
      exitcode = mymain2(verbose1->count,verbose2->count,verbose3->count,verbose1->ival);
   else
   {
      //printf("%s: missing <start|stop> command.\n",progname); 
      fprintf(l_fp,"usage 1:  %s",  progname2);  arg_print_syntax(l_fp,argtable4,"\n");
      fprintf(l_fp,"usage 2:  %s",  progname2);  arg_print_syntax(l_fp,argtable3,"\n");

      fseek(l_fp, 0, SEEK_SET);
      char l_sent[200];
      memset(l_sent, '\0', 200);
      while (1)
      {
         if (NULL == fgets(l_sent, 200, l_fp))
         {
            break;
         }
         else
         {
            strcat(g_response, l_sent);
         }
      }
      fclose(l_fp);
      exitcode =-1;
   }


exit:
   /* deallocate each non-null entry in each argtable */
   arg_freetable(argtable4,sizeof(argtable4)/sizeof(argtable4[0]));
   arg_freetable(argtable3,sizeof(argtable3)/sizeof(argtable3[0]));

   return exitcode;
}

#endif

