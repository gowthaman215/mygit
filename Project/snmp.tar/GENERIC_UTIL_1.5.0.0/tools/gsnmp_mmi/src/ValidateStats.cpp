/*********************************************************************
 **********************************************************************/
#include "argtable2.h"
#include <regex.h>      /* REG_ICASE */
#include <strings.h>
#include <stdlib.h>
#include <curses.h>
#define MAX_OUTPUT_WINDOW_SIZE  5000
extern char g_response[];

char g_globalChar[1000];

#define LPRINTF(...)  { memset(g_globalChar, '\0', 1000); sprintf(g_globalChar, __VA_ARGS__); strlcat(g_response, g_globalChar, MAX_OUTPUT_WINDOW_SIZE); }

const char* g_progNameStats="stats";



void printStatsUsage(void **g_statsCommands, void **g_statsHelp)
{
      strlcat(g_response, "\n\n\tstats command can be used to retrieve statistics for the current slot from the application\n\n", MAX_OUTPUT_WINDOW_SIZE);

      FILE *l_fp = NULL;
      l_fp = fopen("dummy.txt",  "w+");
      if (l_fp)
      {
          fprintf(l_fp, "\tusage 1:  %s",  g_progNameStats);  arg_print_syntax(l_fp,g_statsHelp,"\n");
          fprintf(l_fp, "\tusage 2:  %s",  g_progNameStats);  arg_print_syntax(l_fp,g_statsCommands,"\n\n\n");

          arg_print_glossary(l_fp,g_statsHelp,    "\t%s     %s\n");
          arg_print_glossary(l_fp,g_statsCommands,"\t%s     %s\n");

          fseek(l_fp, 0, SEEK_SET);
          char l_sent[200];
          memset(l_sent, '\0', 200);
          while (1)
          {
             if (NULL == fgets(l_sent, 200, l_fp))
             {
                break;
             }
             else
             {
                strcat(g_response, l_sent);
             }
          }
          fclose(l_fp);
      }
      else
      {
          strcpy(g_response,"Internal Error !! Unable to open dummy.txt");
      }
}


int mymain2(int a,int o,int c,int r,int p, int n, int e, int t, void **g_statsCommands, void **g_statsHelp)
{
   strcpy(g_response, "\n");

   if (c>0)
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("\t-c option is not implemented yet");
      printStatsUsage(g_statsCommands, g_statsHelp);
      return -1;
   }


   if(a==0 && o==0 && c==0 && p==0  && t==0)
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("\tEither (-a) or (-o) or (-p) or (-c) or (-t) should be present");
      printStatsUsage(g_statsCommands, g_statsHelp);
      return -1;
   }

    int l_count=0;
    if (a>0)
      l_count++;
    if (o>0)
      l_count++;
    if (c>0)
      l_count++;
    if (p>0)
      l_count++;
    if (t>0)
      l_count++;

    if (l_count > 1)
    {
        LPRINTF("\tOnly one of (-a) (-o) (-p) (-c) (-t) should be present");
        printStatsUsage(g_statsCommands, g_statsHelp);
        return -1;
    }

    if ( (o>0) || (p>0) )
    {
        if ( (n==0) && (e==0) )
        {
            LPRINTF("\tOp codes based reports (-o) or (-p) should be followed by options (-n) or (-e)");
            printStatsUsage(g_statsCommands, g_statsHelp);
            return -1;
        }

        if ( (n>0) && (e>0) )
        {
            LPRINTF("\tOp codes based reports (-o) or (-p) should be followed by only one of the options (-n) or (-e)");
            printStatsUsage(g_statsCommands, g_statsHelp);
            return -1;
        }
    }
    return 0;
}






//////////////////////////////////////////////////////////////////////////////////
int parseStats(char *p_command)
{

   int p_argc=0; 
   char **p_argv;
   char * pch;
   pch = strtok (p_command," ");
   p_argv = (char**)malloc(1000);

   while (pch != NULL)
   {
      p_argv[p_argc] = (char *) malloc(40);
      strcpy(p_argv[p_argc], pch);
      p_argc++;
      pch = strtok (NULL, " ");
   }

   struct arg_lit *verbose1= arg_lit0("a","",   "Application Contexts wise");
   struct arg_lit *verbose2= arg_lit0("o","",   "OP codes wise (first page)");
   struct arg_lit *verbose5= arg_lit0("p","",   "OP codes wise (last page)");
   struct arg_lit *verbose3= arg_lit0("c","",   "Conversations wise (not implemented yet)");
   struct arg_lit *verbose6= arg_lit0("n","",   "Normal counts (used in conjunction with -o or -p)");
   struct arg_lit *verbose7= arg_lit0("e","",   "Error counts (used in conjunction with -o or -p)");
   struct arg_lit *verbose4= arg_lit0("r","",   "Repeat the command continously. Use Ctrl-C to stop the execution of the command");
   struct arg_lit *verbose8= arg_lit0("t","",   "TCAP Primitive counts");

   //struct arg_int *int1=arg_int1("r",NULL,"<int>","Time in Minutes");
   struct arg_end *end3=arg_end(20);
   void* g_statsCommands[]={verbose1,verbose2,verbose5,verbose3,verbose6,verbose7,verbose8,verbose4,end3};
   int nerrors3;

   /* SYNTAX 4: [--help] [-h] */
   struct arg_lit  *help4    = arg_lit1("h","", "print this help");
   struct arg_end  *end4     = arg_end(20);
   void* g_statsHelp[] = {help4,end4};
   int nerrors4;


   int exitcode=0;
   memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);

   if(arg_nullcheck(g_statsCommands)!=0 || arg_nullcheck(g_statsHelp)!=0 )
   {
      LPRINTF("%s: insufficient memory\n",g_progNameStats);
      exitcode=1;
   }

   FILE *l_fp = fopen("dummy.txt",  "w+");

   /* Above we defined a separate argtable for each possible command line syntax */
   /* and here we parse each one in turn to see if any of them are successful    */
   nerrors4 = arg_parse(p_argc,(char**)p_argv,g_statsHelp);
   nerrors3= arg_parse(p_argc,(char**)p_argv,g_statsCommands);

   if (nerrors3==0)
      exitcode = mymain2(verbose1->count,verbose2->count,verbose3->count,verbose4->count, verbose5->count,verbose6->count,verbose7->count,verbose8->count,(void**)&g_statsCommands, (void**)&g_statsHelp);
   else
   {
       printStatsUsage(g_statsCommands, g_statsHelp);
       exitcode =-1;
   }

exit:
   /* deallocate each non-null entry in each argtable */
   arg_freetable(g_statsHelp,sizeof(g_statsHelp)/sizeof(g_statsHelp[0]));
   arg_freetable(g_statsCommands,sizeof(g_statsCommands)/sizeof(g_statsCommands[0]));
   return exitcode;
}

