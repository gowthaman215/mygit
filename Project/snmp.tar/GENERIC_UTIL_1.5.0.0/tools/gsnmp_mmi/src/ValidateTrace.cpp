/*********************************************************************


 **********************************************************************/
#include <argtable2.h>
#include <regex.h>      /* REG_ICASE */
#include <strings.h>
#include <stdlib.h>
#include <stdio.h>
#include <NgMmlMain.h>

extern char g_response[];

char g_globalSent[100];

#define LPRINTF(...)  { memset(g_globalSent, '\0', 100); sprintf(g_globalSent, __VA_ARGS__); strlcat(g_response, g_globalSent, MAX_OUTPUT_WINDOW_SIZE); }


/* mymain3 implements the actions for syntax 3 */
int mymain5(const char *pattern, const char *pattern2)
{
   if (  (strlen(pattern)==0) &&
         (strlen(pattern2)==0) )
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      LPRINTF("Either MSISDN or IMSI should be present");
      return -1;
   }
   /*printf("syntax 3 matched OK:\n");
     printf("pattern1=\"%s\"\n", pattern);
     printf("pattern2=\"%s\"\n", pattern2);*/

   return 0;
}



int parseTrace(char *p_command);

/*
   int main()
   {
   char l_command[100];
   memset(l_command, '\0', 100);
   strcpy(l_command, "trace start -x   wow no dump");

   parseTrace(l_command);
   }*/

int parseTrace(char *p_command)
{

   int p_argc=0; 
   char **p_argv;

   //char str[] ="- This, a    sample string.";
   char * pch;
   pch = strtok (p_command," ");
   p_argv = (char**)malloc(1000);

   while (pch != NULL)
   {
      //printf ("-%s-\n",pch);
      p_argv[p_argc] = (char *) malloc(40);
      //printf("\n allocated\n");

      //p_argv[p_argc] = (char*)malloc(strlen(pch));
      strcpy(p_argv[p_argc], pch);
      p_argc++;

      pch = strtok (NULL, " ");
   }

   //printf("\n tokenizing done \n\n");
   /*
      int i=0;
      for (i=0; i<p_argc; i++)
      {
      printf("\n printing -%s-", p_argv[i]);
      }*/



   /* SYNTAX 5: trace start [-m <msisdn>] [-i <imsi>] */
   struct arg_rex  *cmd5      = arg_rex1(NULL,  NULL,  "start", NULL, REG_ICASE, NULL);
   struct arg_str  *pattern5_m = arg_str0("m", NULL, "<msisdn>", "msisdn to be traced");
   struct arg_str  *pattern5_i = arg_str0("i", NULL, "<imsi>", "imsi to be traced");
   struct arg_end  *end5     = arg_end(20);
   void* argtable5[] = {cmd5,pattern5_m,pattern5_i,end5};
   int nerrors5;

   /* SYNTAX 6: trace stop [-m <msisdn>] [-i <imsi>] */
   struct arg_rex  *cmd6      = arg_rex1(NULL,  NULL,  "stop", NULL, REG_ICASE, NULL);
   struct arg_str  *pattern6_m = arg_str0("m", NULL, "<msisdn>", "msisdn to be traced");
   struct arg_str  *pattern6_i = arg_str0("i", NULL, "<imsi>", "imsi to be traced");
   struct arg_end  *end6     = arg_end(20);
   void* argtable6[] = {cmd6,pattern6_m,pattern6_i,end6};
   int nerrors6;


   /* SYNTAX 4: [--help] [-h] */
   struct arg_lit  *help4    = arg_lit1("h","help", "print this help and go back to command prompt");
   struct arg_end  *end4     = arg_end(20);
   void* argtable4[] = {help4,end4};
   int nerrors4;

   const char* progname = "trace";
   int exitcode=0;

   memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);

   /* verify all argtable[] entries were allocated sucessfully */
   if (arg_nullcheck(argtable5)!=0 ||
         arg_nullcheck(argtable6)!=0 ||
         arg_nullcheck(argtable4)!=0 )
   {
      /* NULL entries were detected, some allocations must have failed */
      LPRINTF("%s: insufficient memory\n",progname);
      exitcode=1;
   }


   FILE *l_fp = fopen("dummy.txt",  "w+");


   /* Above we defined a separate argtable for each possible command line syntax */
   /* and here we parse each one in turn to see if any of them are successful    */
   nerrors4 = arg_parse(p_argc,(char**)p_argv,argtable4);
   nerrors5 = arg_parse(p_argc,(char**)p_argv,argtable5);
   nerrors6 = arg_parse(p_argc,(char**)p_argv,argtable6);

   /* Execute the appropriate main<n> routine for the matching command line syntax */
   /* In this example program our alternate command line syntaxes are mutually     */
   /* exclusive, so we know in advance that only one of them can be successful.    */
   if (nerrors5==0)
      exitcode = mymain5(pattern5_m->sval[0], pattern5_i->sval[0]);
   else if (nerrors6==0)
      exitcode = mymain5(pattern6_m->sval[0], pattern6_i->sval[0]);
   else
   {
      fprintf(l_fp, "%s: missing <start|stop> command.\n",progname); 
      fprintf(l_fp, "usage 1: %s",  progname);  arg_print_syntax(l_fp,argtable4,"\n");
      fprintf(l_fp, "usage 2: %s",  progname);  arg_print_syntax(l_fp,argtable5,"\n");
      fprintf(l_fp, "usage 3: %s",  progname);  arg_print_syntax(l_fp,argtable6,"\n");

      fseek(l_fp, 0, SEEK_SET);
      char l_sent[200];
      memset(l_sent, '\0', 200);
      while (1)
      {
         if (NULL == fgets(l_sent, 200, l_fp))
         {
            break;
         }
         else
         {
            strcat(g_response, l_sent);
         }
      }
      fclose(l_fp);
      exitcode =-1;
   }

exit:
   /* deallocate each non-null entry in each argtable */
   arg_freetable(argtable4,sizeof(argtable4)/sizeof(argtable4[0]));
   arg_freetable(argtable5,sizeof(argtable5)/sizeof(argtable5[0]));
   arg_freetable(argtable6,sizeof(argtable6)/sizeof(argtable6[0]));

   return exitcode;
}
