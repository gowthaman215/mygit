export LD_LIBRARY_PATH=/opt/product/rgopal/learn/argtable/argtable2-12/ARGTABLE_INSTALL/lib:/usr/sfw/lib/:/opt/product/rgopal/LatestMAP/map-constants/lib/
