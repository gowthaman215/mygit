#PATH should contain the path where the binary snmptrap is present
PATH=$PATH:/usr/sfw/bin/
echo $PATH
LD_LIBRARY_PATH=./lib/

./bin/gmmi
