#ifndef INCL_EncDbConnStr_H
#define INCL_EncDbConnStr_H

#include <Codec.h>

#define BUF_LEN 500
#define KEY_LEN 8
#define MAX_DB_NAME 40
#define MAX_DB_CONN_STR 50


class EncDbConnStr:public Codec
{
   protected:
      char m_PlainData[BUF_LEN];
      char m_LFileData[BUF_LEN];
   public:
      bool updateDbConnList(char *p_action, char *p_dbName, char *p_connString);
      void modifyFile(char *p_action, char *p_dbName, char *p_dbData);
      bool readFromFile(char *p_dbName, char *p_dbData, int &p_dbDataLen);
      bool getActualDbString(char *p_dbstring, char *p_DbConnStr);

};
#endif
