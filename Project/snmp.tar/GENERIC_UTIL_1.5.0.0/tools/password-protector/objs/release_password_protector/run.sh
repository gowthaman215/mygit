#This path should contain the directory where libcrypto.so or libcrypto.so.0.9.7 is present 
LD_LIBRARY_PATH=/usr/sfw/lib/sparcv9/
