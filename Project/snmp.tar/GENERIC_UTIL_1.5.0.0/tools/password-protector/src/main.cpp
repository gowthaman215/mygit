#include <string.h>
#include <iostream>
#include <stdio.h>
#include "EncDbConnStr.h"
#include <sys/types.h>
#include <unistd.h>

#define ADD_CONN_STRING_VERSION  "v1.1.0.1"

void usage(char *p_exe)
{
   printf("\nUsage (%s): %s <-a|-m|-v> <DB_CONN_ALIAS> <DB_CONNECTION_STRING>", ADD_CONN_STRING_VERSION, p_exe);
   printf("\n    -a : add a new record with DB_CONN_ALIAS and DB_CONNECTION_STRING");
   printf("\n    -m : modify an existing DB_CONN_ALIAS record with the current DB_CONNECTION_STRING ");
   printf("\n    -v : view the DB_CONNECTION_STRING for a DB_CONN_ALIAS");
   printf("\n\n");
}
int main(int argc, char *argv[])
{
   bool argcFlag=false;
   if(3 != argc)
   {
      if(4 == argc)
      {
         printf("Number of Argument is :%d\n",argc);
      }
      else
      {
         usage(argv[0]);
         exit(1);
      }
   }
   else if(3 == argc)
   {
      argcFlag=true;
   }
   if(false == argcFlag)
   {
      if(4 != argc)
      {
         usage(argv[0]);
         exit(1);
      }
   }
   if((0 != strcmp(argv[1], "-a")) && (0 != strcmp(argv[1], "-m")) && (0 != strcmp(argv[1], "-v")))
   {
      usage(argv[0]);
      printf("\nArgument 2 should be either -m or -a or -v \n\n");
      exit(1);
   }
   int l_Len = strlen(argv[2]);
   if(MAX_DB_NAME <  l_Len)
   {
      printf("[ERROR]: DB Name: %s :   length (%d) is more than allowed length (%d bytes)\n\n", argv[2], l_Len, MAX_DB_NAME);
      exit(1);
   }
   EncDbConnStr l_encDB;
   if(0 == strcmp(argv[1], "-v"))
   {
      if(0 ==  getuid())
      {
         char l_dbConnectString[MAX_DB_CONN_STR+1];
         memset(l_dbConnectString,'\0',sizeof(l_dbConnectString));
         l_encDB.getActualDbString(argv[2],l_dbConnectString);
         if(strlen(l_dbConnectString) > 1)
         {
            printf("\n\nGet Actual DB Connection String :[%s]\n",l_dbConnectString);
            printf("\n");
         }
         else
         {
            printf("\n\nDB_CONN_ALIAS : [%s] does not exist in the /etc/password-db.dat file !! \n",argv[2]);
            printf("\n");
         }

         return 0;
      }
      else
      {
         printf("\n\npasswordProtector view can be performed by root user only !! ..\n");
         printf("\n");
         return 0;

      }
   }
   if(true == argcFlag)
   {
      usage(argv[0]);
      exit(1);
   }
   int l_DbLen = strlen(argv[3]);

   if(MAX_DB_CONN_STR < l_DbLen)
   {
      printf("[ERROR]: Connection String: %s :   length (%d) is more than allowed length (%d bytes)\n\n", argv[3], l_DbLen, MAX_DB_CONN_STR);
      exit(1);
   }
   else
   {
      printf("DB Name: %s Connection String: %s\n", argv[2], argv[3]);
      l_encDB.updateDbConnList(argv[1], argv[2], argv[3]);
   }
   printf("\n\n");
   return 0;
}

