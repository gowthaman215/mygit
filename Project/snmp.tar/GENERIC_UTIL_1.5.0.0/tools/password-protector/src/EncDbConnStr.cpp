/************************************************************************************
 * FILE NAME      : EncDbConnStr.cpp
 * REMARKS        :
 *************************************************************************************/

#include <des.h>
#include <stdio.h>
#include <errno.h>
#include <sys/stat.h>

#include <EncDbConnStr.h>

#define MAX_RECORD_LEN 100

using namespace std;
bool EncDbConnStr::readFromFile(char *p_dbName, char *p_dbData, int &p_dbDataLen)
{
   long filesize, position;
   FILE *file_ptr;
   bool l_match=false;

   // Open the file in read binary mode
   if ((file_ptr = fopen("/etc/password-db.dat", "rb")) == NULL)
   {
      printf("Error opening file: /etc/password-db.dat\n");
      return false;
   }

   // check the filesize
   if ((fseek(file_ptr, 0, SEEK_END)) != 0) {
      printf("Error in seek operation on file /etc/password-db.dat: errno :%d \n", errno);
      return false;
   }
   printf("Getting %s database connection string from /etc/password-db.dat\n", p_dbName);

   // set filesize variable    
   filesize = ftell(file_ptr);

   // go back
   rewind(file_ptr); 

   // initial position
   position = ftell(file_ptr); 

   char l_DbTag[MAX_DB_NAME+2];
   snprintf(l_DbTag, sizeof(l_DbTag), "%s:", p_dbName);

   char l_DbData[MAX_RECORD_LEN];
   //printf("File position [%ld] file size [%ld] \n", position, filesize);

   while (position < filesize)
   {
      memset(l_DbData, 0, sizeof(l_DbData));
      if(MAX_RECORD_LEN != fread(l_DbData, 1, MAX_RECORD_LEN, file_ptr))
      {
         printf("Error in fread could not read MAX_RECORD_LEN bytes : errno :%d \n",errno);
         return false;
      }

      if(0 == memcmp(l_DbData, l_DbTag, strlen(l_DbTag)))
      {
         printf("Found the DB string %s\n", p_dbName);
         l_DbData[strlen(l_DbTag) + 2] = 0;
         int l_Len = atoi(l_DbData+strlen(l_DbTag));
         memcpy(p_dbData, l_DbData+strlen(l_DbTag)+3, l_Len);
         p_dbDataLen = l_Len;
         break;
      }
      position += MAX_RECORD_LEN;
   }
   fclose(file_ptr);
   return true;
}

bool EncDbConnStr::getActualDbString(char *p_dbstring, char *p_DbConnStr)
{
   memcpy(m_Key1, "lycamobl", sizeof(m_Key1));
   memcpy(m_Key2, "lycatech", sizeof(m_Key2));
   memcpy(m_Key3, "plintron", sizeof(m_Key3));


   char l_CipheredData[MAX_RECORD_LEN];
   memset(l_CipheredData, '\0', sizeof(l_CipheredData));
   int l_CipheredDataLen = 0;
   readFromFile(p_dbstring, l_CipheredData, l_CipheredDataLen);

   if(1 < l_CipheredDataLen)
   {
      memset(p_DbConnStr, 0, l_CipheredDataLen+1);
      Cipher(l_CipheredData, l_CipheredDataLen, p_DbConnStr, DES_DECRYPT);
      return true;
   }
   else 
   {
      printf("Failed to get DBConnection string named %s\n", p_dbstring) ;
      return false;
   }
   return true;
}

bool EncDbConnStr::updateDbConnList(char *p_action, char *p_dbName, char *p_dbConnString)
{
   char l_DbConnRec[MAX_RECORD_LEN+1];

   memset(l_DbConnRec, ' ', sizeof(l_DbConnRec));
   l_DbConnRec[MAX_RECORD_LEN-1] = '\n';
   memcpy(m_Key1, "lycamobl", sizeof(m_Key1));
   memcpy(m_Key2, "lycatech", sizeof(m_Key2));
   memcpy(m_Key3, "plintron", sizeof(m_Key3));

   //Read the license file and store in m_LFileData and size in l_Len
   memset(m_PlainData, 0, sizeof(m_PlainData));

   int l_Len = strlen(p_dbConnString);
   l_Len += (8 - l_Len%8);
   Cipher(p_dbConnString, l_Len, m_PlainData, DES_ENCRYPT);

   sprintf(l_DbConnRec,"%s:%02d:", p_dbName, l_Len);
   memcpy(l_DbConnRec+strlen(l_DbConnRec), m_PlainData, l_Len);
   modifyFile(p_action, p_dbName, l_DbConnRec);
   return true;
}

void EncDbConnStr::modifyFile(char *p_action, char *p_dbName, char *p_DbConnRec)
{
   long filesize, position, prevPosition;
   unsigned char buf[MAX_RECORD_LEN+1];

   FILE *file_ptr;
   bool l_match=false;

   if(0 == strcmp(p_action, "-m"))
   {
      // Open the file in read binary mode
      if ((file_ptr = fopen("/etc/password-db.dat", "rb+")) == NULL)
      {
         printf("[E]: Error opening /etc/password-db.dat  [%d:%s]\n", errno, strerror(errno));
         exit(1);
      }
   }
   else
   {
      if ((file_ptr = fopen("/etc/password-db.dat", "ab+")) == NULL)
      {
         printf("[E]: Error opening /etc/password-db.dat  [%d:%s]\n", errno, strerror(errno));
         exit(1);
      }
      chmod("/etc/password-db.dat", 0644);
   }

   // check the filesize
   if ((fseek(file_ptr, 0, SEEK_END)) != 0) {
      printf("[E]: Error in seek operation on file /etc/password-db.dat [%d:%s]\n", errno, strerror(errno));
      exit(1);
   }

   // set filesize variable    
   filesize = ftell(file_ptr);

   // go back
   rewind(file_ptr); 

   // initial position
   position = ftell(file_ptr); 

   char l_DbTag[MAX_DB_NAME+2];
   snprintf(l_DbTag, sizeof(l_DbTag), "%s:", p_dbName);

   // we're not at the last part of file
   while (position < filesize)
   {
      prevPosition = position;
      if(MAX_RECORD_LEN != fread(buf, 1, MAX_RECORD_LEN, file_ptr))
      {
         printf("[E]: Failed to read database entry\n");
         break;
      }
      if(0 == memcmp(buf, l_DbTag, strlen(l_DbTag)))
      {
         if(0 == strcmp(p_action, "-m")) // Modify DB Connection String
         {
            if((fseek(file_ptr, prevPosition, SEEK_SET)) != 0){
               printf("[E]: Error in seek operation on file /etc/password-db.dat [%d:%s]\n", errno, strerror(errno));
               exit(1);
            }
            fwrite(p_DbConnRec, 1, MAX_RECORD_LEN, file_ptr); 
            printf("Modified the DB string %s", p_dbName);
         }
         else
         {
            printf("DB string %s already Exists!! Use -m option for modification.\n",p_dbName);
         }
         l_match = true; // Add DB Connection String
         break;
      }
      position += MAX_RECORD_LEN;
   }

   if((0 == strcmp(p_action, "-a")) && (false == l_match)) // Add DB Connection String
   {
      if ((fseek(file_ptr, 0, SEEK_END)) != 0) 
      {
         printf("[E]: Error in seek operation on file /etc/password-db.dat [%d:%s]\n", errno, strerror(errno));
         exit(1);
      }
      fwrite(p_DbConnRec, 1, MAX_RECORD_LEN, file_ptr); 
      printf("Added the DB string %s.\n", p_dbName);
   }
   else if((0 == strcmp(p_action, "-m")) && (false == l_match))
   {
      printf("DB string %s does not exist in the file!! Use -a option for addition.\n", p_dbName);
      exit(1);
   }
   fclose(file_ptr);
   return;
}
