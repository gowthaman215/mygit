#include <string.h>
#include <iostream>
#include <stdio.h>

#include "DecDbConnStr.h"
#include "LogOverride.h"
#include "GenUtils.h"

class appliactionOverride: public LogOverride
{
   bool override(char p_logLevel, char *p_data)
   {
      switch(p_logLevel)
      {
         case 'D':
            //g_LoggerObj.log(LOG_LEVEL_DEBUG, "%s", p_data);
            break;
         case 'E':
              // g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s", p_data);
            break;
         case 'T':
            //g_LoggerObj.log(LOG_LEVEL_DEBUG, "%s", p_data);
            break;
         case 'W':
            //g_LoggerObj.log(LOG_LEVEL_WARNING, "%s", p_data);
            break;
         case 'C':
            //g_LoggerObj.log(LOG_LEVEL_CRITICAL, "%s", p_data);
            break;
         default:
            //g_LoggerObj.log(LOG_LEVEL_DEBUG, "%s", p_data);
            break;
      }
      return true;
   }
};

int main(int argc, char *argv[])
{
   if( 2 != argc)
   {
      printf("Usage: ./a <DB_STRING_NAME> \n");
      exit(1);
   }
   char l_dbstring[50];
   char l_actualdbstring[200];
   memset(l_dbstring,'\0',sizeof(l_dbstring));
   strcpy(l_dbstring,argv[1]);
   printf("DB Temp string :%s\n",l_dbstring);
   appliactionOverride *log = new appliactionOverride();

   memset(l_actualdbstring,'\0',sizeof(l_actualdbstring));
   g_DecDbConnStr.getActualDbString(l_dbstring, l_actualdbstring,log);
   printf("Actual string :%s\n",l_actualdbstring);
   return 0;
}

