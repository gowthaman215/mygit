echo 
rm a.out
g++ -m64 -DRAND_KEY main.cpp  -I /export/home/sachi/CodeBase/GENERIC_UTIL_1.1.0.0/gen-util/password-protector/inc/ -I /export/home/sachi/CodeBase/GENERIC_UTIL_1.1.0.0/gen-util/inc/ -L /export/home/sachi/CodeBase/GENERIC_UTIL_1.1.0.0/gen-util/lib -L /usr/local/ssl/lib/ -lnsl -lpthread -lrt -lm -lstdc++ -lsocket -lcrypto -lgen-util
