/***************************************************************
	File:			Logger.h


 ***************************************************************/
#ifndef __LOGGER_H
#define __LOGGER_H

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdarg.h>
#include <dirent.h>
#include <iostream> //Linker Error
using namespace std;

#ifdef SNMP
#include "SNMP.h"
#endif /* SNMP */

 // #define UNIX_PORT

// Logging Mode Constants
#define LOG_MEDIA_LOWER_LIMIT	1	// Define valid lower range for Logging Media
#define LOG_MEDIA_FILE		    1	// File Mode Logging
#define	LOG_MEDIA_CONSOLE	    2	// Console Mode Logging
#define	LOG_MEDIA_IDE		    3	// IDE Mode Logging
#define	LOG_MEDIA_NEW_CONSOLE	4	// New Console Window Mode Logging
#define LOG_MEDIA_UPPER_LIMIT	4	// Define valid upper range for Logging Mode


// Logging Level Constants
#define LOG_LEVEL_LOWER_LIMIT	1	// Define valid lower range for Logging Level
#define LOG_LEVEL_ERROR	        1	// Only Software Errors to be logged here
#define	LOG_LEVEL_CRITICAL	    2	// Highest Priority (useful for delivered code) 
#define	LOG_LEVEL_TRACE	        3	// Trace an event
#define LOG_LEVEL_DEBUG		    4	// Lowest Priority (useful for debugging purposes)
#define LOG_LEVEL_UPPER_LIMIT	4	// Define valid upper range for Logging Level

// Error Code Defined for initialization routine
#define LOGGER_ERR_LEVEL	      1
#define LOGGER_ERR_MODE		      2
#define LOGGER_ERR_FILE		      3
#define LOGGER_ERR_NEW_CONSOLE	  4
#define LOGGER_ERR_SEMAPHORE	  5
#define LOGGER_ERR_BUFFER	      6

#define __FUNCTION__ "func"

// This is the max amount of time calling thread waits for the Logger mutex
#define LOGGER_WAIT_TIME 	    5000		// = 5 seconds

// Internal Buffer size 
#define	LOGGER_BUFFER_SIZE	  10240 // = 10 KBytes buffer

// Date string len used in log method
#define DATE_STRING_LEN		    27

// mPath maximum string size
#define PATH_MAX_SIZE		      260

// mModuleName maximum string size
#define MODULE_NAME_MAX_SIZE	50

// mModuleName maximum string size
#define LOG_MESSAGE_MAX_SIZE	LOGGER_BUFFER_SIZE - 100	// 2900

class Logger
{
private:
#ifdef WIN_32_PORT
	// Windows specific Code
	HANDLE	iLoggerSemaphoreHandle;// Stores Logger Semaphore Handle.
	DWORD	iLoggingThreshold;		// Stores currently selected Logging Threshold.
	DWORD	iLoggingMedia;			// Stores currently selected Logging Media.
	HANDLE	iLoggerFileHandle;		// Stores file handle in case of File Mode Logging (LOG_MEDIA_FILE).
	CHAR *	iLoggerBuffer;			// Stores pointer to internal buffer.
	HANDLE	iLoggerConsoleHandle;	// Store new console window handle in case 
									// of New Console Mode Logging(LOG_MEDIA_NEW_CONSOLE).
#elif UNIX_PORT
	 // UNIX specific Code
	 // int  iLoggerSemaphoreHandle;    // Stores Logger Semaphore Handle.
	  //CxOsCriticalSection m_criticalSection;
	 unsigned long iLoggingThreshold;   // Stores currently selected Logging Threshold.
	 unsigned long iLoggingMedia;       // Stores currently selected Logging Media.
	 int iLoggerFileHandle;             // Stores file handle in case of File Mode Logging (LOG_MEDIA_FILE).
	 char iLoggerBuffer[LOGGER_BUFFER_SIZE]; // Stores pointer to internal buffer.
	 int  iLoggerConsoleHandle;         // Store new console window handle in case
	                                    // of New Console Mode Logging(LOG_MEDIA_NEW_CONSOLE).
	 pthread_mutex_t  edrMutex;         // Store new console window handle in case
#endif
	// This method resets the internal members
	void resetMembers();
	
#ifdef WIN_32_PORT
	// Makes time stamp in string form
	void makeTimeStamp(char *);
	// Makes file name using specified path & file name
	CHAR * makeFileName(CHAR * mFileNameBuffer, CHAR * mPath, CHAR * mFilePrefix);
	// To preserve file name for relocation of file.
	CHAR  iFileName[100];
	// To specify at what size the file should be archived.
	DWORD	iMaxFileSize;
	// Specifies the location where files are archived.
	CHAR * iArchivalDirPath;
	CHAR * iFilePath;
	CHAR * iModuleName;
#elif UNIX_PORT
	// Makes time stamp in string form
	void makeTimeStamp(char *);
	// Makes file name using specified path & file name
	char * makeFileName(char * mFileNameBuffer, char * mPath, char * mFilePrefix);
	// To preserve file name for relocation of file.
 	char iFileName[100];
	// To specify at what size the file should be archived.
	long double iMaxFileSize;
	// Specifies the location where files are archived.
	char * iArchivalDirPath;
	char * iFilePath;
	char * iModuleName;
#endif
	
	volatile long i_SyncCount;

    int m_type;

public:	
    
	// Default Constructor
	Logger();	
	~Logger();	
	
/********************************************************************************
//This method initailizes the Logger. All initializations such as opening a file, 
//memory allocation, creating new console window etc. are done here.	
//
//Parameters:
//
//mLoggingThreshold -> Decides the logging threshold, all messages above this 
//		threshold are ignored. Must be one of the log level constants 
//		described above.
//
//mLoggingMedia -> Target Media. Must be one of the media constants described above.
//
//mPath -> Directory where the logging file has to be created. Required when logging 
//		media is file, otherwise ignored.
//
// *****IMPORTANT: mPath string length should not exceed PATH_MAX_SIZE, 
//	which is currently set to 260 characters.*****
//		
//mModuleName -> Module name, which has created this logger object. Required when 
//		logging media is a file, otherwise ignored. 
//		It is used for creating the file name for logging
//
// *****IMPORTANT: mModuleName string length should not exceed MODULE_NAME_MAX_SIZE, 
//		which is currently set to 50 characters.*****
//
//File name format: "ModuleName_DD_MM_YYYY.log"
//E.g. if the module name is rating engine & current date is 
//10th December 2001 then the file name would be 
//"RatingEngine_10_12_2001.log" 
//
//Return Value:
//If the function succeeds, the return value is nonzero(TRUE).
********************************************************************************/
#ifdef WIN_32_PORT
	BOOL initialize(DWORD mLoggingThreshold, DWORD mLoggingMedia, CHAR * mPath, CHAR * mModuleName,CHAR * mArchivalDirPath,DWORD mMaxFileSize);
#elif UNIX_PORT
    bool initialize(unsigned long mLoggingThreshold, unsigned long mLoggingMedia, char * mPath, char * mModuleName,char * mArchivalDirPath,unsigned long mMaxFileSize, int p_type); 
#endif


/********************************************************************************
// This method performs deallocation of resources such as closing files, 
// memory deallocation, closing console window etc. 
// Note: Subsequent  calls to log() method will return false.
********************************************************************************/
	void terminate();

/********************************************************************************
//This method logs the message to the appropriate media. If the specified log level 
//is greater (lower priority) than threshold set in initialize() method then message 
//is simply ignored & false is returned. False value is also returned when log() method 
//is called before a call to initialize() method has been made.
//	
//This method is implemented as printf() in C language & hence accepts any no. 
//of arguments.E.g.
//e.g Normal string passed, 
//ratLogger->log(LOG_LEVEL_NORMAL, "THIS IS TEST DATA NO 1");
//	
//Something similar to printf() in C language
//ratLogger->log(LOG_LEVEL_WARNING, "THIS IS TEST DATA NO %i",2);
//	
//Important: It is strongly recommended that the calling thread should pass the class 
//name & method name as part of the message, so that logs are clear enough. e.g.	
//ratLogger->log(LOG_LEVEL_WARNING, "RatingController:rate(): THIS IS 
//							TEST DATA NO %i",2);
//
//where "RatingController" is the class name and "rate()" is the method name.
//	
//Parameters:
//
//mLoggingLevel -> The log level of the current message.
//
//mLogMessage -> Message to be logged.
// *****IMPORTANT: mLogMessage string length should not exceed LOG_MESSAGE_MAX_SIZE, 
//		which is currently set to LOGGER_BUFFER_SIZE - 100, i.e  2900 characters.*****	
//
//Return Value:
//If the function succeeds, the return value is nonzero(TRUE).
********************************************************************************/

/*u32 loggingLevel, const char* srcFileName, const char* funcName, 
            s16 lineNumb, u32 UID, u32 PID, const char* msg,...*/
#ifdef WIN_32_PORT
	BOOL log(DWORD mLoggingLevel, CHAR * mLogMessage, ...);
#elif UNIX_PORT
	bool log(unsigned long mLoggingLevel, char * mLogMessage, ...);
	bool log2(unsigned long mLoggingLevel, const char *p_srcFileName, const char *p_funcName,
    int p_LineNumber, int p_UserId, int p_ProviderId, char * mLogMessage, ...);
    bool logHexDump(unsigned int loggingLevel, const char* srcFileName, const char *funcName, 
      int lineNumb, const char * buff, int buffLen);
#endif
    
	long getLoggerSyncCount();
  //TLGB0113 (SB - 80)
  unsigned long getLoggingThreshold();
  bool setLoggingThreshold(unsigned long m_newLogLevel);

          
};

// Declare the global Logger class object
extern Logger g_LoggerObj;
extern Logger g_TraceObj; // definition for the global Trace object


#define ENTER_FUNC g_LoggerObj.log(LOG_LEVEL_DEBUG, "%s<Line: %d> Entered.", __FUNCTION__, __LINE__);
#define EXIT_FUNC g_LoggerObj.log(LOG_LEVEL_DEBUG, "%s<Line: %d> Exit.", __FUNCTION__, __LINE__);


#define DLOG(UID, PID, ...)  g_LoggerObj.log2(LOG_LEVEL_DEBUG,    __FILE__, __FUNCTION__, __LINE__, UID, PID, __VA_ARGS__);
#define TLOG(UID, PID, ...)  g_LoggerObj.log2(LOG_LEVEL_TRACE,    __FILE__, __FUNCTION__, __LINE__, UID, PID, __VA_ARGS__);
#define CLOG(UID, PID, ...)  g_LoggerObj.log2(LOG_LEVEL_CRITICAL, __FILE__, __FUNCTION__, __LINE__, UID, PID, __VA_ARGS__);
#define ELOG(UID, PID, ...)  printf(__VA_ARGS__); g_LoggerObj.log2(LOG_LEVEL_ERROR,__FILE__, __FUNCTION__, __LINE__, UID, PID, __VA_ARGS__);


/*#define DLOG(UID, PID, ...) printf(".");
#define TLOG(UID, PID, ...) printf(".");
#define CLOG(UID, PID, ...) printf(".");
#define ELOG(UID, PID, ...) printf(".");
*/
#endif	/* __LOGGER_H */

#ifdef Linux

extern void strlcat(char* p_desc, char*p_src, int p_size);

#endif
