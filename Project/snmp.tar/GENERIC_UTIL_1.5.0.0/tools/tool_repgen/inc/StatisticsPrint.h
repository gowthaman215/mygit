#ifndef  __NG_MML_MAIN_H
#define  __NG_MML_MAIN_H

#define MAX_OUTPUT_WINDOW_SIZE  30000


#endif

