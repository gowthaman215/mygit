#include <iostream>
#include <map>
#include <StatisticsGenerator.h>
#include "Logger.h"
#include "StatisticsPrint.h"
#include <argtable2.h>
#include <regex.h>      /* REG_ICASE */
#include <strings.h>
#include <stdlib.h>
#include <curses.h>
#include <dirent.h>
#include <stddef.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <errno.h>
#include <string>
//using namespace std;
#define FILE_SIZE 300
map<int,int> g_fileMap;


bool g_fileProcessflag = false;
#ifdef Linux
const char* g_progNameGenerate="grepgen.Linux";
#else
const char* g_progNameGenerate="grepgen.SunOS";
#endif
FILE* outputFile=NULL;
int g_TotalFilesSelected=0;
char g_response[MAX_OUTPUT_WINDOW_SIZE];
extern bool generateReport(const char* , const char* ,const  char* ,int ,int ,const char* , char *);
bool processFile(char*,int,const char*,char*,stats100x *p_stats);
//bool  aggregate(Stats* m_stats, int);
bool  aggregate(stats100x* m_stats, stats100x *p_stats);
extern char g_MapApplCtxtMappingChar[][50];
extern char g_MapOpCodeChar[][50];
bool  printStats(stats100x* m_stats, int p_slot, char * );

#define LPRINTF(...)  { sprintf(g_response, __VA_ARGS__); }


void printGenerateUsage(void **g_generateCommands, void **g_generateHelp)
{

   DLOG(0,0,(char*)"Enter into printGenerateUsage fun");   
   strlcat(g_response, "\n\n", MAX_OUTPUT_WINDOW_SIZE);

   FILE *l_fp = NULL;
   l_fp = fopen("dummy.txt",  "w+");
   if (l_fp)
   {
      printf("version: 1.5.0.0\n");
      printf("usage 1:  %s",  g_progNameGenerate);  arg_print_syntax(stdout,g_generateHelp,"\n");
      printf("usage 2:  %s",  g_progNameGenerate);  arg_print_syntax(stdout,g_generateCommands,"\n\n");
      arg_print_glossary(stdout,g_generateHelp,"      %s %s\n");
      arg_print_glossary(stdout,g_generateCommands,"      %s %s\n");

      fseek(l_fp, 0, SEEK_SET);
      char l_sent[200];
      memset(l_sent, '\0', 200);
      while (1)
      {
         if (NULL == fgets(l_sent, 200, l_fp))
         {
            break;
         }
         else
         {
            strcat(g_response, l_sent);
         }
      }
      fclose(l_fp);
   }
   else
   {
      strcpy(g_response,"Internal Error !! Unable to open dummy.txt");
   }
   DLOG(0,0,(char*)"Exit  From  printGenerateUsage fun");
}



time_t to_seconds(const char *date)
{
   struct tm storage={0,0,0,0,0,0,0,0,0};
   char *p=NULL;
   time_t retval=0;
   p=(char *)strptime(date,"%Y%m%d",&storage);
   if(p==NULL)
   {
      retval=0;
   }
   else
   {
      retval=mktime(&storage);
   }
   return retval;
}


int mymain10(const char* p_path,const char *p_product_entity,
      const char* p_date, const char *p_redirectFile, void** g_generateCommands,void** g_generateHelp)
{
   DLOG(0,0,(char*)"Enter Into mymain fun");

   if((strlen(p_path)==0) ||  (strlen(p_product_entity)==0) || (strlen(p_date)==0) || (strlen(p_redirectFile)==0))
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      printf("All 'Directory Path', 'Product&Entity', 'Date','Report File Name' should be present\n");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }

   if(strlen(p_date)!=8)
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      printf("'Date' incorrectly  entered\n");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }

   int l_start_year;
   int l_start_month;
   int l_start_date;
   char l_temp[10];
   memset(l_temp,'\0',10);
   l_start_year=atoi(strncpy(l_temp,p_date,4));
   memset(l_temp,'\0',10);
   l_start_month=atoi(strncpy(l_temp,p_date+4,2));
   memset(l_temp,'\0',10);
   l_start_date=atoi(strncpy(l_temp,p_date+6,2));

   if((l_start_date == 0  ||l_start_date >31))
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      printf("Date should be between 1-31\n");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }
   if((l_start_month == 0|| l_start_month>12))
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      printf("Month should be between 1-12\n");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }
   if( (l_start_year < 2010) || (l_start_year > 2100))
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      printf("Year should be between 2010-2100\n");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }

   int l_seconds_from_date = to_seconds(p_date);
   int l_seconds_current   = time(NULL);

   if (l_seconds_from_date > l_seconds_current)
   {
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      printf("'Date' is greater than today\n");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }
# if 0
   if((p_applicationContxt == 0)&&(p_opCodeFirst == 0)&&(p_conversation == 0))
   {
      DLOG(0,0,(char*)"p_applicationContxt | p_opCodeFirst | p_conversation %d %d %d %d",p_applicationContxt,p_opCodeFirst,p_conversation);
      memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
      printf("Ethier of Aplication context,Op-Code First,Op-Code Last or Conversation option should be present\n");
      printGenerateUsage(g_generateCommands,g_generateHelp);
      return -1;
   }
#endif
   DLOG(0,0,(char*)"Exit from mymain fun");
   return 0;
}

         stats100x l_stats;
int main(int argc,char** argv)
{
   DLOG(0,0,(char*)"Enter into parseGenerate fun v1.0.0.4");



   bool l_status = g_LoggerObj.initialize(LOG_LEVEL_DEBUG, LOG_MEDIA_FILE, (char*)"./log/", (char*)"TOOL_", (char*)"./log/", 100000000, 0);
   if (!l_status)
   {
      printf("\nUnable to initialize Logger");
      exit(1);
   }


   struct arg_str  *pattern1 = arg_str1("p",NULL,  "<path>", "Path (directory) where the stats files are present");
   struct arg_str  *pattern4 = arg_str1("f",NULL,  "<productname_entityname>", "Product name And Entity name");
   struct arg_str  *pattern5 = arg_str1("d",NULL,  "<date YYYYMMDD>", "The date of the statistics file to be considered");
   struct arg_str  *pattern10 =arg_str1("r",NULL,  "<redirect-file-name>","Redirection file name (the report would be generated into this file)");
   struct arg_end  *end1     = arg_end(20);
   void* g_generateCommands[] = {pattern1,pattern4,pattern5,pattern10,end1};
   int nerrors1;

   /* SYNTAX 4: [--help] [-h] */
   struct arg_lit  *help4    = arg_lit1("h","", "print this help");
   struct arg_end  *end4     = arg_end(20);
   void* g_generateHelp[] = {help4,end4};
   int nerrors4;
   int exitcode=0;
   memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
   if(arg_nullcheck(g_generateCommands)!=0 || arg_nullcheck(g_generateHelp)!=0 )
   {
      printf("%s: insufficient memory\n",g_progNameGenerate);
      exitcode=1;
   }
   FILE *l_fp = fopen("dummy.txt",  "w+");
   nerrors4 = arg_parse(argc,(char**)argv,g_generateHelp);
   nerrors1= arg_parse(argc,(char**)argv,g_generateCommands);
   if (nerrors1==0)
   {
      DLOG(0,0,(char*)"No Errors"); 
      exitcode = mymain10(pattern1->sval[0], pattern4->sval[0], pattern5->sval[0], pattern10->sval[0],
            (void**)&g_generateCommands,(void**)&g_generateHelp); 

      if (0 == exitcode)
      {
         memset(g_response, '\0', MAX_OUTPUT_WINDOW_SIZE);
         //generateReport(pattern1->sval[0],pattern4->sval[0],pattern5->sval[0],pattern10->sval[0],g_response);
         char l_filename[FILE_SIZE];
         char l_year[4+1];
         char l_mon[2+1];
         char l_day[2+1];
         memset(l_year, '\0', sizeof(l_year));
         memset(l_mon, '\0', sizeof(l_mon));
         memset(l_day, '\0', sizeof(l_day));
         memset(l_filename, '\0', sizeof(l_filename));
         strncpy(l_year, pattern5->sval[0], 4);
         strncpy(l_mon, &pattern5->sval[0][4],2);
         strncpy(l_day, &pattern5->sval[0][6],2);
         snprintf(l_filename, sizeof(l_filename), "%s/stats_%s_%s_%s_%s", pattern1->sval[0], pattern4->sval[0], l_year, l_mon, l_day);
         if(false == processFile(l_filename,1,pattern10->sval[0],g_response, &l_stats))
         {
            DLOG(0,0,"failed");
            exit(1);
         }
         else
         {
            DLOG(0,0,"success");
         }
      }

   }
   else
   {
      printGenerateUsage(g_generateCommands,g_generateHelp);
      exitcode =-1;
   }
exit:
   /* deallocate each non-null entry in each argtable */
   arg_freetable(g_generateHelp,sizeof(g_generateHelp)/sizeof(g_generateHelp[0]));
   arg_freetable(g_generateCommands,sizeof(g_generateCommands)/sizeof(g_generateCommands[0]));


   DLOG(0,0,(char*)"Exit from  parseGenerate fun");
   return exitcode;
}


char g_reportHeader[2000];
int  g_currentSlot=-1;


stats100x l_buf;

bool processFile(char* p_filename,int p_slotWise,const char* outFileName,char* p_output, stats100x *p_stats)
{
   DLOG(0,0,(char*)"  Enter into process file ");

   g_fileProcessflag = true;
   struct stat sbuf;

   int fd;
   if ((fd = open(p_filename, O_RDONLY)) == -1) {
      sprintf(p_output, "open  failed for file [%s] %s", p_filename, strerror(errno));
      printf("\n %s\n",p_output);
      return false;
   }

   if (stat(p_filename, &sbuf) == -1) {
      perror("stat");
      return false;
   }

   int l_amt;
   memset(&l_buf, '\0', sizeof(stats100x));
   if ((l_amt= read(fd, (unsigned char*)(&l_buf), sizeof(stats100x))) == -1)
   {
      sprintf(p_output, "read  failed for file [%s] %s", p_filename, strerror(errno));
      printf("\n %s \n",p_output);
      return false;
   }

   printf("\nProcessing the file \n");

   printStats(&l_buf ,p_slotWise, (char*)outFileName);
   /*
      printf("\ncalling aggregate\n");
      if(false==aggregate(&l_buf , p_stats ))
      {
      printf("aggregate return false\n");
      return false;
      }
      */
   close(fd);
   DLOG(0,0,(char*)" Exit from  process file ");
   return true;
}
bool  aggregate(stats100x* m_stats, stats100x *p_stats)
{
   DLOG(0,0,(char*)"  Enter into aggregate func ");
   static int l_copy = 0;
   if(0 == l_copy)
   {
      p_stats->m_currentNumberOfColumns = m_stats->m_currentNumberOfColumns;
      strcpy(p_stats->m_productName, m_stats->m_productName);
      strcpy(p_stats->m_productVersion, m_stats->m_productVersion);
      DLOG(0,0,(char*)" Total Number of the header [%d]",m_stats->m_currentNumberOfColumns);
      for( int l_count = 0; l_count < m_stats->m_currentNumberOfColumns ; l_count++)
      {
         strcpy(p_stats->m_headers[l_count], m_stats->m_headers[l_count]);
         DLOG(0,0,(char*)"Copied Header: [%s] input header:%s] position header[%d]", p_stats->m_headers[l_count],m_stats->m_headers[l_count],l_count); 

      }
      ++l_copy;
   }
   for(int i = 0; i < 24 ; i++)
   {
      for( int l_count = 0; l_count < m_stats->m_currentNumberOfColumns ; l_count++)
      {
         p_stats->m_count[i][l_count] += m_stats->m_count[i][l_count];
         DLOG(0,0,(char*)"Total slot count :[%ld] to toatl slot count added [%ld] from position[%d] for slot[%d]",p_stats->m_count[i][l_count], m_stats->m_count[i][l_count], l_count, i);

      }

   }
   DLOG(0,0,(char*)"  Exit from aggregate func ");

   return true;
}
bool  printStats(stats100x* m_stats, int p_slot, char *p_filename )
{
   DLOG(0,0,(char*)"Enter into printStats func ");
   char l_buffer[2000];
   FILE * pFile;
   if(1 == p_slot )
   {
      pFile = fopen ( p_filename, "w" );
      if(pFile == NULL)
      {
         printf("File not able to Create\n");
         return false;
      }
      TLOG(0,0,(char*)"Product name [%s] Product Version [%s]",m_stats->m_productName,m_stats->m_productVersion);
      TLOG(0,0,(char*)"Slotwise wise Report Generated ");
      memset(l_buffer, '\0',sizeof(l_buffer));
      char *l_dateString = NULL;
      struct tm *tm_ptr=NULL;
      time_t l_tim =time(NULL);
      tm_ptr = localtime(&l_tim);
      l_dateString = asctime(tm_ptr);
      l_dateString[strlen(l_dateString)-1] = '\0';
      sprintf(l_buffer,"Report Generated Time          : %s\n", l_dateString);
      fputs(l_buffer, pFile);

      printf("Product name %s\n",m_stats->m_productName);
      printf("Product Version %s\n",m_stats->m_productVersion);
      memset(l_buffer, '\0',sizeof(l_buffer));
      sprintf(l_buffer,"Product                        : %s\n",m_stats->m_productName);
      //printf("\nputting the buffer [%s]\n", l_buffer);
      fputs (l_buffer, pFile);
      memset(l_buffer, '\0',sizeof(l_buffer));
      sprintf(l_buffer,"Version                        : %s\n",m_stats->m_productVersion);
      fputs (l_buffer, pFile);

      memset(l_buffer, '\0',sizeof(l_buffer));
      sprintf(l_buffer,"Product Entity Name            : %s\n",m_stats->m_entityName);
      fputs (l_buffer, pFile);

      tm_ptr = localtime(&(m_stats->m_fut));
      l_dateString = asctime(tm_ptr);
      l_dateString[strlen(l_dateString)-1] = '\0';
      sprintf(l_buffer,"Stats First Update Time        : %s\n", l_dateString);
      fputs(l_buffer, pFile);

      tm_ptr = localtime(&(m_stats->m_lut));
      l_dateString = asctime(tm_ptr);
      l_dateString[strlen(l_dateString)-1] = '\0';
      sprintf(l_buffer,"Stats Last Update Time         : %s\n\n", l_dateString);
      fputs(l_buffer, pFile);

      //Write the Header
      fputs("R,ID,Event,Addtional Data 1,Additional Data 2,Additional Data 3,", pFile);
      for(int j=0; j<24; j++)
      {
         if(j == 23)
         {
            sprintf(l_buffer, "S%02d\n", j);
         }
         else
         {
            sprintf(l_buffer, "S%02d,", j);
         }
         fputs(l_buffer, pFile);
      }
      fputs("RR,0,RESTARTS,,,,", pFile);

      for(int j=0; j<24; j++)
      {
         if(j == 23)
         {
            sprintf(l_buffer, "%d\n", m_stats->m_startCount[j]);
         }
         else
         {
            sprintf(l_buffer, "%d,", m_stats->m_startCount[j]);
         }
         fputs(l_buffer, pFile);
      }

      //Write the Data
      for(int l_count = 0; l_count < m_stats->m_currentNumberOfColumns ; l_count++)
      {
         fputc('R', pFile);
         fputc(m_stats->m_reportCategory[l_count], pFile);
         fputs(",", pFile);
         sprintf(l_buffer, "%d", 1+l_count);
         fputs(l_buffer, pFile);
         fputs(",", pFile);
         fputs(m_stats->m_headers[l_count], pFile);
         fputs(",", pFile);
         fputs(m_stats->m_2dData[l_count], pFile);
         fputs(",", pFile);
         fputs(m_stats->m_2dData2[l_count], pFile);
         fputs(",", pFile);
         fputs(m_stats->m_2dData3[l_count], pFile);
         fputs(",", pFile);
         for(int j=0; j<24; j++)
         {
            if(j == 23)
               sprintf(l_buffer, "%d\n", m_stats->m_count[j][l_count]);
            else
               sprintf(l_buffer, "%d,", m_stats->m_count[j][l_count]);

            fputs(l_buffer, pFile);
         }
      }

      /*
         fputs("Slot,", pFile);
         for( int l_count = 0; l_count < m_stats->m_currentNumberOfColumns ; l_count++)
         {
         memset(l_buffer, '\0',sizeof(l_buffer));
         DLOG(0,0,(char*)" Header create into out put file [%s]",m_stats->m_headers[l_count]);
         sprintf(l_buffer,"%s", m_stats->m_headers[l_count]);
         fputs (l_buffer, pFile);
         printf("[%s]", l_buffer);
         if(l_count < m_stats->m_currentNumberOfColumns -1)
         {
         strcpy(l_buffer, ",");
         fputs (l_buffer, pFile);
         }
      //getchar();
      }
      memset(l_buffer, '\0',sizeof(l_buffer));
      strcpy(l_buffer,"\n");
      fputs (l_buffer, pFile);

      for(int i = 0; i < 24 ; i++)
      {
      sprintf(l_buffer, "S%02d,", i);
      fputs (l_buffer, pFile);

      for( int l_count = 0; l_count < m_stats->m_currentNumberOfColumns ; l_count++)
      {
      memset(l_buffer, '\0',sizeof(l_buffer));
      printf("%ld,",m_stats->m_count[i][l_count]);
      DLOG(0,0,(char*)"Slot Value into out put file [%ld]",m_stats->m_count[i][l_count]);
      sprintf(l_buffer,"%ld", m_stats->m_count[i][l_count]);
      fputs (l_buffer, pFile);
      if(l_count < m_stats->m_currentNumberOfColumns -1)
      {
      strcpy(l_buffer, ",");
      fputs (l_buffer, pFile);
      }
      }
      memset(l_buffer, '\0',sizeof(l_buffer));
      strcpy(l_buffer,"\n");
      fputs (l_buffer, pFile);
      }
      */
      fclose (pFile);
      printf("\nReport Generated.\n\n");
   }
   else
   {
      pFile = fopen (p_filename, "w" );
      if(pFile == NULL)
      {
         printf("File not able to Create\n");
         return false;
      }
      TLOG(0,0,(char*)"Aggregate wise Report Generated ");
      TLOG(0,0,(char*)"Product name [%s] Product Version [%s]",m_stats->m_productName,m_stats->m_productVersion);
      printf("Product name %s\n",m_stats->m_productName);
      printf("Product Version %s\n",m_stats->m_productVersion);
      memset(l_buffer, '\0',sizeof(l_buffer));
      sprintf(l_buffer,"Product name :%s\n",m_stats->m_productName);
      fputs (l_buffer, pFile);
      memset(l_buffer, '\0',sizeof(l_buffer));
      sprintf(l_buffer,"Product Version  :%s\n",m_stats->m_productVersion);
      fputs (l_buffer, pFile);
      for( int l_count = 0; l_count < m_stats->m_currentNumberOfColumns ; l_count++)
      {
         memset(l_buffer, '\0',sizeof(l_buffer));
         printf("%s,",m_stats->m_headers[l_count]);
         DLOG(0,0,(char*)" Header create into out put file [%s]",m_stats->m_headers[l_count]);
         sprintf(l_buffer,"%s", m_stats->m_headers[l_count]);
         fputs (l_buffer, pFile);

         if(l_count < m_stats->m_currentNumberOfColumns -1)
         {
            strcpy(l_buffer, ",");
            fputs (l_buffer, pFile);
         }

      }
      memset(l_buffer, '\0',sizeof(l_buffer));
      strcpy(l_buffer,"\n");
      fputs (l_buffer, pFile);
      Stats l_stats;
      memset(&l_stats, '\0', sizeof(l_stats));

      for( int l_count = 0; l_count < m_stats->m_currentNumberOfColumns ; l_count++)
      {
         for(int i = 0; i < 24 ; i++)
         {
            l_stats.m_count[l_count] += m_stats->m_count[i][l_count];
         }
         DLOG(0,0,(char*)"Slot Value into out put file [%ld]",l_stats.m_count[l_count]);
         printf("%ld,",l_stats.m_count[l_count]);
         sprintf(l_buffer,"%ld", l_stats.m_count[l_count]);
         fputs (l_buffer, pFile);
         if(l_count < m_stats->m_currentNumberOfColumns -1)
         {
            strcpy(l_buffer, ",");
            fputs (l_buffer, pFile);
         }
      }
      memset(l_buffer, '\0',sizeof(l_buffer));
      strcpy(l_buffer,"\n");
      fputs (l_buffer, pFile);
      fclose (pFile);
   }
   DLOG(0,0,(char*)"  Exit from printStats func ");
   return true;
}






