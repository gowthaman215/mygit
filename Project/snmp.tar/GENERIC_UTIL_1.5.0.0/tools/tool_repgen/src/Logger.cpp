/************************************************************************

 ************************************************************************/

volatile long g_LoggerCounter = 0;
#include <pthread.h>
#include <Logger.h>
#include <SnmpInterface.h>

extern pthread_key_t g_key;


#include <Logger.h>

extern pthread_t handlerThID[6];

#define __FUNCTION__ "func"

Logger g_LoggerObj; // definition for the global Logger object
Logger g_TraceObj; // definition for the global Trace object
Logger g_PlLoggerObj;
Logger g_SlLoggerObj;

Logger::Logger()
{
  resetMembers();
}

Logger::~Logger()
{
}

void Logger::resetMembers()
{
  iLoggingMedia		= 0;
  iLoggingThreshold	= 0;
  iLoggerFileHandle	= 0;
  iLoggerConsoleHandle	= 0;
  iArchivalDirPath	= NULL;
  iMaxFileSize		= 1000000;
  iFilePath		= NULL;
  iModuleName		= NULL;
  i_SyncCount		= 0;
  memset(iLoggerBuffer, '\0', LOGGER_BUFFER_SIZE);
  pthread_mutex_init(&edrMutex, NULL);
} 

char * Logger::makeFileName(char * mFileNameBuffer, char * mPath, char * mFilePrefix)
{
  /*struct tm *tm_ptr=NULL;
  time_t the_time;
  memset(&the_time, '\0', sizeof(time_t));
  (void) time(&the_time);
  tm_ptr = localtime(&the_time);*/

struct tm *tm_ptr=NULL;
time_t l_tim =time(NULL);
tm_ptr = localtime(&l_tim);
  sprintf(mFileNameBuffer, "%s/%s_%02u_%02u_%04u_%02u_%02u_%02u.log", mPath, mFilePrefix, tm_ptr->tm_mday, tm_ptr->tm_mon+1, tm_ptr->tm_year+1900, tm_ptr->tm_hour, tm_ptr->tm_min, tm_ptr->tm_sec);

  if((this->iFilePath == NULL) ||(strcmp(mPath, this->iFilePath)==0))
  {
    strcpy(this->iFileName,mFileNameBuffer);
  }

  return mFileNameBuffer;
}

void Logger::makeTimeStamp(char *p_DateTimeStamp)
{
  /*long timeInSeconds=0;
  struct tm *timeStruct=NULL;

  time(&timeInSeconds);
  timeStruct = localtime(&timeInSeconds);*/

char * dateString=NULL;
struct tm *tm_ptr=NULL;
time_t l_tim =time(NULL);
tm_ptr = localtime(&l_tim);
  dateString = asctime(tm_ptr);
  // Vishal -> commenting to save strlen system call. Always 25th character is '\n', so make it NULL directly
  //*(dateString + strlen(dateString) -1) = 0;
  dateString[24] = 0;
  strcpy(p_DateTimeStamp, dateString);
  //return dateString;
}

bool Logger::initialize(unsigned long mLoggingThreshold, unsigned long mLoggingMedia, char * mPath, char * mModuleName,char * mArchivalDirPath, unsigned long mMaxFileSize, int p_type)
{
  m_type = p_type;
  iArchivalDirPath = (char *)malloc(strlen(mArchivalDirPath) + 1);
  strcpy(iArchivalDirPath, mArchivalDirPath);

  iMaxFileSize = mMaxFileSize;

  iFilePath = (char *)malloc(strlen(mPath) + 1);
  strcpy(iFilePath, mPath);

  iModuleName = (char *)malloc(strlen(mModuleName) + 1);
  strcpy(iModuleName, mModuleName);

  i_SyncCount = 0;
  bool mRetVal = false;
  char mFileNameBuffer[500];
  pthread_mutex_init(&edrMutex, NULL);


  try
  {
    if((mLoggingMedia < LOG_MEDIA_LOWER_LIMIT) || (mLoggingMedia > LOG_MEDIA_UPPER_LIMIT) )
    {
      throw LOGGER_ERR_MODE;
    }
    else
      iLoggingMedia = mLoggingMedia;

    if( (mLoggingThreshold < LOG_LEVEL_LOWER_LIMIT) || (mLoggingThreshold > LOG_LEVEL_UPPER_LIMIT) )
    {
      throw LOGGER_ERR_LEVEL;
    }
    else
      iLoggingThreshold = mLoggingThreshold;


    switch((int)iLoggingMedia)
    {
      case LOG_MEDIA_FILE :	
        if((!mPath) || (!mModuleName) || (PATH_MAX_SIZE < (int)strlen(mPath)) || (MODULE_NAME_MAX_SIZE < (int)strlen(mModuleName)) )
          throw LOGGER_ERR_FILE;
        makeFileName(&mFileNameBuffer[0], this->iFilePath, this->iModuleName);
        int retd;
        int iUmask = S_IWGRP | S_IWOTH;
        int iFileCreationMode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH; 
        int iFlags = O_WRONLY | O_CREAT | O_APPEND;
        int iOldUmask = umask(iUmask);
        retd = open(mPath, O_RDONLY);
        if (retd == -1)			
        {
          int iDirCreationMode = iFileCreationMode | S_IXUSR | S_IXGRP | S_IXOTH;
          int p = mkdir(mPath, iDirCreationMode);
          if(p == -1) 
          {
            perror("Error in Creating Directory");
            throw LOGGER_ERR_FILE;
          }
        }

        // The actual permission will be iFileCreationMode & ~iUmask
        iLoggerFileHandle = open(mFileNameBuffer, iFlags, iFileCreationMode);

        // If unable to open the file than throw error
        if(iLoggerFileHandle == -1)
        {
          throw LOGGER_ERR_FILE;
        }

        // Restore the original umask value.
        umask(iOldUmask);

        break;
    } // end switch


    mRetVal = true;
    log2(LOG_LEVEL_CRITICAL, __FILE__, __FUNCTION__, __LINE__,0,0,"*********************************************************************************************");
    if (1 == m_type)
    {
    log2(LOG_LEVEL_CRITICAL,  __FILE__, __FUNCTION__, __LINE__,0,0,"                                   TRACING STARTED                                           ");
    }
    else
    {
    log2(LOG_LEVEL_CRITICAL,  __FILE__, __FUNCTION__, __LINE__,0,0,"                                   LOGGING STARTED                                           ");
    }
    log2(LOG_LEVEL_CRITICAL,  __FILE__, __FUNCTION__, __LINE__,0,0,"*********************************************************************************************");
  }
  catch (int err_code) 
  {
    iLoggingMedia	= 0;
    iLoggingThreshold	= 0;

    switch (err_code)
    {
      case LOGGER_ERR_FILE :			// File path is not correct
        iLoggerFileHandle		= 0;
        break;
      case LOGGER_ERR_NEW_CONSOLE :	// Console window problem
        iLoggerConsoleHandle	= 0;
        break;
      case LOGGER_ERR_BUFFER :		// Insufficient memory
        break;
    } //end of switch 
  }
  return mRetVal;
}


void Logger::terminate()
{
	log2(LOG_LEVEL_CRITICAL,  __FILE__, __FUNCTION__, __LINE__,0,0,"*********************************************************************************************");
    log2(LOG_LEVEL_CRITICAL,  __FILE__, __FUNCTION__, __LINE__,0,0,"                                   LOGGING STOPPED                                           ");
	log2(LOG_LEVEL_CRITICAL,  __FILE__, __FUNCTION__, __LINE__,0,0,"*********************************************************************************************");

  switch ((int)iLoggingMedia) 
  {
    // If LoggingMedia is file then close file handle
    case LOG_MEDIA_FILE :		
      if(iLoggerFileHandle)
      {
        //CloseHandle(iLoggerFileHandle);
        close(iLoggerFileHandle);
      }
      break;
  };

  if(iModuleName)
    free(iModuleName);

  if(iFilePath )
    free(iFilePath);

  if(iArchivalDirPath)
    free(iArchivalDirPath);

  resetMembers();
}



bool Logger::log2(unsigned long mLoggingLevel, const char *p_srcFileName, const char *p_funcName,
    int p_LineNumber, int p_UserId, int p_ProviderId, char* mLogMessage, ...)
{
  try 
  {
    pthread_mutex_lock(&edrMutex);
    char dateString[25];
    memset(dateString, '\0', 25);

    char debugTag[10];
    memset(debugTag, '\0', 10);

    unsigned long  ulThreadID = pthread_self();
    char m_buffer[3000];
    memset(m_buffer, '\0', 3000);
    if( (mLoggingLevel<LOG_LEVEL_LOWER_LIMIT) || (mLoggingLevel>LOG_LEVEL_UPPER_LIMIT) || (mLoggingLevel>iLoggingThreshold))
    {
      pthread_mutex_unlock(&edrMutex);	
      return false;
    }
    if(!mLogMessage || (LOG_MESSAGE_MAX_SIZE<(int)strlen(mLogMessage)) )	
    {
      pthread_mutex_unlock(&edrMutex);	
      return false;
    }

    //m_criticalSection.Enter();
    this->i_SyncCount++;
    makeTimeStamp(dateString);
		#ifdef Linux
    va_list args ;
		#else
		va_list args = 0;
		#endif
    va_start(args, mLogMessage);

    switch(mLoggingLevel)
    {
      case LOG_LEVEL_CRITICAL:
        strcpy(debugTag,"[C]");
        break;

      case LOG_LEVEL_ERROR:
        strcpy(debugTag,"[E]");
        break;

      case LOG_LEVEL_TRACE:
        strcpy(debugTag,"[T]");
        break;

      case LOG_LEVEL_DEBUG:
        strcpy(debugTag,"[D]");
        break;

      default:
        strcpy(debugTag,"[U]");
        break;
    }/* End of switch */


    char l_idBuffer2[40];
    memset(l_idBuffer2, '\0', 40);
    /*

	if ( (g_SlCurrentContext == 0) || (p_ProviderId > 0) )// If providerId is > 0 then log it as empty
	{
	  sprintf(l_idBuffer2, "%15s", " ");
	}
	else
	{
	  sprintf(l_idBuffer2, "%3s%3s:%08d", g_SlModName, g_SlMessageName, g_SlCurrentContext);

      if (1 == m_type)
      {
          strcat(l_idBuffer2, "|I");
          strcat(l_idBuffer2, g_SlCurrentIMSI);
      }
	}*/

	/*void *l_test2 = NULL;
	l_test2 = pthread_getspecific(g_key);
	if (l_test2 != NULL)
	{
		//printf("\nFor logging DB Request:::: Retrieved value [%s]", (char*)l_test2);
		strcpy(l_idBuffer2, (char*)l_test2);
	}
	else
	{
		//printf("\nl_test2 is null");
	}*/


    //strcat(l_idBuffer, l_idBuffer2);

    memset(iLoggerBuffer, '\0', LOGGER_BUFFER_SIZE);
    vsnprintf(iLoggerBuffer + 
        sprintf(iLoggerBuffer,"%s|%s|%s|", 
          debugTag, 
          dateString, 
          l_idBuffer2), LOGGER_BUFFER_SIZE-200, mLogMessage, args);


    if(NULL != p_srcFileName)
    {
      const char *l_StrIndex = strrchr(p_srcFileName, '/') ;
      if (NULL != l_StrIndex)
        p_srcFileName = ++l_StrIndex;
    }

    snprintf(m_buffer, 3000, "  |%s|%s|%d\n", p_srcFileName, p_funcName, p_LineNumber);
    strlcat(iLoggerBuffer, m_buffer, LOGGER_BUFFER_SIZE-1);

    unsigned long m_FileSize;
    switch (iLoggingMedia)
    {
      case LOG_MEDIA_FILE :			
        struct stat fileStat;


        fstat(this->iLoggerFileHandle, &fileStat);
        m_FileSize = fileStat.st_size;

        chmod(iFileName,0600);
        if(m_FileSize >= this->iMaxFileSize)
        {
          char mFileNameBuffer[500];
          close(this->iLoggerFileHandle);
          makeFileName(&mFileNameBuffer[0],this->iArchivalDirPath,this->iModuleName);

          rename(this->iFileName,mFileNameBuffer);
          makeFileName(&mFileNameBuffer[0],this->iFilePath,this->iModuleName);

          iLoggerFileHandle = creat(mFileNameBuffer,O_CREAT|O_RDWR);
          chmod(iFileName,0600);
          if(iLoggerFileHandle == -1) 
          {
            throw LOGGER_ERR_FILE;
          }
          else // Point to end of the file
          {					
            lseek(iLoggerFileHandle,0,SEEK_END);
          }
        }
        write(iLoggerFileHandle, iLoggerBuffer, strlen(iLoggerBuffer));

        chmod(iFileName,0400);
        break;
      case LOG_MEDIA_CONSOLE :
        printf(iLoggerBuffer);
        break;
    };
    this->i_SyncCount--;
    //m_criticalSection.Leave();
    pthread_mutex_unlock(&edrMutex);	
    return true;
  }
  catch(...)
  {
    //cout<<"**************Unknown exception occured in Logger*************"<<endl;
    if(this->i_SyncCount)
    {
      this->i_SyncCount--;
      //m_criticalSection.Leave();
    }			
    pthread_mutex_unlock(&edrMutex);	
    return false;
  }
}

bool Logger::log(unsigned long mLoggingLevel, char* mLogMessage, ...)
{
  try 
  {
    int debugTagLen;
    char dateString[25];
    memset(dateString, '\0', 25);
    char* debugTag;
    unsigned long  ulThreadID = pthread_self();
    char m_buffer[3000];
    if( (mLoggingLevel<LOG_LEVEL_LOWER_LIMIT) || (mLoggingLevel>LOG_LEVEL_UPPER_LIMIT) || (mLoggingLevel>iLoggingThreshold))
    {
      return false;
    }
    if(!mLogMessage || (LOG_MESSAGE_MAX_SIZE<(int)strlen(mLogMessage)) )	
      return false;

    //m_criticalSection.Enter();
    this->i_SyncCount++;
    makeTimeStamp(dateString);
		#ifdef Linux
    va_list args ;
		#else
    va_list args = 0;
		#endif
    va_start(args, mLogMessage);

    switch(mLoggingLevel)
    {
      case LOG_LEVEL_CRITICAL:
        debugTag = "[C]: ";
        debugTagLen = sizeof("[C]: ");
        break;

      case LOG_LEVEL_TRACE:
        debugTag = "[T]: ";
        debugTagLen = sizeof("[T]: ");
        break;

      case LOG_LEVEL_ERROR:
        debugTag = "[E]: ";
        debugTagLen = sizeof("[E]: ");
        break;

      case LOG_LEVEL_DEBUG:
        debugTag = "[D]: ";
        debugTagLen = sizeof("[D]: ");
        break;

      default:
        debugTag = "[U]: ";
        debugTagLen = sizeof("[U]: ");
        break;
    }/* End of switch */

    strcpy( iLoggerBuffer + vsprintf(iLoggerBuffer + 
          sprintf(iLoggerBuffer,"%s : %s ",dateString, debugTag), mLogMessage, args) 
        + DATE_STRING_LEN + debugTagLen, "\n");

    /* Added By Sadiq S on 16-08-2006 to print Thread Name also */ 
#if 0
    if(ulThreadID== 1) 
      sprintf(m_buffer,"T<%lu:MAIN>",ulThreadID);
    else if(ulThreadID == handlerThID[0]) 
      sprintf(m_buffer,"T<%lu:DECODER>",ulThreadID);
    else if(ulThreadID == handlerThID[1]) 
      sprintf(m_buffer,"T<%lu:ENCODER>",ulThreadID);
    else if(ulThreadID == handlerThID[2]) 
      sprintf(m_buffer,"T<%lu:SMPP>",ulThreadID);
    else if(ulThreadID == handlerThID[3]) 
      sprintf(m_buffer,"T<%lu:SMDPP>",ulThreadID);
    else if(ulThreadID == handlerThID[4]) 
      sprintf(m_buffer,"T<%lu:SMSREQ>",ulThreadID);
    else if(ulThreadID == handlerThID[5]) 
      sprintf(m_buffer,"T<%lu:SMSNOT>",ulThreadID);
    else 
      sprintf(m_buffer,"T<%lu:>",ulThreadID);
#else    
    sprintf(m_buffer,"T<%lu:>",ulThreadID);
#endif    
    strcat(m_buffer,iLoggerBuffer);
    strcpy(iLoggerBuffer,m_buffer);
    unsigned long m_FileSize;
    switch (iLoggingMedia)
    {
      case LOG_MEDIA_FILE :			
        struct stat fileStat;


        fstat(this->iLoggerFileHandle, &fileStat);
        m_FileSize = fileStat.st_size;

        chmod(iFileName,0600);
        if(m_FileSize >= this->iMaxFileSize)
        {
          char mFileNameBuffer[500];
          close(this->iLoggerFileHandle);
          makeFileName(&mFileNameBuffer[0],this->iArchivalDirPath,this->iModuleName);

          rename(this->iFileName,mFileNameBuffer);
          makeFileName(&mFileNameBuffer[0],this->iFilePath,this->iModuleName);

          iLoggerFileHandle = creat(mFileNameBuffer,O_CREAT|O_RDWR);
          chmod(iFileName,0600);
          if(iLoggerFileHandle == -1) 
          {
            throw LOGGER_ERR_FILE;
          }
          else // Point to end of the file
          {					
            lseek(iLoggerFileHandle,0,SEEK_END);
          }
        }
        write(iLoggerFileHandle, iLoggerBuffer, strlen(iLoggerBuffer));

        chmod(iFileName,0400);
        break;
      case LOG_MEDIA_CONSOLE :
        printf(iLoggerBuffer);
        break;
    };
    this->i_SyncCount--;
    //m_criticalSection.Leave();
    return true;
  }
  catch(...)
  {
    //cout<<"**************Unknown exception occured in Logger*************"<<endl;
    if(this->i_SyncCount)
    {
      this->i_SyncCount--;
      //m_criticalSection.Leave();
    }			
    return false;
  }

}

long Logger::getLoggerSyncCount()
{
  return this->i_SyncCount;
}

unsigned long Logger::getLoggingThreshold()
{
  return iLoggingThreshold;
}

bool Logger::setLoggingThreshold(unsigned long m_newLoglevel)
{

  iLoggingThreshold = m_newLoglevel;
  //cout<<"NEWLOGLEVEL:"<<iLoggingThreshold<<endl;
  return true;
}


bool Logger::logHexDump(unsigned int loggingLevel, const char* srcFileName, const char *funcName, 
      int lineNumb, const char * buff, int buffLen)
{

      char  msgBuff[15000] = {0};
      memset(msgBuff, '\0', 15000);

#if 0

      int ind=0;
      for(int i = 0; i < buffLen; i++)
      {
         sprintf(&msgBuff[ind], "%02x ", (char*)buff);
         ind += 3;
      }


#endif
    return log2(loggingLevel, srcFileName, funcName, lineNumb, 0, 0, msgBuff); 
	return true;
}

#ifdef Linux

void strlcat(char* p_desc, char*p_src, int p_size)
{
   snprintf(p_desc, p_size, "%s%s", p_desc, p_src);
}
#endif


