#include <SnmpBufferData.h>
#include <stdio.h>

SnmpBufferData::SnmpBufferData()
{
    m_length=-1;
    m_data=NULL;
}

SnmpBufferData::~SnmpBufferData()
{
    if (m_data != NULL)
    {
        delete[] m_data;
    }
}

