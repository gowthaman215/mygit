#include <LogOverride.h>
#include <stdio.h>

LogOverride::LogOverride()
{
}

LogOverride::~LogOverride()
{
}

LogOverride *g_lo=NULL;

