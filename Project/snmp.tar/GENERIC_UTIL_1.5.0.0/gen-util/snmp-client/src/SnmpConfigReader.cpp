/************************************************************************
 ** FILE NAME    : SnmpConfigReader.cpp
 ** AUTHOR       : 
 ** DEFINTION    : 
 ** REMARKS      :
 ************************************************************************/
#include <SnmpConfigReader.h>
#include <SnmpInterface.h>
#include <SnmpParser.h>

#include <map>
#include <list>
#include <iterator>
#include <iostream>
#include <stdlib.h>
using namespace std;

SnmpConfigData g_SnmpConfigData;
SnmpConfigReader g_SnmpConfigReader;
map<string, SnmpTrapThreshold> g_SnmpThresholdMap;

bool ValidateIpv4(char *p_ipadd)
{
   unsigned b1, b2, b3, b4;
   unsigned char c;

   if (sscanf(p_ipadd, "%3u.%3u.%3u.%3u%c", &b1, &b2, &b3, &b4, &c) != 4)
      return false;

   if ((b1 | b2 | b3 | b4) > 255)
      return  false;

   if (strspn(p_ipadd, "0123456789.") < strlen(p_ipadd))
      return false;

   return true;
}

SnmpTrapThreshold::SnmpTrapThreshold()
{
   m_maxInterval=-1;
   m_lastResetEpoch=0;
   m_lastTrapType=TRAP_TYPE_UNKNOWN;
   m_sentFlag=false;
   m_notSentCounter=0;
}

SnmpTrapThreshold::~SnmpTrapThreshold()
{
}


SnmpConfigData::SnmpConfigData()
{

}

SnmpConfigData::~SnmpConfigData()
{
}

bool SnmpConfigReader::IsString(char *st)
{
   int l_StrLength = strlen(st);

   for(int l_index=0; l_index < l_StrLength; l_index++)
      if (isalpha(st[l_index]))
         return false;

   return true;
}

string SnmpConfigReader::readValue (string parent, string child)
{
   string n = SnmpParser::getChildString (parent, child);
   string v = SnmpParser::getValue (n, child);
   return v;
}

bool SnmpConfigReader::readInteger(string parent, 
      string child, 
      int &ConfigValue,
      int min, 
      int max)
{
   string temp = readValue (parent, child);
   //cout << child << " = " << temp << endl;

   if (false == IsString((char *)temp.c_str()))
   {
      printf("\nConfiguration Value %s not numeric", child.c_str());
      return false;
   }

   ConfigValue  = atoi(temp.c_str());
   if (min > ConfigValue  || max < ConfigValue)
   {
      cout <<"Configuration Value not in valid range" << endl;
      return false;
   }
   return true;
}

bool SnmpConfigReader::readInteger(string parent, 
      string child, 
      unsigned int &ConfigValue,
      unsigned int min, 
      unsigned int max)
{
   string temp = readValue (parent, child);
   //cout << child << " = " << temp <<endl;

   if (false == IsString((char *)temp.c_str()))
   {
      cout <<"Configuration Value not numeric." << endl;
      return false;
   }


   if (min > ConfigValue  || max < ConfigValue)
   {
      cout <<"Configuration Value not in valid range" << endl; 
      cout<<"For the Verification:"<<endl;
      return false;
   }
   ConfigValue  = atoi(temp.c_str());
   return true;
}

bool SnmpConfigReader::readInteger(string parent, 
      string child, 
      short &ConfigValue,
      int min, 
      int max)
{
   string temp = readValue (parent, child);
   //cout << child << " = " << temp <<endl;

   if (false == IsString((char *)temp.c_str()))
   {
      cout <<"Configuration Value not numeric."<<endl;
      return false;
   }


   if (min > ConfigValue  || max < ConfigValue)
   {
      cout <<"Configuration Value not in valid range"<<endl; 
      return false;
   }
   ConfigValue  = atoi(temp.c_str());
   return true;
}

bool SnmpConfigReader::readString(string  parent, string child,  char  *ConfigValue ,unsigned int min, unsigned int max) 
{
   string temp = readValue (parent, child);
   //cout << child << " = " << temp <<endl;

   if(min > temp.size()|| max < temp.size())
   {
      printf("\nInvalid %s Configuration value length %d temp = %s\n", child.c_str(),temp.size(), temp.c_str());
      return false;
   }
   strcpy((char *)ConfigValue , temp.c_str()); 
   return true;
}


bool SnmpConfigReader::readConfig()
{
   string xmlFile;
   try
   {
      s8 m_filepath[128];
      sprintf(m_filepath, "./config/SnmpClientConfigData.xml");

      if(!strcmp(m_filepath, ""))
      {
         cout<<"CONFIGURATION FILE NOT FOUND."<< m_filepath << endl;		
         return false;
      }
      else
      {
         cout<<"CONFIGURATION FILE: "<< m_filepath << endl;
      }

      xmlFile = SnmpParser::readXMLFile(m_filepath);

      string networkserver = SnmpParser::getChildString(xmlFile, "GENERIC_SNMP_CLIENT");

      return true;
   }
   catch(...)
   {
      cout<<"[ERROR]: Failed to read from configuration file for dynamic loglevel change."<<endl;
      return false;
   }
}

char *getLogLevel(char *p_level)
{
   switch (p_level[0])
   {
      case 'D':
         return "DEBUG";
         break;
      case 'T':
         return "TRACE";
         break;
      case 'W':
         return "WARNING";
         break;
      case 'C':
         return "CRITICAL";
         break;
      case 'E':
         return "ERROR";
         break;
      default:
         return "UNKNOWN";
         break;
   }
}

char *getLogMedia(char *p_media)
{
   switch (p_media[0])
   {
      case 'F':
         return "FILE";
         break;
      case 'C':
         return "CONSOLE";
         break;
      default:
         return "UNKNOWN";
         break;
   }
}

bool SnmpConfigReader::readString(string  p_parent, string p_child,  string& p_ConfigValue ,unsigned int p_min, unsigned int p_max)
{
   p_ConfigValue = readValue (p_parent, p_child);

   if(p_min > p_ConfigValue.size()|| p_max < p_ConfigValue.size())
   {
      printf("\nInvalid %s value length. Should be between %d and %d", p_child.c_str(), p_min, p_max);
      return false;
   }
   return true;
}


bool SnmpConfigReader::init(char *p_file)
{
#if 0
   try
   {
      string l_xmlFile = SnmpParser::readXMLFile(p_file);

      if (0 == l_xmlFile.size())
      {
         printf("\nConfiguration file [%s] not found", p_file);
         return false;
      }

      string networkserver = SnmpParser::getChildString (l_xmlFile, "GENERIC_SNMP_CLIENT");
      string l_nsApp = SnmpParser::getChildString(networkserver,"TRAPS");

      for(int l_appCnt=1;l_appCnt<=MAXAPPCONF;++l_appCnt)
      {
         char index[20];
         memset(index,0x00,20);
         sprintf(index,"TRAP_%02d",l_appCnt);

         string l_nsAppCnt1 = SnmpParser::getChildString(l_nsApp,index);

         if(l_nsAppCnt1.empty())
            break;

         SnmpTrapThreshold *l_stt = new SnmpTrapThreshold;

         if(false == readString(l_nsAppCnt1 ,"ID",l_stt->m_trapId, 1, 20))
            return false;

         map<string,SnmpTrapThreshold*>::iterator l_trap_it;
         l_trap_it = g_SnmpThresholdMap.find(l_stt->m_trapId);
         if(l_trap_it != g_SnmpThresholdMap.end())
         {
            UTIL_LOG('C', "Trap [%s] is duplicated", (char*)l_stt->m_trapId.c_str());
            return false;
         }

         UTIL_LOG('T',"Trap Name : [%s] ", (char*)l_stt->m_trapId.c_str());

         if(false == readInteger(l_nsAppCnt1, "INTERVAL",l_stt->m_maxInterval, 0, 24*60*60))
         {
            UTIL_LOG('C',"Invalid INTERVAL");
            return false;
         }

         UTIL_LOG('T',"Interval : [%d] ", l_stt->m_maxInterval);

         l_stt->m_lastResetEpoch=time(NULL)-1;

         UTIL_LOG('T',"Epoch : [%d] ", l_stt->m_lastResetEpoch);

         g_SnmpThresholdMap.insert(pair<string,SnmpTrapThreshold*>(l_stt->m_trapId,l_stt));

      }
      return true;
   }
   catch(...)
   {
      cout<<"[ERROR]: Failed to read from configuration file."<<endl;
      return false;
   }
#endif 
   return true;
}
char *SnmpConfigReader::getConfigPrint()
{
   char *l_configDataChar = new char[10000];
   memset(l_configDataChar, '\0', 5000);
   strcpy(l_configDataChar, "\n");


   char l_temp[2000];
   memset(l_temp, '\0', 2000);

   return l_configDataChar;
}






