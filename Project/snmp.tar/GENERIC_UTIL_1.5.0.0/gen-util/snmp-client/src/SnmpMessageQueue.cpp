#include <SnmpMessageQueue.h>
#include <errno.h>
#include <stdio.h>

SnmpMessageQueue::SnmpMessageQueue(ESnmpQueueType p_QueueType)
{
   m_QueueType = p_QueueType;
}


SnmpMessageQueue::~SnmpMessageQueue()
{
}

int SnmpMessageQueue::size()
{
   return m_q.size();
}

bool SnmpMessageQueue::initialize()
{

   if (0 != pthread_mutex_init(&m_q_mutex, NULL))
   {
      printf("\nUnable to initialize the mutex");
      return false;
   }

   if (-1 == sem_init(&m_semaphore, 0, 0))
   {
      printf("\nUnable to initialize the semaphore [%d]", errno);
      return false;
   }
   return true;
}


bool SnmpMessageQueue::push(void *p_qm)
{
   pthread_mutex_lock(&m_q_mutex);
   m_q.push_back(p_qm);
   pthread_mutex_unlock(&m_q_mutex);
   sem_post(&m_semaphore);
   return true;
}


bool SnmpMessageQueue::pop(void **p_qm)
{
   if (m_QueueType == SNMP_QUEUE_TYPE_BLOCKING)
   {
      int l_sem_result = sem_wait(&m_semaphore);
      if (-1 == l_sem_result)
      {
         printf("\nCRITICAL::ERROR!!!!!!! Semaphore returned error [%d]", errno);
         switch (errno)
         {
            case EINVAL:
               printf("\nCRITICAL::EINVAL received");
               break;
            case ENOSYS:
               printf("\nCRITICAL::ENOSYS received");
               break;
            case EAGAIN:
               printf("\nCRITICAL::EAGAIN received");
               break;
            case EDEADLK:
               printf("\nCRITICAL::EDEADLK received");
               break;
            case EINTR:
               printf("\nCRITICAL::EINTR received");
               break;
            default:
               printf("\nCRITICAL::Unknown errno");
               break;
         }
         return false;
      }
   }
   else
   {
      // Do nothing
   }

   pthread_mutex_lock(&m_q_mutex);

   if (m_q.size() != 0)
   {
      //printf("\nGetting a message from the queue");
      (*p_qm) = m_q[0];
      m_q.pop_front();
      pthread_mutex_unlock(&m_q_mutex);
   }
   else
   {
      pthread_mutex_unlock(&m_q_mutex);

      if (m_QueueType == SNMP_QUEUE_TYPE_BLOCKING)
      {
         printf("\nERROR!!!!!!! SnmpMessageQueue::popMessage ended: Still No data thing coming");
      }
      return false;
   }
   return true;
}


