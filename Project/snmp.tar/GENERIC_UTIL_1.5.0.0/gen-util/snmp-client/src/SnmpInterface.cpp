#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <strings.h>
#include <errno.h>
#include <ctype.h>
#include <SnmpInterface.h>
#include <SnmpMessageQueue.h>
#include <SnmpBufferData.h>
#include <SnmpConfigReader.h>
#include <StatisticsGenerator.h>
#include <StatisticsInitializationHelper.h>

#define  SNMP_CLIENT_VERSION  "1.5.0.1" //"1.5.0.0 Rev1" //"1.5.0.0" //"1.4.3.1" //"1.4.0.0"

#define MAX_TRAPS_PER_TEMPLATE_COUNT  99


char g_selfEntityName[MAX_ENTITY_NAME_LENGTH+1];
char g_agentPort[10];
int  g_agentFd=0;
char g_ipAddress[20];
char g_snmpAgentIp[20+1];
SnmpMessageQueue *g_snmpInputQueue = NULL;
SnmpInterface g_si;
extern map<string, SnmpTrapThreshold> g_SnmpThresholdMap;

void getIpAddress(char *p_ipAddress)
{
	int x, ip_len = 16;
	char * str = NULL, * ip = NULL;
	struct hostent * hent = NULL;

	char l_name[51];
	memset(l_name, '\0', 51);
	size_t l_nameLength=0;
	gethostname(l_name, 50);

	hent = gethostbyname(l_name);
	str = hent -> h_addr_list[0];

	x = (*str < 0) ? (256 + *str) : *str;
	sprintf(p_ipAddress, "%d",x); str++;
	x = (*str < 0) ? (256 + *str) : *str;
	sprintf(p_ipAddress, "%s.%d",p_ipAddress, x); str++;
	x = (*str < 0) ? (256 + *str) : *str;
	sprintf(p_ipAddress, "%s.%d",p_ipAddress, x); str++;
	x = (*str < 0) ? (256 + *str) : *str;
	sprintf(p_ipAddress, "%s.%d%c",p_ipAddress, x, 0x00);

	return;
} 
SnmpInterface::SnmpInterface()
{
	UTIL_LOG('C',"SnmpInterface cons");
	m_initializedFlag=false;
	m_trapCount=0;
	memset(m_trapDesc, '\0', sizeof(m_trapDesc));
	memset(m_trapId, '\0', sizeof(m_trapId));
	memset(&m_uniqueTrapSequenceId, '\0', sizeof(m_uniqueTrapSequenceId));
}

SnmpInterface::~SnmpInterface()
{
	UTIL_LOG('C',"SnmpInterface des");
}
bool responseValidation(char *p_respBuff)
{
	UTIL_LOG('T',"SnmpInterface: Size of threshold map before clearing [%d]", g_SnmpThresholdMap.size());
	//Clearing the old SNMP Threshold map
	g_SnmpThresholdMap.clear();

	UTIL_LOG('T',"SnmpInterface: Threshold map cleared. Recv Response String : [%s]", p_respBuff);

	string l_trapfilter = SnmpParser::getChildString(p_respBuff,"TRAPS_FILTER");

	for(int l_appCnt=1;l_appCnt<=MAX_TRAPS_PER_TEMPLATE_COUNT;++l_appCnt)
	{
		char index[20];
		memset(index,0x00,20);
		sprintf(index,"TRAP_%02d",l_appCnt);

		string l_nsAppCnt1 = SnmpParser::getChildString(l_trapfilter,index);

		if(l_nsAppCnt1.empty())
		{
			UTIL_LOG('C',"%s not found in TRAPS_FILTER tag", index);
			break;
		}

		SnmpTrapThreshold l_stt;
		if(false == g_SnmpConfigReader.readString(l_nsAppCnt1 ,"ID",l_stt.m_trapId, 1, 20))
		{
			UTIL_LOG('E',"Invalid ID");
			return false;
		}
		UTIL_LOG('T',"SnmpInterface: Trap ID: [%s] ", (char*)l_stt.m_trapId.c_str());

		if(false == g_SnmpConfigReader.readInteger(l_nsAppCnt1, "INTERVAL",l_stt.m_maxInterval, 0, 24*60*60))
		{
			UTIL_LOG('E',"Invalid INTERVAL");
			return false;
		}
		UTIL_LOG('T',"SnmpInterface: Interval: [%d] ", l_stt.m_maxInterval);

		l_stt.m_lastResetEpoch=time(NULL)-1;
		UTIL_LOG('T',"Epoch: [%d] ", l_stt.m_lastResetEpoch);

		g_SnmpThresholdMap.insert(pair<string,SnmpTrapThreshold>(l_stt.m_trapId,l_stt));
	}
	UTIL_LOG('T',"SnmpInterface: Size of threshold map after adding threshold traps [%d]", g_SnmpThresholdMap.size());
	return true;
}

bool snmpSendDataToNetwork(int p_sockFd, unsigned char *p_data, int p_length)
{
	unsigned char *l_data = (unsigned char *)"Some Error";
	int l_length=strlen((char*)l_data);

	if (NULL != p_data)
	{
		l_data = p_data;
		l_length = p_length;
	}

	if (0 == l_length)
	{
		UTIL_LOG('E',"SnmpInterface: Invalid length on fd:[%d]", p_sockFd);
		return false;
	}
	if (p_sockFd != 0)
	{
		char l_lengthChar[10];
		memset(l_lengthChar, '\0', 10);
		sprintf(l_lengthChar, "%09d", l_length);

		UTIL_LOG('D',"SnmpInterface: Sending Length [%s] on fd:[%d]", l_lengthChar, p_sockFd);

		if (send(p_sockFd, l_lengthChar, 9, 0) == -1) 
		{
			UTIL_LOG('W',"SnmpInterface: send length failed on fd:[%d]", p_sockFd);
			return false;
		}

		if (send(p_sockFd, l_data, l_length, 0) == -1) 
		{
			UTIL_LOG('W',"SnmpInterface: send data failed on fd:[%d]", p_sockFd);
			return false;
		}
		UTIL_LOG('T',"SnmpInterface: Sending data successfull on fd:[%d]", p_sockFd);
	}
	return true;
}

int SnmpRecvAll(int &s, char *buf, unsigned long len)
{
	int total = 0;
	int bytesleft = len;
	int n;
	while(total < len)
	{
		if(0>s)
			return -1;

		n = recv(s, buf+total, bytesleft,0);
		if (0 >= n)
		{
			if(0 > n)
			{
				//printf("\nrecv failed with errno: %d.", errno);
				if (EINTR == errno)
					continue;
			}
			else
			{
				//printf("\nSocket closed by Peer.");
			}
			//close(s);
			return n;
		}
		total += n;
		bytesleft -= n;
		//printf("\nreceived bytes %d, bytesleft %d, len %d, g_agentFd: %d",n,bytesleft,len, s);
	}
	len = total; // return number actually sent here
	return len;
}

int g_FirstTimeFlag=1;

bool connectToApp(char *p_hostName, char *p_port, int *p_sock, char *p_AppRegResp, char *p_ErrMsg)
{
	int numbytes;  
	char buf[1000];
	struct addrinfo hints, *servinfo, *p;
	int rv;
	char s[INET6_ADDRSTRLEN];
	int l_sock=-1;

	if ( (atoi(p_port) < 1024) ||
			(atoi(p_port) > 99999) )
	{
		sprintf(p_ErrMsg, "port should be between 1024 and 99999");
		return false;
	}

	int l_times=0;
	while(l_sock <= 2 && l_times<5)
	{
		l_times++;
		if ((l_sock = socket(PF_INET, SOCK_STREAM, 0)) == -1) 
		{
			UTIL_LOG('C', "SnmpInterface: socket creation failed");
			return false;
		}
		UTIL_LOG('C',"SnmpInterface: Got fd:[%d] the %dth time", l_sock, l_times);
	}

	if(l_sock < 3)
	{
		UTIL_LOG('C',"SnmpInterface: fd:[%d] is still less than 3", l_sock);
		return false;
	}

	struct sockaddr_in dest_addr; // will hold the destination addr
	dest_addr.sin_family = AF_INET; // host byte order
	dest_addr.sin_port = htons(atoi(p_port)); // short, network byte order
	dest_addr.sin_addr.s_addr = inet_addr(p_hostName);
	memset(&(dest_addr.sin_zero), '\0', 8); // zero the rest of the struct

	if (connect(l_sock, (struct sockaddr *)&dest_addr, sizeof(struct sockaddr)) == -1) 
	{
		close(l_sock);
		sprintf(p_ErrMsg, "connect: %s", strerror(errno));
		return false;
	}

	// Add code for Entity Name

	/*char l_temp[100];
		memset(l_temp, '\0', 100);
		char l_entity[100];
		memset(l_entity, '\0', 100);
		sprintf(l_entity, "%s:%s",g_selfEntityName, g_ipAddress); 
		sprintf(l_temp, "%09d%s", strlen(l_entity), l_entity);


		UTIL_LOG('D',"Sending [%s]", l_temp);

		if (send(l_sock, l_temp, strlen(l_temp), 0) == -1) 
		{
		sprintf(p_ErrMsg, "Unable to send the registration msg");
		close(l_sock);
		l_sock=-1;
		return false;
		}*/

	char * dateString=NULL;
	struct tm *tm_ptr=NULL;
	time_t l_tim =time(NULL);
	tm_ptr = localtime(&l_tim);
	dateString = asctime(tm_ptr);
	dateString[24] = 0;


	char l_entity[1000];
	memset(l_entity, '\0', sizeof(l_entity));
	sprintf(l_entity, "<REGISTRATION><ENTITY_NAME>%s:%s</ENTITY_NAME><DATE>%s</DATE><START_FLAG>%d</START_FLAG><VERSION>%s</VERSION><PRODUCT_ID>%d</PRODUCT_ID><INSTANCE_SEQ_ID>%d</INSTANCE_SEQ_ID><PRODUCT_ID_CHAR>%s</PRODUCT_ID_CHAR></REGISTRATION>", 
			g_selfEntityName, g_ipAddress, dateString, g_FirstTimeFlag,SNMP_CLIENT_VERSION,
			g_si.m_productId, g_si.m_instanceSeqId, g_si.m_productIdChar); 

	if (false == snmpSendDataToNetwork(l_sock, (unsigned char*)l_entity, strlen(l_entity)))
	{
		UTIL_LOG('C',"Unable to send the registration message on fd:[%d]",l_sock);
		return false;
	}

	UTIL_LOG('T',"SnmpInterface: Waiting for registration response on fd:[%d]",l_sock);

	char l_reg_res_length[10];
	memset(l_reg_res_length, '\0', sizeof(l_reg_res_length));
	if (9 != SnmpRecvAll(l_sock, l_reg_res_length, 9))
	{
		close(l_sock);
		UTIL_LOG('C',"SnmpInterface: Unable to receive the registration response length on fd:[%d]",l_sock);
		return false;
	}
	int l_reg_res_length_int = atoi(l_reg_res_length);

	UTIL_LOG('T',"SnmpInterface: Received Registration Response Length [%s] [%d] on fd:[%d]",l_reg_res_length, l_reg_res_length_int,l_sock); 

	if(l_reg_res_length_int > 999999)
	{
		close(l_sock);
		UTIL_LOG('C',"SnmpInterface: Length %s is greater than 999999 on fd:[%d]", l_reg_res_length,l_sock);
		return false;
	}

	char l_reg_res[l_reg_res_length_int +1];
	memset(l_reg_res, '\0', sizeof(l_reg_res));
	if (l_reg_res_length_int != SnmpRecvAll(l_sock, l_reg_res, l_reg_res_length_int))
	{
		close(l_sock);
		UTIL_LOG('C',"SnmpInterface: Unable to receive the registration of length %d on fd:[%d]", l_reg_res_length_int,l_sock);
		return false;
	}
	//get error code
	int l_respCode = 99;

	string l_respBuff=SnmpParser::getChildString(l_reg_res,"REGISTRATION_RESPONSE");
	if(l_respBuff.size() > 0)
	{
		string l_err=SnmpParser::getChildString(l_respBuff, "ERROR_CODE");
		if(false == g_SnmpConfigReader.readInteger(l_err,"ERROR_CODE",l_respCode,0,99999))
		{
			UTIL_LOG('C', "SnmpInterface: Error to read ERROR_CODE from response : [%s]", l_respBuff.c_str());
		}
		string l_temp=SnmpParser::getChildString(l_respBuff, "ERROR_DESC");
		string l_errDesc;

		if(false == g_SnmpConfigReader.readString(l_temp,"ERROR_DESC",l_errDesc,0,99999))
		{
			UTIL_LOG('C', "SnmpInterface: Error to read ERROR_DESC from response : [%s]", l_respBuff.c_str());
		}
		if(l_errDesc.size() > 0)
		{
			UTIL_LOG('C', "SnmpInterface: Error desc from agent: [%s]", l_errDesc.c_str());
		}
		string l_server_data;
		if(false == g_SnmpConfigReader.readString(l_respBuff,"SERVER_DATA",l_server_data,0,99999))
		{
			UTIL_LOG('C', "SnmpInterface: Error to read SERVER_DATA from response : [%s]", l_respBuff.c_str());
		}
		g_si.m_serverData = l_server_data;

		UTIL_LOG('T',"SnmpInterface: Received Registration Response [%s] and Response code [%d] on fd:[%d]",l_reg_res,l_respCode,l_sock); 
	}

	if (0 != l_respCode)
	{
		close(l_sock);
		UTIL_LOG('C', "SnmpInterface: CRITICAL!!! GENERIC SNMP Agent is not accepting the connection on fd:[%d]",l_sock);
		switch (l_respCode)
		{
			case 1:
				UTIL_LOG('C',"SnmpInterface: CRITICAL!!! Error Cause: Entity not configured on fd:[%d]",l_sock);
				break;
			case 2:
				UTIL_LOG('C',"SnmpInterface: CRITICAL!!! Error Cause: Entity already exists");
				UTIL_LOG('C',"SnmpInterface: CRITICAL!!! Error Cause: Entity already exists on fd:[%d]", l_sock);
				break;
			case 3:
				UTIL_LOG('C',"SnmpInterface: CRITICAL!!! Error Cause: Version Mismatch on fd:[%d]",l_sock);
				break;
			default:
				UTIL_LOG('C',"SnmpInterface: CRITICAL!!! Error Cause: Unknown Reason on fd:[%d]",l_sock);
				break;
		}
		UTIL_LOG('C', "SnmpInterface: CRITICAL!!! Could not register with the SNMP Agent. Check Generic SNMP Agent Configuration file on fd:[%%d]", l_sock);
		sleep(2);
		return false;
	}

	responseValidation((char*)l_respBuff.c_str());
	*p_sock = l_sock;
	g_FirstTimeFlag=0;
	return true;
}

void *snmpInterfaceThrFunc(void*)
{
	UTIL_LOG('T',"SnmpInterface: start of snmpInterfaceThrFunc");
	bool l_connectStatus=false;

	while(1)
	{
		if(l_connectStatus == false)
		{
			char l_conn_res[1000];
			memset(l_conn_res, '\0', 1000);
			char l_err_msg[1000];
			memset(l_err_msg, '\0', 1000);
			l_connectStatus = connectToApp(g_snmpAgentIp, g_agentPort, &g_agentFd, l_conn_res, l_err_msg);
			if(false == l_connectStatus)
			{
				UTIL_LOG('W',"SnmpInterface: Unable to connect to the SNMP Agent [%s] at [%s:%s]", l_err_msg, g_snmpAgentIp, g_agentPort);
			}
			else
			{
				UTIL_LOG('T',"SnmpInterface: Connected to the SNMP Agent [%s:%s] on fd:[%d]. ConnRes[%s]", g_snmpAgentIp, g_agentPort, g_agentFd, l_conn_res);
			}
		}
		else
		{
			if(g_agentFd > 0)
			{
				fd_set read_mask;
				FD_ZERO(&read_mask);    
				FD_SET(g_agentFd, &read_mask);  
				struct timeval tv;
				tv.tv_sec = 0;          
				tv.tv_usec = 500000;
				//UTIL_LOG('D',"Checking to see if the connection is closed");
				int nfd = select(g_agentFd+1, &read_mask, (fd_set *)NULL, (fd_set *)NULL, (struct timeval *)&tv);/* will block */
				if (nfd > 0)
				{
					UTIL_LOG('T',"SnmpInterface: select breaked. assuming connection closed on fd:[%d]", g_agentFd);
					close(g_agentFd);
					g_agentFd=-1;
					l_connectStatus=false;
				}

			}
		}

		bool l_status = false;
		do
		{
			void *l_snmpRequest = NULL;
			l_status = g_snmpInputQueue->pop(&l_snmpRequest);
			if (true == l_status)
			{
				SnmpBufferData *l_bd = (SnmpBufferData *)l_snmpRequest;
				UTIL_LOG('D',"SnmpInterface: Got a SNMP Request");
				if(false == l_connectStatus)
				{
					UTIL_LOG('W',"SnmpInterface: No SNMP Agent Connection available. Ignoring the trap");
				}
				else
				{
					UTIL_LOG('T',"SnmpInterface: Connection available. Sending the trap to the agent on fd:[%d]", g_agentFd);
					if (l_status)
					{
						if(false == snmpSendDataToNetwork(g_agentFd, l_bd->m_data, l_bd->m_length))
						{
							UTIL_LOG('C',"SnmpInterface: Sending data to SNMP Agent failed on fd:[%d]", g_agentFd);
							close(g_agentFd);
							g_agentFd=0;
							l_connectStatus=false;
						}
					}
				}

				delete(l_bd);
			}
			else
			{
				//UTIL_LOG('D',"No SNMP Requests to process");
			}
		}
		while (l_status);

		sleep(SNMP_AGENT_RETRY_CONNECTION_TIMER);
	}
	return NULL;
}


bool SnmpInterface::initialize(char *p_selfEntityName, char *p_snmpAgentIp, int p_snmpAgentPort, LogOverride *p_lo, int p_productId, int p_instanceSeqId, char *p_productIdChar)
{
	if( (strlen(p_selfEntityName) < 3) || (strlen(p_selfEntityName) > 9))
	{
		printf("\nERRORSnmpInterface::initialize Entity Name should be between 3-9 digits");
		return false;
	}
	memset(g_selfEntityName, '\0', 10);
	strcpy(g_selfEntityName, p_selfEntityName);

	if (p_lo == NULL)
	{
		printf("\nERRORLog override object is null");
		return false;
	}
	g_lo = p_lo;
	UTIL_LOG('C',"Initializing with SNMP Client v%s", SNMP_CLIENT_VERSION);

	if( (p_snmpAgentPort < 1) || (p_snmpAgentPort > 9999))
	{
		printf("\nERRORSnmpInterface::initialize Agent Port should be between 1 and 9999");
		return false;
	}

	memset(g_agentPort, '\0', 10);
	sprintf(g_agentPort, "%d", p_snmpAgentPort);


	if( (strlen(p_snmpAgentIp) < 3) ||
			(strlen(p_snmpAgentIp) > 20)
		)
	{
		printf("\nERROR: SnmpInterface::initialize Invalid Agent IP: [%s]", p_snmpAgentIp);
		return false;
	}
	memset(g_snmpAgentIp, '\0', 20+1);
	strncpy(g_snmpAgentIp, p_snmpAgentIp, 20);

	if((p_productId < 1) || (p_productId > MAX_PRODUCT_ID))
	{
		printf("\nERROR: SnmpInterface::initialize Invalid Product ID: [%d]", p_productId);
		return false;
	}
	m_productId = p_productId;

	if((p_instanceSeqId < 1) || (p_instanceSeqId > MAX_INSTANCE_SEQ_ID))
	{
		printf("\nERROR: SnmpInterface::initialize Invalid Instance Sequence ID: [%d]", p_instanceSeqId);
		return false;
	}
	m_instanceSeqId = p_instanceSeqId;

	if((strlen(p_productIdChar) < 1) || (strlen(p_productIdChar) > 20))
	{
		printf("\nERROR: SnmpInterface::initialize Invalid ProductID Char: [%s]", p_productIdChar);
		return false;
	}
	snprintf(m_productIdChar, sizeof(p_productIdChar), "%s", p_productIdChar);

	g_snmpInputQueue = new SnmpMessageQueue(SNMP_QUEUE_TYPE_NON_BLOCKING);
	bool l_status = g_snmpInputQueue->initialize();
	if (!l_status)
	{
		printf("\nERRORERROR!! Unable to initialize the SNMP Input Queue");
		return false;
	}
	memset(g_ipAddress, '\0', 20);
	getIpAddress(g_ipAddress);   

	pthread_t l_thread = pthread_create(&l_thread, NULL, snmpInterfaceThrFunc, NULL);

	if (0 != pthread_mutex_init(&m_mutex, NULL))
	{
		printf("\nUnable to initialize the SnmpInterface mutex");
		return false;
	}


	sleep(1);
	m_initializedFlag=true;
	UTIL_LOG('D',"Snmp Interface initialized successfully");
	return true;
}

void SnmpInterface::printTraps()
{
	UTIL_LOG('D',"printTraps count %d", m_trapCount);
	for(int i=0; i<m_trapCount; i++)
	{
		UTIL_LOG('D',"SnmpInterface: PRINTING TRAPS: %d %s\n", i, m_trapDesc[i]);
	}
}

int SnmpInterface::registerSnmpTrap(char *p_trapID, char *p_trapText, int p_uniqueTrapSequenceId)
{
	if(false == m_initializedFlag)
	{
		UTIL_LOG('C',"SnmpInterface: SNMP Interface is not initialized. Ignoring the registration.");
		return false;
	}

	UTIL_LOG('D',"SnmpInterface::registerSnmpTrap");

	if(m_trapCount == MAX_TRAP_COUNT)
	{
		UTIL_LOG('E',"Cannot register more than %d traps", MAX_TRAP_COUNT);
		return -1;
	}

	if( (strlen(p_trapText) <1) || (strlen(p_trapText) > MAX_TRAP_DESC_SIZE))
	{
		UTIL_LOG('C',"SnmpInterface: Cannot register description should be between 1 and %d bytes", MAX_TRAP_DESC_SIZE);
		return -1;
	}

	if( (strlen(p_trapID) <1) || (strlen(p_trapID) > MAX_TRAP_ID_SIZE))
	{
		UTIL_LOG('C',"SnmpInterface: Cannot register description should be between 1 and %d bytes", MAX_TRAP_ID_SIZE);
		return -1;
	}

	if((p_uniqueTrapSequenceId < 1) || (p_uniqueTrapSequenceId > MAX_TRAP_SEQUENCE_ID))
	{
		UTIL_LOG('C',"SnmpInterface: Cannot uniqueTrapSequenceId should be between 1 and %d", MAX_TRAP_SEQUENCE_ID);
		return -1;
	}

	pthread_mutex_lock(&m_mutex);

	map<int,string>::iterator l_iter = m_uniqueTrapSequenceIdMap.find(p_uniqueTrapSequenceId);
	if(l_iter != m_uniqueTrapSequenceIdMap.end())
	{
		UTIL_LOG('C',"SnmpInterface: TrapSequenceId[%d] already registered with TrapID[%s]", p_uniqueTrapSequenceId, l_iter->second.c_str());
		pthread_mutex_unlock(&m_mutex);
		return -1;
	}
	else
	{
		m_uniqueTrapSequenceIdMap[p_uniqueTrapSequenceId] = p_trapID;
	}
	int l_index=m_trapCount;
	strcpy(m_trapDesc[m_trapCount], p_trapText);
	strcpy(m_trapId[m_trapCount], (p_trapID));
	m_uniqueTrapSequenceId[m_trapCount] = p_uniqueTrapSequenceId;
	m_trapCount++;
	//printTraps();
	UTIL_LOG('T',"registerSnmpTrap trap [Index:%d] [ID:%s] [%s] [UniqTrapSeqId:%d]", l_index, p_trapID, p_trapText, p_uniqueTrapSequenceId);
	pthread_mutex_unlock(&m_mutex);
	return l_index;
}

bool SnmpInterface::sendSnmpTrap(int p_trapEvent, ESnmpTrapType p_trapType, ESnmpTrapSeverity p_trapSeverity, char *p_trapAdditionalText)
{
	UTIL_LOG('D',"SnmpInterface::sendSnmpTrap");
	if(false == m_initializedFlag)
	{
		UTIL_LOG('C',"SnmpInterface: SNMP Interface is not initialized. Ignoring the TRAP inititated by the application");
		return false;
	}

	if(NULL != p_trapAdditionalText)
	{
		if( (strlen(p_trapAdditionalText) <1) || (strlen(p_trapAdditionalText) > MAX_TRAP_DESC_SIZE))
		{
			UTIL_LOG('C',"SnmpInterface: Cannot register additional description should be between 1 and %d bytes", MAX_TRAP_DESC_SIZE);
			pthread_mutex_unlock(&m_mutex);
			return false;
		}
	}

	if(TRAP_TYPE_UNKNOWN == p_trapType)
	{
		UTIL_LOG('E',"SnmpInterface: Trap Type is unknown");
		return false;
	}

	if( (p_trapEvent < 0) || (p_trapEvent > m_trapCount) )
	{
		UTIL_LOG('E', "SnmpInterface: Unregistered Trap");
		return false;
	}

	UTIL_LOG('L',"SnmpInterface: calling logstatistics for logging non-filtered data");

	if(NULL != g_sih)
	{
		if(LOG_STATISTICS_RETURN_CODE_NOT_INITIALIAZED == g_sih->logStatistics(m_trapStatsIndex[p_trapType][p_trapEvent]))
		{
			++m_InitialTrapStatsCounts[p_trapType][p_trapEvent];
		}
	}
	else
	{
		++m_InitialTrapStatsCounts[p_trapType][p_trapEvent];
	}


	//Adding Filtration of Traps
	pthread_mutex_lock(&m_mutex);

	SnmpTrapThreshold *l_stt=NULL;
	string l_currentTrap;
	l_currentTrap.assign(m_trapId[p_trapEvent], strlen(m_trapId[p_trapEvent]));

	map<string,SnmpTrapThreshold>::iterator l_trap_it;
	l_trap_it = g_SnmpThresholdMap.find(l_currentTrap);
	if(l_trap_it != g_SnmpThresholdMap.end())
	{
		int l_currentTime = time(NULL);

		l_stt = &l_trap_it->second;
		UTIL_LOG('T', "SnmpInterface: Trap [%s] Limitation is applicable to [%d]. Current Time [%d], Last Epoch [%d]", 
				(char*)l_currentTrap.c_str(), l_stt->m_maxInterval, l_currentTime, l_stt->m_lastResetEpoch);

		if(0 == l_stt->m_maxInterval)
		{
			UTIL_LOG('T', "SnmpInterface: Trap [%s] is totally stopped", (char*)l_currentTrap.c_str());
			l_stt->m_notSentCounter++;
			pthread_mutex_unlock(&m_mutex);
			return false;
		}

		switch (p_trapType)
		{
			case TRAP_TYPE_NORMAL:
				{
					UTIL_LOG('T', "SnmpInterface: Trap Type is normal");
					if(l_currentTime < (l_stt->m_lastResetEpoch+l_stt->m_maxInterval))
					{
						UTIL_LOG('T', "SnmpInterface: Stopping the Trap. Trap already sent in the time frame");
						l_stt->m_notSentCounter++;
						pthread_mutex_unlock(&m_mutex);
						return false;
					}
				}
				break;

			case TRAP_TYPE_PASS:
			case TRAP_TYPE_FAIL:
				{
					UTIL_LOG('T', "SnmpInterface: Trap Type is pass/fail");
					if (p_trapType != l_stt->m_lastTrapType)
					{
						l_stt->m_notSentCounter=0;
						UTIL_LOG('T', "SnmpInterface: Trap Type is different from old trap type. Allowing...");
					}
					else
					{
						if(l_currentTime < (l_stt->m_lastResetEpoch+l_stt->m_maxInterval))
						{
							UTIL_LOG('T',"SnmpInterface: Stopping the Trap. Trap already sent in the time frame");
							l_stt->m_notSentCounter++;
							pthread_mutex_unlock(&m_mutex);
							return false;
						}
					}
				}
				break;

			default:
				{
					UTIL_LOG('C',"SnmpInterface: Default Trap Type. Allowing the trap");
				}
				break;
		}
		l_stt->m_lastTrapType=p_trapType;
		l_stt->m_lastResetEpoch=l_currentTime;
	}
	else
	{
		UTIL_LOG('T', "SnmpInterface: Trap [%s] is not applicable for thresholds", (char*)l_currentTrap.c_str());
	}


	pthread_mutex_unlock(&m_mutex);
	//End of Filtration of Traps

	char l_arr[2000];
	memset(l_arr, '\0', sizeof(l_arr));
	char l_temp[500];
	memset(l_temp, '\0', sizeof(l_temp));

	//<TEXT>DB Connection</TEXT><TYPE>pass</TYPE><SEVERITY>critical</SEVERITY><TIME>20100501000000</TIME>

	strcpy(l_arr, "<REQUEST>");

	sprintf(l_temp, "<ORIG_EQUIP>");
	strcat(l_arr, l_temp);

	char l_entity[100];
	memset(l_entity, '\0', 100);
	sprintf(l_entity, "%s",g_selfEntityName);

	sprintf(l_temp, "%s", l_entity);
	strcat(l_arr, l_temp);

	sprintf(l_temp, "</ORIG_EQUIP>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "<ALARM_ID>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "%s", m_trapId[p_trapEvent]);
	strcat(l_arr, l_temp);

	sprintf(l_temp, "</ALARM_ID>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "<UNIQ_TRAP_SEQ_ID>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "%d", m_uniqueTrapSequenceId[p_trapEvent]);
	strcat(l_arr, l_temp);

	sprintf(l_temp, "</UNIQ_TRAP_SEQ_ID>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "<TEXT>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "%s", m_trapDesc[p_trapEvent]);
	strcat(l_arr, l_temp);

	if(NULL != p_trapAdditionalText)
	{
		sprintf(l_temp, " add.. %s", p_trapAdditionalText);
		strcat(l_arr, l_temp);
	}

	sprintf(l_temp, "</TEXT>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "<TYPE>");
	strcat(l_arr, l_temp);

	switch(p_trapType)
	{
		case TRAP_TYPE_PASS:
			sprintf(l_temp, "pass");
			break;
		case TRAP_TYPE_FAIL:
			sprintf(l_temp, "fail");
			break;
		case TRAP_TYPE_NORMAL:
			sprintf(l_temp, "normal");
			break;
		default:
			sprintf(l_temp, "unknown");
			break;
	}
	strcat(l_arr, l_temp);

	sprintf(l_temp, "</TYPE>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "<SEVERITY>");
	strcat(l_arr, l_temp);

	switch(p_trapSeverity)
	{
		case TRAP_SEVERITY_CRITICAL:
			sprintf(l_temp, "critical");
			break;
		case TRAP_SEVERITY_MAJOR:
			sprintf(l_temp, "major");
			break;
		case TRAP_SEVERITY_MINOR:
			sprintf(l_temp, "minor");
			break;
		case TRAP_SEVERITY_WARNING:
			sprintf(l_temp, "warning");
			break;
		default:
			sprintf(l_temp, "unknown");
			break;
	}
	strcat(l_arr, l_temp);

	sprintf(l_temp, "</SEVERITY>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "<DATETIME>");
	strcat(l_arr, l_temp);

	char * dateString=NULL;
	struct tm *tm_ptr=NULL;
	time_t l_tim =time(NULL);
	tm_ptr = localtime(&l_tim);
	dateString = asctime(tm_ptr);
	dateString[24] = 0;
	strcat(l_arr, dateString);

	sprintf(l_temp, "</DATETIME>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "<IP_ADDRESS>");
	strcat(l_arr, l_temp);

	strcat(l_arr, g_ipAddress);

	sprintf(l_temp, "</IP_ADDRESS>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "<THRESHOLD_INFO>");
	strcat(l_arr, l_temp);

	if(l_stt != NULL)
	{
		if(l_stt->m_notSentCounter > 0)
		{
			sprintf(l_temp, "Stopped %d traps.", l_stt->m_notSentCounter);
		}
		else
		{
			sprintf(l_temp, "Not stopped any traps.", l_stt->m_notSentCounter);
		}
		l_stt->m_notSentCounter=0;
	}
	else
	{
		sprintf(l_temp, "Not Applicable");
	}
	strcat(l_arr, l_temp);

	sprintf(l_temp, "</THRESHOLD_INFO>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "<SERVER_DATA>");
	strcat(l_arr, l_temp);
	strcat(l_arr, m_serverData.c_str());
	sprintf(l_temp, "</SERVER_DATA>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "<INST_SPEC_DATA>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "<UNIQUE_INSTANCE_ID>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "%d", m_instanceSeqId);
	strcat(l_arr, l_temp);

	sprintf(l_temp, "</UNIQUE_INSTANCE_ID>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "<PRODUCT_ID>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "%d", m_productId);
	strcat(l_arr, l_temp);

	sprintf(l_temp, "</PRODUCT_ID>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "</INST_SPEC_DATA>");
	strcat(l_arr, l_temp);

	sprintf(l_temp, "</REQUEST>");
	strcat(l_arr, l_temp);

	UTIL_LOG('D',"SnmpInterface: SNMP Trap string [%d] [%s] ", strlen(l_arr), l_arr);

	SnmpBufferData *l_bd = new SnmpBufferData;
	l_bd->m_data = new unsigned char[strlen(l_arr)+1];
	memset(l_bd->m_data, '\0', strlen(l_arr)+1);
	strcpy((char*)l_bd->m_data, l_arr);
	l_bd->m_length = strlen(l_arr);



	UTIL_LOG('L',"SnmpInterface: calling logstatistics for logging filtered data");
	if(NULL != g_sih)
	{
		if(LOG_STATISTICS_RETURN_CODE_NOT_INITIALIAZED == g_sih->logStatistics(m_trapStatsFilteredIndex[p_trapType][p_trapEvent]))
		{
			++m_InitialTrapStatsFilteredCounts[p_trapType][p_trapEvent];
		}
	}
	else
	{
		++m_InitialTrapStatsFilteredCounts[p_trapType][p_trapEvent];
	}


	g_snmpInputQueue->push(l_bd);

	return true;
}

#ifdef Linux

void strlcat(char* p_desc, char*p_src, int p_size)
{
	snprintf(p_desc, p_size, "%s%s", p_desc, p_src);
}

#endif

