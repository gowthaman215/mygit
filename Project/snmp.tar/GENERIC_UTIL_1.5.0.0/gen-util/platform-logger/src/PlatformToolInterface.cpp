#include <PlatformToolInterface.h>
#include <SnmpInterface.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <strings.h>

map<string, int> g_TraceImsiMap;
map<string, int> g_TraceMsisdnMap;
bool initializeserver();
bool g_sameUser=false;

#define INVALID_USER_STRING  "WARNING!! You are not allowed to execute this command"

void *toolThrFunc(void*)
{
   if (false == initializeserver())
   {
      printf("\nUnable to initialize the Tool Interface Server");
      sleep(2);
      exit(1);
   }
   printf("\nend of toolThrFunc\n");
   return NULL;
}

PlatformToolInterface::PlatformToolInterface()
{
}

PlatformToolInterface::~PlatformToolInterface()
{
}

bool PlatformToolInterface::initialize(int p_port)
{
   if ( (p_port <= 1024) ||
         (p_port > 99999) )
   {
      printf("\nInvalid Port %d", p_port);
      return false;
   }

   memset(g_port, '\0', 10);
   sprintf(g_port, "%d", p_port);

   g_commandQueue = new MessageQueue(QUEUE_TYPE_NON_BLOCKING, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);
   bool l_status = g_commandQueue->initialize();
   if (!l_status)
   {
      printf("\nERROR!! Unable to initialize the Command Queue");
      return false;
   }

   g_commandResponseQueue = new MessageQueue(QUEUE_TYPE_NON_BLOCKING, QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT);
   l_status = g_commandResponseQueue->initialize();
   if (!l_status)
   {
      printf("\nERROR!! Unable to initialize the Command Response Queue");
      return false;
   }

   pthread_t l_thread = pthread_create(&l_thread, NULL, toolThrFunc, NULL);

   return true;
}

// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
   if (sa->sa_family == AF_INET) {
      return &(((struct sockaddr_in*)sa)->sin_addr);
   }

   return &(((struct sockaddr_in6*)sa)->sin6_addr);
}



int RecvAll(int &s, char *buf, unsigned long len);
bool sendData(unsigned char *p_data, int p_length);
bool sendDataToNetwork(unsigned char *p_data, int p_length);

int g_clientDesc=0;
bool g_clientRegDoneFlag=false;


void getResourcesData(char *p_output)
{
   char l_sc[1000];
   memset(l_sc, '\0', sizeof(l_sc));
   char l_db[1000];
   memset(l_db, '\0', sizeof(l_db));
   char l_tm[1000];
   memset(l_tm, '\0', sizeof(l_tm));
   char l_prov[1000];
   memset(l_prov, '\0', sizeof(l_prov));

   g_ContextMangerObject.getStats(l_sc);
   g_act.getStats(l_db);
   g_tm.getStats(l_tm);
   g_tss.getStats(l_prov);
   int l_imd_q_size=0;
   if(NULL != g_InterModuleQueue)
   {
      l_imd_q_size = g_InterModuleQueue->size();
   }
   int l_sim_q=0;
   if (NULL != g_SimulatorCtxtQueue)
   {
      l_sim_q = g_SimulatorCtxtQueue->size();
   }

   TLOG(0,1,"Active Context Map Size: %d", g_activeContextMap.size());

   char l_ctxtData[5000];
   memset(l_ctxtData, '\0', sizeof(l_ctxtData));
   sprintf(l_ctxtData, " %-45s%15s\t%15s\n\n", "Context", "Received", "In Progress");

   for (g_activeContextMapIterator=g_activeContextMap.begin(); 
         g_activeContextMapIterator!=g_activeContextMap.end();
         g_activeContextMapIterator++)
   {
      TLOG(0,1,"Ctxt: %s %d", g_activeContextMapIterator->first.c_str(), g_activeContextMapIterator->second->m_count);
      char l_currentCtxt[1000];
      memset(l_currentCtxt, '\0', sizeof(l_currentCtxt));
      sprintf(l_currentCtxt, " %-45s%15ld\t%15d\n", 
               g_activeContextMapIterator->first.c_str(),
               g_activeContextMapIterator->second->m_totalReceivedCount, 
               g_activeContextMapIterator->second->m_count);
      strlcat(l_ctxtData, l_currentCtxt, 5000);

      map<int,int>::iterator l_itr;
      for (l_itr=g_activeContextMapIterator->second->m_activeContextList.begin(); 
           l_itr!=g_activeContextMapIterator->second->m_activeContextList.end(); 
           l_itr++)
      {
         TLOG(0,0,"%s Context ID: %08d", g_activeContextMapIterator->first.c_str(), l_itr->first);             
      }
   }

   char l_currentCtxt[1000];
   memset(l_currentCtxt, '\0', sizeof(l_currentCtxt));
   sprintf(l_currentCtxt, "\n %45s%15ld\t%15d\n", 
            "Total",
            g_TotalContexts, 
            g_SlActiveContexts);
   strlcat(l_ctxtData, l_currentCtxt, 5000);


   TLOG(0,1,"Out of for loop");

   sprintf(p_output, "\n\t\t\tRESOURCE UTILIZATION REPORT\n\n%s\n\n%s\n\n Inter Module Data Queue Size\t\t\t: %d\n Simulation Contexts Queue Size\t\t\t: %d\n%s\n%s\n OAM Pending Transactions Queue Size\t\t: %d\n\n%s\n", 
         l_sc, 
         l_db,
         l_imd_q_size,
         l_sim_q,
         l_tm,
         l_prov,
         g_OamTransactionsList->size(),
         l_ctxtData);
   TLOG(0,1,"end of getResources data");
}



bool processCommand(char *p_command)
{
   DLOG(0,1,"MMI Tool Called processCommand for command [%s]", p_command);
   char l_responseToBeSent[4000];
   memset(l_responseToBeSent, '\0', sizeof(l_responseToBeSent));
   strcpy(l_responseToBeSent, "Unable to process the command");


   char l_argv[100][40];

   int l_argc=0; 
   //char **l_argv;
   char * pch;
   pch = strtok (p_command," ");
   while (pch != NULL)
   {
      memset(l_argv[l_argc], '\0', 40);
      strncpy(l_argv[l_argc], pch, 39);
      l_argc++;
      pch = strtok (NULL, " ");
   }

   /*int i=0;
     for (i=0; i<l_argc; i++)
     {
     printf("\n printing -%s-", l_argv[i]);
     }*/

   char l_imsi[20+1];
   memset(l_imsi, '\0', 20+1);
   char l_msisdn[20+1];
   memset(l_msisdn, '\0', 20+1);


   char l_commandType = ' ';
   char l_commandSubType = ' ';
   char l_TraceType = ' ';
   char l_logLevel[20+1];
   memset(l_logLevel, '\0', 20+1);

   char l_opCode[3+1];
   memset(l_opCode, '\0', 3+1);
   char l_opVersion[3+1];
   memset(l_opVersion, '\0', 3+1);


   for (int i = 0; i < l_argc; i++)
   {
      if (strcmp (l_argv[i], "-i") == 0)
      {
         memset(l_imsi, '\0', 20+1);
         strcpy (l_imsi, l_argv[++i]);
      }
      if (strcmp (l_argv[i], "-l") == 0)
      {
         memset(l_logLevel, '\0', 20+1);
         strcpy (l_logLevel, l_argv[++i]);
      }
      if (strcmp (l_argv[i], "-m") == 0)
      {
         memset(l_logLevel, '\0', 20+1);
         strcpy (l_logLevel, l_argv[++i]);
         strcpy (l_msisdn, l_logLevel);
      }
      if (strcmp (l_argv[i], "-v") == 0)
      {
         memset(l_opCode, '\0', 3+1);
         strncpy (l_opCode, l_argv[++i], 3);
      }
      if (strcmp (l_argv[i], "-s") == 0)
      {
         memset(l_opVersion, '\0', 3+1);
         strncpy (l_opVersion, l_argv[++i], 3);
      }
      if (strcmp (l_argv[i], "trace") == 0)
      {
         l_commandType = 'T';
      }
      if (strcmp (l_argv[i], "shutdown") == 0)
      {
         l_commandType = 'E';
      }
      if (strcmp (l_argv[i], "modifyconf") == 0)
      {
         l_commandType = 'M';
      }
      if (strcmp (l_argv[i], "reload") == 0)
      {
         l_commandType = 'R';
      }
      if (strcmp (l_argv[i], "profiles") == 0)
      {
         l_commandSubType = 'P';
      }
      if (strcmp (l_argv[i], "configurations") == 0)
      {
         l_commandSubType = 'C';
      }
      if (strcmp (l_argv[i], "oamtransactions") == 0)
      {
         l_commandSubType = 'O';
      }
      if (strcmp (l_argv[i], "changelog") == 0)
      {
         l_commandSubType = 'L';
      }
      if (strcmp (l_argv[i], "changeopcode") == 0)
      {
         l_commandSubType = 'O';
      }
      if (strcmp (l_argv[i], "stats") == 0)
      {
         l_commandType = 'S';
      }
      if (strcmp (l_argv[i], "getinfo") == 0)
      {
         l_commandType = 'I';
      }
      if (strcmp (l_argv[i], "getmoduleinfo") == 0)
      {
         l_commandType = 'G';
      }
      if (strcmp (l_argv[i], "resources") == 0)
      {
         l_commandType = 'Z';
      }
      if (strcmp (l_argv[i], "start") == 0)
      {
         l_TraceType = 'B';
      }
      if (strcmp (l_argv[i], "stop") == 0)
      {
         l_TraceType = 'E';
      }
   }

   /*for (int i = 0; i < l_argc; i++)
     {
     free(l_argv[l_argc]);
     }
     free(l_argv);*/

   if ('T' == l_commandType)
   {
      if(false == g_sameUser)
      {
         sprintf(l_responseToBeSent, "%s", INVALID_USER_STRING);
      }
      else if (g_ConfigData->m_TracingEnabledFlag == 1)
      {
         if ('B' == l_TraceType)
         {
            if (strlen(l_imsi) > 1)
            {
               map<string, int>::iterator l_it;
               l_it = g_TraceImsiMap.find(l_imsi);
               if (l_it != g_TraceImsiMap.end())// matches the list of IMSIs
               {
                  printf("\nIMSI %s was added earlier itself", l_imsi);
                  sprintf(l_responseToBeSent, "IMSI %s was added earlier itself", l_imsi);
               }
               else
               {
                  g_TraceImsiMap[l_imsi] = 1;
                  printf("\nSuccessfully started tracing for imsi %s", l_imsi);
                  sprintf(l_responseToBeSent, "Successfully started tracing for imsi %s", l_imsi);
               }

               /*
                  int l_size = g_TraceImsiMap.size(); // storing size of map before inserting
                  g_TraceImsiMap[l_imsi] = 1;

                  if (g_TraceImsiMap.size() > l_size)
                  {
                  printf("\nSuccessfully started tracing for imsi %s", l_imsi);
                  sprintf(l_responseToBeSent, "Successfully started tracing for imsi %s", l_imsi);
                  }
                  else
                  {
                  printf("\nIMSI %s was added earlier itself", l_imsi);
                  sprintf(l_responseToBeSent, "IMSI %s was added earlier itself", l_imsi);
                  }*/
            }
            else if (strlen(l_msisdn) > 1)
            {
               map<string, int>::iterator l_it;
               l_it = g_TraceMsisdnMap.find(l_msisdn);
               if (l_it != g_TraceMsisdnMap.end())// matches the list of MSISDNs
               {
                  printf("\nMSISDN %s was added earlier itself", l_msisdn);
                  sprintf(l_responseToBeSent, "MSISDN %s was added earlier itself", l_msisdn);
               }
               else
               {
                  g_TraceMsisdnMap[l_msisdn] = 1;
                  printf("\nSuccessfully started tracing for msisdn %s", l_msisdn);
                  sprintf(l_responseToBeSent, "Successfully started tracing for msisdn %s", l_msisdn);
               }
               /*
                  int l_size = g_TraceMsisdnMap.size(); // storing size of map before inserting
                  g_TraceMsisdnMap[l_msisdn] = 1;

                  if (g_TraceMsisdnMap.size() > l_size)
                  {
                  printf("\nSuccessfully started tracing for msisdn %s", l_msisdn);
                  sprintf(l_responseToBeSent, "Successfully started tracing for msisdn %s", l_msisdn);
                  }
                  else
                  {
                  printf("\nMSISDN %s was added earlier itself", l_msisdn);
                  sprintf(l_responseToBeSent, "MSISDN %s was added earlier itself", l_msisdn);
                  }*/
            }
            else
            {
               printf("\nIMSI nor MSISDN present. Command not processed");
               sprintf(l_responseToBeSent, "IMSI nor MSISDN present. Command not processed");
            }
         }
         else
         {
            if (strlen(l_imsi) > 1)
            {
               if (g_TraceImsiMap.erase(l_imsi))
               {
                  printf("\nSuccessfully stopped tracing for imsi %s", l_imsi);
                  sprintf(l_responseToBeSent, "Successfully stopped tracing for imsi %s", l_imsi);
               }
               else
               {
                  printf("\nThe imsi %s was not traced earlier", l_imsi);
                  sprintf(l_responseToBeSent, "The imsi %s was not traced earlier", l_imsi);
               }
            }
            else if (strlen(l_msisdn) > 1)
            {
               if (g_TraceMsisdnMap.erase(l_msisdn))
               {
                  printf("\nSuccessfully stopped tracing for msisdn %s", l_msisdn);
                  sprintf(l_responseToBeSent, "Successfully stopped tracing for msisdn %s", l_msisdn);
               }
               else
               {
                  printf("\nThe msisdn %s was not traced earlier", l_msisdn);
                  sprintf(l_responseToBeSent, "The msisdn %s was not traced earlier", l_msisdn);
               }
            }
            else
            {
               sprintf(l_responseToBeSent, "IMSI nor MSISDN present. Command not processed");
            }
         }
      }
      else
      {
         sprintf(l_responseToBeSent, "Sorry! This feature is not enabled in this application");
      }
      //printf("\n Map Size %d", g_TraceImsiMap.size());
   }
   else if ('E' == l_commandType)
   {
      if(false == g_sameUser)
      {
         sprintf(l_responseToBeSent, "%s", INVALID_USER_STRING);
      }
      else
      {
         strcpy(l_responseToBeSent, "Graceful shutdown is yet to be implemented. Closing the application forcefully...");
         printf("\n\nReceived shutdown command from the MMI Tool. Closing the application.\n\n");
         CLOG(0,1,"Received shutdown command from the MMI Tool. Getting closed");
         g_si.sendSnmpTrap(g_GracefullShutdownTrap, TRAP_TYPE_NORMAL, TRAP_SEVERITY_MAJOR);
         sleep(2);
         exit(1);
      }
   }
   else if ('I' == l_commandType)
   {
      char *l_temp = g_cr->getConfigPrint();
      strcpy(l_responseToBeSent, l_temp);
      delete[] l_temp;
   }
   else if ('G' == l_commandType)
   {
      //printf("\ncalling getModulesPrint func\n");
      char *l_temp = NULL;
      g_cr->getModulesPrint(&l_temp);
      strcpy(l_responseToBeSent, l_temp);

      char l_prof[500];
      memset(l_prof, '\0', sizeof(l_prof));
      g_spd->getStats(l_prof);
      strcat(l_responseToBeSent, l_prof);

      delete[] l_temp;
   }
   else if ('M' == l_commandType)
   {
      if(false == g_sameUser)
      {
         sprintf(l_responseToBeSent, "%s", INVALID_USER_STRING);
      }
      else if (l_commandSubType == 'O')
      {
         if ( (strlen(l_opCode) > 0) && (strlen(l_opVersion) > 0) )
         {
            int l_op = atoi(l_opCode);
            if ( (l_op > 0) && (l_op <= 90) )
            {
               if (g_mm.m_mapping[l_op].m_OpCode > 0)
               {
                  bool l_versionCheck=true;
                  char l_versionCheckChar[200];
                  memset(l_versionCheckChar, '\0', 200);
                  sprintf(l_versionCheckChar, ": not supported for MAP ");

                  if( ('1'==l_opVersion[0]) &&
                        (MapConstants::getMapOpCodeArgPDU( ((EMapOpCode)l_op), MAP_V1 ) == 0)
                    )
                  {
                     l_versionCheck=false;
                     strlcat(l_versionCheckChar, "v1, ", 200);

                  }
                  if( ('1'==l_opVersion[1]) &&
                        (MapConstants::getMapOpCodeArgPDU( ((EMapOpCode)l_op), MAP_V2 ) == 0)
                    )
                  {
                     l_versionCheck=false;
                     strlcat(l_versionCheckChar, "v2, ", 200);
                  }
                  if( ('1'==l_opVersion[2]) &&
                        (MapConstants::getMapOpCodeArgPDU( ((EMapOpCode)l_op), MAP_V3 ) == 0)
                    )
                  {
                     l_versionCheck=false;
                     strlcat(l_versionCheckChar, "v3, ", 200);
                  }

                  if (true == l_versionCheck)
                  {
                     g_mm.m_mapping[l_op].m_Map1Flag = ('1'==l_opVersion[0])?true:false;
                     g_mm.m_mapping[l_op].m_Map2Flag = ('1'==l_opVersion[1])?true:false;
                     g_mm.m_mapping[l_op].m_Map3Flag = ('1'==l_opVersion[2])?true:false;
                     sprintf(l_responseToBeSent, "Successfully Modified the versions accordingly");
                  }
                  else
                  {
                     sprintf(l_responseToBeSent, "Op Code %d %s", l_op, l_versionCheckChar);
                  }
               }
               else
               {
                  sprintf(l_responseToBeSent, "Op Code %d is not defined in the system", l_op);
               }
            }
            else
            {
               sprintf(l_responseToBeSent, "Invalid op code %d", l_op);
            }
         }
         else
         {
            strcpy(l_responseToBeSent, "Invalid changeopcode command");
         }
      }
      else if (l_commandSubType == 'L')
      {
         if (0 == strcmp(l_logLevel, "DEBUG"))
         {
            if (g_ConfigData->m_LogLevel != LOG_LEVEL_DEBUG)
            {
               g_ConfigData->m_LogLevel = LOG_LEVEL_DEBUG;
               g_LoggerObj.setLogLevel(LOG_LEVEL_DEBUG);
               strcpy(l_responseToBeSent, "Log Level changed to DEBUG");
            }
            else
            {
               strcpy(l_responseToBeSent, "Log Level was already DEBUG");
            }
         }
         else if (0 == strcmp(l_logLevel, "TRACE"))
         {
            if (g_ConfigData->m_LogLevel != LOG_LEVEL_TRACE)
            {
               g_ConfigData->m_LogLevel = LOG_LEVEL_TRACE;
               g_LoggerObj.setLogLevel(LOG_LEVEL_TRACE);
               strcpy(l_responseToBeSent, "Log Level changed to TRACE");
            }
            else
            {
               strcpy(l_responseToBeSent, "Log Level was already TRACE");
            }
         }
         else if (0 == strcmp(l_logLevel, "WARNING"))
         {
            if (g_ConfigData->m_LogLevel != LOG_LEVEL_WARNING)
            {
               g_ConfigData->m_LogLevel = LOG_LEVEL_WARNING;
               g_LoggerObj.setLogLevel(LOG_LEVEL_WARNING);
               strcpy(l_responseToBeSent, "Log Level changed to WARNING");
            }
            else
            {
               strcpy(l_responseToBeSent, "Log Level was already WARNING");
            }
         }
         else if (0 == strcmp(l_logLevel, "CRITICAL"))
         {
            if (g_ConfigData->m_LogLevel != LOG_LEVEL_CRITICAL)
            {
               g_ConfigData->m_LogLevel = LOG_LEVEL_CRITICAL;
               g_LoggerObj.setLogLevel(LOG_LEVEL_CRITICAL);
               strcpy(l_responseToBeSent, "Log Level changed to CRITICAL");
            }
            else
            {
               strcpy(l_responseToBeSent, "Log Level was already CRITICAL");
            }
         }
         else if (0 == strcmp(l_logLevel, "ERROR"))
         {
            if (g_ConfigData->m_LogLevel != LOG_LEVEL_ERROR)
            {
               g_ConfigData->m_LogLevel = LOG_LEVEL_ERROR;
               g_LoggerObj.setLogLevel(LOG_LEVEL_ERROR);
               strcpy(l_responseToBeSent, "Log Level changed to ERROR");
            }
            else
            {
               strcpy(l_responseToBeSent, "Log Level was already ERROR");
            }
         }
         else if (0 == strcmp(l_logLevel, "FILE"))
         {
            if (g_ConfigData->m_LogMedia != LOG_MEDIA_FILE)
            {
               g_ConfigData->m_LogMedia = LOG_MEDIA_FILE;
               g_LoggerObj.setLogMedia(LOG_MEDIA_FILE);
               strcpy(l_responseToBeSent, "Log Media changed to FILE");
            }
            else
            {
               strcpy(l_responseToBeSent, "Log Media was already FILE");
            }
         }
         else if (0 == strcmp(l_logLevel, "CONSOLE"))
         {
            if (g_ConfigData->m_LogMedia != LOG_MEDIA_CONSOLE)
            {
               g_ConfigData->m_LogMedia = LOG_MEDIA_CONSOLE;
               g_LoggerObj.setLogMedia(LOG_MEDIA_CONSOLE);
               strcpy(l_responseToBeSent, "Log Media changed to CONSOLE");
            }
            else
            {
               strcpy(l_responseToBeSent, "Log Media was already CONSOLE");
            }
         }
         else
         {
            sprintf(l_responseToBeSent, "Unknown %s", l_logLevel);
         }
      }
      else
      {
         strcpy(l_responseToBeSent, "Unexpected modifyconf received");
      }
   }
   else if ('S' == l_commandType)
   {
      sprintf(l_responseToBeSent, "Stats command in progress... Please wait %d", StatisticsManager::instance()->getTotalStatsSize());

      return sendData((unsigned char *)StatisticsManager::instance()->getCurrentStatsPtr(), sizeof(Stats));
      //return sendData((unsigned char *)StatisticsManager::instance()->getStartStatsPtr(), sizeof(Stats));
   }
   else if ('R' == l_commandType)
   {
      if ('P' == l_commandSubType)
      {
         if(false == g_sameUser)
         {
            sprintf(l_responseToBeSent, "%s", INVALID_USER_STRING);
         }
         else
         {
            g_sc.initiateIndependentContext(NULL, MAP_OP_CODE_MAXIMUM, "", INITIATION_TYPE_IMMEDIATE);
            sprintf(l_responseToBeSent, "Reloading of profiles initiated");
         }
      }
      else if ('C' == l_commandSubType)
      {
         reloadConfigurations(l_responseToBeSent);
      }
      else if ('O' == l_commandSubType)
      {
         g_sc.initiateIndependentContext(NULL, MAP_OP_CODE_dummy_1, "RELOAD", INITIATION_TYPE_IMMEDIATE);
         sprintf(l_responseToBeSent, "Reloading of pending OAM Transactions initiated");
      }
      else
      {
         sprintf(l_responseToBeSent, "Unknown reload command. Not Processed");
      }
   }
   else if ('Z' == l_commandType)
   {
      getResourcesData(l_responseToBeSent);
   }
   else
   {
      sprintf(l_responseToBeSent, "Unknown command. Not Processed");
   }

   TLOG(1,1,"MMI Tool: Sending response : [%s]", l_responseToBeSent);

   return sendData((unsigned char *)l_responseToBeSent, strlen(l_responseToBeSent));
}



bool sendData(unsigned char *p_data, int p_length)
{
   BufferData *l_bd = new BufferData;

   if ( (p_length < 1) ||
         (NULL == p_data)
      )
   {
      CLOG(0,1,"sendData called some error");
      l_bd->m_data = new unsigned char[20];
      memset(l_bd->m_data, '\0', 20);
      strcpy((char*)l_bd->m_data, "Some Error");
      l_bd->m_length = strlen((char*)l_bd->m_data);
   }
   else
   {
      DLOG(0,1,"sendData called normal [%d]", p_length);
      l_bd->m_data = new unsigned char[p_length];
      memset(l_bd->m_data, '\0', p_length);
      memcpy(l_bd->m_data, p_data, p_length);
      l_bd->m_length = p_length;

   }

   g_commandResponseQueue->push(l_bd);
   DLOG(0,1,"sendData end");
   return true;
}


bool sendDataToNetwork(unsigned char *p_data, int p_length)
{
   DLOG(0,1,"sendDataToNetwork called");
   unsigned char *l_data = (unsigned char *)"Some Error";
   int l_length=strlen((char*)l_data);

   if (NULL != p_data)
   {
      l_data = p_data;
      l_length = p_length;
   }

   if (0 == l_length)
   {
      ELOG(0,1,"sendDataToNetwork failed. Invalid length");
      return false;
   }
   if (g_clientDesc != 0)
   {
      char l_lengthChar[10];
      memset(l_lengthChar, '\0', 10);
      sprintf(l_lengthChar, "%09d", l_length);

      TLOG(0,1,"MMI Tool Sending Length [%s]", l_lengthChar);

      if (send(g_clientDesc, l_lengthChar, 9, 0) == -1) 
      {
         perror("send");
         return false;
      }

      if (send(g_clientDesc, l_data, l_length, 0) == -1) 
      {
         perror("send");
         return false;
      }
      DLOG(0,1,"MMI Tool Sending data successfull\n");      
   }
   else
   {
      CLOG(0,1,"No Client Desc present");
   }
   return true;
}

struct reg_msg
{
   uid_t  m_uid;
   time_t m_time;
};


bool initializeserver()
{
   DLOG(0,1,"Initializing the Tool Interface server socket");
   fd_set master;    // master file descriptor list
   fd_set read_fds;  // temp file descriptor list for select()
   int fdmax;        // maximum file descriptor number

   int listener;     // listening socket descriptor
   int newfd;        // newly accept()ed socket descriptor
   struct sockaddr_storage remoteaddr; // client address
   socklen_t addrlen;

   char buf[256];    // buffer for client data
   char buf_length[256];    // buffer for client data
   int nbytes;

   char remoteIP[INET6_ADDRSTRLEN];

   int yes=1;        // for setsockopt() SO_REUSEADDR, below
   int i, rv;

   struct addrinfo hints, *ai, *p;



   FD_ZERO(&master);    // clear the master and temp sets
   FD_ZERO(&read_fds);

   DLOG(0,1,"Calling getaddrinfo");

   // get us a socket and bind it
   memset(&hints, 0, sizeof hints);
   hints.ai_family = AF_UNSPEC;
   hints.ai_socktype = SOCK_STREAM;
   hints.ai_flags = AI_PASSIVE;
   if ((rv = getaddrinfo(NULL, g_port, &hints, &ai)) != 0) {
      fprintf(stderr, "selectserver: %s\n", gai_strerror(rv));
      ELOG(0,1,"selectserver: %s", gai_strerror(rv));
      return false;
   }

   for(p = ai; p != NULL; p = p->ai_next) 
   {
      DLOG(0,1,"Creating socket");
      listener = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
      if (listener < 0) 
      { 
         continue;
      }

      // lose the pesky "address already in use" error message
      setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));

      if (bind(listener, p->ai_addr, p->ai_addrlen) < 0) 
      {
         close(listener);
         ELOG(0,1,"MMI TOOL Interface: Unable to bind on port %s", g_port);
         return false;
      }

      break;
   }

   // if we got here, it means we didn't get bound
   if (p == NULL) {
      ELOG(0,1,"MMI TOOL Interface: Unable to bind on port %s", g_port);
      return false;
   }

   freeaddrinfo(ai); // all done with this

   // listen
   if (listen(listener, 10) == -1) {
      perror("listen");
      ELOG(0,1,"listen failed");
      return false;
   }

   CLOG(0,1,"Ready to accept commands from the MMI Tool");

   // add the listener to the master set
   FD_SET(listener, &master);

   // keep track of the biggest file descriptor
   fdmax = listener; // so far, it's this one

   // main loop
   for(;;) {
      read_fds = master; // copy it
      struct timeval tv;
      tv.tv_sec = 0;
      tv.tv_usec = 500000;
      if(1 == g_OtherConfigData->m_PrintTimerInLog)
      {
         DLOG(0,1,"MMI Tool calling select");
      }
      if (select(fdmax+1, &read_fds, NULL, NULL, &tv) == -1) {
         //perror("select");
         sleep(1);
         continue;
      }

      if (g_commandResponseQueue != NULL)
      {
         void *l_pop = NULL;
         bool l_status = g_commandResponseQueue->pop(&l_pop);
         if (l_status)
         {
            BufferData *l_bd = (BufferData *)l_pop;
            TLOG(0,1,"Got a response to be sent %d", l_bd->m_length);
            sendDataToNetwork(l_bd->m_data, l_bd->m_length);
            delete(l_bd);
         }
      }

      // run through the existing connections looking for data to read
      for(i = 0; i <= fdmax; i++) {
         if (FD_ISSET(i, &read_fds)) { // we got one!!
            if (i == listener) {
               // handle new connections
               addrlen = sizeof remoteaddr;
               newfd = accept(listener,
                     (struct sockaddr *)&remoteaddr,
                     &addrlen);


               if (newfd == -1) {
                  perror("accept");
               } else {

                  //printf("\ng_clientDesc %d", g_clientDesc);
                  if (g_clientDesc != 0)
                  {
                     close(g_clientDesc);
                     FD_CLR(g_clientDesc, &master); // remove from master set
                     g_clientDesc=0;
                  }

                  g_clientDesc = newfd;
                  g_clientRegDoneFlag = false;

                  FD_SET(newfd, &master); // add to master set
                  if (newfd > fdmax) {    // keep track of the max
                     fdmax = newfd;
                  }
                  CLOG(0,1,"New connection from %s on socket %d\n",
                        inet_ntop(remoteaddr.ss_family, get_in_addr((struct sockaddr*)&remoteaddr), remoteIP, INET6_ADDRSTRLEN),
                        newfd);
               }
            } else {
               // handle data from a client
               memset(buf_length, '\0', 256);
               if ((nbytes = RecvAll(i, buf_length, 9)) <= 0) {
                  // got error or connection closed by client
                  if (nbytes == 0) {
                     // connection closed
                     CLOG(0,1,"MMI Tool disconnected (socket-fd %d)", i);
                  } else {
                     perror("recv");
                  }
                  close(i); // bye!
                  g_clientDesc=0;
                  FD_CLR(i, &master); // remove from master set
               } else {

                  //printf("\nTool recv len [%s]", buf_length);
                  DLOG(0,1,"Tool recv len [%s]", buf_length);

                  memset(buf, '\0', 256);
                  nbytes = RecvAll(i, buf, atoi(buf_length));
                  if (nbytes != atoi(buf_length))
                  {
                     //printf("\nCould not receive all %d bytes", atoi(buf_length));
                     CLOG(0,1,"MMI Tool disconnected (socket-fd %d)", i);
                     close(g_clientDesc);
                     FD_CLR(g_clientDesc, &master); // remove from master set
                     g_clientDesc=0;
                  }
                  else
                  {
                     if(false == g_clientRegDoneFlag)
                     {
                        DLOG(0,1,"Received buf [%s]", buf);

                        char l_temp_buf[256];
                        memset(l_temp_buf, '\0', sizeof(l_temp_buf));
                        strcpy(l_temp_buf, buf);

                        // Parse the Registration message
                        char l_received_time[10];
                        char l_received_uid[10];
                        char *l_colon = NULL;

                        l_colon = strchr(l_temp_buf, ':');
                        if(l_colon != NULL)
                        {
                           strncpy(l_received_uid, l_temp_buf, strlen(l_temp_buf) - strlen(l_colon));
                           strncpy(l_received_time, &l_temp_buf[strlen(l_temp_buf) - strlen(l_colon)+1], strlen(l_colon)-1);

                           DLOG(0,1,"UID [%s] [%s]", l_received_uid, l_received_time);

                           time_t l_tim_first =time(NULL);
                           DLOG(0,1,"l_tim_first %d got %d", l_tim_first, atoi(l_received_time));
                           int l_diff = abs(l_tim_first/10-atoi(l_received_time)/10);
                           if (l_diff > 10)
                           {
                              CLOG(0,1,"MMI Tool Invalid Registration. Closing the connection. Diff [%d]", l_diff);
                              close(g_clientDesc);
                              FD_CLR(g_clientDesc, &master); // remove from master set
                              g_clientDesc=0;
                              g_clientRegDoneFlag=false;
                           }
                           else
                           {
                              TLOG(0,1,"MMI Tool connected (socket-fd %d)", g_clientDesc);
                              char l_instance[100];
                              memset(l_instance, '\0', 100);
                              sprintf(l_instance, "%s%03d_%05d", g_ConfigData->m_EntityName, g_ConfigData->m_InstanceId, getpid());
                              sendDataToNetwork((unsigned char*)l_instance, strlen(l_instance));
                              g_clientRegDoneFlag=true;
                              if (g_uid == atoi(l_received_uid))
                              {
                                 g_sameUser=true;
                              }
                              else
                              {
                                 g_sameUser=false;
                              }
                           }
                        }
                        else
                        {
                           CLOG(0,1,"MMI Tool Invalid Registration Format. Closing the connection.");
                           close(g_clientDesc);
                           FD_CLR(g_clientDesc, &master); // remove from master set
                           g_clientDesc=0;
                           g_clientRegDoneFlag=false;
                        }
                     }
                     else
                     {
                        DLOG(0,1,"command [%s]\n", buf);

                        char *l_newBuffer = new char[nbytes+1];
                        memset(l_newBuffer, '\0', nbytes+1);
                        strncpy(l_newBuffer, buf, nbytes);

                        DLOG(0,1,"pushing into queue\n", buf);

                        g_commandQueue->push(l_newBuffer);
                     }
                  }
               }
            } // END handle data from client
         } // END got new incoming connection
      } // END looping through file descriptors
   } // END for(;;)--and you thought it would never end!

   return false;
}


int RecvAll(int &s, char *buf, unsigned long len)
{
   unsigned long total = 0;
   int bytesleft = len;
   int n;
   while(total < len)
   {
      if(0>s)
         return -1;

      n = recv(s, buf+total, bytesleft,0);
      if (0 >= n)
      {
         if(0 > n)
         {
            printf("\n%s <Ln:%d> recv failed with errno: %d.", 
                  __FUNCTION__, __LINE__, errno);
            if (EINTR == errno)
               continue;
         }
         else
            printf("\n%s <Ln:%d> Socket closed by Peer.", __FUNCTION__, __LINE__);
         //close(s);
         return n;
      }
      total += n;
      bytesleft -= n;
      //printf("\nreceived bytes %d, bytesleft %d, len %d, sockFd: %d",n,bytesleft,len, s);
   }
   len = total; // return number actually sent here
   return len;
}

