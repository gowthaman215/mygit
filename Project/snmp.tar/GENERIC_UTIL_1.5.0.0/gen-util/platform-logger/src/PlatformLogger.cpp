#include <pthread.h>
#include <PlatformLogger.h>


extern pthread_key_t g_key;
extern pthread_t handlerThID[6];


PlatformLogger g_PlatformLoggerObj; // definition for the global PlatformLogger object

PlatformLogger::PlatformLogger()
{
   resetMembers();
}

PlatformLogger::~PlatformLogger()
{
}

void PlatformLogger::resetMembers()
{
   m_instanceId = 0;
   iLoggingMedia		= 0;
   iLoggingThreshold	= 0;
   iLoggerFileHandle	= 0;
   iLoggerConsoleHandle	= 0;
   iArchivalDirPath	= NULL;
   iMaxFileSize		= 1000000;
   iFilePath		= NULL;
   iModuleName		= NULL;
   i_SyncCount		= 0;
   memset(iLoggerBuffer, '\0', PL_LOGGER_BUFFER_SIZE);
   pthread_mutex_init(&edrMutex, NULL);
} 

char *PlatformLogger::makeFileName(char * mFileNameBuffer, char * mPath, char * mFilePrefix)
{
   struct tm *tm_ptr=NULL;
   time_t l_tim =time(NULL);
   tm_ptr = localtime(&l_tim);
   sprintf(mFileNameBuffer, "%s/%s_I%02d_%04u_%02u_%02u_%02u_%02u_%02u_P%05d.log", 
         mPath, mFilePrefix, m_instanceId, 
         tm_ptr->tm_year+1900,  tm_ptr->tm_mon+1, tm_ptr->tm_mday, tm_ptr->tm_hour, tm_ptr->tm_min, tm_ptr->tm_sec, getpid());

   if((this->iFilePath == NULL) ||(strcmp(mPath, this->iFilePath)==0))
   {
      strcpy(this->iFileName,mFileNameBuffer);
   }
   return mFileNameBuffer;
}

void PlatformLogger::makeTimeStamp(char *p_DateTimeStamp)
{
   /*
   char * dateString=NULL;
   struct tm *tm_ptr=NULL;
   time_t l_tim =time(NULL);
   tm_ptr = localtime(&l_tim);
   dateString = asctime(tm_ptr);
   dateString[24] = 0;
   strcpy(p_DateTimeStamp, dateString);
   */
   long timeInSeconds;
   struct tm *timeStruct;
   char dateString[16];
   time(&timeInSeconds);
   timeStruct = localtime(&timeInSeconds);
   memset(dateString,'\0',sizeof(dateString));
   strftime(dateString,16,"%m-%d.%H:%M:%S", timeStruct);
   strcpy(p_DateTimeStamp, dateString);
   return;
}

bool PlatformLogger::initialize(unsigned long mLoggingThreshold, unsigned long mLoggingMedia, char * mPath, char * mModuleName,
                        char * mArchivalDirPath, unsigned long mMaxFileSize, int p_instanceId, int p_applicationDlgIdLength)
{
   m_instanceId = p_instanceId;
   if (m_instanceId < 0 || m_instanceId > 99)
   {
      printf("\nInstance Id %d should be between 1 and 99", m_instanceId);
      return false;
   }

   if ( (p_applicationDlgIdLength > 5) || (p_applicationDlgIdLength < 0))
   {
      printf("\nApplication Dlg Id Length %d should be between 0 and 5", p_applicationDlgIdLength);
      return false;
   }
   m_applicationDlgIdLength=p_applicationDlgIdLength;

   iArchivalDirPath = (char *)malloc(strlen(mArchivalDirPath) + 1);
   strcpy(iArchivalDirPath, mArchivalDirPath);
   iMaxFileSize = mMaxFileSize;
   iFilePath = (char *)malloc(strlen(mPath) + 1);
   strcpy(iFilePath, mPath);
   iModuleName = (char *)malloc(strlen(mModuleName) + 1);
   strcpy(iModuleName, mModuleName);

   if (0 != pthread_mutex_init(&g_bc_mutex, NULL))
   {
      printf("\nUnable to initialize the mutex");
      return false;
   }

   i_SyncCount = 0;
   bool mRetVal = false;
   char mFileNameBuffer[500];
   memset(mFileNameBuffer, '\0', 500);
   pthread_mutex_init(&edrMutex, NULL);

   try
   {
      if((mLoggingMedia < PL_LOG_MEDIA_LOWER_LIMIT) || (mLoggingMedia > PL_LOG_MEDIA_UPPER_LIMIT) )
      {
         throw PL_LOGGER_ERR_MODE;
      }
      else
         iLoggingMedia = mLoggingMedia;

      if( (mLoggingThreshold < PL_LOG_LEVEL_LOWER_LIMIT) || (mLoggingThreshold > PL_LOG_LEVEL_UPPER_LIMIT) )
      {
         throw PL_LOGGER_ERR_LEVEL;
      }
      else
         iLoggingThreshold = mLoggingThreshold;

      switch((int)iLoggingMedia)
      {
         case PL_LOG_MEDIA_FILE :	
            if((!mPath) || (!mModuleName) || (PL_PATH_MAX_SIZE < (int)strlen(mPath)) || (PL_MODULE_NAME_MAX_SIZE < (int)strlen(mModuleName)) )
               throw PL_LOGGER_ERR_FILE;
            makeFileName(&mFileNameBuffer[0], this->iFilePath, this->iModuleName);
            int retd;
            int iUmask = S_IWGRP | S_IWOTH;
            int iFileCreationMode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH; 
            int iFlags = O_WRONLY | O_CREAT | O_APPEND;
            int iOldUmask = umask(iUmask);
            retd = open(mPath, O_RDONLY);
            if (retd == -1)			
            {
               int iDirCreationMode = iFileCreationMode | S_IXUSR | S_IXGRP | S_IXOTH;
               int p = mkdir(mPath, iDirCreationMode);
               if(p == -1) 
               {
                  perror("Error in Creating Directory");
                  throw PL_LOGGER_ERR_FILE;
               }
            }

            // The actual permission will be iFileCreationMode & ~iUmask
            iLoggerFileHandle = open(mFileNameBuffer, iFlags, iFileCreationMode);

            // If unable to open the file than throw error
            if(iLoggerFileHandle == -1)
            {
               throw PL_LOGGER_ERR_FILE;
            }

            // Restore the original umask value.
            umask(iOldUmask);

            break;
      } // end switch

      mRetVal = true;
      log(NULL, PL_LOG_LEVEL_CRITICAL, __FILE__, __FUNCTION__, __LINE__,"***********************************************************************************");
      log(NULL, PL_LOG_LEVEL_CRITICAL,  __FILE__, __FUNCTION__, __LINE__,"                         LOGGING STARTED                                           ");
      log(NULL, PL_LOG_LEVEL_CRITICAL,  __FILE__, __FUNCTION__, __LINE__,"***********************************************************************************");
   }
   catch (int err_code) 
   {
      iLoggingMedia	= 0;
      iLoggingThreshold	= 0;

      switch (err_code)
      {
         case PL_LOGGER_ERR_FILE :			// File path is not correct
            iLoggerFileHandle		= 0;
            break;
         case PL_LOGGER_ERR_NEW_CONSOLE :	// Console window problem
            iLoggerConsoleHandle	= 0;
            break;
         case PL_LOGGER_ERR_BUFFER :		// Insufficient memory
            break;
      } //end of switch 
   }
   return mRetVal;
}


void PlatformLogger::terminate()
{
   log(NULL, PL_LOG_LEVEL_CRITICAL,  __FILE__, __FUNCTION__, __LINE__,"***********************************************************************************");
   log(NULL, PL_LOG_LEVEL_CRITICAL,  __FILE__, __FUNCTION__, __LINE__,"                         LOGGING STOPPED                                           ");
   log(NULL, PL_LOG_LEVEL_CRITICAL,  __FILE__, __FUNCTION__, __LINE__,"***********************************************************************************");

   switch ((int)iLoggingMedia) 
   {
      // If LoggingMedia is file then close file handle
      case PL_LOG_MEDIA_FILE :		
         if(iLoggerFileHandle)
         {
            //CloseHandle(iLoggerFileHandle);
            close(iLoggerFileHandle);
         }
         break;
   };

   if(iModuleName)
      free(iModuleName);

   if(iFilePath )
      free(iFilePath);

   if(iArchivalDirPath)
      free(iArchivalDirPath);

   resetMembers();
}



bool PlatformLogger::log(BaseContext *p_bc, unsigned long mLoggingLevel, const char *p_srcFileName, const char *p_funcName,
      int p_LineNumber, char* mLogMessage, ...)
{
   try 
   {
      pthread_mutex_lock(&edrMutex);
      char l_dateString[25];
      memset(l_dateString, '\0', 25);

      char debugTag[10];
      memset(debugTag, '\0', 10);

      unsigned long  ulThreadID = pthread_self();
      char m_buffer[PL_LOGGER_BUFFER_SIZE];
      memset(m_buffer, '\0', PL_LOGGER_BUFFER_SIZE);
      if( (mLoggingLevel<PL_LOG_LEVEL_LOWER_LIMIT) || (mLoggingLevel>PL_LOG_LEVEL_UPPER_LIMIT) || (mLoggingLevel>iLoggingThreshold))
      {
         pthread_mutex_unlock(&edrMutex);	
         return false;
      }
      if(!mLogMessage || (PL_LOG_MESSAGE_MAX_SIZE<(int)strlen(mLogMessage)) )	
      {
         pthread_mutex_unlock(&edrMutex);	
         return false;
      }

      //m_criticalSection.Enter();
      this->i_SyncCount++;
      makeTimeStamp(l_dateString);

#ifdef SunOS
      va_list args = 0;
#else
      va_list args;
#endif
      va_start(args, mLogMessage);

      switch(mLoggingLevel)
      {
         case PL_LOG_LEVEL_CRITICAL:
            strcpy(debugTag,"C");
            break;

         case PL_LOG_LEVEL_PERFORMANCE:
            strcpy(debugTag,"P");
            break;

         case PL_LOG_LEVEL_NORMAL:
            strcpy(debugTag,"N");
            break;

         case PL_LOG_LEVEL_WARNING:
            strcpy(debugTag,"W");
            break;


         case PL_LOG_LEVEL_DEBUG:
            strcpy(debugTag,"D");
            break;

         default:
            strcpy(debugTag,"U");
            break;
      }/* End of switch */


      char l_idBuffer2[400];
      memset(l_idBuffer2, '\0', 400);

      if (NULL == p_bc)
      {
         sprintf(l_idBuffer2, "%20s", " ");
      }
      else
      {
         sprintf(l_idBuffer2, "%3s:%s", p_bc->getMessageName(), p_bc->getSessionId());
      }

      if (m_applicationDlgIdLength > 0)
      {
         char l_temp[20];
         memset(l_temp, '\0', sizeof(l_temp));
         if (NULL == p_bc)
         {
            sprintf(l_temp, "|%6s", " ");
         }
         else
         {
            sprintf(l_temp, "|D%05d", p_bc->getApplicationSessionId());
         }
         strcat(l_idBuffer2, l_temp);
      }

      char l_thread_id[200];
      memset(l_thread_id, '\0', sizeof(l_thread_id));
      int l_thread_id_int = pthread_self();
      if (l_thread_id_int < 99999)
      {
         sprintf(l_thread_id, "T%05d|%s:%d", l_thread_id_int, p_funcName, p_LineNumber);
      }
      else
      {
         sprintf(l_thread_id, "T%d|%s:%d", l_thread_id_int, p_funcName, p_LineNumber);
      }

      memset(iLoggerBuffer, '\0', PL_LOGGER_BUFFER_SIZE);
      vsnprintf(iLoggerBuffer + 
            sprintf(iLoggerBuffer,"%s|%s|%s|%s| ", 
               debugTag, 
               l_dateString, 
               l_idBuffer2,
               l_thread_id), PL_LOGGER_BUFFER_SIZE-200, mLogMessage, args);


      if(NULL != p_srcFileName)
      {
         const char *l_StrIndex = strrchr(p_srcFileName, '/') ;
         if (NULL != l_StrIndex)
            p_srcFileName = ++l_StrIndex;
      }
      strcat(iLoggerBuffer, "\n");



      /*
      snprintf(m_buffer, 3000, "  |%s|%s|%d\n", p_srcFileName, p_funcName, p_LineNumber);
      if('\n' == iLoggerBuffer[strlen(iLoggerBuffer)-1])
      {
         iLoggerBuffer[strlen(iLoggerBuffer)-1] = '\0';
      }
      strlcat(iLoggerBuffer, m_buffer, PL_LOGGER_BUFFER_SIZE-1);
      */

      unsigned long m_FileSize;
      switch (iLoggingMedia)
      {
         case PL_LOG_MEDIA_FILE :			
            struct stat fileStat;


            fstat(this->iLoggerFileHandle, &fileStat);
            m_FileSize = fileStat.st_size;

            chmod(iFileName,0644);
            if(m_FileSize >= this->iMaxFileSize)
            {
               char mFileNameBuffer[500];
               memset(mFileNameBuffer, '\0', 500);
               close(this->iLoggerFileHandle);
               makeFileName(&mFileNameBuffer[0],this->iArchivalDirPath,this->iModuleName);

               rename(this->iFileName,mFileNameBuffer);
               makeFileName(&mFileNameBuffer[0],this->iFilePath,this->iModuleName);

               iLoggerFileHandle = creat(mFileNameBuffer,O_CREAT|O_RDWR);
               chmod(iFileName,0444);
               if(iLoggerFileHandle == -1) 
               {
                  throw PL_LOGGER_ERR_FILE;
               }
               else // Point to end of the file
               {					
                  lseek(iLoggerFileHandle,0,SEEK_END);
               }
            }
            write(iLoggerFileHandle, iLoggerBuffer, strlen(iLoggerBuffer));

            chmod(iFileName,0644);
            break;
         case PL_LOG_MEDIA_CONSOLE :
            printf(iLoggerBuffer);
            break;
      };
      this->i_SyncCount--;
      //m_criticalSection.Leave();
      pthread_mutex_unlock(&edrMutex);	
      return true;
   }
   catch(...)
   {
      //cout<<"**************Unknown exception occured in PlatformLogger*************"<<endl;
      if(this->i_SyncCount)
      {
         this->i_SyncCount--;
         //m_criticalSection.Leave();
      }			
      pthread_mutex_unlock(&edrMutex);	
      return false;
   }
}



long PlatformLogger::getLoggerSyncCount()
{
   return this->i_SyncCount;
}

unsigned long PlatformLogger::getLoggingThreshold()
{
   return iLoggingThreshold;
}

bool PlatformLogger::setLoggingThreshold(unsigned long m_newLoglevel)
{

   iLoggingThreshold = m_newLoglevel;
   //cout<<"NEWLOGLEVEL:"<<iLoggingThreshold<<endl;
   return true;
}


bool PlatformLogger::logHexDump(unsigned int loggingLevel, const char* srcFileName, const char *funcName, 
      int lineNumb, const char * buff, int buffLen)
{

   char  msgBuff[15000] = {0};
   memset(msgBuff, '\0', 15000);

#if 0

   int ind=0;
   for(int i = 0; i < buffLen; i++)
   {
      sprintf(&msgBuff[ind], "%02x ", (char*)buff);
      ind += 3;
   }


#endif
   return log(NULL, loggingLevel, srcFileName, funcName, lineNumb, msgBuff); 
   return true;
}


