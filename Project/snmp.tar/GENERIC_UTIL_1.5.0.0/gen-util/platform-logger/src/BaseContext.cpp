#include <BaseContext.h>
#include <PlatformLogger.h>

#define MAX_SL_CONTEXTS   9999

char g_SlCurrentCtxtTraceEnabledFlag=' ';
char g_SlCurrentIMSI[20+1];
char g_SlCurrentMSISDN[20+1];
int  g_SlCurrentContext=0;
int  g_SlContexts=MAX_SL_CONTEXTS;
long g_TotalContexts=0;
int  g_SlCurrentRscType=0;
int  g_SlActiveContexts=0;
char g_SlModName[4];
char g_SlMessageName[4];

int g_BaseTime;

pthread_mutex_t g_bc_mutex;


BaseContext::BaseContext()
{
   reset();
}

void BaseContext::reset()
{
   memset(m_TraceImsi, '\0', 20+1);
   memset(m_TraceMsisdn, '\0', 20+1);
   m_TraceEnabledFlag=' ';

   memset(m_MsgName, '\0', sizeof(m_MsgName));

   strcpy(m_MsgName, "MSG");

   pthread_mutex_lock(&g_bc_mutex);
   if (++g_SlContexts < MAX_SL_CONTEXTS)
   {
      m_CurrentCounter=g_SlContexts;
   }
   else
   {
      g_BaseTime=time(NULL);
      m_CurrentCounter=1;
      g_SlContexts=1;
   }   
   memset(m_SessionId, '\0', sizeof(m_SessionId));
   sprintf(m_SessionId, "%02d%010d%04d", g_PlatformLoggerObj.m_instanceId, g_BaseTime, m_CurrentCounter);
   m_ApplicationSessionId=0;

   pthread_mutex_unlock(&g_bc_mutex);

}

BaseContext::~BaseContext()
{
}

bool BaseContext::setTraceImsi(char *p_imsi)
{
   /*
   map<string, int>::iterator l_it;
   l_it = g_TraceImsiMap.find(p_imsi);
   if (l_it != g_TraceImsiMap.end())// matches the list of IMSIs
   {
      printf("\nSetting trace imsi for the subscriber");
      strcpy(m_TraceImsi, p_imsi);
      m_TraceEnabledFlag= 'I';

      g_SlCurrentCtxtTraceEnabledFlag = 'I';
      strcpy(g_SlCurrentIMSI, m_TraceImsi);
   }*/
   return true;
}

bool BaseContext::setTraceMsisdn(char *p_msisdn)
{
   /*
   map<string, int>::iterator l_it;
   l_it = g_TraceMsisdnMap.find(p_msisdn);
   if (l_it != g_TraceMsisdnMap.end())// matches the list of MSISDNs
   {
      printf("\nSetting trace msisdn for the subscriber");
      strcpy(m_TraceMsisdn, p_msisdn);
      m_TraceEnabledFlag= 'M';

      g_SlCurrentCtxtTraceEnabledFlag = 'M';
      strcpy(g_SlCurrentMSISDN, m_TraceMsisdn);
   }*/
   return true;
}

bool BaseContext::setMessageName(char *p_msg)
{
   strncpy(m_MsgName, p_msg, BASE_CONTEXT_MSG_SIZE);
}


char *BaseContext::getMessageName()
{
   return m_MsgName;
}


char *BaseContext::getSessionId()
{
   return m_SessionId;
}

void BaseContext::setApplicationSessionId(int p_ApplicationSessionId)
{
   m_ApplicationSessionId=p_ApplicationSessionId;
}

int BaseContext::getApplicationSessionId()
{
   return m_ApplicationSessionId;
}
