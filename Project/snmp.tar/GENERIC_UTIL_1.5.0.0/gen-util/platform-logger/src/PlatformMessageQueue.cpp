#include <PlatformMessageQueue.h>
#include <PlatformLogger.h>
#include <sys/msg.h>



PlatformMessageQueue::PlatformMessageQueue(EPlQueueType p_QueueType, EPlQueuePersistenceType p_QueuePersistenceType)
{
   m_QueueType = p_QueueType;
   m_QueuePersistenceType = p_QueuePersistenceType;
   m_persMsgId=0;
   m_persKey=1;
}


PlatformMessageQueue::~PlatformMessageQueue()
{
}

int get_queue_ds( int qid, struct msqid_ds *qbuf )
{
        if( msgctl( qid, IPC_STAT, qbuf) == -1)
        {
                return(-1);
        }
        return(0);
}


bool change_queue_size( int qid, int size )
{
        struct msqid_ds tmpbuf;

        /* Retrieve a current copy of the internal data structure */
        if (0 != get_queue_ds( qid, &tmpbuf))
        {
           CLOG(NULL, "get_queue_ds failed\n");
           return false;
        }

        /* Change the permissions using an old trick */
        tmpbuf.msg_qbytes = size;

        /* Update the internal data structure */
        if( msgctl( qid, IPC_SET, &tmpbuf) == -1)
        {
                return(-1);
        }
        
        return true;
}

int get_queue_size(int qid)
{
        struct msqid_ds tmpbuf;

        /* Retrieve a current copy of the internal data structure */
        if (0 != get_queue_ds( qid, &tmpbuf))
        {
           CLOG(NULL, "get_queue_ds failed\n");
           return 0;
        }

        return tmpbuf.msg_qnum;
}


int PlatformMessageQueue::size()
{
   if(PL_QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT == m_QueuePersistenceType)
   {
      return m_q.size();
   }
   else
   {
      return get_queue_size(m_persMsgId);
   }
}




bool PlatformMessageQueue::initialize()
{

   if (0 != pthread_mutex_init(&m_q_mutex, NULL))
   {
      printf("\nUnable to initialize the mutex");
      return false;
   }

   if (-1 == sem_init(&m_semaphore, 0, 0))
   {
      printf("\nUnable to initialize the semaphore [%d]", errno);
      return false;
   }

   if(PL_QUEUE_PERSISTENCE_TYPE_PERSISTENT == m_QueuePersistenceType)
   {
      m_persMsgId =  msgget (2460+001, 0640|IPC_CREAT);
      if(m_persMsgId <0)
      {
         printf("\nIPC MessageQ creation failed, Key = %d, errno = %d, ErrText = %s",m_persKey, errno, strerror(errno));
         return false;
      }
      else
      {
         NLOG(NULL, "Message Queue PERSISTENT successfull: %d", m_persMsgId);
         return change_queue_size(m_persMsgId, 1000000);
      }
   }

   return true;
}




bool PlatformMessageQueue::push(void *p_qm, int p_length)
{
   if(PL_QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT == m_QueuePersistenceType)
   {
      pthread_mutex_lock(&m_q_mutex);
      m_q.push_back(p_qm);
      pthread_mutex_unlock(&m_q_mutex);
      sem_post(&m_semaphore);
   }
   else  //PERSISTENCE CASE
   {
      if ((p_length < 1) || (p_length > PL_MAX_QUEUE_DATA_SIZE))
      {
         CLOG(NULL, "Invalid message data length: %d", p_length);
         return false;
      }
      else
      {
         NLOG(NULL, "MsgQ Push length: %d", p_length);
         mymsg l_msg;
         memset(&l_msg, '\0', sizeof(l_msg));
         l_msg.m_type = PL_MSG_TYPE;
         memcpy(l_msg.m_text, p_qm, p_length);
         if(msgsnd(m_persMsgId, &l_msg, p_length, 0)<0)
         {
            CLOG(NULL, "MsgQ Send failed, MsgLen = %d, MsgId = %d, errno = %d, ErrText = %s",p_length, m_persMsgId, errno, strerror(errno));
            return false;
         }

         char *l_temp = (char*)p_qm;
         delete []l_temp;
      }
   }
   return true;
}


bool PlatformMessageQueue::pop(void **p_qm)
{
   if(PL_QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT == m_QueuePersistenceType)
   {
      if (m_QueueType == PL_QUEUE_TYPE_BLOCKING)
      {
   do_wait_loop:
         int l_sem_result = sem_wait(&m_semaphore);
         if (-1 == l_sem_result)
         {
            CLOG(NULL, "Semaphore interrupted [%d]", errno);
            if(EINTR == errno)
            {
               CLOG(NULL, "Received a EINTR signal. Waiting on semaphore again");
               goto do_wait_loop;
            }
            else
            {
               switch (errno)
               {
                  case EINVAL:
                     CLOG(NULL, "EINVAL received");
                     break;
                  case ENOSYS:
                     CLOG(NULL, "ENOSYS received");
                     break;
                  case EAGAIN:
                     CLOG(NULL, "EAGAIN received");
                     break;
                  case EDEADLK:
                     CLOG(NULL, "EDEADLK received");
                     break;
                  case EINTR:
                     CLOG(NULL, "EINTR received");
                     break;
                  default:
                     CLOG(NULL, "Unknown errno");
                     break;
               }
               return false;
            }
         }
      }
      else
      {
         // Do nothing
      }

      pthread_mutex_lock(&m_q_mutex);

      if (m_q.size() != 0)
      {
         //printf("\nGetting a message from the queue");
         (*p_qm) = m_q[0];
         m_q.pop_front();
         pthread_mutex_unlock(&m_q_mutex);
      }
      else
      {
         pthread_mutex_unlock(&m_q_mutex);

         if (m_QueueType == PL_QUEUE_TYPE_BLOCKING)
         {
            CLOG(NULL,"ERROR!!!!!!! Still No data thing coming");
            CLOG(NULL,"ERROR!!!!!!! PlatformMessageQueue::popMessage ended");
         }
         return false;
      }
   }
   else
   {
      mymsg l_msg;
      memset(&l_msg, '\0', sizeof(l_msg));
      l_msg.m_type = PL_MSG_TYPE;
      int l_length=0;
      l_length= msgrcv(m_persMsgId, &l_msg, PL_MAX_QUEUE_DATA_SIZE, 0, IPC_NOWAIT);

      if(l_length < 0)
      {
         if (ENOMSG == errno)
         {
            NLOG(NULL, "No messages in the message queue with MsgId = %d", m_persMsgId);
            return false;
         }
         else
         {
            CLOG(NULL, "Some other error MsgId = %d, errno = %d, ErrText = %s", m_persMsgId, errno, strerror(errno));
            return false;
         }
      }
      else
      {
         DLOG(NULL, "Successfully received the message: %d", l_length);
         *p_qm = new unsigned char[l_length+1];
         memcpy(*p_qm, l_msg.m_text, l_length);
      }
   }
   return true;
}





bool PlatformMessageQueue::pop_without_lock(void **p_qm)
{
   if(PL_QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT == m_QueuePersistenceType)
   {
      if (m_QueueType == PL_QUEUE_TYPE_BLOCKING)
      {
         int l_sem_result = sem_wait(&m_semaphore);
         if (-1 == l_sem_result)
         {
            CLOG(NULL, "Semaphore interrupted [%d]", errno);
            switch (errno)
            {
               case EINVAL:
                  CLOG(NULL, "EINVAL received");
                  break;
               case ENOSYS:
                  CLOG(NULL, "ENOSYS received");
                  break;
               case EAGAIN:
                  CLOG(NULL, "EAGAIN received");
                  break;
               case EDEADLK:
                  CLOG(NULL, "EDEADLK received");
                  break;
               case EINTR:
                  CLOG(NULL, "EINTR received");
                  break;
               default:
                  CLOG(NULL, "Unknown errno");
                  break;
            }
            return false;
         }
      }
      else
      {
         // Do nothing
      }

      //pthread_mutex_lock(&m_q_mutex);

      if (m_q.size() != 0)
      {
         //printf("\nGetting a message from the queue");
         (*p_qm) = m_q[0];
         m_q.pop_front();
         //pthread_mutex_unlock(&m_q_mutex);
      }
      else
      {
         //pthread_mutex_unlock(&m_q_mutex);

         if (m_QueueType == PL_QUEUE_TYPE_BLOCKING)
         {
            CLOG(NULL,"ERROR!!!!!!! Still No data thing coming");
            CLOG(NULL,"ERROR!!!!!!! PlatformMessageQueue::popMessage ended");
         }
         return false;
      }
   }
   else
   {
   }

   return true;
}
void PlatformMessageQueue::lock()
{
   pthread_mutex_lock(&m_q_mutex);
}
void PlatformMessageQueue::unlock()
{
   pthread_mutex_unlock(&m_q_mutex);
}

int PlatformMessageQueue::getSemCount()
{
   int l_value=-1;
   if (0 != sem_getvalue(&m_semaphore, &l_value))
   {
      CLOG(NULL, "sem_getvalue failed %d", errno);
   }
   return l_value;
}
