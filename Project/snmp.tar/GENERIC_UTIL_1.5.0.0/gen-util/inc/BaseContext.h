#ifndef __BASE_CONTEXT_H
#define __BASE_CONTEXT_H

#include <string>
#include <map>
#include <pthread.h>
using namespace std;


#define BASE_CONTEXT_MSG_SIZE   3
#define BASE_CONTEXT_MOD_SIZE   3

class BaseContext
{
   public:
      BaseContext();
      virtual ~BaseContext();

      bool setTraceImsi(char *p_imsi);
      bool setTraceMsisdn(char *p_msisdn);

      bool setMessageName(char *p_msg);
      bool setModuleName(char *p_msisdn);

      char *getMessageName();
      char *getSessionId();

      void setApplicationSessionId(int);
      int  getApplicationSessionId();

      void reset();

   private:
      char m_TraceImsi[20+1];
      char m_TraceMsisdn[20+1];
      char m_SessionId[16+1];
      char m_TraceEnabledFlag;

      char m_MsgName[BASE_CONTEXT_MSG_SIZE+1];
      int  m_CurrentCounter;
      int  m_ApplicationSessionId;
};

extern pthread_mutex_t g_bc_mutex;

#endif

