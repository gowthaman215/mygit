/***************************************************************
File:			PlatformLogger.h
 ***************************************************************/
#ifndef __PLATFORM_LOGGER_H
#define __PLATFORM_LOGGER_H

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdarg.h>
#include <dirent.h>
#include <iostream>
#include <BaseContext.h>
using namespace std;


// Logging Mode Constants
#define  PL_LOG_MEDIA_LOWER_LIMIT	1// Define valid lower range for Logging Media
#define  PL_LOG_MEDIA_FILE		      1// File Mode Logging
#define	PL_LOG_MEDIA_CONSOLE	      2// Console Mode Logging
#define	PL_LOG_MEDIA_IDE		      3// IDE Mode Logging
#define	PL_LOG_MEDIA_NEW_CONSOLE	4// New Console Window Mode Logging
#define  PL_LOG_MEDIA_UPPER_LIMIT	4// Define valid upper range for Logging Mode


// Logging Level Constants
#define PL_LOG_LEVEL_LOWER_LIMIT	  1// Define valid lower range for Logging Level
#define PL_LOG_LEVEL_CRITICAL	     1	// Highest Priority (useful for delivered code) 
#define PL_LOG_LEVEL_WARNING	     2	// 
#define PL_LOG_LEVEL_PERFORMANCE	  3	// 
#define PL_LOG_LEVEL_NORMAL	     4	// 
#define PL_LOG_LEVEL_DEBUG		     5	// Lowest Priority (useful for debugging purposes)
#define PL_LOG_LEVEL_UPPER_LIMIT	  5// Define valid upper range for Logging Level

// Error Code Defined for initialization routine
#define PL_LOGGER_ERR_LEVEL	      1
#define PL_LOGGER_ERR_MODE		      2
#define PL_LOGGER_ERR_FILE		      3
#define PL_LOGGER_ERR_NEW_CONSOLE	4
#define PL_LOGGER_ERR_SEMAPHORE	   5
#define PL_LOGGER_ERR_BUFFER	      6

// Internal Buffer size 
#define	PL_LOGGER_BUFFER_SIZE	  3000 // = 10 KBytes buffer

// Date string len used in log method
#define PL_DATE_STRING_LEN		     27

// mPath maximum string size
#define PL_PATH_MAX_SIZE		     260

// mModuleName maximum string size
#define PL_MODULE_NAME_MAX_SIZE	  50

// mModuleName maximum string size
#define PL_LOG_MESSAGE_MAX_SIZE	  PL_LOGGER_BUFFER_SIZE - 200	// 2900

class PlatformLogger
{
   private:
      unsigned long iLoggingThreshold;   // Stores currently selected Logging Threshold.
      unsigned long iLoggingMedia;       // Stores currently selected Logging Media.
      int iLoggerFileHandle;             // Stores file handle in case of File Mode Logging (LOG_MEDIA_FILE).
      char iLoggerBuffer[PL_LOGGER_BUFFER_SIZE]; // Stores pointer to internal buffer.
      int  iLoggerConsoleHandle;         // Store new console window handle in case
      pthread_mutex_t  edrMutex;         // Store new console window handle in case
      // This method resets the internal members
      void resetMembers();
      // Makes time stamp in string form
      void makeTimeStamp(char *);
      // Makes file name using specified path & file name
      char * makeFileName(char * mFileNameBuffer, char * mPath, char * mFilePrefix);
      // To preserve file name for relocation of file.
      char iFileName[100];
      // To specify at what size the file should be archived.
      long double iMaxFileSize;
      // Specifies the location where files are archived.
      char * iArchivalDirPath;
      char * iFilePath;
      char * iModuleName;
      volatile long i_SyncCount;

      int m_applicationDlgIdLength;

   public:	

      int m_instanceId;

      // Default Constructor
      PlatformLogger();	
      ~PlatformLogger();	
      void setLogLevel(int p_level)
      {
         iLoggingThreshold=p_level;
      }
      void setLogMedia(int p_media)
      {
         iLoggingMedia=p_media;
      }

      bool initialize(unsigned long mLoggingThreshold, unsigned long mLoggingMedia, char * mPath, 
            char * mModuleName,char * mArchivalDirPath,unsigned long mMaxFileSize, int p_type, int p_applicationDlgIdLength); 

      void terminate();
      bool log(BaseContext *bc,unsigned long mLoggingLevel, const char *p_srcFileName, const char *p_funcName,
            int p_LineNumber, char * mLogMessage, ...);
      bool logHexDump(unsigned int loggingLevel, const char* srcFileName, const char *funcName, 
            int lineNumb, const char * buff, int buffLen);

      long getLoggerSyncCount();
      //TLGB0113 (SB - 80)
      unsigned long getLoggingThreshold();
      bool setLoggingThreshold(unsigned long m_newLogLevel);

}; 

extern PlatformLogger g_PlatformLoggerObj; // definition for the global PlatformLogger object

#define DLOG(CTXT, ...)  g_PlatformLoggerObj.log(CTXT, PL_LOG_LEVEL_DEBUG,     __FILE__, __FUNCTION__, __LINE__, __VA_ARGS__);   
#define PLOG(CTXT, ...)  g_PlatformLoggerObj.log(CTXT, PL_LOG_LEVEL_PERFORMANCE,     __FILE__, __FUNCTION__, __LINE__, __VA_ARGS__);   
#define WLOG(CTXT, ...)  g_PlatformLoggerObj.log(CTXT, PL_LOG_LEVEL_WARNING,   __FILE__, __FUNCTION__, __LINE__, __VA_ARGS__); 
#define CLOG(CTXT, ...)  g_PlatformLoggerObj.log(CTXT, PL_LOG_LEVEL_CRITICAL,  __FILE__, __FUNCTION__, __LINE__, __VA_ARGS__);   
#define NLOG(CTXT, ...)  g_PlatformLoggerObj.log(CTXT, PL_LOG_LEVEL_NORMAL,   __FILE__, __FUNCTION__, __LINE__, __VA_ARGS__); 


#endif	/* __PLATFORM_LOGGER_H */

