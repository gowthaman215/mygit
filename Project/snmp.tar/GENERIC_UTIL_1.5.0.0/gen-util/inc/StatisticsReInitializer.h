#ifndef __STATISTICS_RE_INITIALIZER_H
#define __STATISTICS_RE_INITIALIZER_H

class StatisticsReInitializer
{
   public:
      static StatisticsReInitializer *instance();
      bool reinitialize();


   private:
      StatisticsReInitializer();
      ~StatisticsReInitializer();
};

extern StatisticsReInitializer *g_sr;


#endif

