#ifndef INCL_DecryptKey_H
#define INCL_DecryptKey_H

#include <Codec.h>
#include <LogOverride.h>

#define BUF_LEN 500
#define KEY_LEN 8

#define MAX_DB_NAME 40
#define MAX_DB_CONN_STR 50
#define MAX_RECORD_LEN 100

class DecDbConnStr: public Codec
{
   private:
      bool readFromFile(char *p_DbName, char *p_DbConnStr, int &p_DbDataLen);
   public:
      bool getActualDbString(char *p_DbString, char *p_DbConnStr, LogOverride *p_TranLog);
};

extern DecDbConnStr g_DecDbConnStr;

#endif
