#ifndef __PLATFORM_TOOL_INTERFACE_H
#define __PLATFORM_TOOL_INTERFACE_H

#include <MessageQueue.h>
#include <map>
using namespace std;

class PlatformToolInterface
{
    public:
        PlatformToolInterface();
        ~PlatformToolInterface();

        bool initialize(int p_port);
    
};

extern PlatformToolInterface g_ti;
extern bool processCommand(char *p_command);
extern map<string, int> g_TraceImsiMap;
extern map<string, int> g_TraceMsisdnMap;

#endif

