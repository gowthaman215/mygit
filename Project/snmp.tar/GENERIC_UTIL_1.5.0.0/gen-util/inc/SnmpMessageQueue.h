#ifndef __SNMP_MESSAGE_QUEUE_H
#define __SNMP_MESSAGE_QUEUE_H

#include <deque>
#include <semaphore.h>
#include <pthread.h>

using namespace std;

enum ESnmpQueueType
{
    SNMP_QUEUE_TYPE_BLOCKING=0,
    SNMP_QUEUE_TYPE_NON_BLOCKING
};


class SnmpMessageQueue
{
    public:
        SnmpMessageQueue(ESnmpQueueType p_QueueType);
        ~SnmpMessageQueue();

        bool initialize();
        bool push(void *p_qm);
        bool pop(void **p_qm);
        int size();

    private:
        deque<void*> m_q;
        pthread_mutex_t m_q_mutex;
        sem_t m_semaphore;


        ESnmpQueueType m_QueueType;

};

#endif

