#ifndef INCL_LICENVAL_H
#define INCL_LICENVAL_H

#include <Codec.h>
#include <pthread.h>
#include <LogOverride.h>

#define BUF_LEN 500
#define KEY_LEN 8

class SubscriberBase
{
   public :
      SubscriberBase(){}
      ~SubscriberBase(){}
      virtual bool GetSubsCount(long &p_sub)=0;
};

class LicenVal: public Codec
{
   protected:
      char                 m_PlainData[BUF_LEN];
      char                 m_LFileData[BUF_LEN];
      char                 m_MacAddressList[10][30];
      char                 m_HostId[20];
      static int s_Count;
      static int s_MaxInstance;


   public:
      ~LicenVal();
      LicenVal(){}
      static LicenVal* GetInstance();
      bool GetAllMacAddresses();
      bool ValidateLicense(char* p_MacAddr, char* p_HostId, char* p_ProdName, int& p_LicenseType, long& p_SubscriberBase, int& p_TransactionBase, int& p_NumOfInst, char* p_Action);
      bool Init(char* p_ProdName, const int p_ShmIndex, const int p_ShmChkInterval, const int p_SubsCntInterval, 
            SubscriberBase *p_sb, int& p_LicenseType, int& p_TransactionBase, LogOverride *p_lo);
};

#define LIC_LOG(LOG_LEVEL, ...) {if(g_liclo != NULL) { char l_msg[1000]; memset(l_msg, '\0', 1000); sprintf(l_msg, __VA_ARGS__); g_liclo->override(LOG_LEVEL, l_msg); } }
#endif
