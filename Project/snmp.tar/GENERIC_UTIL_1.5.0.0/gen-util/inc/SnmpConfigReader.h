#ifndef __SNMP_CONFIG_READER_H
#define __SNMP_CONFIG_READER_H

#include <string.h>
#include <iostream>
#include <stdio.h>
#include <SnmpParser.h>
#include <UniTypes.h>

using namespace std;

#define MAXAPPCONF			50

enum ESnmpTrapType
{
   TRAP_TYPE_PASS,
   TRAP_TYPE_FAIL,
   TRAP_TYPE_NORMAL,
   TRAP_TYPE_UNKNOWN
};

class SnmpTrapThreshold
{
   public:
      SnmpTrapThreshold();
      ~SnmpTrapThreshold();

      //Configured Data
      string m_trapId;
      int    m_maxInterval;

      //MAP data
      int    m_lastResetEpoch;
      ESnmpTrapType m_lastTrapType;
      bool m_sentFlag;
      int  m_notSentCounter;

};

class SnmpConfigReader
{
   private:
      bool IsString(char *);
      string readValue (string parent, string child);

   public:
      bool readConfig();
      bool init(char *p_file);
      string i_errorMsg;
      bool readInteger(string parent, string child, unsigned  int &value , unsigned int min, unsigned int max);
      bool readInteger(string parent, string child, int &value , int min,int max);
      bool readInteger(string parent, string child, short &value , int min, int max);
      bool readString(string parent,  string child,  char * ConfigValue,unsigned int min, unsigned int max);
      bool readString(string  p_parent, string p_child,  string& p_ConfigValue ,unsigned int p_min, unsigned int p_max);
      char *getConfigPrint();
};

class SnmpConfigData
{
   public:
      SnmpConfigData();
      ~SnmpConfigData();
};

extern SnmpConfigData g_SnmpConfigData;
extern SnmpConfigReader g_SnmpConfigReader;


#endif /* __SNMP_CONFIG_READER_H */
