/*********************************************************************
** FILE NAME	: LCCUniTypes.h 
** AUTHOR	: Sadiq S
** DEFINITION	: Type Defines for defined data types.
** REMARKS	:
*********************************************************************/

#ifndef _LCCUNITYPES_H
#define _LCCUNITYPES_H

#include <iostream>
#include <string>

using namespace std;

typedef char            s8;   /* Exactly one byte (7 bits) */
typedef unsigned char   u8;   /* Exactly one byte (8 bits) */
typedef short           s16;  /* Exactly 2 bytes (15 bits) */
typedef unsigned short  u16;  /* Exactly 2 bytes (16 bits) */
typedef int             s32;  /* Exactly 4 byte (31 bits) */
typedef unsigned int    u32;  /* Exactly 4 byte (32 bits) */
typedef bool            Boolean;
typedef string          String;

typedef int SOCKET;

// For CStrBcdConv class
#define MAX_BCD_STR_LEN 10  /* Maximum length of address string */
#define MAX_NUM_STR_LEN 20  /* (2*MAX_BCD_STR_LEN) */

#endif /* _LCCUNITYPES_H */
