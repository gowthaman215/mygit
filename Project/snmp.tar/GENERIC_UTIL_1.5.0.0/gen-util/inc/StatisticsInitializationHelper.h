#ifndef __STATISTICS_INITIALIZE_HELPER_H
#define __STATISTICS_INITIALIZE_HELPER_H

#include <StatisticsGenerator.h>

class StatisticsInitializationHelper
{
   public:
      static bool                     initializeStatistics(char *p_path, char *p_EntityName, char *p_appName, char *p_appVersion);
      static bool                     reInitializeStatistics();
      static ELogStatisticsReturnCode logStatistics(int p_index, int p_value=LOG_STATS_DEFAULT_VALUE, ParameterData *p_pd=NULL);
      static bool                     getReportData(int p_start, int p_end, char *p_text, unsigned int p_maxTextSize);

      virtual bool                    applicationInitializationCallback(StatisticsGenerator *p_sg)=0;


   private:
      static StatisticsGenerator *m_sg;
      static bool m_initializedFlag;

      static char    m_filePath[1000+1];
      static char    m_productVersion[MAX_PRODUCT_VERSION_SIZE+1];
      static char    m_productName[MAX_PRODUCT_NAME_SIZE+1];
      static char    m_entityName[MAX_ENTITY_NAME+1];
      static pthread_mutex_t m_mutex;

   protected:
      StatisticsInitializationHelper();
      virtual ~StatisticsInitializationHelper();

   friend class StatisticsGenerator;
   friend class SnmpInterface;

};

extern StatisticsInitializationHelper *g_sih;

#endif

