/***********************************************************************
 * 
 * REVISION HISTORY 
 * 
 * v1.5.0.0
 * --------
 * 1. Added "int p_uniqueTrapSequenceId", an additional parameter in the registerSnmpTrap function
 * 
 * 
 *
 * **********************************************************************/

#ifndef __SNMP_INTERFACE_H
#define __SNMP_INTERFACE_H

#include <SnmpMessageQueue.h>
#include <LogOverride.h>
#include <SnmpConfigReader.h>
#include <map>
#include <string>

#define MAX_TRAP_COUNT                      500
#define MAX_TRAP_DESC_SIZE                  200
#define MAX_TRAP_ID_SIZE                    30
#define MAX_TRAP_SEQUENCE_ID                99999
#define MAX_PRODUCT_ID                      99999
#define MAX_INSTANCE_SEQ_ID                 99999
#define SNMP_AGENT_RETRY_CONNECTION_TIMER   1
#define MAX_ENTITY_NAME_LENGTH              10


class StatisticsGenerator;

enum ESnmpInternalUniqueTrapSequenceId
{
   SNMP_INTERNAL_UNIQUE_TRAP_SEQUENCE_SUBS_BASE=9000,
   SNMP_INTERNAL_UNIQUE_TRAP_SEQUENCE_LIC_VAL,
   SNMP_INTERNAL_UNIQUE_TRAP_SEQUENCE_STATS,
   SNMP_INTERNAL_UNIQUE_TRAP_SEQUENCE_THB

};

enum ESnmpTrapSeverity
{
   TRAP_SEVERITY_CRITICAL,
   TRAP_SEVERITY_MAJOR,
   TRAP_SEVERITY_MINOR,
   TRAP_SEVERITY_WARNING
};

class SnmpInterface
{
   private:
      int m_trapCount;
      char m_trapDesc[MAX_TRAP_COUNT][MAX_TRAP_DESC_SIZE+1];
      char m_trapId[MAX_TRAP_COUNT][MAX_TRAP_ID_SIZE+1];
      int  m_uniqueTrapSequenceId[MAX_TRAP_COUNT];
      bool m_initializedFlag;
      pthread_mutex_t m_mutex;

      int  m_trapStatsIndex[3][MAX_TRAP_COUNT];
      int  m_trapStatsFilteredIndex[3][MAX_TRAP_COUNT];

      int  m_InitialTrapStatsCounts[3][MAX_TRAP_COUNT];
      int  m_InitialTrapStatsFilteredCounts[3][MAX_TRAP_COUNT];
      map<int,string> m_uniqueTrapSequenceIdMap;

   public:
      SnmpInterface();
      ~SnmpInterface();
      string m_serverData;
      int  m_productId;
      int  m_instanceSeqId;
      char m_productIdChar[20+1];

      bool initialize(char *p_selfEntityName, char *p_snmpAgentIp, int p_snmpAgentPort, LogOverride *p_lo, int p_productId, int p_instanceSeqId, char *p_productIdChar);
      int  registerSnmpTrap(char *p_trapID, char *p_trapText, int p_uniqueTrapSequenceId);
      void printTraps();
      bool sendSnmpTrap(int, ESnmpTrapType, ESnmpTrapSeverity, char *p_trapAdditionalText=NULL);

      friend class StatisticsGenerator;
};


extern SnmpInterface g_si;

#ifdef Linux

extern void strlcat(char* p_desc, char*p_src, int p_size);

#endif

#endif

