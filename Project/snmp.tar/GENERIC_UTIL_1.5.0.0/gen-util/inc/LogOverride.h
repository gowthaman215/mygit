#ifndef __LOG_OVERRIDE_H
#define __LOG_OVERRIDE_H

class LogOverride
{
   private:

   public:
      LogOverride();
      ~LogOverride();

      virtual bool override(char p_logLevel, char *p_data)=0;
};

extern LogOverride *g_lo;
#define UTIL_LOG(LOG_LEVEL, ...) {if(g_lo != NULL) { char l_msg[1000]; memset(l_msg, '\0', 1000); sprintf(l_msg, __VA_ARGS__); g_lo->override(LOG_LEVEL, l_msg); } }

#endif

