#ifndef __GEN_UTILS_H
#define __GEN_UTILS_H

#ifndef PLINTRON_LICENSING
char       g_RandKey[10];
#endif

#endif

