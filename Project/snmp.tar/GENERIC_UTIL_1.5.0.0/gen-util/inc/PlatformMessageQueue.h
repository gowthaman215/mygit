#ifndef __PLATFORM_MESSAGE_QUEUE_H
#define __PLATFORM_MESSAGE_QUEUE_H

#include <deque>
#include <semaphore.h>
#include <pthread.h>

using namespace std;

enum EPlQueueType
{
    PL_QUEUE_TYPE_BLOCKING=0,
    PL_QUEUE_TYPE_NON_BLOCKING
};

enum EPlQueuePersistenceType
{
    PL_QUEUE_PERSISTENCE_TYPE_NON_PERSISTENT=0,
    PL_QUEUE_PERSISTENCE_TYPE_PERSISTENT
};

#define PL_MAX_QUEUE_DATA_SIZE  2000
#define PL_MSG_TYPE             1

 struct  mymsg {
         long  m_type;     /* message type */
         char  m_text[PL_MAX_QUEUE_DATA_SIZE+1];  /* message text */
 };

class PlatformMessageQueue
{
    public:
        PlatformMessageQueue(EPlQueueType p_QueueType, EPlQueuePersistenceType p_QueuePersistenceType);
        ~PlatformMessageQueue();

        bool initialize();
        bool push(void *p_qm, int p_length=0);
        bool pop(void **p_qm);
        int size();

        bool pop_without_lock(void **p_qm); // Can be used for popping multiple messages by locking and unlocking explicitly
        void lock();
        void unlock();
        int getSemCount();


    private:
        deque<void*> m_q;
        pthread_mutex_t m_q_mutex;
        sem_t m_semaphore;

        EPlQueueType m_QueueType;
        EPlQueuePersistenceType m_QueuePersistenceType;
        int m_persMsgId;
        int m_persKey;

};

#endif

