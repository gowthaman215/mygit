#ifndef __STATISTICS_GENERATOR_
#define __STATISTICS_GENERATOR_

#include <list>
#include <pthread.h>
#include <map>
#include <string>
using namespace std;

#define MAX_NUMBER_STATISTICS_COUNTS   50000
#define MAX_SIZE_OF_STATISTICS_HEADER  60
#define MAX_SIZE_OF_2D_HEADER          10
#define MAX_PRODUCT_NAME_SIZE          50
#define MAX_PRODUCT_VERSION_SIZE       50
#define MAX_ENTITY_NAME                100
#define LOG_STATS_DEFAULT_VALUE        -99999

#define DEFAULT_2D_DATA                "_UNKNOWN"


class HeaderData
{
   public:
      string m_h1;
      string m_h2;
      string m_h3;
};

class MultiDimensionalData
{
   public:
      int          m_numOfColumns;
      string       m_header1;
      string       m_header2;
      string       m_header3;
      list<HeaderData> m_hd;
};

class ParameterData
{
   public:
      string m_p1;
      string m_p2;
      string m_p3;
};


enum ELogStatisticsReturnCode
{
   LOG_STATISTICS_RETURN_CODE_SUCCESS = 0,
   LOG_STATISTICS_RETURN_CODE_NOT_INITIALIAZED = 0,
   LOG_STATISTICS_RETURN_CODE_INVALID_INDEX,
   LOG_STATISTICS_RETURN_CODE_VALUE_SHOULD_NOT_BE_PRESENT,
   LOG_STATISTICS_RETURN_CODE_VALUE_SHOULD_BE_PRESENT,
   LOG_STATISTICS_RETURN_CODE_GETTING_REINITIALIZED,
   LOG_STATISTICS_RETURN_CODE_OTHER
};

enum ELogStatisticsPegType
{
   PEG_TYPE_INCREMENT_COUNTER = 0,
   PEG_TYPE_MAX_COUNTER,
   PEG_TYPE_VALUE,
   PEG_TYPE_4D_INCREMENT_COUNTER
};

struct Stats
{
   int m_slotNumber;
   long m_count[MAX_NUMBER_STATISTICS_COUNTS];
};

struct StatsHeader
{
   char m_productName[MAX_PRODUCT_NAME_SIZE+1];
   char m_productVersion[MAX_PRODUCT_VERSION_SIZE+1];
   char m_entityName[MAX_ENTITY_NAME+1];
   int  m_maxNumberOfColumns;
   int  m_currentNumberOfColumns;
   time_t  m_fut;
   time_t  m_lut;
};

struct stats100x : StatsHeader
{
   int  m_startCount[24];
   char m_reportCategory[MAX_NUMBER_STATISTICS_COUNTS+1];
   char m_headers[MAX_NUMBER_STATISTICS_COUNTS][MAX_SIZE_OF_STATISTICS_HEADER+1];
   char m_2dData [MAX_NUMBER_STATISTICS_COUNTS][2 + MAX_SIZE_OF_2D_HEADER + MAX_SIZE_OF_STATISTICS_HEADER+1];
   char m_2dData2[MAX_NUMBER_STATISTICS_COUNTS][2 + MAX_SIZE_OF_2D_HEADER + MAX_SIZE_OF_STATISTICS_HEADER+1];
   char m_2dData3[MAX_NUMBER_STATISTICS_COUNTS][2 + MAX_SIZE_OF_2D_HEADER + MAX_SIZE_OF_STATISTICS_HEADER+1];
   int  m_count[24][MAX_NUMBER_STATISTICS_COUNTS];
};


//   char m_headers[MAX_NUMBER_STATISTICS_COUNTS][MAX_SIZE_OF_STATISTICS_HEADER+1];
//   Stats m_slots[24];

bool  aggregate(Stats* m_stats, int p_slotNumber);


class StoredIndices
{
   public:
      int             m_count;
      map<string,int> m_data;
};

class StatisticsGenerator
{
   public:
      void print();

      ELogStatisticsReturnCode logStatistics(int p_index, int p_value=LOG_STATS_DEFAULT_VALUE, ParameterData *p_pd=NULL);

      int addHeader(ELogStatisticsPegType p_pegType, char *p_header, char *p_header2, char p_rep, MultiDimensionalData *p_mdd=NULL);
      bool updateHeaderDesc(int p_headerIndex, ELogStatisticsPegType p_pegType, char *p_header, char *p_header2, char p_rep);
      bool getReportsList(char *p_text, unsigned int p_maxSizeOfText);
      bool getReportData(int p_start, int p_end, char *p_text, unsigned int p_maxTextSize);

      Stats* getStartStatsPtr();
      int    getTotalStatsSize();

      StatisticsGenerator();
      ~StatisticsGenerator();

   private:
	    bool initializeOtherStatsHeaders();
	    bool markFailure(char *p_header, char *p_header2, char *p_errorDesc);
      bool initialize(char *p_path, char *p_EntityName);
      bool getStatsPtr();
      bool setApplicationName( char *p_appName);
      bool setApplicationVersion( char *p_appName);
      int  m_headerCount;
      char m_reportCategory[MAX_NUMBER_STATISTICS_COUNTS+1];
      char m_headers[MAX_NUMBER_STATISTICS_COUNTS][MAX_SIZE_OF_STATISTICS_HEADER+1];
      ELogStatisticsPegType m_pegTypeArray[MAX_NUMBER_STATISTICS_COUNTS];
      char m_2dData [MAX_NUMBER_STATISTICS_COUNTS][MAX_SIZE_OF_STATISTICS_HEADER+1];
      char m_2dData2[MAX_NUMBER_STATISTICS_COUNTS][MAX_SIZE_OF_STATISTICS_HEADER+1];
      char m_2dData3[MAX_NUMBER_STATISTICS_COUNTS][MAX_SIZE_OF_STATISTICS_HEADER+1];
      char m_productVersion[MAX_PRODUCT_VERSION_SIZE+1];
      char m_productName[MAX_PRODUCT_NAME_SIZE+1];
      char m_entityName[MAX_ENTITY_NAME+1];
      int  m_maxNumberOfColumns;


      void *m_stats;
      StatsHeader *m_startStatsPtr;

      bool    m_initializedFlag;
      bool    m_mappingFlag;

      int     m_slotsInADay;
      char    m_filePath[1000+1];

      int     m_day;
      int     m_slot;
      int     m_fd;

      pthread_mutex_t m_mutex;
      bool    m_debugLogs;
      map<int, StoredIndices*> m_2DMap;

			string  m_addHeaderFailureReason;

      friend class StatisticsInitializationHelper;
};

extern StatisticsGenerator *g_sg;


#endif

