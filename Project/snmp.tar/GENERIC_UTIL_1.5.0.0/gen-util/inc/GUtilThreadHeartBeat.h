#ifndef __GUTIL_THREAD_HEART_BEATH_H_
#define __GUTIL_THREAD_HEART_BEATH_H_

#include <pthread.h>
#include <map>

using namespace std;

#define MAX_THREAD_NAME_SIZE  100

enum EThreadHangedAction
{
      THREAD_HANGED_ACTION_UNKNOWN = 0,
      THREAD_HANGED_ACTION_DO_NOTHING,
      THREAD_HANGED_ACTION_CAPTURE_PSTACK,
      THREAD_HANGED_ACTION_CAPTURE_PSTACK_AND_EXIT,
      THREAD_HANGED_ACTION_GENERATE_CORE_WITHOUT_EXIT,
      THREAD_HANGED_ACTION_GENERATE_CORE_AND_EXIT,
      THREAD_HANGED_ACTION_EXIT
};

class ThreadData
{
   public:
      ThreadData();
      ~ThreadData();

      int    m_mnat;
      time_t m_lastAliveCalledTime;
      char   m_threadName[MAX_THREAD_NAME_SIZE+1];
      bool   m_lastSent;
};

class GUtilThreadHeartBeat
{
   public:
      bool initialize(EThreadHangedAction p_tha);
      bool registerMe(int p_mnat, char *p_threadName); //This API shall be called by the application threads which are to be monitored
      bool iAmAlive();                                 //This API shall be called by the application threads in their thread loops at frequent intervals
      bool unRegisterMe();                             //This API shall remove registration of the thread

      map<int,ThreadData> m_tdm;
      pthread_rwlock_t  m_lock;
      int    m_trapId;
      bool   m_debugLogs;
      EThreadHangedAction m_tha;

      GUtilThreadHeartBeat();
      ~GUtilThreadHeartBeat();

   private:
      bool   m_initializedFlag;
};


extern GUtilThreadHeartBeat g_thb;



#endif

