#ifndef __SNMP_BUFFER_DATA_H
#define __SNMP_BUFFER_DATA_H

class SnmpBufferData
{
    public:
        SnmpBufferData();
        ~SnmpBufferData();

        int m_length;
        unsigned char *m_data;
};

#endif

