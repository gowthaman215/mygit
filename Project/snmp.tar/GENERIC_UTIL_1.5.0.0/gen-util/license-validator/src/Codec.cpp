#include <des.h>
#include <Codec.h>

char *atohx(char *p_dst, const char *p_src)
{  
   char *l_ret = p_dst;
   for(int lsb, msb; *p_src; p_src += 2)
   {  
      msb = tolower(*p_src);
      lsb = tolower(*(p_src + 1));
      msb -= isdigit(msb) ? 0x30 : 0x57;
      lsb -= isdigit(lsb) ? 0x30 : 0x57;
      if((msb < 0x0 || msb > 0xf) || (lsb < 0x0 || lsb > 0xf))
      {
         *l_ret = 0;
         return NULL;
      }
      *p_dst++ = (char)(lsb | (msb << 4));  
   }
   //*p_dst = 0;
   return l_ret;
}

bool Codec::PrintHex(const char* str, const char* buf, const int len)
{
#if 0
   char tmpStr[1000], lTemp[5];
   if(len > 300)
   {
      printf("%s <Ln:%d> Length is more than 300. [len:%d]\n", __FUNCTION__, __LINE__, len);
      return false;
   }

   memset(tmpStr, 0, sizeof(tmpStr));
   for(int j=0; j<len; j++)
   {
      snprintf(lTemp, 4, "%02x ", buf[j]&0x00ff);
      strncat(tmpStr,lTemp,4);
   }

   printf( "%s <Ln:%d> %s [len:%d, buf:%s]\n", __FUNCTION__, __LINE__, str, len, tmpStr);
#endif

   return true;
}

Codec::Codec()
{
   memset(m_Key1, 0, sizeof(m_Key1));
   memset(m_Key2, 0, sizeof(m_Key2));
   memset(m_Key3, 0, sizeof(m_Key3));
}

void Codec::Cipher(char* in, int len, char* outData, int encdec)
{
   char key1[10]="";
   char key2[10]="";
   char key3[10]="";
   memset(key1, 0, sizeof(key1));
   memset(key2, 0, sizeof(key2));
   memset(key3, 0, sizeof(key3));
   memcpy(key1, m_Key1, sizeof(key1));
   memcpy(key2, m_Key2, sizeof(key2));
   memcpy(key3, m_Key3, sizeof(key3));

   PrintHex("Key1 value: ", key1, 8);
   PrintHex("Key2 value: ", key2, 8);
   PrintHex("Key3 value: ", key3, 8);
   char ivchar[] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
   char out[255]="";
   char dec[255]="";
   int i;

   DES_key_schedule ks1,ks2,ks3;
   DES_cblock iv;
   memcpy(iv, ivchar, sizeof(ivchar));

   DES_set_key((const_DES_cblock *)key1, &ks1);
   DES_set_key((const_DES_cblock *)key2, &ks2);
   DES_set_key((const_DES_cblock *)key3, &ks3);

   PrintHex("Input Data: ", in, len);
#if 0
   printf("\n Before encoding = ");
   for(i=0; i<len; i++)
   {
      printf(" %02x", in[i]&0x00ff);
   }
   printf("\n");
#endif

   DES_ede3_cbc_encrypt((const unsigned char*)in, (unsigned char*)out, len, &ks1, &ks2, &ks3, &iv, encdec);

   PrintHex("Output Data: ", out, len);
#if 1
   //printf("\n After encoding = ");
   for(i=0; i<len; i++)
   {
      outData[i] = out[i]&0x00ff;
      //printf(" %02x", out[i]&0x00ff);
   }
   //printf("\n");
#endif

#if 0
   memcpy(outData, out+len-8, 8);

   PrintHex("Computed RC/CC is ", outData, 8);
#if 1
   printf("\n Computed RC/CC is = ");
   for(i=0; i<8; i++)
   {
      printf(" %02x", outData[i]&0x00ff);
   }
   printf("\n");
#endif
#endif
#if 0
   memcpy(iv, ivchar, sizeof(ivchar));
   DES_set_key((const_DES_cblock *)key1, &ks1);
   DES_set_key((const_DES_cblock *)key2, &ks2);
   DES_set_key((const_DES_cblock *)key3, &ks3);

   DES_ede3_cbc_encrypt((const unsigned char*)out, (unsigned char*)dec, len, &ks1, &ks2, &ks3, &iv, DES_DECRYPT);

   PrintHex("After decoding (for verification): ", dec, len);
#if 0
   printf("\n After decoding = ");
   for(i=0; i<len; i++)
   {
      printf(" %02x", dec[i]&0x00ff);
   }
   printf("\n");
#endif
#endif

   memset(m_Key1, 0, sizeof(m_Key1));
   memset(m_Key2, 0, sizeof(m_Key2));
   memset(m_Key3, 0, sizeof(m_Key3));
}
