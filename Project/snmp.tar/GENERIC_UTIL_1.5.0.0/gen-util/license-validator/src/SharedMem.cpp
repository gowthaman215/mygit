#include <sys/types.h> 
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <iostream.h> /* For O_* constants */
#include <unistd.h>
#include <errno.h>
#include <fstream>
#include "LogOverride.h"
#include "LicenVal.h"
using namespace std;

extern int g_NumOfInst;
extern int g_ShmInterval;
extern char g_ProdName[9];
key_t g_Key;
void* MonitorSHM(void* p_Arg);

struct ProcDetails
{
   pid_t m_PID;
   time_t m_TIME;
};

int exec(char* p_Cmd, char* p_Output)
{
   FILE *fp;
   fp = popen(p_Cmd, "r");
   if (fp == NULL) 
   {
      UTIL_LOG('C', "Failed to run command" );
      return -1;
   }

   /*
      while (fgets(p_Output, 100-1, fp) != NULL) 
      {
      printf("%s", p_Output);
      }*/

   fgets(p_Output, 100-1, fp);
   pclose(fp);

   return 0;
}

bool CreateSHM(int index)
{
   int l_ShmId;
   ProcDetails *l_ProcDetails;


   if(index >= g_NumOfInst)
   {
      UTIL_LOG('C', "INVALID INSTANCE ID: %d", index+1);
      return false;
   }

   char l_FileName[20];
   snprintf(l_FileName, sizeof(l_FileName), "/etc/%s.lic", g_ProdName);
   //ofstream l_KeyFile(l_FileName, ofstream::binary);
   //l_KeyFile.write(g_ProdName, strlen(g_ProdName));
   //l_KeyFile.close();

   g_Key = ftok(l_FileName, 1);

   if (0 > (l_ShmId = shmget(g_Key, sizeof(ProcDetails)*g_NumOfInst, 0)))
   {
      UTIL_LOG('T', "mmm does not exist. Creating.");
      if (0 > (l_ShmId = shmget(g_Key, sizeof(ProcDetails)*g_NumOfInst, IPC_CREAT | 0666)))
      {
         UTIL_LOG('C', "Error in creating mmm. [errno:%d, err:%s]", errno, strerror(errno));
         return false;
      }

      if((l_ProcDetails = (ProcDetails*)shmat(l_ShmId, NULL, 0)) == (ProcDetails*) -1)
      {
         UTIL_LOG('C', "Error in attaching mmm [errno:%d, err:%s]", errno, strerror(errno));
         return false;
      }

      memset(l_ProcDetails, 0, sizeof(ProcDetails)*g_NumOfInst);
   }
   else
   {

      if((l_ProcDetails = (ProcDetails*)shmat(l_ShmId, NULL, 0)) == (ProcDetails*) -1)
      {
         UTIL_LOG('C', "Error in attaching mmm [errno:%d, err:%s]", errno, strerror(errno));
         return false;
      }
   }

   l_ProcDetails += index;


   if(l_ProcDetails->m_PID)
   {
      UTIL_LOG('T', "PID Exist in mmm [%d] Interval [%d]", l_ProcDetails->m_PID, g_ShmInterval);

      if(l_ProcDetails->m_PID != getpid())
      {
         if(l_ProcDetails->m_TIME + (g_ShmInterval+10) < time(NULL))
         {
            UTIL_LOG('T', "Allowing the exe");
         }
         else
         {
            UTIL_LOG('W', "Existing PID is active!!!! Cannot start this instance.");
            return false;
         }
      }


#if 0
      char l_Cmd[100];
      char l_Output[100];
      snprintf(l_Cmd, sizeof(l_Cmd), "ps -ef | grep %ld| grep -v grep ", l_ProcDetails->m_PID);
      memset(l_Output, 0, sizeof(l_Output));
      exec(l_Cmd, l_Output);
      UTIL_LOG('D', "PID search details [%s]", l_Output);

      if(strlen(l_Output) > 0)
      {
         UTIL_LOG('C', "Existing PID is active");
         return false;
      }
      else
         UTIL_LOG('T', "Existing PID is Not active");
#endif
   }

   l_ProcDetails->m_PID = getpid();
   l_ProcDetails->m_TIME = time(NULL);
   UTIL_LOG('T', "Inserting PID: %ld  TIME: %d", l_ProcDetails->m_PID, l_ProcDetails->m_TIME);


#if 0
   //UPGRADATION OF LICENSE 
   printf("\n mmm Deleting. ");
   if(-1 == shmctl(l_ShmId, IPC_RMID, (struct shmid_ds*) 0))
   {
      printf("\n Error in deleting mmm errno:%d, err:%s", errno, strerror(errno));
      return false;
   }

   if (0 > (l_ShmId = shmget(g_Key, sizeof(ProcDetails)*g_NumOfInst+1, IPC_CREAT | 0600)))
   {
      printf("\n Error in extending mmm errno:%d, err:%s", errno, strerror(errno));
      return false;
   }

   if((l_ProcDetails = (ProcDetails*)shmat(l_ShmId, NULL, 0)) == (ProcDetails*) -1)
   {
      printf("\n Error in attaching mmm ");
      return false;
   }

   l_ProcDetails += index;

   l_ProcDetails->m_PID = getpid();
   printf("\n Inserting PID: %ld \n", l_ProcDetails->m_PID);
#endif
   pthread_t   l_thread;
   pthread_attr_t l_attr;
   pthread_attr_init(&l_attr);
   pthread_attr_setdetachstate(&l_attr, PTHREAD_CREATE_DETACHED);

   if(0 != pthread_create(&l_thread, &l_attr, MonitorSHM, (void*)index))
   {
      UTIL_LOG('C', "Failed to create thread to monitor mmm [errno:%d, err:%s]", errno, strerror(errno));
      return false;
   }
   pthread_attr_destroy (&l_attr);
   return true;
}

void* MonitorSHM(void* p_Arg)
{
   int l_ShmId;
   ProcDetails *l_ProcDetails;
#ifdef SunOS
   int l_Index = (int) p_Arg;
#else
   int l_Index = 0;
#endif
   pid_t l_SelfPid = getpid();

   while(1)
   {
      if (0 > (l_ShmId = shmget(g_Key, sizeof(ProcDetails)*g_NumOfInst, 0)))
      {
         UTIL_LOG('C', "Error in getting mmm. [errno:%d, err:%s]", errno, strerror(errno));
         sleep(2);
         exit(1);
      }

      if((l_ProcDetails = (ProcDetails*)shmat(l_ShmId, NULL, 0)) == (ProcDetails*) -1)
      {
         UTIL_LOG('C', "Error in attaching mmm. [errno:%d, err:%s]", errno, strerror(errno));
         sleep(2);
         exit(1);
      }

      l_ProcDetails += l_Index;

      if(l_ProcDetails->m_PID)
      {
         if(l_SelfPid != l_ProcDetails->m_PID)
         {
            UTIL_LOG('C', "Already some process is running in the mmm. Exiting. [PID:%ld]", l_ProcDetails->m_PID);
            sleep(2);
            exit(1);
         }
         else
         {
            UTIL_LOG('D', "Self PID is in the mmm");
            l_ProcDetails->m_TIME = time(NULL);
            sleep(g_ShmInterval);
         }
      }
      else
      {
         UTIL_LOG('C', "No PID in the mmm. Exiting.");
         sleep(2);
         exit(1);
      }

      if( -1 == shmdt(l_ProcDetails-l_Index))
      {
         UTIL_LOG('C', "Error in detaching mmm. [errno:%d, err:%s]", errno, strerror(errno));
         sleep(2);
         exit(1);
      }
   }
}
