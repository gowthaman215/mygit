/************************************************************************************
 * FILE NAME      : LicenVal.cpp
 * REMARKS        :
 *************************************************************************************/

#include <LicenVal.h>
//#include "des.h"
#include "string.h"
#include <stdio.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#ifdef SunOS
#include <sys/sockio.h>
#endif
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fstream>
#include <XMLReader.h>

using namespace std;

extern void registerTraps();
extern char       g_RandKey[10];
extern XMLReader  g_xmlData;
int               g_NumOfInst;
long              g_SubscriberBase;
int               g_ShmInterval;
char              g_ProdName[9];
char              g_Action[2];
SubscriberBase*   g_sb;
int               g_firstVal=0;

int LicenVal::s_Count = 0;
int LicenVal::s_MaxInstance = 1;
bool CreateSHM(int);

LicenVal *g_lic = NULL;

LicenVal::~LicenVal()
{
   --s_Count;
}

LicenVal* LicenVal::GetInstance()
{
   LicenVal* ptr = NULL;

   //if(s_MaxInstance > s_Count)
   if(g_lic == NULL)
   {
      g_lic = new LicenVal();
      ++s_Count;                           // Increment no of instances
   }
   return g_lic;
}

void* subscriberCountThr(void *p_Interval)
{
#ifdef SunOS
   int l_interval = (int)p_Interval;
#else
   int l_interval = 60;
#endif
   //int l_SubsBaseTrap = g_si.registerSnmpTrap("SUBS_BASE", "Subscriber Base Exceeded");

   //sleep(3);

   long l_SubsCount=-1;
   while(1)
   {
      UTIL_LOG('D', "Initiating Subscriber Counting");
      g_sb->GetSubsCount(l_SubsCount);
      if(-2 == l_SubsCount)
      {
         UTIL_LOG('C',"Unable to retrieve data from DB");
         sleep(2);
         exit(1);
      }
      else if(-1 != l_SubsCount)
      {
         g_firstVal=1;
         UTIL_LOG('D', "Current Subscriber Count: %ld", l_SubsCount);
         if(l_SubsCount > g_SubscriberBase)
         {
            UTIL_LOG('C', "Subscriber Count exceeded Max limit. [Count:%ld, Max:%ld] Action[%c]", l_SubsCount, g_SubscriberBase, g_Action[0]);

            if(!strcmp(g_Action, "N"))
            {
               //send trap
               UTIL_LOG('W', "Action-Notify - Sending SnmpTrap");
               g_xmlData.sendSnmpTrap(g_SubsBaseTrap);
            }
            else //S
            {
               UTIL_LOG('W', "Action-Stop Sending SnmpTrap and Exiting !!!!!!!!!!");
               g_xmlData.sendSnmpTrap(g_SubsBaseTrap);
               sleep(2);
               exit(1);
            }
         }
         sleep(l_interval);
      }
      else
      {
         UTIL_LOG('C', "Subscriber Count not known yet");
         sleep(1);
      }
   }
}

bool  LicenVal::GetAllMacAddresses()
{
   char l_MacAddress[30];
   int   i,j,sock,nicount;
   char  octet[3];
   struct   arpreq arpreq;
   struct   ifreq nicnumber[24];
   struct   ifconf ifconf;

   memset(nicnumber,'\0',sizeof(nicnumber));
   memset(m_MacAddressList, '\0', sizeof(m_MacAddressList));
   memset(l_MacAddress, '\0', sizeof(l_MacAddress));

   if ((sock=socket(AF_INET,SOCK_DGRAM,0)) > -1) {
      ifconf.ifc_buf = (caddr_t)nicnumber;
      ifconf.ifc_len = sizeof(nicnumber);
   } else {
      UTIL_LOG('C',"Could not create socket. [errno:%d, err:%s]", errno, strerror(errno));
      return false;
   }

   if (!ioctl(sock,SIOCGIFCONF,(char*)&ifconf)) 
   {
      nicount = ifconf.ifc_len/(sizeof(struct ifreq));

      for (i = 0; i <= nicount; i++) 
      { 
         memset(l_MacAddress,'\0',sizeof(l_MacAddress));
         UTIL_LOG('D',"Interface: %s", nicnumber[i].ifr_name);

         ((struct sockaddr_in*)&arpreq.arp_pa)->sin_addr.s_addr=
            ((struct sockaddr_in*)&nicnumber[i].ifr_addr)->sin_addr.s_addr;
         if (!(ioctl(sock,SIOCGARP,(char*)&arpreq))) {

            for (j = 0; j <= 5; j++) {
               snprintf(octet,sizeof(octet),"%02x",
                     (unsigned char)arpreq.arp_ha.sa_data[j]);
               strcat (l_MacAddress,octet);
            }
         }

         snprintf(m_MacAddressList[i], 30, "%s", l_MacAddress);
         //strncpy(m_MacAddressList[i], l_MacAddress, 30-1);
         //m_MacAddressList[i][strlen(l_MacAddress)] = '\0';
         UTIL_LOG('D',"MAC Address: %s", l_MacAddress);
      }
      close(sock);
   } 
   else {
      close(sock);
      UTIL_LOG('C',"ioctl error. [errno:%d, err:%s]", errno, strerror(errno));
      return false;
   }

   //Host Id

   struct in_addr in;
   in.s_addr = gethostid();

   if (in.s_addr == INADDR_NONE) {
      UTIL_LOG('C',"gethostid failed. [errno:%d, err:%s]", errno, strerror(errno));
      return false;
   }
   sprintf(m_HostId, "%x", in.s_addr);
   UTIL_LOG('D',"hostid: %x", in.s_addr);

   return true;
}

bool LicenVal::ValidateLicense(char* p_MacAddr, char* p_HostId, char* p_ProdName, int& p_LicenseType, long& p_SubscriberBase, int& p_TransactionBase, int& p_NumOfInst, char* p_Action)
{
   UTIL_LOG('D', "Validating license with MacAddr:%s", p_MacAddr);
   atohx(m_Key1, p_MacAddr);
   strcpy(m_Key2, p_HostId);
   memcpy(m_Key3, g_RandKey, sizeof(m_Key3));

   //Read the license file and store in m_LFileData and size in l_Len
   memset(m_PlainData, 0, sizeof(m_PlainData));
   memset(m_LFileData, 0, sizeof(m_LFileData));

   int l_Len=0;
   ifstream fp;
   char l_FileName[15];
   snprintf(l_FileName, sizeof(l_FileName), "/etc/%s.lic", p_ProdName);
   UTIL_LOG('D', "Reading File: %s", l_FileName);
   fp.open(l_FileName,ifstream::binary);
   fp.seekg (0, ios::end);
   l_Len = fp.tellg();
   if(l_Len <= 0 )
   {
      fp.close();
      UTIL_LOG('C', "Unable to read the file: %s", l_FileName);
      return false;
   }
   UTIL_LOG('D', "Len of data:%d", l_Len);
   fp.seekg(0, ios::beg);

   fp.read(m_LFileData, l_Len);
   fp.close();


   UTIL_LOG('D', "Decoding license");

   Cipher(m_LFileData, l_Len, m_PlainData, DES_DECRYPT);
   //Cipher(m_LFileData, l_Len, m_PlainData, DES_ENCRYPT);

   if(NULL == strstr(m_PlainData, p_MacAddr))
   {
      UTIL_LOG('C', "MAC Address Validation failed");
      return false;
   }

   if(false == g_xmlData.readXMLData(m_PlainData))
   {
      UTIL_LOG('C', "XML parsing failed");
      return false;
   }

   if(!strcmp(g_xmlData.m_McaAddress,p_MacAddr))
   {
      UTIL_LOG('T', "MAC Address Validated.");
   }
   else
   {
      UTIL_LOG('C', "MAC Address Validation failed");
      return false;
   }
   if(!strcmp(g_xmlData.m_HostId,m_HostId))
   {
      UTIL_LOG('T', "Host ID Validated.");
   }
   else
   {
      UTIL_LOG('C', "Host ID Validation failed");
      return false;
   }
   if(!strcmp(g_xmlData.m_ProductName, p_ProdName))
   {
      UTIL_LOG('T', "Product Name has been validated.");
   }
   else
   {
      UTIL_LOG('C', "Product Name Validation failed.");
      return false;
   }
   p_LicenseType=g_xmlData.m_LicType;
   p_SubscriberBase=g_xmlData.m_NumSubscriber;
   p_TransactionBase=g_xmlData.m_TransPsec;
   p_NumOfInst=g_xmlData.m_NumInstance;
   p_Action[0] = g_xmlData.m_Action[0];
   p_Action[1] = '\0';

   //Parse the m_PlainData and get the outputs LicenseType, SubscriberBase, TransactionBase, NumOfInst along with MAC address and host id

   //Compare MAC address, Host id and Product Name

   UTIL_LOG('D', "Decoded buffer: %s", m_PlainData);

   return true;
}

bool LicenVal::Init(char* p_ProdName, const int p_ShmIndex, const int p_ShmInterval, const int p_SubsCntInterval, SubscriberBase *p_sb, int& p_LicenseType, int& p_TransactionBase, LogOverride *p_liclo)
{
   bool l_Pass = false;
   pthread_t   l_thread;
   pthread_attr_t l_attr;

   if(NULL == p_liclo)
   {
      UTIL_LOG('D', "Unable to find the licensing logger");
      g_xmlData.sendSnmpTrap(g_LicValTrap);
      return false;
   }
   g_lo = p_liclo;

   UTIL_LOG('D', "Getting All MAC address.");
   if(false == GetAllMacAddresses())
   {
      UTIL_LOG('C', "Getting MAC address & host id failed.");
      g_xmlData.sendSnmpTrap(g_LicValTrap);
      return false;
   }
   UTIL_LOG('D', "Getting MAC address success.");

   for(int i=0; i<10; i++)
   {
      if(strlen(m_MacAddressList[i]) > 0)
      {
         UTIL_LOG('D', "Validating MAC address %d", i+1);

         //Adding conversion to lower case
         char l_lowerMac[30];
         memset(l_lowerMac, '\0', sizeof(l_lowerMac));
         char l_lowerHostid[20];
         memset(l_lowerHostid, '\0', sizeof(l_lowerHostid));
         for(int l_k=0; l_k<strlen(m_MacAddressList[i]); l_k++)
         {
            l_lowerMac[l_k] = tolower(m_MacAddressList[i][l_k]);
         }
         for(int l_k=0; l_k<strlen(m_HostId); l_k++)
         {
            l_lowerHostid[l_k] = tolower(m_HostId[l_k]);
         }
         //End of adding conversion to lower case

         if(true == ValidateLicense(l_lowerMac, l_lowerHostid, p_ProdName, p_LicenseType, g_SubscriberBase, p_TransactionBase, g_NumOfInst, g_Action))
         {
            l_Pass = true;
            UTIL_LOG('T', "License is matched for %s.", m_MacAddressList[i]);
            break;
         }
         else
         {
            l_Pass = false;
            UTIL_LOG('C', "License is NOT matched for %s.", m_MacAddressList[i]);
         }
      }
   }
   if(false == l_Pass)
   {
      UTIL_LOG('C', "License is NOT matched with any of the MAC Addresses");
      g_xmlData.sendSnmpTrap(g_LicValTrap);
      return false;
   }

   g_ShmInterval = p_ShmInterval;
   snprintf(g_ProdName, sizeof(g_ProdName), "%s", p_ProdName);

   if(false == CreateSHM(p_ShmIndex))
   {
      UTIL_LOG('C', "Failed to create mmm [errno:%d, err:%s]", errno, strerror(errno));
      g_xmlData.sendSnmpTrap(g_LicValTrap);
      return false;
   }

   if(g_SubscriberBase > 0)
   {
      pthread_attr_init(&l_attr);
      pthread_attr_setdetachstate(&l_attr, PTHREAD_CREATE_DETACHED);
      UTIL_LOG('D', "Subs Count Interval:%d", p_SubsCntInterval);

      g_sb = p_sb;

      if(0 != pthread_create(&l_thread, &l_attr, subscriberCountThr, (void*)p_SubsCntInterval))
      {
         UTIL_LOG('C', "Failed to create thread to handle Subscriber Count [errno:%d, err:%s]", errno, strerror(errno));
      }
      pthread_attr_destroy (&l_attr);
   }
   registerTraps();
   return l_Pass;
}
