#ifndef INCL_CODEC_H
#define INCL_CODEC_H

#include <iostream>
#include <stdio.h>
#include <string>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
//#include <SnmpInterface.h>

char *atohx(char *p_dst, const char *p_src);

class Codec
{
   protected:
      char                 m_Key1[8];
      char                 m_Key2[8];
      char                 m_Key3[8];

   public:
      Codec();
      void      Cipher(char* in, int len, char* outData, int encdec);
      bool      PrintHex(const char* str, const char* buf, const int len);
};
#endif
