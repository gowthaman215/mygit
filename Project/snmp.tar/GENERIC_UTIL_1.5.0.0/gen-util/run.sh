export SYSTEM_OS=`uname -s`
