#include <StatisticsReInitializer.h>


StatisticsReInitializer *g_sg=StatisticsReInitializer::instance();

StatisticsReInitializer::StatisticsReInitializer()
{
}

StatisticsReInitializer::~StatisticsReInitializer()
{
}

int  StatisticsReInitializer::addHeader(ELogStatisticsPegType p_pegType, char *p_header, char *p_header2, char p_rep, MultiDimensionalData *p_mdd)
{
   if(true == m_initializedFlag)
   {
      UTIL_LOG('E',"addHeader should be called before initialization only");
      return -1;
   }

   if( (0 == strncmp(p_header, "MAX.", 4)) || (0 == strncmp(p_header, "VAL.", 4)))
   {
      UTIL_LOG('E',"addHeader Header should not start with MAX. or VAL.");
      return -1;
   }

   if(PEG_TYPE_4D_INCREMENT_COUNTER == p_pegType)
   {
      if((0 > p_mdd->m_hd.size()) || (p_mdd->m_hd.size() > MAX_2D_COUNTS))
      {
         UTIL_LOG('E',"addHeader 2DCount should be between 1 and %d", p_mdd->m_hd.size());
         return -1;
      }
      if(m_headerCount+p_mdd->m_hd.size() > MAX_NUMBER_STATISTICS_COUNTS)
      {
         UTIL_LOG('E', "addHeader called with 2D index:%d which is greater than the maximum %d possible", m_headerCount+p_mdd->m_hd.size(), MAX_NUMBER_STATISTICS_COUNTS);
         return -1;
      }
   }

   if(m_headerCount > MAX_NUMBER_STATISTICS_COUNTS)
   {
      UTIL_LOG('E', "addHeader called with index:%d which is greater than the maximum %d possible", m_headerCount, MAX_NUMBER_STATISTICS_COUNTS);
      return -1;
   }

   if(strlen(p_header)+strlen(p_header2) > MAX_SIZE_OF_STATISTICS_HEADER)
   {
      UTIL_LOG('E', "addHeader called with header:[%s:%s] which is greater than the maximum header length %d possible", 
            p_header, p_header2, MAX_SIZE_OF_STATISTICS_HEADER);
      return -1;
   }

   UTIL_LOG('T', "addHeader called with pegType:%d index:%d header:%s:%s rep:%c",  p_pegType, m_headerCount, p_header, p_header2, p_rep);
   if((PEG_TYPE_INCREMENT_COUNTER == p_pegType) || (PEG_TYPE_VALUE == p_pegType) || (PEG_TYPE_MAX_COUNTER == p_pegType))
   {
      if(PEG_TYPE_INCREMENT_COUNTER == p_pegType)
      {
         snprintf(m_headers[m_headerCount], sizeof(m_headers[m_headerCount]), "%s:%s",p_header, p_header2);
      }
      else if(PEG_TYPE_VALUE == p_pegType)
      {
         snprintf(m_headers[m_headerCount], sizeof(m_headers[m_headerCount]), "VAL.%s:%s",p_header, p_header2);
      }
      else if(PEG_TYPE_MAX_COUNTER == p_pegType)
      {
         snprintf(m_headers[m_headerCount], sizeof(m_headers[m_headerCount]), "MAX.%s:%s",p_header, p_header2);
      }
      m_reportCategory[m_headerCount] = p_rep;
      ++m_headerCount;
      return m_headerCount;
   }
   else if(PEG_TYPE_4D_INCREMENT_COUNTER == p_pegType)
   {
      int l_returnIndex = -1;
      StoredIndices *l_si = new StoredIndices;
      l_si->m_count = p_mdd->m_numOfColumns;
      UTIL_LOG('T', "addHeader called with 2dCount:%d", p_mdd->m_hd.size());
      int l_i=0;

      list<HeaderData> l_temp_list = p_mdd->m_hd;
      HeaderData l_hd_default;
      l_hd_default.m_h1 = DEFAULT_2D_DATA;
      l_hd_default.m_h2 = DEFAULT_2D_DATA;
      l_hd_default.m_h3 = DEFAULT_2D_DATA;
      l_temp_list.push_back(l_hd_default);
      for(list<HeaderData>::iterator l_list_iter=l_temp_list.begin(); l_list_iter != l_temp_list.end(); l_list_iter++)
      {
         UTIL_LOG('T', "addHeader called with 2d-Data::%d:[%s][%s][%s]", l_i, (*l_list_iter).m_h1.c_str(), (*l_list_iter).m_h2.c_str(),
               (*l_list_iter).m_h3.c_str());
         snprintf(m_headers[m_headerCount], sizeof(m_headers[m_headerCount]), "%s:%s",p_header, p_header2);
         if(p_mdd->m_numOfColumns >=1)
         {
            snprintf(m_2dData[m_headerCount], sizeof(m_2dData[m_headerCount]), "%s: %s", p_mdd->m_header1.c_str(), (*l_list_iter).m_h1.c_str());
         }
         if(p_mdd->m_numOfColumns >=2)
         {
            snprintf(m_2dData2[m_headerCount], sizeof(m_2dData2[m_headerCount]), "%s: %s", p_mdd->m_header2.c_str(), (*l_list_iter).m_h2.c_str());
         }
         if(p_mdd->m_numOfColumns >=3)
         {
            snprintf(m_2dData3[m_headerCount], sizeof(m_2dData3[m_headerCount]), "%s: %s", p_mdd->m_header3.c_str(), (*l_list_iter).m_h3.c_str());
         }
         m_reportCategory[m_headerCount] = p_rep;
         ++m_headerCount;

         string l_temp_string_to_be_stored;
         if(1 == p_mdd->m_numOfColumns)
         {
            l_temp_string_to_be_stored = (*l_list_iter).m_h1;
         }
         else if(2 == p_mdd->m_numOfColumns)
         {
            l_temp_string_to_be_stored = (*l_list_iter).m_h1 + "|" + (*l_list_iter).m_h2;
         }
         else if(3 == p_mdd->m_numOfColumns)
         {
            l_temp_string_to_be_stored = (*l_list_iter).m_h1 + "|" + (*l_list_iter).m_h2 + "|" + (*l_list_iter).m_h3;
         }

         l_si->m_data[l_temp_string_to_be_stored] = m_headerCount;

         if(0 == l_i)
         {
            l_returnIndex = m_headerCount;
         }
         l_i++;
      }
      m_2DMap[l_returnIndex] = l_si;
      return l_returnIndex;
   }
   else
   {
      UTIL_LOG('E', "addHeader Invalid PEG_TYPE:%d", p_pegType);
      return -1;
   }
}

bool StatisticsReInitializer::updateHeaderDesc(int p_headerIndex, ELogStatisticsPegType p_pegType, char *p_header, char *p_header2, char p_rep)
{
   if(false == m_initializedFlag)
   {
      UTIL_LOG('E',"updateHeaderDesc should be called after initialization only");
      return false;
   }

   if(p_headerIndex > m_headerCount-1)
   {
      UTIL_LOG('E', "updateHeaderDesc The index %d is beyond the max headers created %d", p_headerIndex-1, m_headerCount);
      return false;
   }

   if(strlen(p_header)+strlen(p_header2) > MAX_SIZE_OF_STATISTICS_HEADER)
   {
      UTIL_LOG('E', "updateHeaderDesc called with header:[%s:%s] which is greater than the maximum header length %d possible", 
            p_header, p_header2, MAX_SIZE_OF_STATISTICS_HEADER);
      return false;
   }

   pthread_mutex_lock(&m_mutex);
   UTIL_LOG('L', "updateHeaderDesc called with pegType:%d index:%d header:%s:%s rep:%c",  p_pegType, p_headerIndex-1, p_header, p_header2, p_rep);
   if((PEG_TYPE_INCREMENT_COUNTER == p_pegType) || (PEG_TYPE_VALUE == p_pegType) || (PEG_TYPE_MAX_COUNTER == p_pegType))
   {
      if(PEG_TYPE_INCREMENT_COUNTER == p_pegType)
      {
         snprintf(m_headers[p_headerIndex-1], sizeof(m_headers[p_headerIndex-1]), "%s:%s",p_header, p_header2);
      }
      else if(PEG_TYPE_VALUE == p_pegType)
      {
         snprintf(m_headers[p_headerIndex-1], sizeof(m_headers[p_headerIndex-1]), "VAL.%s:%s",p_header, p_header2);
      }
      else if(PEG_TYPE_MAX_COUNTER == p_pegType)
      {
         snprintf(m_headers[p_headerIndex-1], sizeof(m_headers[p_headerIndex-1]), "MAX.%s:%s",p_header, p_header2);
      }
      m_reportCategory[p_headerIndex-1] = p_rep;
      if(NULL != m_startStatsPtr)
      {
         UTIL_LOG('L', "updateHeaderDesc m_startStatsPtr is not null. Updating in the file too");
         strcpy(((stats100x*)m_startStatsPtr)->m_headers[p_headerIndex-1], m_headers[p_headerIndex-1]);
         strcpy(((stats100x*)m_startStatsPtr)->m_2dData[p_headerIndex-1], m_2dData[p_headerIndex-1]);
         strcpy(((stats100x*)m_startStatsPtr)->m_2dData2[p_headerIndex-1], m_2dData2[p_headerIndex-1]);
         strcpy(((stats100x*)m_startStatsPtr)->m_2dData3[p_headerIndex-1], m_2dData3[p_headerIndex-1]);
         ((stats100x*)m_startStatsPtr)->m_reportCategory[p_headerIndex-1] = m_reportCategory[p_headerIndex-1];
      }
      else
      {
         UTIL_LOG('L', "updateHeaderDesc m_startStatsPtr is null. Not updating in the file");
      }
      pthread_mutex_unlock(&m_mutex);
      return true;
   }
   else
   {
      pthread_mutex_unlock(&m_mutex);
      return false;
   }
}

bool StatisticsReInitializer::setApplicationName( char *p_appName)
{
   UTIL_LOG('L', "setApplicationName called with AppName:%s", p_appName);

   if(strlen(p_appName) > MAX_PRODUCT_NAME_SIZE)
   {
      UTIL_LOG('E', "setApplicationName called with name:%s which is greater than the maximum header length %d possible", 
            p_appName, MAX_PRODUCT_NAME_SIZE);
      return false;
   }

   strcpy(m_productName, p_appName);
   return true;

}
bool StatisticsReInitializer::setApplicationVersion( char *p_version)
{
   UTIL_LOG('L', "setApplicationVersion called with AppVer:%s", p_version);

   if(strlen(p_version) > MAX_PRODUCT_VERSION_SIZE)
   {
      UTIL_LOG('E', "setApplicationVersion called with version:%s which is greater than the maximum header length %d possible", 
            p_version, MAX_PRODUCT_VERSION_SIZE);
      return false;
   }

   strcpy(m_productVersion, p_version);
   return true;

}

bool StatisticsReInitializer::initialize(char *p_path, char *p_EntityName)
{
   UTIL_LOG('L',"start of StatisticsReInitializer initialize func");
   m_slotsInADay = 24;

   if((strlen(p_EntityName) < 1) || (strlen(p_EntityName) > MAX_ENTITY_NAME_LENGTH))
   {
      UTIL_LOG('C',"Invalid Entity Name. Should not be greater than %d bytes", MAX_ENTITY_NAME_LENGTH);
      return false;
   }

   char *l_gutilDebugLogs = getenv("GUTIL_DEBUG_LOGS");
   if(NULL != l_gutilDebugLogs)
   {
      if(NULL != strstr(l_gutilDebugLogs, "STAT"))
      {
         m_debugLogs = true;
         UTIL_LOG('T', "GUTIL_DEBUG_LOGS is enabled for STAT. Shall print debug logs too");
      }
   }


   if(true == g_si.m_initializedFlag)
   {
      if(0 != strcmp(g_selfEntityName, p_EntityName))
      {
         UTIL_LOG('C',"Invalid Entity Name. It should be same as what is passed to the SNMP Interface ");
         return false;
      }

      g_statsTemporaryErrorTrapId = g_si.registerSnmpTrap("STATS", "Statistics error",SNMP_INTERNAL_UNIQUE_TRAP_SEQUENCE_STATS);
      if(g_statsTemporaryErrorTrapId < 0)
      {
         UTIL_LOG('E',"initialize: Unable to register the trap %d. Check whether SNMP is enabled.", g_statsTemporaryErrorTrapId);
         return false;
      }
   }
   snprintf(g_selfEntityName, MAX_ENTITY_NAME_LENGTH, "%s", p_EntityName);

   if (strlen(p_path) < 1)
   {
      UTIL_LOG('C',"Invalid File Path");
      return false;
   }

   m_maxNumberOfColumns=MAX_NUMBER_STATISTICS_COUNTS;

   if( (strlen(g_ipAddress)> 0) || (strlen(g_selfEntityName) > 0))
   {
      snprintf(m_entityName, sizeof(m_entityName), "%s:%s", g_selfEntityName, g_ipAddress);
   }

   pthread_mutex_init(&m_mutex, NULL);

   UTIL_LOG('L',"Number of SNMP Traps registered %d", g_si.m_trapCount);
   for(int i=0; i<g_si.m_trapCount; i++)
   {
      char l_tempChar[100+1];
      snprintf(l_tempChar, sizeof(l_tempChar), "%d:%s", g_si.m_uniqueTrapSequenceId[i], g_si.m_trapId[i]);

      g_si.m_trapStatsIndex[0][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar,         "TRIG:PASS",   'T');
      g_si.m_trapStatsIndex[1][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar,         "TRIG:FAIL",   'T');
      g_si.m_trapStatsIndex[2][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar,         "TRIG:NORMAL", 'T');

      g_si.m_trapStatsFilteredIndex[0][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar, "DELV:PASS",   'T');
      g_si.m_trapStatsFilteredIndex[1][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar, "DELV:FAIL",   'T');
      g_si.m_trapStatsFilteredIndex[2][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar, "DELV:NORMAL", 'T');
      UTIL_LOG('L', "Registered SNMP Trap [%s] for statistics indices %d", l_tempChar, 
            g_si.m_trapStatsIndex[0][i], g_si.m_trapStatsIndex[1][i], g_si.m_trapStatsIndex[2][i],
            g_si.m_trapStatsFilteredIndex[0][i], g_si.m_trapStatsFilteredIndex[1][i], g_si.m_trapStatsFilteredIndex[2][i]);

   }


   char l_dir[1000+1];
   memset(l_dir, '\0', sizeof(l_dir));
   snprintf(l_dir, sizeof(l_dir), "%s", p_path);
   snprintf(m_filePath, sizeof(m_filePath), "%s", l_dir);

   struct stat l_sbuf;
   if (stat(l_dir, &l_sbuf) == -1) 
   {
      UTIL_LOG('L',"stat command for dir [%s] failed with error [%s]. hence creating directory", l_dir, strerror(errno));
      int l_DirCreationMode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH  | S_IXUSR | S_IXGRP | S_IXOTH; 
      UTIL_LOG('L',"Creating Directory : %s", l_dir);
      int l_dirResult = mkdir(l_dir, l_DirCreationMode);
      if(-1 == l_dirResult) 
      {
         UTIL_LOG('E',"Error in creating statistics directory: %s", l_dir);
         return false;
      }
   }
   else
   {
      UTIL_LOG('L',"stat command for dir is success");
   }
   if(false == getStatsPtr())
   {
      return false;
   }
   if(NULL != m_startStatsPtr)
   {
      (((stats100x*)m_startStatsPtr)->m_startCount[m_slot])++;
   }
   m_initializedFlag=true;

   for(int i=0; i<g_si.m_trapCount; i++)
   {
      if(g_si.m_InitialTrapStatsCounts[0][i])
         g_sg->logStatistics(g_si.m_trapStatsIndex[0][i]);
      if(g_si.m_InitialTrapStatsCounts[1][i])
         g_sg->logStatistics(g_si.m_trapStatsIndex[1][i]);
      if(g_si.m_InitialTrapStatsCounts[2][i])
         g_sg->logStatistics(g_si.m_trapStatsIndex[2][i]);

      if(g_si.m_InitialTrapStatsFilteredCounts[0][i])
         g_sg->logStatistics(g_si.m_trapStatsFilteredIndex[0][i]);
      if(g_si.m_InitialTrapStatsFilteredCounts[1][i])
         g_sg->logStatistics(g_si.m_trapStatsFilteredIndex[1][i]);
      if(g_si.m_InitialTrapStatsFilteredCounts[2][i])
         g_sg->logStatistics(g_si.m_trapStatsFilteredIndex[2][i]);
   }
   return true;
}



bool StatisticsReInitializer::getReportsList(char *p_text, unsigned int p_maxSizeOfText)
{
   if(true == m_debugLogs)
   {
      UTIL_LOG('D', "getReportsList called with size %d", p_maxSizeOfText);
   }
   if(p_maxSizeOfText < 10)
   {
      UTIL_LOG('E', "p_maxSizeOfText should be atleast 10");
      return false;
   }
   memset(p_text, '\0', sizeof(p_maxSizeOfText));
   if(false == m_initializedFlag)
   {
      UTIL_LOG('W',"getReportsList sg not initialized");
      return false;
   }

   if(m_headerCount > 0)
   {
      UTIL_LOG('L', "getReportsList HeaderCount:%d", m_headerCount);

#define MAX_REPORTS    100
      char l_repCategories[MAX_REPORTS];
      memset(l_repCategories, '\0', sizeof(l_repCategories));
      int  l_repStartCount[MAX_REPORTS];
      int  l_repEndCount[MAX_REPORTS];

      int l_repCount=0;
      for(int l_i=0; l_i<m_headerCount && l_repCount<MAX_REPORTS; l_i++)
      {
         if(true == m_debugLogs)
         {
            UTIL_LOG('T', "getReportsList m_reportCategory:%c l_repCategories:%c", m_reportCategory[l_i], l_repCategories[l_repCount]);
         }
         if(0 == l_i)
         {
            if(true == m_debugLogs)
            {
               UTIL_LOG('T',"start 0");
            }
            l_repCategories[l_repCount] = m_reportCategory[l_i];
            l_repStartCount[l_repCount] = 1+l_i;
            l_repCount++;
         }
         else 
         {
            if(m_reportCategory[l_i] != l_repCategories[l_repCount-1]) //start
            {
               if(true == m_debugLogs)
               {
                  UTIL_LOG('T',"start");
               }
               l_repCategories[l_repCount] = m_reportCategory[l_i];
               l_repStartCount[l_repCount] = 1+l_i;
               l_repEndCount[l_repCount-1] = l_i;
               l_repCount++;
            }
         }
      }
      l_repEndCount[l_repCount-1]=m_headerCount;

      snprintf(p_text, p_maxSizeOfText, "\nReportsList:\n");
      char l_reportData[100+1];
      for(int l_j=0; l_j<l_repCount; l_j++)
      {
         snprintf(l_reportData, sizeof(l_reportData), 
               "\nReport %02d:  Type:%c  Start:%5d  End:%5d", 1+l_j, l_repCategories[l_j], l_repStartCount[l_j], l_repEndCount[l_j]);
         strlcat(p_text, l_reportData, p_maxSizeOfText);
      }
      strlcat(p_text, "\n", p_maxSizeOfText);
   }
   else
   {
      snprintf(p_text, p_maxSizeOfText, "No Reports.");
   }
   return true;
}



bool StatisticsReInitializer::getReportData(int p_start, int p_end, char *p_text, unsigned int p_maxTextSize)
{
   if(true == m_debugLogs)
   {
      UTIL_LOG('D', "getReportData called with size %d. start:%d end:%d", p_maxTextSize, p_start, p_end);
   }
   if(p_maxTextSize < 10)
   {
      UTIL_LOG('E', "p_maxSizeOfText should be atleast 10");
      return false;
   }
   snprintf(p_text, p_maxTextSize, "Report Data: Some Error");
   if(false == m_initializedFlag)
   {
      UTIL_LOG('W',"getReportData sg not initialized");
      return false;
   }
   char l_additionalText[1000+1];

   if(
         (p_start < 1) || 
         (p_start > m_headerCount) ||
         (p_end < 1) || 
         (p_end > m_headerCount)
     )
   {
      snprintf(p_text, p_maxTextSize, "begin %d and end %d should be between 1 and %d", p_start, p_end, m_headerCount);
      getReportsList(l_additionalText, sizeof(l_additionalText)-1);
      strlcat(p_text, l_additionalText, p_maxTextSize);
      UTIL_LOG('W', "%s", p_text);
      return false;
   }

   if(p_start > p_end)
   {
      snprintf(p_text, p_maxTextSize, "begin %d should be less than or equal to end %d", p_start, p_end);
      getReportsList(l_additionalText, sizeof(l_additionalText)-1);
      strlcat(p_text, l_additionalText, p_maxTextSize);
      UTIL_LOG('W', "%s", p_text);
      return false;
   }

   if((p_end-p_start) > 50)
   {
      snprintf(p_text, p_maxTextSize, "begin %d and end %d diff should be max 50", p_start, p_end);
      getReportsList(l_additionalText, sizeof(l_additionalText)-1);
      strlcat(p_text, l_additionalText, p_maxTextSize);
      UTIL_LOG('W', "%s", p_text);
      return false;
   }

   if(NULL != m_startStatsPtr)
   {
      pthread_mutex_lock(&m_mutex);
      UTIL_LOG('L', "getReportData m_startStatsPtr is not null. Getting the data");
      char l_reportDataEach[100+1];
      snprintf(p_text, p_maxTextSize, "\n");
      for(int l_i=p_start; l_i<=p_end; l_i++)
      {
         snprintf(l_reportDataEach, sizeof(l_reportDataEach), "\n%5d  R%c  %-50s %-50s %-50s %-50s : %5d", 
               l_i,
               ((stats100x*)m_startStatsPtr)->m_reportCategory[l_i-1],
               ((stats100x*)m_startStatsPtr)->m_headers[l_i-1],
               ((stats100x*)m_startStatsPtr)->m_2dData[l_i-1],
               ((stats100x*)m_startStatsPtr)->m_2dData2[l_i-1],
               ((stats100x*)m_startStatsPtr)->m_2dData3[l_i-1],
               ((stats100x*)m_startStatsPtr)->m_count[m_slot][l_i-1]);
         strlcat(p_text, l_reportDataEach, p_maxTextSize);
      }
      pthread_mutex_unlock(&m_mutex);
   }
   else
   {
      if(true == m_debugLogs)
      {
         UTIL_LOG('D', "getReportData m_startStatsPtr is NULL");
      }
   }

   return true;
}


