#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>
#include <StatisticsGenerator.h>
#include <LogOverride.h>
#include <SnmpInterface.h>
#include <list>
#include <StatisticsInitializationHelper.h>


extern char g_ipAddress[];
extern char g_selfEntityName[];
StatisticsGenerator *m_sg;
int g_fileSize;

bool    g_statsTemporaryErrorFlag = false;
time_t  g_statsTemporaryErrorTime = 0;
int     g_statsTemporaryErrorTrapId;

StatisticsGenerator::StatisticsGenerator()
{
	UTIL_LOG('L',"StatisticsGenerator :cons:");
	m_slotsInADay=-1;
	m_day=-1;
	m_slot=-1;
	m_initializedFlag=false;
	m_stats= NULL;
	m_startStatsPtr= NULL;
	m_mappingFlag=false;
	m_fd=-1;

	m_headerCount=0;
	//m_stats = new FullStats;
	memset(m_headers, '\0', sizeof(m_headers));
	memset(&m_pegTypeArray, '\0', sizeof(m_pegTypeArray));
	memset(m_2dData, '\0', sizeof(m_2dData));
	memset(m_2dData2, '\0', sizeof(m_2dData2));
	memset(m_2dData3, '\0', sizeof(m_2dData3));
	memset(m_productName, '\0', sizeof(m_productName));
	memset(m_productVersion, '\0', sizeof(m_productVersion));
	m_debugLogs=false;
}

StatisticsGenerator::~StatisticsGenerator()
{
	UTIL_LOG('L',"StatisticsGenerator :des:");
	if(NULL != m_startStatsPtr)
	{
		if(0 ==  munmap(m_startStatsPtr, g_fileSize))
		{
			UTIL_LOG('L',"Stats munmap success");
		}
		else
		{
			UTIL_LOG('E',"Stats munmap failure errno: %d", errno);
		}
	}
	m_startStatsPtr=NULL;
	map<int, StoredIndices*>::iterator l_iter;
	UTIL_LOG('L',"Deleting map data");
	for(l_iter = m_2DMap.begin(); l_iter != m_2DMap.end(); l_iter++)
	{
		delete(l_iter->second);
	}
	UTIL_LOG('L',"End of deleting map data");

	UTIL_LOG('L',"StatisticsGenerator end of :des:");
}

Stats* StatisticsGenerator::getStartStatsPtr()
{
	//TODOreturn m_startStatsPtr->m_slots;
	return NULL;
}


int StatisticsGenerator::getTotalStatsSize()
{
	return (m_slotsInADay * sizeof(Stats));
}



void StatisticsGenerator::print()
{
	printf("\nCalling StatisticsGenerator::print()\n");
	if (false == m_initializedFlag)
	{
		//printf("\nStatistics Manager is not initialized");
		return;
	}

	if(NULL == m_stats)
	{
		UTIL_LOG('C',"ERROR!! m_stats is NULL");
		return;
	}
}
struct stats100x g_statsChangedData;
struct stats100x l_stats;
extern int       g_firstTimeStats;


bool StatisticsGenerator::getStatsPtr()
{
	/*
		 if (false == m_initializedFlag)
		 {
		 UTIL_LOG('C',"Statistics Manager is not initialized");
		 return false;
		 }
		 */

	//Using the global time struct set in CurrentTime;s setCurrentTime
	struct tm *g_timeStruct=NULL;
	time_t l_tim =time(NULL);
	g_timeStruct = localtime(&l_tim);

	if (g_timeStruct->tm_mday != m_day)
	{
		if (-1 == m_day)
		{
			if(true == g_firstTimeStats)
			{
				UTIL_LOG('L',"This is at application startup");
			}
			else
			{
				UTIL_LOG('L',"This is at a re-initialization of stats");
			}
		}
		else
		{
			UTIL_LOG('L',"This is a day change");

			if (NULL != m_startStatsPtr)
			{
				UTIL_LOG('L',"MUNMAP size:%d", g_fileSize);
				if(0 ==  munmap(m_startStatsPtr, g_fileSize))
				{
					UTIL_LOG('L',"Stats munmap success");
				}
				else
				{
					UTIL_LOG('E',"Stats munmap failure errno: %d", errno);
				}
				m_startStatsPtr=NULL;
				if(m_fd>-1)
				{
					UTIL_LOG('L',"closing the fd:%d after munmap", m_fd);
					close(m_fd);
				}
			}
		}

		UTIL_LOG('L', "Stats: FilePath:%s, ProductName:%s, EntityName:%s", m_filePath, m_productName, g_selfEntityName);

		struct stat sbuf;
		char l_fileName[400];
		memset(l_fileName, '\0', sizeof(l_fileName));
		sprintf(l_fileName, "%s/%s_%s_%s_%04u_%02u_%02u", 
				m_filePath,
				"stats", 
				m_productName,
				g_selfEntityName,
				g_timeStruct->tm_year+1900,
				g_timeStruct->tm_mon+1, 
				g_timeStruct->tm_mday);

		int l_fileCreationMode = S_IRWXU | S_IRWXG | S_IRWXO;
		int l_flags = O_RDWR | O_CREAT | O_APPEND;

		if ((m_fd = open(l_fileName, O_RDWR)) == -1) 
		{
			if ((m_fd = open(l_fileName, l_flags, l_fileCreationMode)) == -1) 
			{
				UTIL_LOG('C',"Unable to create the file");
				return false;
			}
			else
			{
				UTIL_LOG('L',"Created file fd %d. stats100xLength:%d, StatsHeaderLength:%d", m_fd, sizeof(stats100x), sizeof(StatsHeader));
				int l_written=0;

				memset(&l_stats, '\0', sizeof(l_stats));
				strcpy(l_stats.m_productName, m_productName);
				strcpy(l_stats.m_productVersion, m_productVersion);
				strcpy(l_stats.m_entityName, m_entityName);
				l_stats.m_maxNumberOfColumns = m_maxNumberOfColumns;
				l_stats.m_currentNumberOfColumns=m_headerCount;
				l_stats.m_fut = time(NULL);
				for(int i=0; i<l_stats.m_maxNumberOfColumns; i++)
				{
					strcpy(l_stats.m_headers[i], m_headers[i]);
					strcpy(l_stats.m_2dData[i], m_2dData[i]);
					strcpy(l_stats.m_2dData2[i], m_2dData2[i]);
					strcpy(l_stats.m_2dData3[i], m_2dData3[i]);
				}
				snprintf(l_stats.m_reportCategory, sizeof(m_reportCategory), m_reportCategory);

            int l_totalWritten=0;
            UTIL_LOG('L', "FD is %d", m_fd);
            unsigned char *l_char = (unsigned char *)&l_stats;
            while (l_totalWritten < sizeof(l_stats))
            {
               UTIL_LOG('L', "Trying to write %d bytes", sizeof(l_stats)-l_totalWritten);
				   l_written = write(m_fd, l_char+l_totalWritten, sizeof(l_stats)-l_totalWritten);
               if(-1 == l_written)
               {
                  UTIL_LOG('E',"write failed into fd:%d errno:%d desc:%s", m_fd, errno, strerror(errno));
                  break;
               }
               else
               {
                  l_totalWritten += l_written;
                  UTIL_LOG('L',"Written %d bytes (cumulative %d bytes) of %d bytes", l_written, l_totalWritten, sizeof(l_stats));
               }
            }
				if (l_totalWritten != sizeof(l_stats))
				{
					UTIL_LOG('C',"Now probably there is no space in the disk. Tried to write %d but written only %d", sizeof(l_stats),  l_totalWritten);
					if(m_fd>0)
					{
						UTIL_LOG('C',"Closing the descriptor %d", m_fd);
						close(m_fd);
					}
					return false;
				}
				else
				{
					UTIL_LOG('L',"Writing the statistics file success. ");
					/*
						 UTIL_LOG('L',"Writing the application header[%d] into statistics file success. MaxNumberOfColumns[%d]", 
						 sizeof(FullStats), l_stats.m_maxNumberOfColumns);

						 char l_header[l_stats.m_maxNumberOfColumns][MAX_SIZE_OF_STATISTICS_HEADER+1];
						 memset(l_header, '\0', sizeof(l_header));

						 l_written = write(m_fd, l_header, sizeof(l_header));
						 if (l_written != sizeof(l_header))
						 {
						 UTIL_LOG('C',"Probably there is no space in the disk");
						 if(m_fd>0)
						 {
						 UTIL_LOG('C',"Closing the descriptor %d", m_fd);
						 close(m_fd);
						 }
						 return false;
						 }

						 UTIL_LOG('D',"Writing the column headers [%d] success. Writing values into the file", sizeof(l_header));
						 int k=0;
						 for(int j=1; j<=l_stats.m_maxNumberOfColumns; j++)
						 {
						 for(int i=1; i<=24; i++)
						 {
						 ++k;
						 long value=0;//[l_stats.m_maxNumberOfColumns];
						 l_written = write(m_fd, &value, sizeof(value));
						 if (l_written != sizeof(value))
						 {
						 UTIL_LOG('C',"Index %d Probably there is no space in the disk", i);
						 if(m_fd>0)
						 {
						 UTIL_LOG('C',"Index %d Closing the descriptor %d", i, m_fd);
						 close(m_fd);
						 }
						 return false;
						 }
						 }
						 }
						 UTIL_LOG('D',"Written %d values into the file. Total size[%d]", k, k*sizeof(long));
						 */
				}
			}
		}
		else
		{
			UTIL_LOG('C',"Opened existing file %s %d", l_fileName, m_fd);
		}

		int l_expectedSize = m_slotsInADay * sizeof(Stats);
		if (stat(l_fileName, &sbuf) == -1) {
			UTIL_LOG('E',"stat command failed %s", strerror(errno));
			return false;
		}

		/*
			 if (l_expectedSize != sbuf.st_size)
			 {
			 UTIL_LOG('E',"Expected Size is %d, But File existing with size %d", l_expectedSize, sbuf.st_size);
			 if(m_fd>0)
			 {
			 UTIL_LOG('C',"Closing the descriptor %d", m_fd);
			 close(m_fd);
			 }
			 UTIL_LOG('L',"Removing the file [%s]", l_fileName);
			 int l_removeResult = remove(l_fileName);
			 if (0 == l_removeResult)
			 {
			 UTIL_LOG('L',"Removing file success");
			 }
			 else
			 {
			 UTIL_LOG('L',"Removing file failure: %d", errno);
			 }

			 return false;
			 }
			 */

		UTIL_LOG('L',"Calling mmap size[%d]", sbuf.st_size);
		g_fileSize=sbuf.st_size;

		m_startStatsPtr =  (StatsHeader*) mmap((caddr_t)0, sbuf.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, m_fd, 0);
		if ((caddr_t)m_startStatsPtr == (caddr_t)(-1)) 
		{
			//perror("mmap");
			UTIL_LOG('C',"mmap command failed %s", strerror(errno));
			if(m_fd>0)
			{
				UTIL_LOG('E',"Closing the descriptor %d", m_fd);
				close(m_fd);
			}
			return false;
		}
		else
		{

			UTIL_LOG('C',"mmap command success");
			UTIL_LOG('L',"File Data Name[%s], Version[%s], EntityName[%s], MaxNumbOfColumns[%d], CurrentNumOfColumns[%d], Fut[%d], Lut[%d]", 
					m_startStatsPtr->m_productName,
					m_startStatsPtr->m_productVersion,
					m_startStatsPtr->m_entityName,
					m_startStatsPtr->m_maxNumberOfColumns,
					m_startStatsPtr->m_currentNumberOfColumns,
					m_startStatsPtr->m_fut,
					m_startStatsPtr->m_lut);

			UTIL_LOG('L',"Application Data Name[%s], Version[%s], EntityName[%s], MaxNumbOfColumns[%d], CurrentNumOfColumns[%d]", 
					m_productName,
					m_productVersion,
					m_entityName,
					m_maxNumberOfColumns,
					m_headerCount);

			if(0 != strcmp(m_startStatsPtr->m_productName, m_productName))
			{
				UTIL_LOG('C',"Product Name mismatch. File Product Name [%s], Application Product Name [%s]", 
						m_startStatsPtr->m_productName, m_productName);
				return false;
			}

			int l_min = m_startStatsPtr->m_currentNumberOfColumns;
			if(m_headerCount < m_startStatsPtr->m_currentNumberOfColumns)
			{
				UTIL_LOG('W',"File has more number of columns %d than the current application %d", 
						m_startStatsPtr->m_currentNumberOfColumns, m_headerCount);
				l_min = m_headerCount;
			}

			UTIL_LOG('L',"Checking if the file has to be refreshed");
			bool l_areHeadersChangedFlag=false;
			for(int i=0; i<l_min; i++)
			{
				if(
						(0 != strcmp(((stats100x*)m_startStatsPtr)->m_headers[i], m_headers[i])) ||
						(0 != strcmp(((stats100x*)m_startStatsPtr)->m_2dData[i], m_2dData[i])) ||
						(0 != strcmp(((stats100x*)m_startStatsPtr)->m_2dData2[i], m_2dData2[i])) ||
						(0 != strcmp(((stats100x*)m_startStatsPtr)->m_2dData3[i], m_2dData3[i]))
					)
				{
					l_areHeadersChangedFlag=true;
					UTIL_LOG('C', "%dth header didn't match. File has [%s] while application is saying [%s]", 
							1+i, ((stats100x*)m_startStatsPtr)->m_headers[i], m_headers[i]);
					break;
				}
			}
			if(true == l_areHeadersChangedFlag)
			{
				UTIL_LOG('L',"Refreshing the counts...");
				memset(&g_statsChangedData, '\0', sizeof(g_statsChangedData));

				g_statsChangedData.m_fut = m_startStatsPtr->m_fut;
				for(int i=0; i<24; i++)
				{
					g_statsChangedData.m_startCount[i] = ((stats100x*)m_startStatsPtr)->m_startCount[i];
				}
				for(int i=0; i<m_headerCount; i++)
				{
					strcpy(g_statsChangedData.m_headers[i], m_headers[i]);
					strcpy(g_statsChangedData.m_2dData[i], m_2dData[i]);
					strcpy(g_statsChangedData.m_2dData2[i], m_2dData2[i]);
					strcpy(g_statsChangedData.m_2dData3[i], m_2dData3[i]);
					g_statsChangedData.m_reportCategory[i]= m_reportCategory[i];
				}

				for(int i=0; i<m_startStatsPtr->m_currentNumberOfColumns; i++)
				{
					UTIL_LOG('D',"Checking the presence of %d %s", i+1, ((stats100x*)m_startStatsPtr)->m_headers[i]);
					bool l_headerFound=false;
					int j=0;
					for(j=0; j<m_headerCount; j++)
					{
						if(
								(0 == strcmp(m_headers[j], ((stats100x*)m_startStatsPtr)->m_headers[i])) &&
								(0 == strcmp(m_2dData[j],  ((stats100x*)m_startStatsPtr)->m_2dData[i]))  &&
								(0 == strcmp(m_2dData2[j], ((stats100x*)m_startStatsPtr)->m_2dData2[i])) &&
								(0 == strcmp(m_2dData3[j], ((stats100x*)m_startStatsPtr)->m_2dData3[i]))
							)
						{
							UTIL_LOG('D',"Header is found at %d", 1+j);
							l_headerFound=true;
							break;
						}
					}
					if(true == l_headerFound)
					{
						g_statsChangedData.m_reportCategory[j] = ((stats100x*)m_startStatsPtr)->m_reportCategory[i];
						for(int k=0; k<24; k++)
						{
							if(((stats100x*)m_startStatsPtr)->m_count[k][i] > 0)
							{
								UTIL_LOG('L', "Updating the count of slot %d header %s with value %d", 
										k, m_headers[j], ((stats100x*)m_startStatsPtr)->m_count[k][i]);
								g_statsChangedData.m_count[k][j] = ((stats100x*)m_startStatsPtr)->m_count[k][i];
							}
						}
					}
				}

				UTIL_LOG('L', "Replacing the mmap file. This shall take some time...");
				memcpy(m_startStatsPtr, &g_statsChangedData, sizeof(stats100x));
				UTIL_LOG('L', "Done with replacing the mmap file");
			}
			else
			{
				UTIL_LOG('L', "Not refreshing the counts");
			}


			strcpy(m_startStatsPtr->m_productName, m_productName);
			strcpy(m_startStatsPtr->m_productVersion, m_productVersion);
			strcpy(m_startStatsPtr->m_entityName, m_entityName);
			UTIL_LOG('D',"after copying version %s", m_startStatsPtr->m_productVersion);
			if(m_headerCount > m_startStatsPtr->m_currentNumberOfColumns)
			{
				m_startStatsPtr->m_currentNumberOfColumns = m_headerCount;
				for(int i=0; i<m_startStatsPtr->m_maxNumberOfColumns; i++)
				{
					strcpy(((stats100x*)m_startStatsPtr)->m_headers[i], m_headers[i]);
					strcpy(((stats100x*)m_startStatsPtr)->m_2dData[i], m_2dData[i]);
					strcpy(((stats100x*)m_startStatsPtr)->m_2dData2[i], m_2dData2[i]);
					strcpy(((stats100x*)m_startStatsPtr)->m_2dData3[i], m_2dData3[i]);
					((stats100x*)m_startStatsPtr)->m_reportCategory[i] = m_reportCategory[i];
				}
			}
		}
		m_mappingFlag=true;
		m_day = g_timeStruct->tm_mday;
	}

	int l_slot=-1;
	l_slot =  ( g_timeStruct->tm_hour * m_slotsInADay) / 24;
	if (l_slot != m_slot)
	{
		if (-1 == m_slot)
		{
			UTIL_LOG('C',"Slot Change: application startup l_slot %d", l_slot);
		}
		else
		{
			UTIL_LOG('C',"Slot Change: general slot change l_slot %d", l_slot);
		}
		UTIL_LOG('D',"m_maxNumberOfColumns*100 %d", m_maxNumberOfColumns*100);
		UTIL_LOG('D',"m_maxNumberOfColumns*sizeof(long) %d", m_maxNumberOfColumns*sizeof(long));
		//int l_offset=(sizeof(FullStats)+ (m_maxNumberOfColumns*100) + l_slot*( m_maxNumberOfColumns*sizeof(long)));

		//UTIL_LOG('D', "offset %d", l_offset);
		//m_stats = ((char*)m_startStatsPtr)+ l_offset;
		m_slot = l_slot;
	}
	if (m_slot != -1)
	{
		return true;
	}
	else
	{
		UTIL_LOG('C',"m_stats is NULL");
	}
	return false;
}




ELogStatisticsReturnCode StatisticsGenerator::logStatistics(int p_index, int p_value, ParameterData *p_hd)
{
	int l_index = p_index;
	if(false == m_initializedFlag)
	{
		UTIL_LOG('W',"logStatistics not initialized");
		return LOG_STATISTICS_RETURN_CODE_NOT_INITIALIAZED;
	}
	if( (l_index > MAX_NUMBER_STATISTICS_COUNTS) || (l_index < 0))
	{
		UTIL_LOG('E', "logStatistics called with index:%d which is invalid. 0 to Maximum %d possible", l_index, MAX_NUMBER_STATISTICS_COUNTS);
		return LOG_STATISTICS_RETURN_CODE_INVALID_INDEX;
	}
	if(true == m_debugLogs)
	{
		UTIL_LOG('T',"Index %d, Value %d, Header [%s]", l_index, p_value, m_headers[l_index-1]);
	}

	if(m_2DMap.size() > 0)
	{
		map<int, StoredIndices*>::iterator l_iter = m_2DMap.find(p_index);
		if(l_iter == m_2DMap.end())
		{
			UTIL_LOG('D',"Index %d is not 2D type ", p_index);
		}
		else
		{
			UTIL_LOG('D',"Index %d is of 2D type ", p_index);
			if(NULL == p_hd)
			{
				UTIL_LOG('D',"Input value is found NULL");
				return LOG_STATISTICS_RETURN_CODE_VALUE_SHOULD_BE_PRESENT;
			}
			StoredIndices *l_si = l_iter->second;
			UTIL_LOG('D',"Retrieved SI data with count:%d", l_si->m_count);

			string l_unknown_string = DEFAULT_2D_DATA;
			string l_temp_string_to_be_stored;
			if(1 == l_si->m_count)
			{
				l_temp_string_to_be_stored = p_hd->m_p1;
			}
			else if(2 == l_si->m_count)
			{
				l_temp_string_to_be_stored = p_hd->m_p1 + "|" + p_hd->m_p2;
				l_unknown_string = l_unknown_string + "|" + DEFAULT_2D_DATA;
			}
			else if(3 == l_si->m_count)
			{
				l_temp_string_to_be_stored = p_hd->m_p1 + "|" + p_hd->m_p2 + "|" + p_hd->m_p3;
				l_unknown_string = l_unknown_string + "|" + DEFAULT_2D_DATA + "|" + DEFAULT_2D_DATA;
			}

			map<string,int>::iterator l_iter_inside = l_si->m_data.find(l_temp_string_to_be_stored);
			if(l_iter_inside == l_si->m_data.end())
			{
				UTIL_LOG('E',"Index %d with data[%s] is not available in map", p_index, l_temp_string_to_be_stored.c_str());
				l_iter_inside = l_si->m_data.find(l_unknown_string);
				if(l_iter_inside == l_si->m_data.end())
				{
					UTIL_LOG('E',"Still not found [%s]", l_unknown_string.c_str());
					return LOG_STATISTICS_RETURN_CODE_VALUE_SHOULD_BE_PRESENT;
				}
				else
				{
					UTIL_LOG('T',"Logging for UNKNOWN data");
					l_index = l_iter_inside->second;
				}
			}
			else
			{
				l_index = l_iter_inside->second;
				UTIL_LOG('L',"Index %d with data[%s] is available with index %d", p_index, l_temp_string_to_be_stored.c_str(), l_index);
			}
		}
	}

	/*

		 if(LOG_STATS_DEFAULT_VALUE != p_value) //value is present
		 {
	//if(!((NULL == strstr(m_headers[l_index-1], "MAX.")) || (NULL == strstr(m_headers[l_index-1], "VAL."))))
	if( (m_pegTypeArray[l_index-1] != PEG_TYPE_MAX_COUNTER) && (m_pegTypeArray[l_index-1] != PEG_TYPE_VALUE) )
	{
	UTIL_LOG('E', "ERROR!!!!!!!!!!!!!   logStatistics should not be called with a value %d for non PEG_TYPE_MAX_COUNTER  & PEG_TYPE_VALUE case", p_value);
	return LOG_STATISTICS_RETURN_CODE_VALUE_SHOULD_NOT_BE_PRESENT;
	}
	}
	else //value is not present
	{
	//if((NULL != strstr(m_headers[l_index-1], "MAX."))  || (NULL != strstr(m_headers[l_index-1], "VAL.")))
	if((m_pegTypeArray[l_index-1] == PEG_TYPE_MAX_COUNTER) || (m_pegTypeArray[l_index-1] == PEG_TYPE_VALUE))
	{
	UTIL_LOG('E', "ERROR!!!!!!!!!!!!!   logStatistics should not be called without a value %d defined for PEG_TYPE_MAX_COUNTER or PEG_TYPE_VALUE case", p_value);
	return LOG_STATISTICS_RETURN_CODE_VALUE_SHOULD_BE_PRESENT;
	}
	}
	*/


	pthread_mutex_lock(&m_mutex);


	if(true == m_debugLogs)
	{
		UTIL_LOG('T',"logStatistics called with index [%d] slot[%d]", l_index, m_slot);
	}
	if(false == g_statsTemporaryErrorFlag)
	{
		//UTIL_LOG('D', "No Temporary error found. Continuing");
		if (false != getStatsPtr())
		{
			if(-1 != m_slot)
			{
				long l_value=-1;
				//if(NULL != strstr(m_headers[l_index-1], "VAL"))
				if(m_pegTypeArray[l_index-1] == PEG_TYPE_MAX_COUNTER)
				{
					if(true == m_debugLogs)
					{
						UTIL_LOG('T',"logStatistics called for PEG_TYPE_VALUE");
					}
					l_value = ((stats100x*)m_startStatsPtr)->m_count[m_slot][l_index-1] = p_value;
				}
				//else if(NULL != strstr(m_headers[l_index-1], "MAX"))
				else if(m_pegTypeArray[l_index-1] == PEG_TYPE_VALUE)
				{
					if(true == m_debugLogs)
					{
						UTIL_LOG('T',"logStatistics called for PEG_TYPE_MAX_COUNTER Old %d", ((stats100x*)m_startStatsPtr)->m_count[m_slot][l_index-1]);
					}
					if(((stats100x*)m_startStatsPtr)->m_count[m_slot][l_index-1] < p_value)
					{
						l_value = ((stats100x*)m_startStatsPtr)->m_count[m_slot][l_index-1] = p_value;
					}
				}
				else
				{
					if(true == m_debugLogs)
					{
						UTIL_LOG('T',"logStatistics called for PEG_TYPE_INCREMENT_COUNTER");
					}
					l_value = ((stats100x*)m_startStatsPtr)->m_count[m_slot][l_index-1]++;
				}
				m_startStatsPtr->m_lut = time(NULL);
				if(true == m_debugLogs)
				{
					UTIL_LOG('L',"Current value of index %d is %d", l_index, l_value);
				}
				pthread_mutex_unlock(&m_mutex);
				return LOG_STATISTICS_RETURN_CODE_SUCCESS;
			}
			else
			{
				UTIL_LOG('E',"m_stats is null");
				pthread_mutex_unlock(&m_mutex);
				return LOG_STATISTICS_RETURN_CODE_OTHER;
			}
		}
		else
		{
			UTIL_LOG('L',"getStatsPtr failed");
			g_statsTemporaryErrorFlag = true;
			g_statsTemporaryErrorTime = time(NULL);
			pthread_mutex_unlock(&m_mutex);

			if(g_statsTemporaryErrorTrapId >= 0)
			{
				UTIL_LOG('C', "Sending a trap for statistics temporary error");
				g_si.sendSnmpTrap(g_statsTemporaryErrorTrapId, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
			}
			else
			{
				UTIL_LOG('E', "Unable to send an SNMP trap. Id[%d]", g_statsTemporaryErrorTrapId);
			}
		}
	}
	else
	{
		UTIL_LOG('D', "Still there is a temporary error in Statistics creation.");
		if(time(NULL) > g_statsTemporaryErrorTime+3600)
		{
			UTIL_LOG('L', "Time crossed more than an hour since the last Statistics Try.");
			g_statsTemporaryErrorFlag = false;
			g_statsTemporaryErrorTime = time(NULL);
			pthread_mutex_unlock(&m_mutex);

#if 0
			if(g_statsTemporaryErrorTrapId >= 0)
			{
				UTIL_LOG('C', "Sending a trap for statistics temporary error");
				g_si.sendSnmpTrap(g_statsTemporaryErrorTrapId, TRAP_TYPE_NORMAL, TRAP_SEVERITY_CRITICAL);
			}
			else
			{
				UTIL_LOG('E', "Unable to send an SNMP trap. Id[%d]", g_statsTemporaryErrorTrapId);
			}
#endif
		}
		else
		{
			pthread_mutex_unlock(&m_mutex);
		}
	}
	return LOG_STATISTICS_RETURN_CODE_OTHER;
}

bool StatisticsGenerator::markFailure(char *p_header, char *p_header2, char *p_errorDesc)
{
	UTIL_LOG('E', "Marking a failure with Header[%s:%s]. Reason[%s]", p_header, p_header2, p_errorDesc);
	m_addHeaderFailureReason = "Header - ";
	m_addHeaderFailureReason += p_header;
	m_addHeaderFailureReason += ":";
	m_addHeaderFailureReason += p_header2;
	m_addHeaderFailureReason += " Reason: ";
	m_addHeaderFailureReason += p_errorDesc;
	return true;
}

int  StatisticsGenerator::addHeader(ELogStatisticsPegType p_pegType, char *p_header, char *p_header2, char p_rep, MultiDimensionalData *p_mdd)
{
	if(true == m_initializedFlag)
	{
		UTIL_LOG('E',"addHeader should be called before initialization only");
		markFailure(p_header, p_header2, "addHeader should be called before initialization only");
		return -1;
	}

	if( (0 == strncmp(p_header, "MAX.", 4)) || (0 == strncmp(p_header, "VAL.", 4)))
	{
		UTIL_LOG('E',"addHeader Header should not start with MAX. or VAL.");
		markFailure(p_header, p_header2, "addHeader Header should not start with MAX. or VAL.");
		return -1;
	}

	if(PEG_TYPE_4D_INCREMENT_COUNTER == p_pegType)
	{
		if((0 > p_mdd->m_hd.size()))
		{
			UTIL_LOG('E',"addHeader 4DCount should be greater than 1");
			markFailure(p_header, p_header2, "addHeader 4DCount invalid");
			return -1;
		}
		if(m_headerCount+p_mdd->m_hd.size() > MAX_NUMBER_STATISTICS_COUNTS)
		{
			UTIL_LOG('E', "addHeader called with 2D index:%d which is greater than the maximum %d possible", m_headerCount+p_mdd->m_hd.size(), MAX_NUMBER_STATISTICS_COUNTS);
			markFailure(p_header, p_header2, "addHeader called with 2D which is greater than the maximum possible");
			return -1;
		}
	}

	if(m_headerCount > MAX_NUMBER_STATISTICS_COUNTS)
	{
		UTIL_LOG('E', "addHeader called with index:%d which is greater than the maximum %d possible", m_headerCount, MAX_NUMBER_STATISTICS_COUNTS);
		markFailure(p_header, p_header2, "addHeader called which is greater than the maximum possible");
		return -1;
	}

	if(strlen(p_header)+strlen(p_header2) > MAX_SIZE_OF_STATISTICS_HEADER)
	{
		UTIL_LOG('E', "addHeader called with header:[%s:%s] which is greater than the maximum header length %d possible", 
				p_header, p_header2, MAX_SIZE_OF_STATISTICS_HEADER);
		markFailure(p_header, p_header2, "addHeader called with header which is greater than the maximum header length possible");
		return -1;
	}

	m_pegTypeArray[m_headerCount]=p_pegType;

	UTIL_LOG('T', "addHeader called with pegType:%d index:%d header:%s:%s rep:%c",  p_pegType, m_headerCount, p_header, p_header2, p_rep);
	if((PEG_TYPE_INCREMENT_COUNTER == p_pegType) || (PEG_TYPE_VALUE == p_pegType) || (PEG_TYPE_MAX_COUNTER == p_pegType))
	{
		if(PEG_TYPE_INCREMENT_COUNTER == p_pegType)
		{
			snprintf(m_headers[m_headerCount], sizeof(m_headers[m_headerCount]), "%s:%s",p_header, p_header2);
		}
		else if(PEG_TYPE_VALUE == p_pegType)
		{
			snprintf(m_headers[m_headerCount], sizeof(m_headers[m_headerCount]), "VAL.%s:%s",p_header, p_header2);
		}
		else if(PEG_TYPE_MAX_COUNTER == p_pegType)
		{
			snprintf(m_headers[m_headerCount], sizeof(m_headers[m_headerCount]), "MAX.%s:%s",p_header, p_header2);
		}
		m_reportCategory[m_headerCount] = p_rep;
		++m_headerCount;
		return m_headerCount;
	}
	else if(PEG_TYPE_4D_INCREMENT_COUNTER == p_pegType)
	{
		if(p_mdd->m_header1.size() > MAX_SIZE_OF_2D_HEADER)
		{
			markFailure(p_header, p_header2, "addHeader Invalid m_header1 size");
			return -1;
		}
		if(p_mdd->m_header2.size() > MAX_SIZE_OF_2D_HEADER)
		{
			markFailure(p_header, p_header2, "addHeader Invalid m_header2 size");
			return -1;
		}
		if(p_mdd->m_header3.size() > MAX_SIZE_OF_2D_HEADER)
		{
			markFailure(p_header, p_header2, "addHeader Invalid m_header3 size");
			return -1;
		}

		int l_returnIndex = -1;
		StoredIndices *l_si = new StoredIndices;
		l_si->m_count = p_mdd->m_numOfColumns;
		UTIL_LOG('T', "addHeader called with 4DCount:%d", p_mdd->m_hd.size());
		int l_i=0;

		list<HeaderData> l_temp_list = p_mdd->m_hd;
		HeaderData l_hd_default;
		l_hd_default.m_h1 = DEFAULT_2D_DATA;
		l_hd_default.m_h2 = DEFAULT_2D_DATA;
		l_hd_default.m_h3 = DEFAULT_2D_DATA;
		l_temp_list.push_back(l_hd_default);
		for(list<HeaderData>::iterator l_list_iter=l_temp_list.begin(); l_list_iter != l_temp_list.end(); l_list_iter++)
		{
			if((*l_list_iter).m_h1.size() > MAX_SIZE_OF_STATISTICS_HEADER)
			{
				markFailure(p_header, p_header2, "addHeader Invalid m_h1 size");
				return -1;
			}
			if((*l_list_iter).m_h2.size() > MAX_SIZE_OF_STATISTICS_HEADER)
			{
				markFailure(p_header, p_header2, "addHeader Invalid m_h2 size");
				return -1;
			}
			if((*l_list_iter).m_h3.size() > MAX_SIZE_OF_STATISTICS_HEADER)
			{
				markFailure(p_header, p_header2, "addHeader Invalid m_h3 size");
				return -1;
			}
			UTIL_LOG('T', "addHeader called with 2d-Data::%d:[%s][%s][%s]", l_i, (*l_list_iter).m_h1.c_str(), (*l_list_iter).m_h2.c_str(),
					(*l_list_iter).m_h3.c_str());
			snprintf(m_headers[m_headerCount], sizeof(m_headers[m_headerCount]), "%s:%s",p_header, p_header2);
			if(p_mdd->m_numOfColumns >=1)
			{
				snprintf(m_2dData[m_headerCount], sizeof(m_2dData[m_headerCount]), "%s: %s", p_mdd->m_header1.c_str(), (*l_list_iter).m_h1.c_str());
			}
			if(p_mdd->m_numOfColumns >=2)
			{
				snprintf(m_2dData2[m_headerCount], sizeof(m_2dData2[m_headerCount]), "%s: %s", p_mdd->m_header2.c_str(), (*l_list_iter).m_h2.c_str());
			}
			if(p_mdd->m_numOfColumns >=3)
			{
				snprintf(m_2dData3[m_headerCount], sizeof(m_2dData3[m_headerCount]), "%s: %s", p_mdd->m_header3.c_str(), (*l_list_iter).m_h3.c_str());
			}
			m_reportCategory[m_headerCount] = p_rep;
			++m_headerCount;

			string l_temp_string_to_be_stored;
			if(1 == p_mdd->m_numOfColumns)
			{
				l_temp_string_to_be_stored = (*l_list_iter).m_h1;
			}
			else if(2 == p_mdd->m_numOfColumns)
			{
				l_temp_string_to_be_stored = (*l_list_iter).m_h1 + "|" + (*l_list_iter).m_h2;
			}
			else if(3 == p_mdd->m_numOfColumns)
			{
				l_temp_string_to_be_stored = (*l_list_iter).m_h1 + "|" + (*l_list_iter).m_h2 + "|" + (*l_list_iter).m_h3;
			}

			l_si->m_data[l_temp_string_to_be_stored] = m_headerCount;

			if(0 == l_i)
			{
				l_returnIndex = m_headerCount;
			}
			l_i++;
		}
		m_2DMap[l_returnIndex] = l_si;
		return l_returnIndex;
	}
	else
	{
		UTIL_LOG('E', "addHeader Invalid PEG_TYPE:%d", p_pegType);
		markFailure(p_header, p_header2, "addHeader Invalid PEG_TYPE");
		return -1;
	}
}

bool StatisticsGenerator::updateHeaderDesc(int p_headerIndex, ELogStatisticsPegType p_pegType, char *p_header, char *p_header2, char p_rep)
{
	if(false == m_initializedFlag)
	{
		UTIL_LOG('E',"updateHeaderDesc should be called after initialization only");
		return false;
	}

	if(p_headerIndex > m_headerCount-1)
	{
		UTIL_LOG('E', "updateHeaderDesc The index %d is beyond the max headers created %d", p_headerIndex-1, m_headerCount);
		return false;
	}

	if(strlen(p_header)+strlen(p_header2) > MAX_SIZE_OF_STATISTICS_HEADER)
	{
		UTIL_LOG('E', "updateHeaderDesc called with header:[%s:%s] which is greater than the maximum header length %d possible", 
				p_header, p_header2, MAX_SIZE_OF_STATISTICS_HEADER);
		return false;
	}

	pthread_mutex_lock(&m_mutex);
	UTIL_LOG('L', "updateHeaderDesc called with pegType:%d index:%d header:%s:%s rep:%c",  p_pegType, p_headerIndex-1, p_header, p_header2, p_rep);
	if((PEG_TYPE_INCREMENT_COUNTER == p_pegType) || (PEG_TYPE_VALUE == p_pegType) || (PEG_TYPE_MAX_COUNTER == p_pegType))
	{
		if(PEG_TYPE_INCREMENT_COUNTER == p_pegType)
		{
			snprintf(m_headers[p_headerIndex-1], sizeof(m_headers[p_headerIndex-1]), "%s:%s",p_header, p_header2);
		}
		else if(PEG_TYPE_VALUE == p_pegType)
		{
			snprintf(m_headers[p_headerIndex-1], sizeof(m_headers[p_headerIndex-1]), "VAL.%s:%s",p_header, p_header2);
		}
		else if(PEG_TYPE_MAX_COUNTER == p_pegType)
		{
			snprintf(m_headers[p_headerIndex-1], sizeof(m_headers[p_headerIndex-1]), "MAX.%s:%s",p_header, p_header2);
		}
		m_reportCategory[p_headerIndex-1] = p_rep;
		if(NULL != m_startStatsPtr)
		{
			UTIL_LOG('L', "updateHeaderDesc m_startStatsPtr is not null. Updating in the file too");
			strcpy(((stats100x*)m_startStatsPtr)->m_headers[p_headerIndex-1], m_headers[p_headerIndex-1]);
			strcpy(((stats100x*)m_startStatsPtr)->m_2dData[p_headerIndex-1], m_2dData[p_headerIndex-1]);
			strcpy(((stats100x*)m_startStatsPtr)->m_2dData2[p_headerIndex-1], m_2dData2[p_headerIndex-1]);
			strcpy(((stats100x*)m_startStatsPtr)->m_2dData3[p_headerIndex-1], m_2dData3[p_headerIndex-1]);
			((stats100x*)m_startStatsPtr)->m_reportCategory[p_headerIndex-1] = m_reportCategory[p_headerIndex-1];
		}
		else
		{
			UTIL_LOG('L', "updateHeaderDesc m_startStatsPtr is null. Not updating in the file");
		}
		pthread_mutex_unlock(&m_mutex);
		return true;
	}
	else
	{
		pthread_mutex_unlock(&m_mutex);
		return false;
	}
}

bool StatisticsGenerator::setApplicationName( char *p_appName)
{
	UTIL_LOG('L', "setApplicationName called with AppName:%s", p_appName);

	if(strlen(p_appName) > MAX_PRODUCT_NAME_SIZE)
	{
		UTIL_LOG('E', "setApplicationName called with name:%s which is greater than the maximum header length %d possible", 
				p_appName, MAX_PRODUCT_NAME_SIZE);
		return false;
	}

	strcpy(m_productName, p_appName);
	return true;

}
bool StatisticsGenerator::setApplicationVersion( char *p_version)
{
	UTIL_LOG('L', "setApplicationVersion called with AppVer:%s", p_version);

	if(strlen(p_version) > MAX_PRODUCT_VERSION_SIZE)
	{
		UTIL_LOG('E', "setApplicationVersion called with version:%s which is greater than the maximum header length %d possible", 
				p_version, MAX_PRODUCT_VERSION_SIZE);
		return false;
	}

	strcpy(m_productVersion, p_version);
	return true;

}

bool StatisticsGenerator::initializeOtherStatsHeaders()
{
	UTIL_LOG('L',"Number of SNMP Traps registered %d", g_si.m_trapCount);
	for(int i=0; i<g_si.m_trapCount; i++)
	{
		char l_tempChar[100+1];
		snprintf(l_tempChar, sizeof(l_tempChar), "%d:%s", g_si.m_uniqueTrapSequenceId[i], g_si.m_trapId[i]);

		g_si.m_trapStatsIndex[0][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar,         "TRIG:PASS",   'T');
		g_si.m_trapStatsIndex[1][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar,         "TRIG:FAIL",   'T');
		g_si.m_trapStatsIndex[2][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar,         "TRIG:NORMAL", 'T');

		g_si.m_trapStatsFilteredIndex[0][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar, "DELV:PASS",   'T');
		g_si.m_trapStatsFilteredIndex[1][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar, "DELV:FAIL",   'T');
		g_si.m_trapStatsFilteredIndex[2][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar, "DELV:NORMAL", 'T');
		UTIL_LOG('L', "Registered SNMP Trap [%s] for statistics indices %d", l_tempChar, 
				g_si.m_trapStatsIndex[0][i], g_si.m_trapStatsIndex[1][i], g_si.m_trapStatsIndex[2][i],
				g_si.m_trapStatsFilteredIndex[0][i], g_si.m_trapStatsFilteredIndex[1][i], g_si.m_trapStatsFilteredIndex[2][i]);

	}
	return true;
}

bool StatisticsGenerator::initialize(char *p_path, char *p_EntityName)
{
	UTIL_LOG('L',"start of StatisticsGenerator initialize func");
	m_slotsInADay = 24;

	if((strlen(p_EntityName) < 1) || (strlen(p_EntityName) > MAX_ENTITY_NAME_LENGTH))
	{
		UTIL_LOG('C',"Invalid Entity Name. Should not be greater than %d bytes", MAX_ENTITY_NAME_LENGTH);
		return false;
	}

	char *l_gutilDebugLogs = getenv("GUTIL_DEBUG_LOGS");
	if(NULL != l_gutilDebugLogs)
	{
		if(NULL != strstr(l_gutilDebugLogs, "STAT"))
		{
			m_debugLogs = true;
			UTIL_LOG('T', "GUTIL_DEBUG_LOGS is enabled for STAT. Shall print debug logs too");
		}
	}


	if(true == g_si.m_initializedFlag)
	{
		if(0 != strcmp(g_selfEntityName, p_EntityName))
		{
			UTIL_LOG('C',"Invalid Entity Name. It should be same as what is passed to the SNMP Interface ");
			return false;
		}

		/* TODO
			 g_statsTemporaryErrorTrapId = g_si.registerSnmpTrap("STATS", "Statistics error",SNMP_INTERNAL_UNIQUE_TRAP_SEQUENCE_STATS);
			 if(g_statsTemporaryErrorTrapId < 0)
			 {
			 UTIL_LOG('E',"initialize: Unable to register the trap %d. Check whether SNMP is enabled.", g_statsTemporaryErrorTrapId);
			 return false;
			 }
			 */
	}
	snprintf(g_selfEntityName, MAX_ENTITY_NAME_LENGTH, "%s", p_EntityName);

	if (strlen(p_path) < 1)
	{
		UTIL_LOG('C',"Invalid File Path");
		return false;
	}

	m_maxNumberOfColumns=MAX_NUMBER_STATISTICS_COUNTS;

	if( (strlen(g_ipAddress)> 0) || (strlen(g_selfEntityName) > 0))
	{
		snprintf(m_entityName, sizeof(m_entityName), "%s:%s", g_selfEntityName, g_ipAddress);
	}

	pthread_mutex_init(&m_mutex, NULL);

#if 0
	UTIL_LOG('L',"Number of SNMP Traps registered %d", g_si.m_trapCount);
	for(int i=0; i<g_si.m_trapCount; i++)
	{
		char l_tempChar[100+1];
		snprintf(l_tempChar, sizeof(l_tempChar), "%d:%s", g_si.m_uniqueTrapSequenceId[i], g_si.m_trapId[i]);

		g_si.m_trapStatsIndex[0][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar,         "TRIG:PASS",   'T');
		g_si.m_trapStatsIndex[1][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar,         "TRIG:FAIL",   'T');
		g_si.m_trapStatsIndex[2][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar,         "TRIG:NORMAL", 'T');

		g_si.m_trapStatsFilteredIndex[0][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar, "DELV:PASS",   'T');
		g_si.m_trapStatsFilteredIndex[1][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar, "DELV:FAIL",   'T');
		g_si.m_trapStatsFilteredIndex[2][i] = addHeader(PEG_TYPE_INCREMENT_COUNTER, l_tempChar, "DELV:NORMAL", 'T');
		UTIL_LOG('L', "Registered SNMP Trap [%s] for statistics indices %d", l_tempChar, 
				g_si.m_trapStatsIndex[0][i], g_si.m_trapStatsIndex[1][i], g_si.m_trapStatsIndex[2][i],
				g_si.m_trapStatsFilteredIndex[0][i], g_si.m_trapStatsFilteredIndex[1][i], g_si.m_trapStatsFilteredIndex[2][i]);

	}

#endif

	char l_dir[1000+1];
	memset(l_dir, '\0', sizeof(l_dir));
	snprintf(l_dir, sizeof(l_dir), "%s", p_path);
	snprintf(m_filePath, sizeof(m_filePath), "%s", l_dir);

	struct stat l_sbuf;
	if (stat(l_dir, &l_sbuf) == -1) 
	{
		UTIL_LOG('L',"stat command for dir [%s] failed with error [%s]. hence creating directory", l_dir, strerror(errno));
		int l_DirCreationMode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH  | S_IXUSR | S_IXGRP | S_IXOTH; 
		UTIL_LOG('L',"Creating Directory : %s", l_dir);
		int l_dirResult = mkdir(l_dir, l_DirCreationMode);
		if(-1 == l_dirResult) 
		{
			UTIL_LOG('E',"Error in creating statistics directory: %s", l_dir);
			if(true == g_firstTimeStats)
			{
				UTIL_LOG('E', "returning false since first time");
				return false;
			}
			else
			{
				UTIL_LOG('L', "returning true since not first time");
				return true;
			}
		}
	}
	else
	{
		UTIL_LOG('L',"stat command for dir is success");
	}
	if(false == getStatsPtr())
	{
		if(true == g_firstTimeStats)
		{
			UTIL_LOG('E', "returning false since first time");
			return false;
		}
		else
		{
			UTIL_LOG('L', "returning true since not first time");
			return true;
		}
	}
	if(NULL != m_startStatsPtr)
	{
		(((stats100x*)m_startStatsPtr)->m_startCount[m_slot])++;
	}
	m_initializedFlag=true;

#if 1
	if(NULL != g_sih)
	{
		for(int i=0; i<g_si.m_trapCount; i++)
		{
			if(g_si.m_InitialTrapStatsCounts[0][i])
				g_sih->m_sg->logStatistics(g_si.m_trapStatsIndex[0][i]);
			if(g_si.m_InitialTrapStatsCounts[1][i])
				g_sih->m_sg->logStatistics(g_si.m_trapStatsIndex[1][i]);
			if(g_si.m_InitialTrapStatsCounts[2][i])
				g_sih->m_sg->logStatistics(g_si.m_trapStatsIndex[2][i]);

			if(g_si.m_InitialTrapStatsFilteredCounts[0][i])
				g_sih->m_sg->logStatistics(g_si.m_trapStatsFilteredIndex[0][i]);
			if(g_si.m_InitialTrapStatsFilteredCounts[1][i])
				g_sih->m_sg->logStatistics(g_si.m_trapStatsFilteredIndex[1][i]);
			if(g_si.m_InitialTrapStatsFilteredCounts[2][i])
				g_sih->m_sg->logStatistics(g_si.m_trapStatsFilteredIndex[2][i]);
		}
	}
#endif
	return true;
}



bool StatisticsGenerator::getReportsList(char *p_text, unsigned int p_maxSizeOfText)
{
	if(true == m_debugLogs)
	{
		UTIL_LOG('D', "getReportsList called with size %d", p_maxSizeOfText);
	}
	if(p_maxSizeOfText < 10)
	{
		UTIL_LOG('E', "p_maxSizeOfText should be atleast 10");
		return false;
	}
	memset(p_text, '\0', sizeof(p_maxSizeOfText));
	if(false == m_initializedFlag)
	{
		UTIL_LOG('W',"getReportsList sg not initialized");
		return false;
	}

	if(m_headerCount > 0)
	{
		UTIL_LOG('L', "getReportsList HeaderCount:%d", m_headerCount);

#define MAX_REPORTS    100
		char l_repCategories[MAX_REPORTS];
		memset(l_repCategories, '\0', sizeof(l_repCategories));
		int  l_repStartCount[MAX_REPORTS];
		int  l_repEndCount[MAX_REPORTS];

		int l_repCount=0;
		for(int l_i=0; l_i<m_headerCount && l_repCount<MAX_REPORTS; l_i++)
		{
			if(true == m_debugLogs)
			{
				UTIL_LOG('T', "getReportsList m_reportCategory:%c l_repCategories:%c", m_reportCategory[l_i], l_repCategories[l_repCount]);
			}
			if(0 == l_i)
			{
				if(true == m_debugLogs)
				{
					UTIL_LOG('T',"start 0");
				}
				l_repCategories[l_repCount] = m_reportCategory[l_i];
				l_repStartCount[l_repCount] = 1+l_i;
				l_repCount++;
			}
			else 
			{
				if(m_reportCategory[l_i] != l_repCategories[l_repCount-1]) //start
				{
					if(true == m_debugLogs)
					{
						UTIL_LOG('T',"start");
					}
					l_repCategories[l_repCount] = m_reportCategory[l_i];
					l_repStartCount[l_repCount] = 1+l_i;
					l_repEndCount[l_repCount-1] = l_i;
					l_repCount++;
				}
			}
		}
		l_repEndCount[l_repCount-1]=m_headerCount;

		snprintf(p_text, p_maxSizeOfText, "\nReportsList:\n");
		char l_reportData[100+1];
		for(int l_j=0; l_j<l_repCount; l_j++)
		{
			snprintf(l_reportData, sizeof(l_reportData), 
					"\nReport %02d:  Type:%c  Start:%5d  End:%5d", 1+l_j, l_repCategories[l_j], l_repStartCount[l_j], l_repEndCount[l_j]);
			strlcat(p_text, l_reportData, p_maxSizeOfText);
		}
		strlcat(p_text, "\n", p_maxSizeOfText);
	}
	else
	{
		snprintf(p_text, p_maxSizeOfText, "No Reports.");
	}
	return true;
}



bool StatisticsGenerator::getReportData(int p_start, int p_end, char *p_text, unsigned int p_maxTextSize)
{
	if(true == m_debugLogs)
	{
		UTIL_LOG('D', "getReportData called with size %d. start:%d end:%d", p_maxTextSize, p_start, p_end);
	}
	if(p_maxTextSize < 10)
	{
		UTIL_LOG('E', "p_maxSizeOfText should be atleast 10");
		return false;
	}
	snprintf(p_text, p_maxTextSize, "Report Data: Some Error");
	if(false == m_initializedFlag)
	{
		UTIL_LOG('W',"getReportData sg not initialized");
		return false;
	}
	char l_additionalText[1000+1];

	if(
			(p_start < 1) || 
			(p_start > m_headerCount) ||
			(p_end < 1) || 
			(p_end > m_headerCount)
		)
	{
		snprintf(p_text, p_maxTextSize, "begin %d and end %d should be between 1 and %d", p_start, p_end, m_headerCount);
		getReportsList(l_additionalText, sizeof(l_additionalText)-1);
		strlcat(p_text, l_additionalText, p_maxTextSize);
		UTIL_LOG('W', "%s", p_text);
		return false;
	}

	if(p_start > p_end)
	{
		snprintf(p_text, p_maxTextSize, "begin %d should be less than or equal to end %d", p_start, p_end);
		getReportsList(l_additionalText, sizeof(l_additionalText)-1);
		strlcat(p_text, l_additionalText, p_maxTextSize);
		UTIL_LOG('W', "%s", p_text);
		return false;
	}

	if((p_end-p_start) > 50)
	{
		snprintf(p_text, p_maxTextSize, "begin %d and end %d diff should be max 50", p_start, p_end);
		getReportsList(l_additionalText, sizeof(l_additionalText)-1);
		strlcat(p_text, l_additionalText, p_maxTextSize);
		UTIL_LOG('W', "%s", p_text);
		return false;
	}

	if(NULL != m_startStatsPtr)
	{
		pthread_mutex_lock(&m_mutex);
		UTIL_LOG('L', "getReportData m_startStatsPtr is not null. Getting the data");
		char l_reportDataEach[100+1];
		snprintf(p_text, p_maxTextSize, "\n");
		for(int l_i=p_start; l_i<=p_end; l_i++)
		{
			snprintf(l_reportDataEach, sizeof(l_reportDataEach), "\n%5d  R%c  %-50s %-50s %-50s %-50s : %5d", 
					l_i,
					((stats100x*)m_startStatsPtr)->m_reportCategory[l_i-1],
					((stats100x*)m_startStatsPtr)->m_headers[l_i-1],
					((stats100x*)m_startStatsPtr)->m_2dData[l_i-1],
					((stats100x*)m_startStatsPtr)->m_2dData2[l_i-1],
					((stats100x*)m_startStatsPtr)->m_2dData3[l_i-1],
					((stats100x*)m_startStatsPtr)->m_count[m_slot][l_i-1]);
			strlcat(p_text, l_reportDataEach, p_maxTextSize);
		}
		pthread_mutex_unlock(&m_mutex);
	}
	else
	{
		if(true == m_debugLogs)
		{
			UTIL_LOG('D', "getReportData m_startStatsPtr is NULL");
		}
	}

	return true;
}


