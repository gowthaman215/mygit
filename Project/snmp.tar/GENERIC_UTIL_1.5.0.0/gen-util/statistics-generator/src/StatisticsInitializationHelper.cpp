#include <StatisticsInitializationHelper.h>
#include <StatisticsGenerator.h>
#include <LogOverride.h>
#include <SnmpInterface.h>


StatisticsInitializationHelper *g_sih=NULL;
bool StatisticsInitializationHelper::m_initializedFlag=false;
StatisticsGenerator *StatisticsInitializationHelper::m_sg=NULL;
char    StatisticsInitializationHelper::m_filePath[1000+1];
char    StatisticsInitializationHelper::m_productVersion[MAX_PRODUCT_VERSION_SIZE+1];
char    StatisticsInitializationHelper::m_productName[MAX_PRODUCT_NAME_SIZE+1];
char    StatisticsInitializationHelper::m_entityName[MAX_ENTITY_NAME+1];
pthread_mutex_t    StatisticsInitializationHelper::m_mutex;

StatisticsInitializationHelper::StatisticsInitializationHelper()
{
	g_sih = this;
	UTIL_LOG('L',"StatisticsInitializationHelper :cons:");
	m_sg = NULL;
}

StatisticsInitializationHelper::~StatisticsInitializationHelper()
{
	UTIL_LOG('L',"StatisticsInitializationHelper :des:");
}


/*
	 bool StatisticsInitializationHelper::applicationInitializationCallback(StatisticsGenerator *p_sg)
	 {
	 UTIL_LOG('E',"Applications should inherit the applicationInitializationCallback. Please check!!");
	 return false;
	 }
	 */
int  g_firstTimeStats=true;
//extern bool initializeOtherStatsHeaders();

bool StatisticsInitializationHelper::initializeStatistics(char *p_path, char *p_EntityName, char *p_appName, char *p_appVersion)
{
	UTIL_LOG('L',"initializeStatistics called");
  if(false == g_firstTimeStats)
	{
	   UTIL_LOG('E',"initializeStatistics should be called only once in application life");
		 return false;
	}

  pthread_mutex_init(&m_mutex, NULL);

	StatisticsGenerator *l_sg = new StatisticsGenerator();

	if(NULL == g_sih)
	{
		UTIL_LOG('E',"StatisticsInitializationHelper::initializeStatistics g_sih is NULL");
		return false;
	}

	l_sg->setApplicationName(p_appName);
	l_sg->setApplicationVersion(p_appVersion);

	bool l_status = g_sih->applicationInitializationCallback(l_sg);
	if(false == l_status)
	{
		UTIL_LOG('C',"applicationInitializationCallback failed");
		return false;
	}
	else
	{
		UTIL_LOG('L',"applicationInitializationCallback success");

		if(false == l_sg->initializeOtherStatsHeaders())
		{
		   UTIL_LOG('L',"applicationInitializationCallback initializeOtherStatsHeaders failed");
		   return false;
		}

		if(l_sg->m_addHeaderFailureReason.size() > 0)
		{
			UTIL_LOG('E',"Atleast one of the addHeader failed. Last addHeader failed reason [%s]", l_sg->m_addHeaderFailureReason.c_str());
			return false;
		}

		if(NULL != m_sg)
		{
			delete(m_sg);
			m_sg = NULL;
		}
		m_sg = l_sg;

		l_status = m_sg->initialize(p_path, p_EntityName);
		if(false == l_status)
		{
			UTIL_LOG('C', "StatisticsGenerator initialize failed");
			return false;
		}
		else
		{
			UTIL_LOG('L', "StatisticsGenerator initialize success");

			snprintf(m_filePath, sizeof(m_filePath), "%s", p_path);
			snprintf(m_productVersion, sizeof(m_productVersion), "%s", p_appVersion);
			snprintf(m_productName, sizeof(m_productName), "%s", p_appName);
			snprintf(m_entityName, sizeof(m_entityName), "%s", p_EntityName);
			m_initializedFlag = true;
         g_firstTimeStats=false;
			return true;
		}
	}
   g_firstTimeStats=false;
	return l_status;
}

bool StatisticsInitializationHelper::reInitializeStatistics()
{
	UTIL_LOG('L',"reInitializeStatistics called");
	StatisticsGenerator *l_sg = new StatisticsGenerator();

	if(NULL == l_sg)
	{
	   UTIL_LOG('C', "Unable to new SG ptr");
		 return false;
	}

  pthread_mutex_lock(&m_mutex);
	bool l_status = g_sih->applicationInitializationCallback(l_sg);
	if(false == l_status)
	{
	  m_initializedFlag = false;
    pthread_mutex_unlock(&m_mutex);

		UTIL_LOG('C',"applicationInitializationCallback failed. Deleting the new SG ptr");
		delete(l_sg);

		return false;
	}
	else
	{
		UTIL_LOG('L',"applicationInitializationCallback success");

		if(false == l_sg->initializeOtherStatsHeaders())
		{
		   UTIL_LOG('L',"applicationInitializationCallback initializeOtherStatsHeaders failed");
		   return false;
		}


		if(l_sg->m_addHeaderFailureReason.size() > 0)
		{
			UTIL_LOG('E',"Atleast one of the addHeader failed. Last addHeader failed reason [%s]", l_sg->m_addHeaderFailureReason.c_str());

	    m_initializedFlag = false;
      pthread_mutex_unlock(&m_mutex);

		  delete(l_sg);
			return false;
		}

		if(NULL != m_sg)
		{
			UTIL_LOG('L',"applicationInitializationCallback deleting the old SG ptr");
			delete(m_sg);
			m_sg = NULL;
		}
		UTIL_LOG('L',"applicationInitializationCallback setting AppName and Version");
		m_sg = l_sg;

		m_sg->setApplicationName(m_productName);
		m_sg->setApplicationVersion(m_productVersion);
		UTIL_LOG('L', "initialize called with path [%s], entityname[%s]", m_filePath, m_entityName);
		l_status = m_sg->initialize(m_filePath, m_entityName);
		if(false == l_status)
		{
			UTIL_LOG('C', "StatisticsGenerator initialize failed");
      pthread_mutex_unlock(&m_mutex);
			return false; 
		}
		else
		{
			UTIL_LOG('L', "StatisticsGenerator initialize success");
			m_initializedFlag = true;
      pthread_mutex_unlock(&m_mutex);
			return true;
		}
	}
	UTIL_LOG('C', "It should not have come here. status:%d", l_status);

	m_initializedFlag = false;
  pthread_mutex_unlock(&m_mutex);
	return l_status;
}


ELogStatisticsReturnCode StatisticsInitializationHelper::logStatistics(int p_index, int p_value, ParameterData *p_pd)
{
	if((NULL != m_sg) && (true == m_initializedFlag))
	{
    pthread_mutex_lock(&m_mutex);
		ELogStatisticsReturnCode l_returnCode = m_sg->logStatistics(p_index, p_value, p_pd);
    pthread_mutex_unlock(&m_mutex);
		return l_returnCode;
	}
	else
	{
	  UTIL_LOG('W',"Statistics not initialized. initializedflag:%d, m_sg:%d", m_initializedFlag, m_sg);
		return LOG_STATISTICS_RETURN_CODE_NOT_INITIALIAZED;
	}
}


bool StatisticsInitializationHelper::getReportData(int p_start, int p_end, char *p_text, unsigned int p_maxTextSize)
{
	if(NULL != m_sg)
	{
		UTIL_LOG('L',"Calling getReportData upon application's request");
		return m_sg->getReportData(p_start, p_end, p_text, p_maxTextSize);
	}
	else
	{
		UTIL_LOG('E',"StatisticsGenerator not initialized yet");
		return false;
	}
}
