#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>
#include <GUtilThreadHeartBeat.h>
#include <LogOverride.h>
#include <SnmpInterface.h>

GUtilThreadHeartBeat g_thb;


bool gutilExecuteCommand(char *p_command, char *p_buff, int p_maxSize)
{
   FILE *ptr;
#define MAX_OUTPUT_SIZE 1028
   char path[MAX_OUTPUT_SIZE];
   memset(path,'\0',sizeof(path));
   printf("\ncommand: [%s]\n", p_command);

   if((ptr = popen(p_command, "r"))!=NULL)
   {
      while (fgets(path, MAX_OUTPUT_SIZE, ptr) != NULL)
      {
         strlcat(p_buff,path,p_maxSize);
      }
      if(-1 == pclose(ptr))
      {
         UTIL_LOG('W',"Error in pclose() errno:%d", errno);
      }
      return true;
   }
   else
   {
      UTIL_LOG('W', "Failed to execute the command :%s",p_command);
      return false;
   }
   return false;
}



ThreadData::ThreadData()
{
   m_mnat=0;
   m_lastAliveCalledTime=0;
   m_lastSent=false;
   memset(m_threadName, '\0', sizeof(m_threadName));
}

ThreadData::~ThreadData()
{
}

GUtilThreadHeartBeat::GUtilThreadHeartBeat()
{
   m_initializedFlag=false;
   m_trapId=0;
   m_debugLogs=false;
   m_tha=THREAD_HANGED_ACTION_DO_NOTHING;
}

GUtilThreadHeartBeat::~GUtilThreadHeartBeat()
{
   m_tdm.clear();
}


bool GUtilThreadHeartBeat::registerMe(int p_mnat, char *p_threadName)
{
   if(false == m_initializedFlag)
   {
      UTIL_LOG('W',"GUtilThreadHeartBeat:registerMe initialize not called");
      return true;
   }

   if(strlen(p_threadName) > MAX_THREAD_NAME_SIZE)
   {
      UTIL_LOG('E',"GUtilThreadHeartBeat:registerMe Thread Name length %d should not be greater than %d", 
            strlen(p_threadName), MAX_THREAD_NAME_SIZE);
      return true;
   }

   int l_threadId = pthread_self();
   map<int, ThreadData>::iterator l_tdm_iterator;
   if(0 != pthread_rwlock_wrlock(&m_lock))
   {
      UTIL_LOG('E',"Unable to perform wrlock. errno:%d", errno);
      return false;
   }

   l_tdm_iterator = m_tdm.find(l_threadId);
   if(l_tdm_iterator ==  m_tdm.end())
   {
      UTIL_LOG('L',"Registering the ThreadId:%d", l_threadId);
      ThreadData l_td;
      l_td.m_mnat = p_mnat;
      l_td.m_lastAliveCalledTime = time(NULL);
      snprintf(l_td.m_threadName, MAX_THREAD_NAME_SIZE, p_threadName);
      m_tdm[l_threadId] = l_td;
      if(0 != pthread_rwlock_unlock(&m_lock))
      {
         UTIL_LOG('E',"Unable to perform unlock after wrlock. errno:%d", errno);
      }
      return true;
   }
   else
   {
      UTIL_LOG('E',"ThreadId:%d Already registered", l_threadId);
      if(0 != pthread_rwlock_unlock(&m_lock))
      {
         UTIL_LOG('E',"Unable to perform unlock after wrlock. errno:%d", errno);
      }
      return false;
   }
}

bool GUtilThreadHeartBeat::unRegisterMe()
{
   if(false == m_initializedFlag)
   {
      UTIL_LOG('W',"GUtilThreadHeartBeat:unRegisterMe initialize not called");
      return true;
   }

   int l_threadId = pthread_self();
   map<int, ThreadData>::iterator l_tdm_iterator;
   if(0 != pthread_rwlock_wrlock(&m_lock))
   {
      UTIL_LOG('E',"Unable to perform wrlock. errno:%d", errno);
      return false;
   }

   l_tdm_iterator = m_tdm.find(l_threadId);
   if(l_tdm_iterator !=  m_tdm.end())
   {
      UTIL_LOG('L',"UnRegistering the ThreadId:%d", l_threadId);
      m_tdm.erase(l_tdm_iterator);
      if(0 != pthread_rwlock_unlock(&m_lock))
      {
         UTIL_LOG('E',"Unable to perform unlock after wrlock. errno:%d", errno);
      }
      return true;
   }
   else
   {
      UTIL_LOG('E',"ThreadId:%d not registered at all", l_threadId);
      if(0 != pthread_rwlock_unlock(&m_lock))
      {
         UTIL_LOG('E',"Unable to perform unlock after wrlock. errno:%d", errno);
      }
      return false;
   }
}


bool GUtilThreadHeartBeat::iAmAlive()
{
   int l_threadId = pthread_self();
   if(false == m_initializedFlag)
   {
      if(true == m_debugLogs)
      {
         UTIL_LOG('D',"ThreadId:%d Not Initialized", l_threadId);
      }
      return true;
   }
   map<int, ThreadData>::iterator l_tdm_iterator;

   pthread_rwlock_rdlock(&m_lock);
   l_tdm_iterator = m_tdm.find(l_threadId);
   if(l_tdm_iterator !=  m_tdm.end())
   {
      if(true == m_debugLogs)
      {
         UTIL_LOG('L',"Marking the ThreadId:%d Alive", l_threadId);
      }
      m_tdm[l_threadId].m_lastAliveCalledTime = time(NULL);
      if(0 != pthread_rwlock_unlock(&m_lock))
      {
         UTIL_LOG('E',"Unable to perform unlock after rdlock. errno:%d", errno);
      }
      return true;
   }
   else
   {
      UTIL_LOG('E',"ThreadId:%d Not Registered", l_threadId);
      if(0 != pthread_rwlock_unlock(&m_lock))
      {
         UTIL_LOG('E',"Unable to perform unlock after rdlock. errno:%d", errno);
      }
      return false;
   }
   return true;
}

void mysleep(int p_intervalInSecs)
{
   struct timeval l_tv;
   l_tv.tv_sec = p_intervalInSecs;
   l_tv.tv_usec = 0;

   int l_ret;
   do
   {
      l_ret = select(1,NULL,NULL,NULL,&l_tv);
   }
   while((l_ret == -1)&&(errno == EINTR)); //select is interruped too

   return;
}

void *GUtilThreadOberverThreadFunc(void *p_gthb)
{
   GUtilThreadHeartBeat *l_gthb = (GUtilThreadHeartBeat*)p_gthb;
   UTIL_LOG('T',"TOT: start of GUtilThreadOberverThreadFunc function");
   while(1)
   {
      mysleep(60);
      if(true == l_gthb->m_debugLogs)
      {
         UTIL_LOG('T',"TOT: woke");
      }
      if(0 != pthread_rwlock_rdlock(&l_gthb->m_lock))
      {
         UTIL_LOG('E',"TOT: Unable to perform rdlock. errno:%d", errno);
         return NULL;
      }
      if(l_gthb->m_tdm.size()>0)
      {
         int l_currentTime = time(NULL);
         map<int,ThreadData>::iterator l_iter;
         for(l_iter=l_gthb->m_tdm.begin(); l_iter!=l_gthb->m_tdm.end(); l_iter++)
         {
            if(l_currentTime > l_iter->second.m_mnat + l_iter->second.m_lastAliveCalledTime)
            {
               UTIL_LOG('W',"TOT: Found the ThreadId:%d[%s] not alive", l_iter->first, l_iter->second.m_threadName);
               //send a trap here
               g_si.sendSnmpTrap(l_gthb->m_trapId, TRAP_TYPE_FAIL, TRAP_SEVERITY_CRITICAL, l_iter->second.m_threadName);

               //Actions to be performed

               if(THREAD_HANGED_ACTION_DO_NOTHING == l_gthb->m_tha)
               {
                  UTIL_LOG('D',"TOT: ThreadId:%d No action configured at thread hanged condition", l_iter->first);
               }

               if( (THREAD_HANGED_ACTION_CAPTURE_PSTACK == l_gthb->m_tha) ||
                     (THREAD_HANGED_ACTION_CAPTURE_PSTACK_AND_EXIT == l_gthb->m_tha)
                 )
               {
                  UTIL_LOG('C',"TOT: ThreadId:%d Application is configured to capture pstack output", l_iter->first);

                  char l_buffer[10000+1];
                  memset(l_buffer, '\0', sizeof(l_buffer));
                  char l_command[50+1];
                  snprintf(l_command, sizeof(l_command), "pstack %d/%d", getpid(), l_iter->first);
                  gutilExecuteCommand(l_command, l_buffer, 10000);
                  UTIL_LOG('C',"TOT: ThreadId:%d pstack output: [%s]", l_iter->first, l_buffer);
               }

               if(THREAD_HANGED_ACTION_GENERATE_CORE_WITHOUT_EXIT == l_gthb->m_tha)
               {
                  if(false == l_iter->second.m_lastSent)
                  {
                     UTIL_LOG('T',"TOT: ThreadId:%d Generating core now", l_iter->first);
                     char l_buffer[10000+1];
                     memset(l_buffer, '\0', sizeof(l_buffer));
                     char l_command[50+1];
                     snprintf(l_command, sizeof(l_command), "gcore %d", getpid());
                     gutilExecuteCommand(l_command, l_buffer, 10000);
                     UTIL_LOG('C',"TOT: ThreadId:%d gcore output: [%s]", l_iter->first, l_buffer);
                  }
                  else
                  {
                     UTIL_LOG('T',"TOT: ThreadId:%d Not generating core now", l_iter->first);
                  }
               }

               if(THREAD_HANGED_ACTION_GENERATE_CORE_AND_EXIT == l_gthb->m_tha)
               {
                  UTIL_LOG('C',"TOT: ThreadId:%d Application is configured to generate core and exit", l_iter->first);
                  mysleep(2); //To ensure logs are written to disk (in cases where logs are buffered)
                  abort();
               }

               if( (THREAD_HANGED_ACTION_EXIT == l_gthb->m_tha) ||
                     (THREAD_HANGED_ACTION_CAPTURE_PSTACK_AND_EXIT == l_gthb->m_tha) ||
                     (THREAD_HANGED_ACTION_GENERATE_CORE_AND_EXIT == l_gthb->m_tha)
                 )
               {
                  UTIL_LOG('C',"TOT: ThreadId:%d Application is configured to exit. Exiting...", l_iter->first);
                  mysleep(2); //To ensure logs are written to disk (in cases where logs are buffered)
                  exit(1);
               }

               l_iter->second.m_lastSent=true;
            }
            else
            {
               if(true == l_iter->second.m_lastSent)
               {
                  UTIL_LOG('W',"TOT: Found the ThreadId:%d[%s] became alive by now. Sending a pass trap", l_iter->first, l_iter->second.m_threadName);
                  l_iter->second.m_lastSent=false;
                  g_si.sendSnmpTrap(l_gthb->m_trapId, TRAP_TYPE_PASS, TRAP_SEVERITY_MINOR, l_iter->second.m_threadName);
               }
            }
         }
      }
      if(0 != pthread_rwlock_unlock(&l_gthb->m_lock))
      {
         UTIL_LOG('E',"TOT: Unable to perform unlock after rdlock. errno:%d", errno);
         return NULL;
      }
   }
   UTIL_LOG('E',"TOT: ERROR!!!!!!!!!!!!! Exiting. THIS SHOULD NOT HAPPEN");
   return NULL;
}



bool GUtilThreadHeartBeat::initialize(EThreadHangedAction p_tha)
{
   if(THREAD_HANGED_ACTION_UNKNOWN == p_tha)
   {
      UTIL_LOG('E',"GUtilThreadHeartBeat:initialize Application should not call THREAD_HANGED_ACTION_UNKNOWN");
      return false;
   }

   if(0 != pthread_rwlock_init(&m_lock, NULL))
   {
      UTIL_LOG('E',"GUtilThreadHeartBeat:initialize Unable to perform rwlock initialization errno:%d", errno);
      return false;
   }

   char *l_gutilDebugLogs = getenv("GUTIL_DEBUG_LOGS");
   if(NULL != l_gutilDebugLogs)
   {
      if(NULL != strstr(l_gutilDebugLogs, "THB"))
      {
         m_debugLogs = true;
         UTIL_LOG('T', "GUTIL_DEBUG_LOGS is enabled for THB. Shall print debug logs too");
      }
   }

   char *l_gutilThbAction = getenv("GUTIL_THB_ACTION");
   if(NULL != l_gutilThbAction)
   {
      UTIL_LOG('C', "GUTIL_THB_ACTION env variable found. Overriding the action!!!");
      if(0 == strcmp(l_gutilThbAction, "CAPTURE_PSTACK"))
      {
         UTIL_LOG('C', "GUTIL_THB_ACTION is configured with CAPTURE_PSTACK");
         m_tha = THREAD_HANGED_ACTION_CAPTURE_PSTACK;
      }
      else if(0 == strcmp(l_gutilThbAction, "EXIT"))
      {
         UTIL_LOG('C', "GUTIL_THB_ACTION is configured with EXIT");
         m_tha = THREAD_HANGED_ACTION_EXIT;
      }
      else if(0 == strcmp(l_gutilThbAction, "CAPTURE_PSTACK_AND_EXIT"))
      {
         UTIL_LOG('C', "GUTIL_THB_ACTION is configured with CAPTURE_PSTACK_AND_EXIT");
         m_tha = THREAD_HANGED_ACTION_CAPTURE_PSTACK_AND_EXIT;
      }
      else if(0 == strcmp(l_gutilThbAction, "GENERATE_CORE_AND_EXIT"))
      {
         UTIL_LOG('C', "GUTIL_THB_ACTION is configured with GENERATE_CORE_AND_EXIT");
         m_tha = THREAD_HANGED_ACTION_GENERATE_CORE_AND_EXIT;
      }
      else if(0 == strcmp(l_gutilThbAction, "GENERATE_CORE_WITHOUT_EXIT"))
      {
         UTIL_LOG('C', "GUTIL_THB_ACTION is configured with GENERATE_CORE_WITHOUT_EXIT");
         m_tha = THREAD_HANGED_ACTION_GENERATE_CORE_WITHOUT_EXIT;
      }
      else if(0 == strcmp(l_gutilThbAction, "DO_NOTHING"))
      {
         UTIL_LOG('C', "GUTIL_THB_ACTION is configured with DO_NOTHING");
         m_tha = THREAD_HANGED_ACTION_DO_NOTHING;
      }
      else 
      {
         UTIL_LOG('C', "Unrecognized Operation: [%s]. GUTIL_THB_ACTION is being assumed as DO_NOTHING");
         m_tha = THREAD_HANGED_ACTION_DO_NOTHING;
      }
   }
   else
   {
      UTIL_LOG('C', "GUTIL_THB_ACTION is not found");
      m_tha = THREAD_HANGED_ACTION_DO_NOTHING;
   }

   pthread_t l_thread = pthread_create(&l_thread, NULL, GUtilThreadOberverThreadFunc, this);
   m_trapId  = g_si.registerSnmpTrap("THB", "Thread Heart-Beat",SNMP_INTERNAL_UNIQUE_TRAP_SEQUENCE_THB);
   if(m_trapId < 1)
   {
      UTIL_LOG('E',"GUtilThreadHeartBeat:initialize Unable to register the trap %d. Check whether SNMP is enabled.", m_trapId);
      return false;
   }
   m_initializedFlag=true;
   return true;
}


