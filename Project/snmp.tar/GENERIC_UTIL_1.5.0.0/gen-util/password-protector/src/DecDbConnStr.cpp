/************************************************************************************
 * FILE NAME      : DecDbConnStr.cpp
 * REMARKS        :
 *************************************************************************************/

//#include <des.h>
#include <errno.h>
#include <string.h>

#include <DecDbConnStr.h>
#include <LogOverride.h>

using namespace std;

bool DecDbConnStr::readFromFile(char *p_dbName, char *p_dbData, int &p_dbDataLen)
{
   long filesize, position;
   FILE *file_ptr;
   bool l_match=false;

   // Open the file in read binary mode
   if ((file_ptr = fopen("/etc/password-db.dat", "rb")) == NULL)
   {
      UTIL_LOG('C',"Error opening file: /etc/password-db.dat");
      return false;
   }

   // check the filesize
   if ((fseek(file_ptr, 0, SEEK_END)) != 0) {
      UTIL_LOG('E', "Error in seek operation on file /etc/password-db.dat: errno :%d ", errno);
      return false;
   }
   UTIL_LOG('D', "Getting %s database connection string from /etc/password-db.dat", p_dbName);

   // set filesize variable    
   filesize = ftell(file_ptr);

   // go back
   rewind(file_ptr); 

   // initial position
   position = ftell(file_ptr); 

   char l_DbTag[MAX_DB_NAME+2];
   snprintf(l_DbTag, sizeof(l_DbTag), "%s:", p_dbName);

   char l_DbData[MAX_RECORD_LEN];
   //printf("File position [%ld] file size [%ld] \n", position, filesize);

   while (position < filesize)
   {
      memset(l_DbData, 0, sizeof(l_DbData));
      if(MAX_RECORD_LEN != fread(l_DbData, 1, MAX_RECORD_LEN, file_ptr))
      {
         UTIL_LOG('E',"Error in fread could not read MAX_RECORD_LEN bytes : errno :%d ",errno);
         return false;
      }

      if(0 == memcmp(l_DbData, l_DbTag, strlen(l_DbTag)))
      {
         UTIL_LOG('D',"Found the DB string %s", p_dbName);
         l_DbData[strlen(l_DbTag) + 2] = 0;
         int l_Len = atoi(l_DbData+strlen(l_DbTag));
         memcpy(p_dbData, l_DbData+strlen(l_DbTag)+3, l_Len);
         p_dbDataLen = l_Len;
         break;
      }
      position += MAX_RECORD_LEN;
   }
   fclose(file_ptr);
   return true;
}

DecDbConnStr g_DecDbConnStr;
bool DecDbConnStr::getActualDbString(char *p_dbstring, char *p_DbConnStr, LogOverride *p_tranlog)
{
   if(NULL == p_tranlog)
   {
      printf("Unable to find the TranslatorLogOverride logger \n");
      return false;
   }
   memcpy(m_Key1, "lycamobl", sizeof(m_Key1));
   memcpy(m_Key2, "lycatech", sizeof(m_Key2));
   memcpy(m_Key3, "plintron", sizeof(m_Key3));

   g_lo = p_tranlog;

   char l_CipheredData[MAX_RECORD_LEN];
   memset(l_CipheredData, '\0', sizeof(l_CipheredData));
   int l_CipheredDataLen = 0;
   readFromFile(p_dbstring, l_CipheredData, l_CipheredDataLen);

   if(1 < l_CipheredDataLen)
   {
      memset(p_DbConnStr, 0, l_CipheredDataLen+1);
      Cipher(l_CipheredData, l_CipheredDataLen, p_DbConnStr, DES_DECRYPT);
      //UTIL_LOG('D',"DB Connection string %s" , p_DbConnStr); //Commented so that not to show
      return true;
   }
   else 
   {
      UTIL_LOG('E',"Failed to get DBConnection string named %s", p_dbstring) ;
      return false;
   }
   return true;
}
